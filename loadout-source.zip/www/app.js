'use strict';
const STORAGE_KEY = 'loadout-jee-2027-v1';
const SUBJECTS = ['Physics','Chemistry','Mathematics'];
const CHAPTER_ROWS = [
['Physics','Units and Dimensions',4],['Physics','Motion In One Dimension',5],['Physics','Motion In Two Dimensions',5],['Physics','Laws of Motion',5],['Physics','Work Power Energy',5],['Physics','COM, Momentum & Collision',4],['Physics','Rotational Motion',5],['Physics','Gravitation',5],['Physics','Mech. Prop. of Solids',4],['Physics','Mech. Prop. of Fluids',5],['Physics','Thermal Prop. of Matter',5],['Physics','Thermodynamics',5],['Physics','Kinetic Theory of Gases',5],['Physics','Oscillations',5],['Physics','Waves and Sound',5],['Physics','Electrostatics',6],['Physics','Capacitance',4],['Physics','Current Electricity',7],['Physics','Magnetic Prop. of Matter',5],['Physics','Magnetic Effects of Current',6],['Physics','EM Induction',6],['Physics','Alternating Current',6],['Physics','EM Waves',4],['Physics','Ray Optics',7],['Physics','Wave Optics',6],['Physics','Dual Nature of Matter',4],['Physics','Atomic Physics',4],['Physics','Nuclear Physics',5],['Physics','Semiconductors',6],['Physics','Communication System',4,'extra'],['Physics','Mathematics in Physics',4,'support'],
['Chemistry','Basic Concepts of Chemistry',4],['Chemistry','Structure of Atom',5],['Chemistry','Periodicity in Properties',5],['Chemistry','Chemical Bonding',5],['Chemistry','States of Matter',5,'extra'],['Chemistry','Thermodynamics (C)',6],['Chemistry','Chemical Equilibrium',4],['Chemistry','Ionic Equilibrium',5],['Chemistry','Redox Reactions',4],['Chemistry','Hydrogen',4,'extra'],['Chemistry','s Block Elements',3,'extra'],['Chemistry','p Block (Grp 13 & 14)',5],['Chemistry','General Organic Chemistry',6],['Chemistry','Hydrocarbons',7],['Chemistry','Environmental Chemistry',4,'extra'],['Chemistry','Solid State',5,'extra'],['Chemistry','Solutions',5],['Chemistry','Electrochemistry',5],['Chemistry','Chemical Kinetics',6],['Chemistry','Surface Chemistry',4,'extra'],['Chemistry','Isolation of Metals',5,'extra'],['Chemistry','p Block (Grp 15–18)',7],['Chemistry','d and f Block Elements',5],['Chemistry','Coordination Compounds',5],['Chemistry','Haloalkanes & Haloarenes',4],['Chemistry','Alcohols Phenols Ethers',6],['Chemistry','Aldehydes & Ketones',5],['Chemistry','Carboxylic Acid Derivatives',4],['Chemistry','Amines',5],['Chemistry','Biomolecules',5],['Chemistry','Polymers',3,'extra'],['Chemistry','Chemistry in Everyday Life',4,'extra'],['Chemistry','Practical Chemistry',3],
['Mathematics','Basic of Mathematics',4],['Mathematics','Quadratic Equation',5],['Mathematics','Complex Number',5],['Mathematics','Permutation Combination',7],['Mathematics','Sequences and Series',6],['Mathematics','Binomial Theorem',5],['Mathematics','Trig. Ratios & Identities',5],['Mathematics','Trigonometric Equations',4],['Mathematics','Straight Lines',6],['Mathematics','Circle',5],['Mathematics','Parabola',5],['Mathematics','Ellipse',4],['Mathematics','Hyperbola',4],['Mathematics','Limits',4],['Mathematics','Functions',6],['Mathematics','Continuity & Differentiability',5],['Mathematics','Differentiation',4],['Mathematics','Application of Derivatives',6],['Mathematics','Indefinite Integration',5],['Mathematics','Definite Integration',5],['Mathematics','Area Under Curves',4],['Mathematics','Differential Equations',6],['Mathematics','Vector Algebra',5],['Mathematics','Three Dimensional Geometry',6],['Mathematics','Probability',6],['Mathematics','Matrices',5],['Mathematics','Determinants',5],['Mathematics','Inverse Trig. Functions',5],['Mathematics','Sets and Relations',4],['Mathematics','Mathematical Reasoning',4,'extra'],['Mathematics','Heights and Distances',3,'extra'],['Mathematics','Statistics',4]
];
const makeId = s => String(s).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const CHAPTERS = CHAPTER_ROWS.map((r,i)=>({id:makeId(r[0]+'-'+r[1]),subject:r[0],name:r[1],tests:r[2],status:r[3]||'core',index:i}));
const CHAP_BY_ID = Object.fromEntries(CHAPTERS.map(c=>[c.id,c]));
const PHYSICS_HISTORY = window.LOADOUT_PHYSICS_HISTORY || {chapters:[],source_years:[2025,2024,2023,2022,2021,2020,2019],summary:{chapter_count:0,subtopic_count:0}};
const CHEMISTRY_HISTORY = window.LOADOUT_CHEMISTRY_HISTORY || {chapters:[],source_years:[2025,2024,2023,2022,2021,2020,2019],summary:{chapter_count:0,subtopic_count:0}};
const MATHEMATICS_HISTORY = window.LOADOUT_MATHEMATICS_HISTORY || window.LOADOUT_MATH_HISTORY || {chapters:[],source_years:[2025,2024,2023,2022,2021,2020,2019],summary:{chapter_count:0,subtopic_count:0}};
const HISTORICAL_DATASETS = {Physics:PHYSICS_HISTORY,Chemistry:CHEMISTRY_HISTORY,Mathematics:MATHEMATICS_HISTORY};
const ALIASES = {
'physics-motion-in-one-dimension':'physics-motion-in-one-dimension','motion in 1d':'physics-motion-in-one-dimension','motion 1d':'physics-motion-in-one-dimension','motion in one dimension':'physics-motion-in-one-dimension',
'motion 2d':'physics-motion-in-two-dimensions','motion in 2d':'physics-motion-in-two-dimensions','motion in two dimensions':'physics-motion-in-two-dimensions',
'com momentum collision':'physics-com-momentum-and-collision','com momentum and collision':'physics-com-momentum-and-collision','center of mass momentum collision':'physics-com-momentum-and-collision',
'mechanical properties of solids':'physics-mech-prop-of-solids','mech properties solids':'physics-mech-prop-of-solids','mechanical properties of fluids':'physics-mech-prop-of-fluids',
'kinetic theory':'physics-kinetic-theory-of-gases','thermodynamics chemistry':'chemistry-thermodynamics-c','thermodynamics (c)':'chemistry-thermodynamics-c','some basic concepts':'chemistry-basic-concepts-of-chemistry','basic concepts of chemistry':'chemistry-basic-concepts-of-chemistry',
'chem equilibrium':'chemistry-chemical-equilibrium','ionic equilibrium':'chemistry-ionic-equilibrium','pnc':'mathematics-permutation-combination','p&c':'mathematics-permutation-combination','permutation and combination':'mathematics-permutation-combination',
'sequences and series':'mathematics-sequences-and-series','sequence and series':'mathematics-sequences-and-series','trigonometric functions':'mathematics-trig-ratios-and-identities','trig ratios and identities':'mathematics-trig-ratios-and-identities','trigonometric equations':'mathematics-trigonometric-equations',
'continuity and differentiability':'mathematics-continuity-and-differentiability','continuity diff':'mathematics-continuity-and-differentiability','inverse trigonometry':'mathematics-inverse-trig-functions','inverse trig':'mathematics-inverse-trig-functions','3d geometry':'mathematics-three-dimensional-geometry','three dimensional geometry':'mathematics-three-dimensional-geometry',
'iupac nomenclature':'chemistry-general-organic-chemistry','isomerism':'chemistry-general-organic-chemistry','goc':'chemistry-general-organic-chemistry','general organic chemistry':'chemistry-general-organic-chemistry',
'carboxylic acid derivatives':'chemistry-carboxylic-acid-derivatives','aldehydes and ketones':'chemistry-aldehydes-and-ketones','alcohols phenols ethers':'chemistry-alcohols-phenols-ethers','d and f block':'chemistry-d-and-f-block-elements','d & f block':'chemistry-d-and-f-block-elements',
'p block':'chemistry-p-block-grp-15-18','p-block':'chemistry-p-block-grp-15-18','p block grp 13 and 14':'chemistry-p-block-grp-13-and-14','p block grp 15 18':'chemistry-p-block-grp-15-18','states of matter':'chemistry-states-of-matter','mathematics in physics':'physics-mathematics-in-physics','basic math':'mathematics-basic-of-mathematics','basic of maths':'mathematics-basic-of-mathematics',
'quadratic eq':'mathematics-quadratic-equation','sequences series':'mathematics-sequences-and-series','straight line':'mathematics-straight-lines','differential equation':'mathematics-differential-equations','sets relations':'mathematics-sets-and-relations','ray optics':'physics-ray-optics','waves and sound':'physics-waves-and-sound','magnetic properties of matter':'physics-magnetic-prop-of-matter','magnetic prop of matter':'physics-magnetic-prop-of-matter','em induction':'physics-em-induction','alternating current':'physics-alternating-current','work power energy':'physics-work-power-energy'
};
function norm(s){return window.LoadoutModules?.chapterMap?.normalize(s)??String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/\*/g,'').replace(/[–—]/g,'-').replace(/&/g,' and ').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ')}
function resolveChapter(value, subject){const service=window.LoadoutModules?.chapterMap?.resolveChapter;return service?service(value,CHAPTERS,ALIASES,CHAP_BY_ID,subject):null}
const QPT = [
{id:'QPT-1',date:'2026-10-11',kind:'chapter',name:'QPT 1',subjects:{Physics:['Units and Dimensions','Mathematics in Physics','Motion In One Dimension','Motion In Two Dimensions'],Chemistry:['Basic Concepts of Chemistry','Structure of Atom'],Mathematics:['Basic of Mathematics','Quadratic Equation','Sequences and Series']}},
{id:'QPT-2',date:'2026-10-14',kind:'chapter',name:'QPT 2',subjects:{Physics:['Laws of Motion','Work Power Energy'],Chemistry:['Solutions','Electrochemistry','Chemical Kinetics'],Mathematics:['Trig. Ratios & Identities','Trigonometric Equations']}},
{id:'QPT-3',date:'2026-10-18',kind:'chapter',name:'QPT 3',subjects:{Physics:['COM, Momentum & Collision','Rotational Motion'],Chemistry:['Chemical Equilibrium','Ionic Equilibrium'],Mathematics:['Permutation Combination','Binomial Theorem']}},
{id:'QPT-4',date:'2026-10-21',kind:'checkpoint',name:'QPT 4',after:[1,2,3],label:'PYQ checkpoint · all chapters through QPT 3'},
{id:'QPT-5',date:'2026-10-25',kind:'chapter',name:'QPT 5',subjects:{Physics:['Atomic Physics','Dual Nature of Matter','Nuclear Physics'],Chemistry:['Redox Reactions','Thermodynamics (C)'],Mathematics:['Straight Lines','Circle']}},
{id:'QPT-6',date:'2026-10-28',kind:'chapter',name:'QPT 6',subjects:{Physics:['Kinetic Theory of Gases','Thermal Prop. of Matter','Thermodynamics'],Chemistry:['Periodicity in Properties','Chemical Bonding'],Mathematics:['Parabola','Ellipse','Hyperbola']}},
{id:'QPT-7',date:'2026-11-01',kind:'chapter',name:'QPT 7',subjects:{Physics:['Mech. Prop. of Fluids','Mech. Prop. of Solids','Oscillations'],Chemistry:['General Organic Chemistry'],Mathematics:['Matrices','Determinants']},topics:{Chemistry:['IUPAC Nomenclature','GOC','Isomerism']}},
{id:'QPT-8',date:'2026-11-04',kind:'checkpoint',name:'QPT 8',after:[5,6,7],label:'PYQ checkpoint · chapters from QPT 5–7'},
{id:'QPT-9',date:'2026-11-08',kind:'chapter',name:'QPT 9',subjects:{Physics:['Electrostatics','Gravitation'],Chemistry:['Hydrocarbons','Haloalkanes & Haloarenes'],Mathematics:['Sets and Relations','Functions','Inverse Trig. Functions']}},
{id:'QPT-10',date:'2026-11-11',kind:'chapter',name:'QPT 10',subjects:{Physics:['Capacitance','Current Electricity'],Chemistry:['Alcohols Phenols Ethers','Aldehydes & Ketones'],Mathematics:['Limits','Continuity & Differentiability','Application of Derivatives']}},
{id:'QPT-11',date:'2026-11-15',kind:'checkpoint',name:'QPT 11',after:[9,10],label:'PYQ checkpoint · chapters from QPT 9–10'},
{id:'QPT-12',date:'2026-11-18',kind:'chapter',name:'QPT 12',subjects:{Physics:['Magnetic Effects of Current','Magnetic Prop. of Matter'],Chemistry:['Carboxylic Acid Derivatives','Amines'],Mathematics:['Indefinite Integration','Definite Integration']}},
{id:'QPT-13',date:'2026-11-22',kind:'chapter',name:'QPT 13',subjects:{Physics:['EM Induction','Alternating Current'],Chemistry:['Biomolecules','Coordination Compounds'],Mathematics:['Area Under Curves','Differential Equations']}},
{id:'QPT-14',date:'2026-11-23',kind:'checkpoint',name:'QPT 14',after:[12,13],label:'PYQ checkpoint · chapters from QPT 12–13'},
{id:'QPT-15',date:'2026-11-25',kind:'chapter',name:'QPT 15',subjects:{Physics:['Wave Optics','Ray Optics'],Chemistry:['d and f Block Elements','p Block (Grp 13 & 14)','p Block (Grp 15–18)','Practical Chemistry'],Mathematics:['Three Dimensional Geometry','Vector Algebra']}},
{id:'QPT-16',date:'2026-11-27',kind:'chapter',name:'QPT 16',subjects:{Physics:['Waves and Sound','EM Waves','Semiconductors'],Chemistry:['General Organic Chemistry','Hydrocarbons'],Mathematics:['Complex Number','Probability','Statistics']}}
];
const QFT = Array.from({length:30},(_,i)=>({id:`QFT-${i+1}`,name:`QFT ${i+1}`,date:i<15?['2026-11-29','2026-12-06','2026-12-13','2026-12-17','2026-12-20','2026-12-24','2026-12-27','2026-12-31','2027-01-03','2027-01-06','2027-01-08','2027-01-10','2027-01-12','2027-01-14','2027-01-15'][i]:'2027-02-15',phase:i<15?'Before January attempt':'From 15 Feb 2027 onward',note:i<15?'Full syllabus · upload date':'Full syllabus · date not specified beyond 15 Feb'}));
function scheduledNames(q){if(q.subjects)return SUBJECTS.flatMap(s=>(q.subjects[s]||[]).map(n=>({subject:s,name:n,chapter:resolveChapter(n,s)})));if(q.after){let all=[];q.after.forEach(num=>{const prev=QPT.find(x=>x.id===`QPT-${num}`);if(prev&&prev.subjects)all=all.concat(scheduledNames(prev));});return all;}return []}
QPT.forEach(q=>{q.chapterRefs=scheduledNames(q).map(x=>x.chapter).filter(Boolean);if(q.topics)q.topicRefs=q.topics.Chemistry||[];q.chapterIds=[...new Set(q.chapterRefs.map(c=>c.id))];q.subjectsCount=q.subjects?Object.values(q.subjects).reduce((s,a)=>s+a.length,0):null;});
const CORE_CHAPTERS = CHAPTERS.filter(c=>c.status==='core');
const EXTRA_CHAPTERS = CHAPTERS.filter(c=>c.status==='extra');
const SUBJECT_META = {Physics:{color:'#74b9ff',short:'PHY'},Chemistry:{color:'#72e0bd',short:'CHEM'},Mathematics:{color:'#c0a8ff',short:'MATH'}};
const TAGS = ['conceptual','recall','application','comparison','calculation','careless','time','unclassified'];
const TAG_LABELS = {conceptual:'Conceptual model',recall:'Recall',application:'Application / mechanism',comparison:'Comparison / ordering',calculation:'Calculation',careless:'Careless reading',time:'Time / selection',unclassified:'Unclassified'};
const RECOVERABILITY = {conceptual:.48,recall:.65,application:.55,comparison:.55,calculation:.68,careless:.72,time:.55,unclassified:.35};
const HOURS = {conceptual:3,recall:1,application:2,comparison:1.5,calculation:1,careless:.75,time:1,unclassified:2};
const OBSERVATION_WEIGHT={QCT:1,QPT:.5,QFT:.35,HFT:.5,OTHER:.35};
const DEFAULTS={version:1,settings:{alpha:.35,priorStrength:2,blockQuestions:75,blockMinutes:180,defaultQCTQuestions:15,defaultQCTMinutes:30,correctMarks:4,wrongMarks:-1},attempts:[],forecasts:[],ui:{view:'dashboard'}};
let installPromptEvent=null;let hasValidLegacyStateAtBoot=false;let mainStateMirrorPromise=Promise.resolve(true);const mainStateRecoveryGate=window.LoadoutRecoveryGate.create();let state=loadState();let currentView='dashboard';let chapterSearch='',chapterSubject='All',chapterFilter='All';let testFilter='All';let forecastType='QPT',forecastId='QPT-4';let importText='';let dirty=false;let historySubject='Physics',historyChapterNumber=2,historyYear='2025',historyTopicName='',historySearch='',historySort='recent';
function loadState(){try{const raw=localStorage.getItem(STORAGE_KEY);if(raw){const d=JSON.parse(raw);if(d&&typeof d==='object'&&Array.isArray(d.attempts)&&d.settings&&typeof d.settings==='object'){hasValidLegacyStateAtBoot=true;return {...structuredClone(DEFAULTS),...d,settings:{...DEFAULTS.settings,...d.settings},attempts:d.attempts,forecasts:Array.isArray(d.forecasts)?d.forecasts:[]};}}}catch(e){console.warn('Could not load local data',e);}return structuredClone(DEFAULTS)}
function stableJson(value){if(value===null||typeof value!=='object')return JSON.stringify(value);if(Array.isArray(value))return '['+value.map(stableJson).join(',')+']';return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+stableJson(value[key])).join(',')+'}';}
function persist(){if(mainStateRecoveryGate.status().blocked){toast('Saving is paused to protect an unverified recovery copy. Export the original record and explicitly resume from the recovery notice.');return false;}try{const raw=JSON.stringify(state);localStorage.setItem(STORAGE_KEY,raw);if(window.Loadout?.storage){const snapshot=JSON.parse(raw);mainStateMirrorPromise=window.Loadout.storage.mirror('legacy','main-state',snapshot).then(async result=>{if(!result.verified)throw new Error('Private state mirror did not read back identically.');const stored=await window.Loadout.storage.readMirror('legacy','main-state');if(!stored||stableJson(stored)!==stableJson(snapshot))throw new Error('Private state mirror content differs after flush.');return true;}).catch(error=>{window.Loadout?.diagnostics?.record?.('warn','legacy-state-mirror-failed',{message:error.message});return false;});}if(window.LoadoutDatabase)window.LoadoutDatabase.enqueueSync(JSON.parse(raw)).catch(error=>window.Loadout?.diagnostics?.record?.('warn','structured-db-sync-failed',{message:error.message}));dirty=false;return true;}catch(e){toast('Could not save local data. Export a backup and free storage space.');console.error('Persistence error',e);return false}}
async function flushPersistedState(){if(!window.Loadout?.storage)return true;await mainStateMirrorPromise;await window.Loadout.storage.flush();const mirrored=await window.Loadout.storage.readMirror('legacy','main-state');if(!mirrored||stableJson(mirrored)!==stableJson(state))throw new Error('Study records are saved locally but the app-private recovery mirror could not be verified. Export a backup before leaving this session.');await window.LoadoutDatabase?.flush?.().catch(error=>window.Loadout?.diagnostics?.record?.('warn','structured-db-flush-failed',{message:error.message}));return true;}
window.LoadoutStatePersistence=Object.freeze({flush:flushPersistedState,localStorageKey:STORAGE_KEY,async status(){return {localStateValid:Array.isArray(state.attempts),nativeMirrorPending:!!(await mainStateMirrorPromise)===false};}});
function renderRecoveryBlockedNotice(){
 const main=document.querySelector('main.main');
 if(!main||document.getElementById('loadout-recovery-blocked'))return;
 const panel=document.createElement('section');panel.id='loadout-recovery-blocked';panel.className='notice amber';panel.setAttribute('role','alert');panel.style.cssText='margin:0 0 16px;padding:14px;border:1px solid var(--amber,#f5bd69);border-radius:14px;background:rgba(245,189,105,.08)';
 const heading=document.createElement('strong');heading.textContent='Recovery is paused to protect your original study data';
 const message=document.createElement('p');message.textContent='Loadout could not verify an app-private copy of the previous local study record. New writes are temporarily blocked so the original record is not overwritten. Export the original bytes first. After checking that export, you can explicitly resume using the currently loaded or recovered state.';
 const actions=document.createElement('div');actions.style.cssText='display:flex;gap:8px;flex-wrap:wrap;margin-top:10px';
 const exportButton=document.createElement('button');exportButton.type='button';exportButton.className='btn small';exportButton.textContent='Export original record';exportButton.addEventListener('click',()=>{const original=mainStateRecoveryGate.originalText();if(original==null){toast('The original record could not be read, so it is not available to export.');return;}downloadBlob(original,'loadout-original-recovery-record.json','application/json');});
 const resumeButton=document.createElement('button');resumeButton.type='button';resumeButton.className='btn danger small';resumeButton.textContent='Resume with current state';resumeButton.addEventListener('click',()=>{const before=mainStateRecoveryGate.status();const original=mainStateRecoveryGate.originalText();const warning=before.hasOriginal?'Have you exported and checked the original recovery record? Resuming allows Loadout to write the current state over the previous local record. Continue?':'The original study record could not be read or exported. Resuming may cause existing study data to be unavailable. Have you independently recovered it or decided to proceed?';if(!confirm(warning))return;mainStateRecoveryGate.resume(true);panel.remove();if(!persist()){mainStateRecoveryGate.block(original,'The first resumed write did not complete.');renderRecoveryBlockedNotice();}});
 actions.append(exportButton,resumeButton);panel.append(heading,message,actions);main.insertBefore(panel,main.firstChild);
}
async function hydrateLegacyPrivateState(){
 const nativeAvailable=!!window.Loadout?.storage;let observedLocalRaw=null;
 try{
  if(!nativeAvailable){
   if(!hasValidLegacyStateAtBoot){try{const raw=localStorage.getItem(STORAGE_KEY);observedLocalRaw=raw;if(raw!==null)mainStateRecoveryGate.block(raw,'No native private recovery store is available to preserve an invalid local record.');}catch(readError){mainStateRecoveryGate.block(null,'The local record could not be read safely: '+readError.message);}}
   return;
  }
  await window.LoadoutReady?.catch(()=>{});
  const store=await window.Loadout.storage.create({namespace:'legacy',name:'main-state',lifetime:'persistent'});
  if(hasValidLegacyStateAtBoot){
   try{observedLocalRaw=localStorage.getItem(STORAGE_KEY);}catch(_){}
   // localStorage is the legacy app's synchronous write authority. Preserve a differing
   // private mirror before reconciling it, because it may contain data from a failed write.
   const mirrorBefore=await store.get();
   if(mirrorBefore&&stableJson(mirrorBefore)!==stableJson(state)){
    const mirrorRecoveryBytes=JSON.stringify(mirrorBefore);
    const archive=await window.Loadout.storage.create({namespace:'legacy-recovery',name:`pre-reconcile-main-state-${Date.now()}`,lifetime:'persistent'});
    await archive.set(mirrorBefore);
    const archived=await archive.get();
    if(!archived||stableJson(archived)!==stableJson(mirrorBefore)){mainStateRecoveryGate.block(mirrorRecoveryBytes,'Divergent private mirror could not be verified in its recovery archive.');throw new Error('Divergent private mirror could not be verified in its recovery archive; reconciliation stopped to protect both copies.');}
    await window.Loadout.diagnostics.record('warn','legacy-state-mirror-divergence',{localAttempts:state.attempts.length,mirrorAttempts:Array.isArray(mirrorBefore.attempts)?mirrorBefore.attempts.length:null,mirrorArchived:true,archiveReadbackVerified:true});
   }
   const mirrored=await window.Loadout.storage.mirror('legacy','main-state',state);
   await window.Loadout.storage.flush();
   if(!mirrored.verified)throw new Error('Private recovery mirror failed exact read-back verification.');
   return;
  }
  let localRaw=null;try{localRaw=localStorage.getItem(STORAGE_KEY);observedLocalRaw=localRaw;}catch(readError){mainStateRecoveryGate.block(null,'The local study record could not be read safely: '+readError.message);await window.Loadout.diagnostics.record('error','legacy-local-state-read-failed',{message:readError.message,localWriteBlocked:true});}
  if(localRaw!==null){
   // Preserve exact corrupt bytes in app-private storage before attempting recovery.
   try{
    const recovery=await window.Loadout.storage.create({namespace:'legacy-recovery',name:'corrupt-main-state',lifetime:'persistent'});
    const alreadyArchived=await recovery.get();
    if(alreadyArchived==null)await recovery.set(localRaw);
    const archivedRaw=await recovery.get();
    if(archivedRaw!==localRaw)throw new Error('Corrupt local study record was not preserved byte-for-byte in app-private storage.');
   }catch(copyError){
    mainStateRecoveryGate.block(localRaw,copyError.message);
    await window.Loadout.diagnostics.record('error','legacy-state-quarantine-copy-failed',{message:copyError.message,localWriteBlocked:true});
   }
  }
  const saved=await store.get();
  if(saved&&Array.isArray(saved.attempts)&&saved.settings&&typeof saved.settings==='object'){
   state={...structuredClone(DEFAULTS),...saved,settings:{...DEFAULTS.settings,...saved.settings},attempts:saved.attempts,forecasts:Array.isArray(saved.forecasts)?saved.forecasts:[]};
   if(!mainStateRecoveryGate.status().blocked)localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
   hasValidLegacyStateAtBoot=true;
   await window.Loadout.diagnostics.record('recovery','legacy-state-restored-from-private-mirror',{attempts:state.attempts.length,forecasts:state.forecasts.length,corruptLocalCopyPreserved:localRaw!==null&&!mainStateRecoveryGate.status().blocked,localWriteBlocked:mainStateRecoveryGate.status().blocked});
   renderCurrent();
  }else if(localRaw!==null){
   mainStateRecoveryGate.block(localRaw,'No valid app-private recovery mirror was available.');
   await window.Loadout.diagnostics.record('error','legacy-state-recovery-unavailable',{localWriteBlocked:true,reason:'No valid private mirror was found; the original local record must not be overwritten.'});
  }
 }catch(error){
  window.Loadout?.diagnostics?.record?.('warn','legacy-state-hydration-failed',{message:error.message});
  if(!mainStateRecoveryGate.status().blocked)mainStateRecoveryGate.block(observedLocalRaw??JSON.stringify(state),error.message);
 }
 finally{document.documentElement.classList.remove('loadout-recovery-pending');if(mainStateRecoveryGate.status().blocked)renderRecoveryBlockedNotice();}
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function fmt(n,d=1){return Number.isFinite(Number(n))?Number(n).toLocaleString('en-IN',{minimumFractionDigits:d,maximumFractionDigits:d}):'—'}
function dateFmt(s){if(!s)return 'Date not set';const d=new Date(s+'T12:00:00');return Number.isNaN(+d)?s:d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'2-digit'})}
function scheduleDateLabel(s){return s&&s.phase==='From 15 Feb 2027 onward'?'From 15 Feb 2027':dateFmt(s?.date)}
function dateTimeISO(){const d=new Date(),offset=d.getTimezoneOffset();return new Date(d.getTime()-offset*60000).toISOString().slice(0,10)}
function scoreOf(c,w){return Number(c||0)*state.settings.correctMarks+Number(w||0)*state.settings.wrongMarks}
function scorePercent(score,n){return n>0?100*score/(state.settings.correctMarks*n):null}
function pctClass(v){return v>=80?'green':v>=65?'purple':v>=45?'amber':'red'}
function chapClass(c){return c.status==='extra'?'amber':c.status==='support'?'purple':''}
function chapterAttempts(ch){return window.LoadoutModules.chapterMap.chapterAttempts(ch,state.attempts,OBSERVATION_WEIGHT)}
function globalBaseline(){return window.LoadoutModules.chapterIntelligence.calculateBaseline(CORE_CHAPTERS,state.attempts,OBSERVATION_WEIGHT,state.settings)}
function chapterStats(ch){return window.LoadoutModules.chapterIntelligence.calculateStats({chapter:ch,attempts:chapterAttempts(ch),baseline:globalBaseline(),settings:state.settings,tags:TAGS,recoverability:RECOVERABILITY,hours:HOURS})}
function allAttempts(){return state.attempts.filter(a=>a.score!==null&&a.score!==undefined).sort((a,b)=>(a.date||'').localeCompare(b.date||''))}
function forecastsFor(type){return state.forecasts.filter(f=>f.type===type)}
function linkedForecast(testId,type){return [...state.forecasts].reverse().find(f=>f.testId.toUpperCase()===String(testId||'').toUpperCase()&&f.type===type)}
function regressionFor(type){return window.LoadoutModules.forecastEngine.regressionFor(type,allAttempts())}
function getSchedule(type,id){return (type==='QPT'?QPT:QFT).find(x=>x.id===id)||null}
function predict(type,id){const schedule=getSchedule(type,id);return window.LoadoutModules.forecastEngine.predict({type,id,schedule,chapters:{all:CORE_CHAPTERS,byId:CHAP_BY_ID,globalBaseline:globalBaseline()},settings:state.settings,chapterStats,regression:regressionFor(type)})}
function nextSchedule(){const completed=new Set(allAttempts().map(a=>String(a.testId||'').toUpperCase()));const doneQpt=QPT.map(q=>Number(q.id.split('-')[1])).filter(n=>completed.has(`QPT-${n}`));if(doneQpt.length){for(let n=Math.max(...doneQpt)+1;n<=16;n++){const q=QPT.find(x=>x.id===`QPT-${n}`);if(q&&!completed.has(q.id))return q;}}const today=dateTimeISO();const remaining=[...QPT,...QFT].filter(s=>!completed.has(s.id.toUpperCase()));const upcoming=remaining.filter(s=>s.date>=today).sort((a,b)=>a.date.localeCompare(b.date));if(upcoming.length)return upcoming[0];return remaining.sort((a,b)=>b.date.localeCompare(a.date))[0]||null}
function aggregateErrorStats(){const map={};state.attempts.forEach(t=>{(t.chapterResults||[]).forEach(r=>{const errors=r.errorCounts||{};TAGS.forEach(tag=>map[tag]=(map[tag]||0)+(Number(errors[tag])||0));(r.questionErrors||[]).forEach(e=>{const tg=TAGS.includes(e.category)?e.category:'unclassified';map[tg]=(map[tg]||0)+1;});});(t.questionErrors||[]).forEach(e=>{const tag=TAGS.includes(e.category)?e.category:'unclassified';map[tag]=(map[tag]||0)+1;});});return map}
function predictionMetrics(type=null){const rows=allAttempts().filter(a=>a.prediction&&Number.isFinite(a.score)&&(!type||a.prediction.type===type));const rawRows=rows.filter(a=>Number.isFinite(a.prediction.raw));const rawErrors=rawRows.map(a=>a.score-a.prediction.raw);const stat=errs=>errs.length?{mae:errs.reduce((s,e)=>s+Math.abs(e),0)/errs.length,bias:errs.reduce((s,e)=>s+e,0)/errs.length,rmse:Math.sqrt(errs.reduce((s,e)=>s+e*e,0)/errs.length),maxAbs:Math.max(...errs.map(Math.abs))}:{mae:null,bias:null,rmse:null,maxAbs:null};const raw=stat(rawErrors);const calibratedRows=rows.filter(a=>Number.isFinite(a.prediction.calibrated));const calibratedErrors=calibratedRows.map(a=>a.score-a.prediction.calibrated);const calibrated=stat(calibratedErrors);const bounds=rawRows.filter(a=>Number.isFinite(a.prediction.lower)&&Number.isFinite(a.prediction.upper));const coverage=bounds.length?100*bounds.filter(a=>a.score>=a.prediction.lower&&a.score<=a.prediction.upper).length/bounds.length:null;return {n:rawRows.length,...raw,coverage,calibratedN:calibratedRows.length,calibratedMae:calibrated.mae,calibratedBias:calibrated.bias,calibratedRmse:calibrated.rmse,calibratedMaxAbs:calibrated.maxAbs};}
function subjectStats(subject){const arr=CORE_CHAPTERS.filter(c=>c.subject===subject).map(chapterStats);const tested=arr.filter(s=>s.observations);const avg=tested.length?tested.reduce((s,x)=>s+x.mastery,0)/tested.length:null;return {count:arr.length,tested:tested.length,avg,chapters:arr}}
function ratingLabel(score){if(score==null)return 'UNRATED';if(score<40)return 'RECRUIT';if(score<55)return 'BRONZE';if(score<70)return 'SILVER';if(score<80)return 'GOLD';if(score<90)return 'PLATINUM';return 'DIAMOND'}
function statsForDashboard(){return window.LoadoutModules.dashboardAnalytics.calculateSummary({attempts:state.attempts,chapterRows:CHAPTERS,chapterStats,baseline:globalBaseline(),today:dateTimeISO()})}
function toast(msg){const el=document.getElementById('toast');el.textContent=msg;el.style.opacity='1';el.style.transform='translate(-50%,0)';clearTimeout(toast._t);toast._t=setTimeout(()=>{el.style.opacity='0';el.style.transform='translate(-50%,20px)'},2900)}
const viewInfo={dashboard:['PERFORMANCE INTELLIGENCE / 01','Command center','Every test is data. Every weakness has a price.'],chapters:['MASTERY MAP / 02','Chapter map','Find your strongest maps, expensive mistakes, and highest-return drills.'],historical:['PYQ INTELLIGENCE / 03','Historical PYQ intelligence','Explore verified Physics, Chemistry, and Mathematics E–M–T–O trends from 2019–2025, alongside source mentorship notes.'],tests:['EXECUTION LOG / 04','Test history','One clean ledger for chapter tests, part tests, checkpoints, and mocks.'],forecasts:['PREDICTION ENGINE / 05','Forecast lab','Forecast first. Test later. Measure every prediction error.'],chatbot:['AI COACH / 06','AI Coach','JEE-aware study coach. Paste your API key and ask about weak chapters, strategy, or any concept.'],data:['SYSTEM CONTROL / 06','Data & settings','Structured import, transparent assumptions, export, and recovery.']};
function switchView(view){if(!viewInfo[view])return;currentView=view;state.ui.view=view;document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id===`view-${view}`));document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===view));document.getElementById('pageEyebrow').textContent=viewInfo[view][0];document.getElementById('pageTitle').textContent=viewInfo[view][1];document.getElementById('pageSubtitle').textContent=viewInfo[view][2];persist();renderCurrent();window.scrollTo({top:0,behavior:'smooth'});}
function navWiring(){document.getElementById('quickLog').addEventListener('click',openTestModal);}
document.addEventListener('click',e=>{const button=e.target.closest('button[data-view]');if(!button)return;const view=button.dataset.view;if(!viewInfo[view])return;e.preventDefault();switchView(view);});
function renderCurrent(){const handled=window.LoadoutFeatureRuntime?.render(currentView,{legacy:window.LoadoutLegacyViews});if(!handled){if(currentView==='dashboard')renderDashboard();else if(currentView==='chapters')renderChapters();else if(currentView==='historical')renderHistorical();else if(currentView==='tests')renderTests();else if(currentView==='forecasts')renderForecasts();else if(currentView==='chatbot')renderChatbot();else renderData();}if(currentView==='data')window.LoadoutDatabase?.attachSettingsPanel?.();}
function scorePill(score,max){return `<span class="tag ${score>=.8*max?'green':score>=.55*max?'purple':'amber'}">${fmt(score,1)} / ${fmt(max,0)}</span>`}
function renderDashboard(){const root=document.getElementById('view-dashboard'),d=statsForDashboard(),qpt=nextSchedule(),chapStats=CORE_CHAPTERS.map(chapterStats),priority=chapStats.filter(s=>s.observations).sort((a,b)=>b.priority-a.priority).slice(0,5),subjectCards=SUBJECTS.map(s=>({s,...subjectStats(s)}));const latest=d.last;const forecast=qpt?predict(qpt.id.startsWith('QPT')?'QPT':'QFT',qpt.id):null;const cntExtra=EXTRA_CHAPTERS.length;
root.innerHTML=`<div class="card hero"><div class="hero-content"><div class="hero-chip"><span>✦</span>YOUR TRAINING ENVIRONMENT · ${esc(ratingLabel(d.comp.length?d.avg:null))} · ${d.xp} XP</div><h2>${d.comp.length?'The next mark is hiding in your data.':'Build your baseline. Then break it.'}</h2><p>${d.comp.length?`You have logged ${d.comp.length} completed test${d.comp.length===1?'':'s'}. Keep every attempt tied to its raw outcomes so Loadout can learn what transfers to mixed tests.`:'No results have been entered yet. Start with the next test analysis: import structured feedback from ChatGPT or log a test manually. No fake demo scores, no made-up history.'}</p><div class="hero-actions"><button class="btn primary" data-action="log">＋ Log a test</button><button class="btn" data-action="import">⇄ Import ChatGPT data</button><button class="btn" data-action="forecast">⌁ Open forecast lab</button></div></div></div>
<div class="grid stats">
<div class="card stat-card" style="--glow:var(--purple)"><span class="stat-icon">▦</span><div class="stat-label">Chapters with evidence</div><div class="stat-value">${d.tested}<span class="muted" style="font-size:15px;font-weight:600"> / ${CHAPTERS.length}</span></div><div class="stat-foot">${CHAPTERS.length-d.tested} not tested yet</div><div class="progress" style="margin-top:12px"><span style="width:${100*d.tested/CHAPTERS.length}%"></span></div></div>
<div class="card stat-card" style="--glow:var(--mint)"><span class="stat-icon">↗</span><div class="stat-label">Chapter-test baseline</div><div class="stat-value">${d.comp.length?fmt(d.avg,1):'—'}<span class="muted" style="font-size:14px"> / 100</span></div><div class="stat-foot">Mean of recorded chapter-level scaled results</div></div>
<div class="card stat-card" style="--glow:var(--amber)"><span class="stat-icon">◎</span><div class="stat-label">Latest completed test</div><div class="stat-value">${latest?fmt(latest.score,0):'—'}<span class="muted" style="font-size:14px"> / ${latest?fmt(latest.maxMarks,0):'—'}</span></div><div class="stat-foot">${latest?`${esc(latest.title)} · ${dateFmt(latest.date)}`:'Your first result will appear here'}</div></div>
<div class="card stat-card" style="--glow:var(--blue)"><span class="stat-icon">⌁</span><div class="stat-label">Forecast mean absolute error</div><div class="stat-value">${d.mae==null?'—':fmt(d.mae,1)}<span class="muted" style="font-size:14px"> marks</span></div><div class="stat-foot">${d.preds.length?`${d.preds.length} scored test${d.preds.length===1?'':'s'} with saved forecast`:'Save forecasts before tests to measure accuracy'}</div></div>
</div>
<div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Subject telemetry</h2><p class="sub">Regularized chapter estimates · evidence coverage matters</p></div><span class="tag purple">3 SUBJECTS</span></div><div class="bar-list">${subjectCards.map(x=>`<div><div class="bar-row"><div class="bar-name"><span class="subject-color" style="background:${SUBJECT_META[x.s].color}"></span>${x.s}</div><div class="progress"><span style="width:${Math.max(0,Math.min(100,x.avg||0))}%;background:${SUBJECT_META[x.s].color}"></span></div><div class="bar-value">${x.avg==null?'—':fmt(x.avg,1)}</div></div><div class="tiny" style="margin:5px 0 0 2px">${x.tested}/${x.count} chapters have data${x.avg==null?' · not rated':` · ${ratingLabel(x.avg)}`}</div></div>`).join('')}</div><div class="divider"></div><div class="notice">The chapter baseline is not a JEE percentile. It's your net-mark percentage across recorded chapter-level tests, regularized for limited evidence.</div></div>
<div class="card pad"><div class="card-header"><div><h2>Next on the schedule</h2><p class="sub">Based on the uploaded October Batch schedule</p></div><span class="tag ${qpt&&qpt.kind==='checkpoint'?'amber':'purple'}">${qpt?esc(qpt.id):'COMPLETE'}</span></div>${qpt?`<div class="eyebrow" style="color:var(--muted)">${scheduleDateLabel(qpt)} · ${qpt.kind==='checkpoint'?'PYQ CHECKPOINT':qpt.phase?esc(qpt.phase.toUpperCase()):'PART TEST'}</div><h3 style="font-size:24px;margin:7px 0 4px">${esc(qpt.name)}</h3><p class="sub" style="margin-bottom:16px">${qpt.label?esc(qpt.label):qpt.subjects?`${qpt.chapterIds.length} unique mapped chapters · three subjects`:esc(qpt.note||'Full syllabus')}</p>${forecast?`<div class="forecast-score" style="font-size:43px">${fmt(forecast.calibrated,1)}<em> / ${state.settings.blockQuestions*state.settings.correctMarks}</em></div><div class="tiny" style="margin-top:6px">Current estimate · ${forecast.confidence.toLowerCase()} confidence</div>`:`<div class="notice">No upcoming schedule item could be resolved.</div>`}<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><button class="btn primary" data-action="forecast-schedule" data-id="${qpt.id}">Build forecast ↗</button><button class="btn" data-action="log-schedule" data-id="${qpt.id}">Log result</button></div>`:`<div class="empty"><strong>All scheduled tests have entries</strong>Keep adding future QFT tests as they become available.</div>`}</div></div>
<div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Highest-return training targets</h2><p class="sub">Heuristic priority = recoverable marks estimate per intervention hour</p></div><button class="btn small" data-action="chapters">Full chapter map ↗</button></div>${priority.length?`<div class="chapter-list">${priority.map(s=>chapterRowHtml(s)).join('')}</div>`:`<div class="empty"><strong>Nothing to rank yet</strong>Import a chapter result or log a chapterwise test to unlock weakness prioritization.</div>`}</div>
<div class="card pad"><div class="card-header"><div><h2>Recent executions</h2><p class="sub">Last five completed results</p></div><button class="btn small" data-action="tests">View history ↗</button></div>${d.comp.length?`<div class="chapter-list">${d.comp.slice(-5).reverse().map(a=>`<div class="chapter-row"><div><div class="chapter-name">${esc(a.title||a.testId)}</div><div class="chapter-meta"><span class="tag">${esc(a.type)}</span><span class="tiny">${dateFmt(a.date)}</span>${a.prediction?`<span class="tag ${a.score-a.prediction.raw>=0?'green':'red'}">Δ ${a.score-a.prediction.raw>=0?'+':''}${fmt(a.score-a.prediction.raw,1)}</span>`:''}</div></div><div class="chapter-score"><strong>${fmt(a.score,0)}</strong><small>/ ${fmt(a.maxMarks,0)}</small></div></div>`).join('')}</div>`:`<div class="empty"><strong>No test history</strong>Your real results will populate this feed.</div>`}</div></div>
<div class="card pad" style="margin-bottom:15px"><div class="card-header"><div><h2>Ranked progression</h2><p class="sub">Cosmetic training XP rewards unique completed test records and explicit diagnostics. It never changes predicted or actual marks.</p></div><span class="tag purple">${esc(d.rank.name.toUpperCase())}</span></div><div class="grid stats metric-three" style="margin-bottom:10px"><div class="stat-card"><div class="stat-label">Training XP</div><div class="stat-value">${d.xp}</div><div class="stat-foot">${d.comp.length} completed unique tests</div></div><div class="stat-card"><div class="stat-label">Current study streak</div><div class="stat-value">${d.streak}<span class="muted" style="font-size:13px"> day${d.streak===1?'':'s'}</span></div><div class="stat-foot">Based on dates with completed tests</div></div><div class="stat-card"><div class="stat-label">Next tier</div><div class="stat-value" style="font-size:24px">${d.nextRank?esc(d.nextRank.name):'MAX'}</div><div class="stat-foot">${d.nextRank?`${Math.max(0,d.nextRank.min-d.xp)} XP to promotion`:'Diamond achieved'}</div></div></div><div class="progress"><span style="width:${d.nextRank?Math.max(0,Math.min(100,100*(d.xp-d.rank.min)/(d.nextRank.min-d.rank.min))):100}%;background:linear-gradient(90deg,var(--purple),var(--mint))"></span></div><div class="tiny" style="margin-top:7px">XP formula: +25 per completed test, +2 per recorded classified error (capped at +20/test), +2 per chapter result (capped at +10/test). This rewards thorough logging, not high marks or guessing.</div></div>
<div class="notice amber"><b>Source note:</b> the PDF lists 96 QCT rows, including chapters marked with an asterisk as beyond JEE Main and a separate “Mathematics in Physics” support row. Loadout keeps every source row and marks those categories instead of deleting them. The resulting core filter is derived from that file and may not match a separately grouped 25/29/29 chapter taxonomy.</div>`;
}
function chapterRowHtml(s){const c=s.chapter;const score=s.mastery;return `<div class="chapter-row"><div><div class="chapter-name">${esc(c.name)}</div><div class="chapter-meta"><span class="tag" style="color:${SUBJECT_META[c.subject].color}">${esc(c.subject)}</span><span class="tag ${pctClass(score)}">${s.count} QCT${s.count===1?'':'s'}${s.transferCount?` + ${s.transferCount} block obs.`:''}</span>${s.trend!=null?`<span class="tag ${s.trend>=0?'green':'red'}">${s.trend>=0?'↑':'↓'} ${fmt(Math.abs(s.trend),1)} pp</span>`:''}</div></div><div class="chapter-score"><strong class="${score>=70?'good':score<50?'warn':''}">${score==null?'—':fmt(score,1)}</strong><small>${s.priority?fmt(s.priority,1)+' priority':'no errors tagged'}</small></div></div>`}
function renderChapters(){const root=document.getElementById('view-chapters');const filtered=CHAPTERS.filter(c=>(chapterSubject==='All'||c.subject===chapterSubject)&&(chapterFilter==='All'||(chapterFilter==='Core'&&c.status==='core')||(chapterFilter==='Extra'&&c.status==='extra')||(chapterFilter==='Support'&&c.status==='support'))&&norm(c.name).includes(norm(chapterSearch)));const order=['Physics','Chemistry','Mathematics'];root.innerHTML=`<div class="card pad"><div class="card-header"><div><h2>83+ chapter performance map</h2><p class="sub">Browse every chapter listed in the QCT schedule; star-marked extras and support topics remain visible.</p></div><span class="tag purple">${CHAPTERS.length} SOURCE ROWS</span></div><div class="filters"><input id="chapterSearch" class="input" placeholder="Search a chapter or topic…" value="${esc(chapterSearch)}"><select id="chapterSubject"><option>All</option>${SUBJECTS.map(s=>`<option ${chapterSubject===s?'selected':''}>${s}</option>`).join('')}</select><select id="chapterFilter"><option value="All" ${chapterFilter==='All'?'selected':''}>All rows</option><option value="Core" ${chapterFilter==='Core'?'selected':''}>Core filter</option><option value="Extra" ${chapterFilter==='Extra'?'selected':''}>Beyond JEE Main *</option><option value="Support" ${chapterFilter==='Support'?'selected':''}>Support topics</option></select><button class="btn" id="clearChapterFilters">Reset</button></div></div><div class="section-head"><div><h2>${filtered.length} chapters</h2><p>Click any chapter to inspect attempts, estimated mastery, error tags and QCT count.</p></div></div>${filtered.length?order.filter(s=>filtered.some(c=>c.subject===s)).map(sub=>`<div class="subject-heading"><span class="subject-color" style="background:${SUBJECT_META[sub].color}"></span>${sub}<span class="count-badge">${filtered.filter(c=>c.subject===sub).length}</span></div><div class="mastery-grid">${filtered.filter(c=>c.subject===sub).map(c=>{const s=chapterStats(c);const mastery=s.mastery;return `<button class="mastery-cell" data-action="chapter-detail" data-id="${c.id}" style="text-align:left;color:var(--text);cursor:pointer"><div class="mc-name" title="${esc(c.name)}">${esc(c.name)} ${c.status==='extra'?'*':''}${c.status==='support'?'·':''}</div><strong class="${mastery==null?'muted':mastery>=70?'good':mastery<50?'warn':''}">${mastery==null?'—':fmt(mastery,1)}</strong><span class="tiny">${s.count} / ${c.tests} planned QCTs${s.transferCount?` · ${s.transferCount} block obs.`:''}</span><div class="progress" style="margin-top:8px"><span style="width:${Math.max(0,Math.min(100,mastery||0))}%;${c.status==='extra'?'background:var(--amber)':''}"></span></div></button>`}).join('')}</div>`).join(''):`<div class="empty"><strong>No matching chapter</strong>Try a different search or reset the filters.</div>`}<div class="notice" style="margin-top:18px">Mastery index = recency-weighted scaled test result, shrunk toward the overall chapter-test baseline using the configured prior strength. An empty cell means no chapter-level evidence exists; it is not a zero score.</div>`;
const si=document.getElementById('chapterSearch');si.addEventListener('input',e=>{chapterSearch=e.target.value;const pos=e.target.selectionStart;renderChapters();const x=document.getElementById('chapterSearch');x.focus();x.setSelectionRange(pos,pos)});document.getElementById('chapterSubject').addEventListener('change',e=>{chapterSubject=e.target.value;renderChapters()});document.getElementById('chapterFilter').addEventListener('change',e=>{chapterFilter=e.target.value;renderChapters()});document.getElementById('clearChapterFilters').addEventListener('click',()=>{chapterSearch='';chapterSubject='All';chapterFilter='All';renderChapters()});}
function renderTests(){const root=document.getElementById('view-tests');const list=state.attempts.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''));const filtered=list.filter(a=>testFilter==='All'||a.type===testFilter);const completed=filtered.filter(a=>a.score!==null&&a.score!==undefined);root.innerHTML=`<div class="card pad"><div class="card-header"><div><h2>Test execution ledger</h2><p class="sub">Predictions are linked to actual results by test ID. Forecasts remain frozen after a test is completed.</p></div><button class="btn primary" data-action="log">＋ Log test</button></div><div class="filters"><select id="testFilter"><option>All</option><option ${testFilter==='QCT'?'selected':''}>QCT</option><option ${testFilter==='QPT'?'selected':''}>QPT</option><option ${testFilter==='QFT'?'selected':''}>QFT</option><option ${testFilter==='HFT'?'selected':''}>HFT</option><option ${testFilter==='OTHER'?'selected':''}>OTHER</option></select><span class="pill">${completed.length} completed · ${list.length-completed.length} forecasts awaiting result</span></div></div><div class="section-head"><div><h2>Recorded attempts</h2><p>Score is recalculated from correct and wrong counts; a source-provided score never overrides the arithmetic.</p></div></div>${filtered.length?`<div class="table-wrap"><table><thead><tr><th>Test / date</th><th>Type</th><th>Outcome C/W/U</th><th>Score</th><th>Predicted</th><th>Residual</th><th>Actions</th></tr></thead><tbody>${filtered.map(a=>`<tr><td><strong>${esc(a.title||a.testId)}</strong><div class="tiny">${dateFmt(a.date)} · ${esc(a.testId||'No ID')}</div></td><td><span class="tag">${esc(a.type)}</span></td><td>${a.score==null?'—':`${a.correct}/${a.wrong}/${a.unattempted}`}<div class="tiny">${a.n} questions · ${a.minutes??'—'} min</div></td><td>${a.score==null?'<span class="muted">Awaiting result</span>':`<strong>${fmt(a.score,0)}</strong><div class="tiny">${fmt(a.maxMarks,0)} max</div>`}</td><td>${a.prediction?`${fmt(a.prediction.raw,1)}<div class="tiny">raw estimate</div>`:'—'}</td><td>${a.prediction&&a.score!=null?`<span class="${a.score-a.prediction.raw>=0?'good':'bad'}">${a.score-a.prediction.raw>=0?'+':''}${fmt(a.score-a.prediction.raw,1)}</span>`:'—'}</td><td><div class="table-actions"><button class="btn small" data-action="test-detail" data-id="${esc(a.id)}">View</button><button class="btn small danger" data-action="delete-test" data-id="${esc(a.id)}">×</button></div></td></tr>`).join('')}</tbody></table></div>`:`<div class="card"><div class="empty"><strong>No test attempts in this filter</strong>Log a test or import structured feedback from ChatGPT.</div></div>`}<div class="notice" style="margin-top:15px">To calibrate a forecast, save it before taking the test, then log the actual result with the same test ID (e.g. <b>QPT-4</b>). The app learns from previous residuals but does not claim tiny error tolerances from sparse data.</div>`;
document.getElementById('testFilter').addEventListener('change',e=>{testFilter=e.target.value;renderTests()});}
function renderForecasts(){const root=document.getElementById('view-forecasts');const list=forecastType==='QPT'?QPT:QFT;const pick=getSchedule(forecastType,forecastId)||list[0];if(pick)forecastId=pick.id;const p=pick?predict(forecastType,pick.id):null;const saved=pick?state.forecasts.find(f=>f.testId===pick.id&&f.type===forecastType):null;const completed=pick?allAttempts().find(a=>a.testId.toUpperCase()===pick.id.toUpperCase()&&a.type===forecastType):null;const today=dateTimeISO();const arr=allAttempts().filter(a=>a.prediction&&a.prediction.type===forecastType);const cal=regressionFor(forecastType);const metrics=predictionMetrics(forecastType);
root.innerHTML=`<div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Forecast lab</h2><p class="sub">Select a scheduled test and save the prediction before seeing the result.</p></div><span class="tag purple">DETERMINISTIC MATH</span></div><div class="form-grid two"><div class="field"><label for="forecastType">Test family</label><select id="forecastType"><option value="QPT" ${forecastType==='QPT'?'selected':''}>QPT · Part test</option><option value="QFT" ${forecastType==='QFT'?'selected':''}>QFT · Full syllabus</option></select></div><div class="field"><label for="forecastId">Scheduled test</label><select id="forecastId">${list.map(s=>`<option value="${s.id}" ${s.id===forecastId?'selected':''}>${s.id} · ${scheduleDateLabel(s)}</option>`).join('')}</select></div></div>${p?`<div style="display:flex;gap:7px;flex-wrap:wrap;margin:16px 0 18px"><span class="pill">${scheduleDateLabel(p.sched)}</span><span class="pill">${esc(p.confidence)} confidence</span><span class="pill">${p.covered}/${p.chapters.length} chapters with history</span></div><div class="forecast-score">${fmt(p.calibrated,1)}<em> / ${p.questionCount*state.settings.correctMarks}</em></div><div class="tiny" style="margin-top:8px">Calibrated central estimate · raw model ${fmt(p.raw,1)} · interval ${fmt(p.lower,1)}–${fmt(p.upper,1)}</div><div class="forecast-scale"><div class="scale-item"><small>RAW ESTIMATE</small><strong>${fmt(p.raw,1)}</strong></div><div class="scale-item"><small>HISTORICAL MAE</small><strong>${metrics.mae==null?'—':fmt(metrics.mae,1)}</strong></div><div class="scale-item"><small>FORECASTS GRADED</small><strong>${cal.n}</strong></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:17px"><button class="btn primary" data-action="save-forecast" data-id="${p.id}" ${completed?'disabled':''}>${saved?'↻ Update forecast snapshot':'✓ Save forecast snapshot'}</button><button class="btn" data-action="log-schedule" data-id="${p.id}" ${completed?'disabled':''}>Log actual result</button></div>${saved?`<div class="notice green" style="margin-top:13px">Forecast saved on ${dateFmt(saved.savedOn)}${completed?' and matched to a completed attempt.':' . When logging the result, use this exact schedule ID.'}</div>`:''}${completed?`<div class="notice" style="margin-top:13px">This scheduled test is already logged with score ${fmt(completed.score,0)}. Its original saved prediction is retained for honest calibration.</div>`:''}`:`<div class="empty">No prediction available for this schedule item.</div>`}</div>
<div class="card pad"><div class="card-header"><div><h2>How this forecast is made</h2><p class="sub">Transparent assumptions; no AI inside the calculator.</p></div><span class="tag">MODEL v1</span></div><div class="chapter-list"><div class="chapter-row"><div><div class="chapter-name">1 · Chapter estimates</div><div class="chapter-meta">EMA of scaled net marks, shrunk toward the cohort's chapter baseline. QCT weight 1.0; QPT 0.5; QFT 0.35; HFT 0.5.</div></div><div class="chapter-score"><strong>α ${fmt(state.settings.alpha,2)}</strong><small>recency weight</small></div></div><div class="chapter-row"><div><div class="chapter-name">2 · Marks per question</div><div class="chapter-meta">Scaled net marks are converted to expected marks per question under +4/−1.</div></div><div class="chapter-score"><strong>4M/100</strong><small>linear conversion</small></div></div><div class="chapter-row"><div><div class="chapter-name">3 · Paper aggregation</div><div class="chapter-meta">QPT uses equal chapter weights by default because chapter-level question allocation isn't in the schedule. QFT uses core chapter average.</div></div><div class="chapter-score"><strong>${state.settings.blockQuestions}</strong><small>questions assumed</small></div></div><div class="chapter-row"><div><div class="chapter-name">4 · Calibration</div><div class="chapter-meta">${esc(cal.method)}. Current coefficients: a = ${fmt(cal.a,2)}, b = ${fmt(cal.b,3)}; calibrated estimate = a + b × raw estimate. The correction is applied after at least two paired forecasts; linear calibration is attempted from eight.</div></div><div class="chapter-score"><strong>${cal.n}</strong><small>graded forecasts</small></div></div></div><div class="notice amber" style="margin-top:15px">The interval is provisional until you have comparable, pre-saved forecasts. Schedule PDF has the chapter combinations and dates, but not actual chapter question counts inside each QPT. That limitation is displayed, not hidden.</div></div></div>
<div class="card pad"><div class="card-header"><div><h2>Chapters included in this estimate</h2><p class="sub">Sorted by the scheduled order where possible. Unmeasured chapters use a weak baseline prior.</p></div><span class="tag">${p?p.chapters.length:0} CHAPTERS</span></div>${p?`<div class="forecast-chapters">${p.chapters.map(x=>`<div class="fc-chip"><strong>${esc(x.chapter.name)}</strong><span>${x.observations?`${fmt(x.mastery,1)}/100 · ${x.count} QCT + ${x.transferCount} block obs · ${x.confidence}`:'No chapter tests · baseline prior only'}</span><div class="progress" style="margin-top:7px"><span style="width:${Math.max(0,Math.min(100,x.mastery))}%;background:${SUBJECT_META[x.chapter.subject].color}"></span></div></div>`).join('')}</div>`:`No chapters resolved.`}</div>
<div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Forecast calibration history</h2><p class="sub">Only tests with forecasts saved before the attempt count here.</p></div><span class="tag">${arr.length} PAIRED</span></div><div class="grid stats metric-five" style="margin-bottom:14px"><div class="stat-card"><div class="stat-label">MAE</div><div class="stat-value" style="font-size:22px">${metrics.mae==null?'—':fmt(metrics.mae,1)}</div><div class="stat-foot">marks</div></div><div class="stat-card"><div class="stat-label">Bias</div><div class="stat-value" style="font-size:22px">${metrics.n?`${metrics.bias>=0?'+':''}${fmt(metrics.bias,1)}`:'—'}</div><div class="stat-foot">actual − raw</div></div><div class="stat-card"><div class="stat-label">RMSE</div><div class="stat-value" style="font-size:22px">${metrics.rmse==null?'—':fmt(metrics.rmse,1)}</div><div class="stat-foot">marks</div></div><div class="stat-card"><div class="stat-label">Worst miss</div><div class="stat-value" style="font-size:22px">${metrics.maxAbs==null?'—':fmt(metrics.maxAbs,1)}</div><div class="stat-foot">absolute marks</div></div><div class="stat-card"><div class="stat-label">Interval cover</div><div class="stat-value" style="font-size:22px">${metrics.coverage==null?'—':fmt(metrics.coverage,0)+'%'}</div><div class="stat-foot">empirical coverage</div></div></div><div class="notice" style="margin-bottom:12px">Raw-model MAE: <b>${metrics.mae==null?'—':fmt(metrics.mae,1)} marks</b>. Saved calibrated-forecast MAE: <b>${metrics.calibratedMae==null?'—':fmt(metrics.calibratedMae,1)} marks</b>${metrics.calibratedN?` across ${metrics.calibratedN} paired tests`:''}. These are historical results on the forecasts saved before each test; use them to check whether calibration actually helps.</div>${arr.some(a=>a.score!=null)?`<div class="table-wrap"><table><thead><tr><th>Test</th><th>Saved raw</th><th>Saved calibrated</th><th>Actual</th><th>Raw residual</th><th>Calibrated residual</th></tr></thead><tbody>${arr.filter(a=>a.score!=null).map(a=>`<tr><td>${esc(a.testId)}<div class="tiny">${dateFmt(a.date)}</div></td><td>${fmt(a.prediction.raw,1)}</td><td>${Number.isFinite(a.prediction.calibrated)?fmt(a.prediction.calibrated,1):'—'}</td><td>${fmt(a.score,0)}</td><td class="${a.score-a.prediction.raw>=0?'good':'bad'}">${a.score-a.prediction.raw>=0?'+':''}${fmt(a.score-a.prediction.raw,1)}</td><td class="${Number.isFinite(a.prediction.calibrated)&&a.score-a.prediction.calibrated>=0?'good':'bad'}">${Number.isFinite(a.prediction.calibrated)?`${a.score-a.prediction.calibrated>=0?'+':''}${fmt(a.score-a.prediction.calibrated,1)}`:'—'}</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><strong>No forecasts graded yet</strong>Save a prediction snapshot before your next test to start measuring errors.</div>`}</div>`;
root.innerHTML+=`<div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Part-test schedule · QPT 1–16</h2><p class="sub">Chapter combinations and checkpoint ranges transcribed from page 5 of the schedule PDF.</p></div><span class="tag">16 TESTS</span></div><div class="table-wrap"><table style="min-width:850px"><thead><tr><th>Test / date</th><th>Format</th><th>Scheduled syllabus</th><th>Status</th><th>Actions</th></tr></thead><tbody>${QPT.map(q=>{const done=allAttempts().some(a=>a.testId.toUpperCase()===q.id.toUpperCase()&&a.score!=null);const saved=state.forecasts.some(f=>f.testId===q.id&&f.type==='QPT');const summary=q.kind==='checkpoint'?q.label:Object.entries(q.subjects||{}).map(([sub,names])=>`${sub}: ${names.join(', ')}`).join(' · ')+(q.topics?` · Topics: ${q.topics.Chemistry.join(', ')}`:'');return `<tr><td><strong>${q.id}</strong><div class="tiny">${dateFmt(q.date)}</div></td><td><span class="tag ${q.kind==='checkpoint'?'amber':'purple'}">${q.kind==='checkpoint'?'PYQ CHECKPOINT':'CHAPTER BLOCK'}</span></td><td style="max-width:450px;white-space:normal">${esc(summary)}</td><td>${done?'<span class="tag green">Logged</span>':saved?'<span class="tag purple">Forecast saved</span>':'<span class="tag">Not logged</span>'}</td><td><div class="table-actions"><button class="btn small" data-action="forecast-schedule" data-id="${q.id}">Forecast</button><button class="btn small" data-action="log-schedule" data-id="${q.id}">Log</button></div></td></tr>`}).join('')}</tbody></table></div></div><div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Full-test schedule · QFT 1–30</h2><p class="sub">Full syllabus; page 6 gives individual upload dates for the first 15, then “from 15 Feb 2027” for the second phase.</p></div><span class="tag">30 TESTS</span></div><div class="table-wrap"><table style="min-width:650px"><thead><tr><th>Test</th><th>Upload date</th><th>Phase</th><th>Status</th><th>Actions</th></tr></thead><tbody>${QFT.map(q=>{const done=allAttempts().some(a=>a.testId.toUpperCase()===q.id.toUpperCase()&&a.score!=null);const saved=state.forecasts.some(f=>f.testId===q.id&&f.type==='QFT');return `<tr><td><strong>${q.id}</strong></td><td>${scheduleDateLabel(q)}</td><td><span class="tag">${q.phase==='Before January attempt'?'Before Jan attempt':'Phase 2 · from 15 Feb'}</span></td><td>${done?'<span class="tag green">Logged</span>':saved?'<span class="tag purple">Forecast saved</span>':'<span class="tag">Not logged</span>'}</td><td><div class="table-actions"><button class="btn small" data-action="forecast-schedule" data-id="${q.id}">Forecast</button><button class="btn small" data-action="log-schedule" data-id="${q.id}">Log</button></div></td></tr>`}).join('')}</tbody></table></div></div>`;document.getElementById('forecastType').addEventListener('change',e=>{forecastType=e.target.value;forecastId=(forecastType==='QPT'?QPT:QFT)[0].id;renderForecasts()});document.getElementById('forecastId').addEventListener('change',e=>{forecastId=e.target.value;renderForecasts()});}
function historySum(topic, years){return (years||[]).reduce((sum,y)=>sum+(topic?.years?.[String(y)]?.total||0),0)}
function activeHistoryDataset(){return HISTORICAL_DATASETS[historySubject]||HISTORICAL_DATASETS.Physics}
function historyChapterByNumber(n){const data=activeHistoryDataset();return data.chapters.find(c=>c.chapter_number===Number(n))||data.chapters[0]||null}
function firstMappedHistoryChapter(data){return data?.chapters?.find(c=>['core','support'].includes(c.schedule_mapping_status))||data?.chapters?.[0]||null}
function historyScheduleLabel(c){if(!c.schedule_chapter_id)return 'Historical-only row · not separately listed in QCT catalog';const sc=CHAP_BY_ID[c.schedule_chapter_id];if(!sc)return 'Catalog link unavailable';return `${sc.name} · ${sc.tests} planned QCTs`}
function historyCount(v){return v&&Number.isFinite(Number(v))?Number(v):0}
function renderHistorical(){
 const root=document.getElementById('view-historical');
 const data=activeHistoryDataset();
 const available=Object.keys(HISTORICAL_DATASETS).filter(k=>Array.isArray(HISTORICAL_DATASETS[k]?.chapters)&&HISTORICAL_DATASETS[k].chapters.length);
 if(!data?.chapters?.length){root.innerHTML=`<div class="card pad"><h2>${esc(historySubject)} historical data not loaded yet</h2><p class="sub">The historical-data module was not found. Check that its script file sits beside index.html, then refresh.</p><button class="btn" type="button" data-view="dashboard">Back to command center</button></div>`;return;}
 let chapter=historyChapterByNumber(historyChapterNumber);if(!chapter){chapter=firstMappedHistoryChapter(data);historyChapterNumber=chapter?.chapter_number;}
 const years=(data.source_years||data.summary?.years||[2025,2024,2023,2022,2021,2020,2019]).map(String);if(!years.includes(String(historyYear)))historyYear=years[0]||'2025';
 const y=String(historyYear),topicList=chapter.topics||[];
 const selectedTopic=topicList.find(t=>t.name===historyTopicName)||topicList[0];historyTopicName=selectedTopic?.name||'';
 const visibleTopics=topicList.map((topic,index)=>({topic,index})).filter(x=>norm(x.topic.name).includes(norm(historySearch)));
 const safeTotal=(topic,yr)=>historyCount(topic?.years?.[String(yr)]?.total);
 visibleTopics.sort((a,b)=>historySort==='latest'?safeTotal(b.topic,y)-safeTotal(a.topic,y):historySort==='all'?historySum(b.topic,years.map(Number))-historySum(a.topic,years.map(Number)):historySum(b.topic,[2023,2024,2025])-historySum(a.topic,[2023,2024,2025]));
 const zero={easy:0,moderate:0,tough:0,total:0};
 const cTotal=chapter.chapter_totals?.[y]||zero;
 const chapterAllYears=years.reduce((agg,yr)=>{const v=chapter.chapter_totals?.[yr]||zero;for(const k of ['easy','moderate','tough','total'])agg[k]+=historyCount(v[k]);return agg;},{easy:0,moderate:0,tough:0,total:0});
 const recentYears=years.filter(yr=>Number(yr)>=2023&&Number(yr)<=2025);
 const recentTotal=recentYears.reduce((s,yr)=>s+historyCount(chapter.chapter_totals?.[yr]?.total),0);
 const topTopic=[...topicList].sort((a,b)=>historySum(b,recentYears.map(Number))-historySum(a,recentYears.map(Number)))[0];
 const maxYear=Math.max(1,...years.map(yr=>historyCount(chapter.chapter_totals?.[yr]?.total)));
 const bars=years.slice().reverse().map(yr=>{const val=historyCount(chapter.chapter_totals?.[yr]?.total);const h=val===0?2:Math.max(4,100*val/maxYear);return `<div class="history-year-col ${yr===y?'selected':''}"><div class="history-year-value">${val}</div><div class="history-year-stick"><span style="height:${h}%" title="${yr}: ${val} source-reported questions"></span></div><div class="history-year-label">${yr}</div></div>`}).join('');
 const matrixRows=visibleTopics.map(({topic,index})=>{const selected=topic.name===selectedTopic?.name;return `<tr class="${selected?'selected-topic':''}"><td class="history-sticky-topic"><button class="history-topic-button" type="button" data-action="history-topic" data-index="${index}" title="Select this subtopic">${esc(topic.name)}</button></td>${years.map(yr=>{const v=topic.years?.[yr]||zero;return `<td class="history-count">${historyCount(v.easy)}</td><td class="history-count">${historyCount(v.moderate)}</td><td class="history-count">${historyCount(v.tough)}</td><td class="history-count history-total-cell"><strong>${historyCount(v.total)}</strong></td>`}).join('')}</tr>`}).join('');
 const detailYears=years.slice().sort((a,b)=>Number(b)-Number(a));
 const selectedHistory=selectedTopic?detailYears.map(yr=>{const v=selectedTopic.years?.[yr]||zero;return `<tr ${yr===y?'style="background:#8b7cff12"':''}><td><strong>${yr}</strong></td><td>${historyCount(v.easy)}</td><td>${historyCount(v.moderate)}</td><td>${historyCount(v.tough)}</td><td><strong>${historyCount(v.total)}</strong></td><td>${v.total?fmt(100*historyCount(v.easy)/historyCount(v.total),0)+'%':'—'}</td></tr>`}).join(''):'';
 const yearlyTotals=detailYears.map(yr=>{const v=chapter.chapter_totals?.[yr]||zero;return `<tr ${yr===y?'style="background:#8b7cff12"':''}><td><strong>${yr}</strong></td><td>${historyCount(v.easy)}</td><td>${historyCount(v.moderate)}</td><td>${historyCount(v.tough)}</td><td><strong>${historyCount(v.total)}</strong></td></tr>`}).join('');
 const mapped=chapter.schedule_mapping_status==='core'||chapter.schedule_mapping_status==='support';
 const mapBadge=chapter.schedule_mapping_status==='extra'?'extra':chapter.schedule_mapping_status==='unmapped'?'unmapped':mapped?'mapped':'unmapped';
 const dataLabel=historySubject==='Physics'?'Physics':historySubject==='Chemistry'?'Chemistry':'Mathematics';
 const sourceYears=[...years].sort((a,b)=>Number(b)-Number(a));
 const difficultyLabels='E = Easy · M = Medium (source PDF: Moderate) · T = Hard (source PDF: Tough) · O = Total/Overall';
 const sourceFile=esc(data.source_file||`${historySubject} historical PYQ document`);
 const excludedTopics=Array.isArray(data.excluded_topics)?data.excluded_topics:[];
 const excludedHtml=excludedTopics.length?`<div class="card pad" style="margin-top:14px"><details><summary style="cursor:pointer;font-weight:800">Excluded topics · ${excludedTopics.length} rows removed from the active matrix</summary><p class="sub" style="margin:10px 0 12px">Rule: O/Overall = 0 in both 2024 and 2025. Names and source-page references are retained for your audit; their historical numeric rows are not part of the active dataset.</p><div class="table-wrap history-table"><table style="min-width:540px"><thead><tr><th>Chapter</th><th>Excluded topic</th><th>PDF page</th><th>Reason</th></tr></thead><tbody>${excludedTopics.map(x=>`<tr><td>${esc(x.chapter)}</td><td>${esc(x.topic)}</td><td>${historyCount(x.source_pdf_page)}</td><td>O = 0 in 2024 and 2025</td></tr>`).join('')}</tbody></table></div></details></div>`:'';
 const sourceNotesHtml=chapter.source_notes?`<div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Source notes & mentorship footnotes</h2><p class="sub">Additional note preserved from the supplied chapter page</p></div></div><div class="history-source-text">${esc(chapter.source_notes)}</div></div>`:'';
 root.innerHTML=`
 <div class="card hero"><div class="hero-content"><div class="hero-chip"><span>◉</span>HISTORICAL EXAM INTELLIGENCE · ${esc(dataLabel.toUpperCase())}</div><h2>Read the historical pattern. Keep the uncertainty visible.</h2><p>The supplied ${esc(dataLabel)} PYQ document contains ${historyCount(data.summary?.chapter_count)} chapter sheets. The active matrix has ${historyCount(data.summary?.subtopic_count)} subtopic rows after excluding ${historyCount(data.summary?.excluded_topic_count)} topics with O = 0 in both 2024 and 2025. Historical data remains separate from your personal mastery and score calibration.</p><div class="hero-actions"><span class="pill">2019–2025</span><span class="pill">${historyCount(data.summary?.subtopic_count)} subtopics</span><span class="pill">E–M–T–O retained</span></div></div></div>
 <div class="grid stats history-grid"><div class="stat-card card" style="--glow:var(--purple)"><div class="stat-label">Chapter sheets</div><div class="stat-value">${historyCount(data.summary?.chapter_count)}</div><div class="stat-foot">Source chapter tables</div></div><div class="stat-card card" style="--glow:var(--mint)"><div class="stat-label">Subtopic rows</div><div class="stat-value">${historyCount(data.summary?.subtopic_count)}</div><div class="stat-foot">${historyCount(data.summary?.excluded_topic_count)} excluded by 2024–25 zero-O rule</div></div><div class="stat-card card" style="--glow:var(--blue)"><div class="stat-label">Years covered</div><div class="stat-value">${years.length}</div><div class="stat-foot">2019 through 2025</div></div><div class="stat-card card" style="--glow:var(--amber)"><div class="stat-label">Arithmetic checks</div><div class="stat-value">${data.summary?.source_counts_validated?'PASS':'CHECK'}</div><div class="stat-foot">Topic rows vs. source totals</div></div></div>
 <div class="notice amber" style="margin-bottom:15px"><b>Interpretation guardrail:</b> ${esc(data.denominator_limit||'The source does not identify the paper/shift denominator behind annual counts.')} Historical counts do not automatically change your personal QPT/QFT score forecasts. <br><br><b>Exclusion guardrail:</b> topics with source O = 0 in both 2024 and 2025 are removed from the active subtopic matrix. Chapter-level totals stay source-original; prior to 2024, those chapter totals may include excluded topics and therefore may not equal the sum of visible active rows.</div>
 <div class="card pad"><div class="card-header"><div><h2>Choose dataset and chapter</h2><p class="sub">One shared explorer for Physics, Chemistry, and Mathematics. Original source wording and chapter mentorship sections are preserved; removed topics are only listed in the exclusion register.</p></div><span class="tag purple">SOURCE DATA</span></div><div class="history-controls history-controls-wide"><div class="field"><label for="historySubject">Subject dataset</label><select id="historySubject">${['Physics','Chemistry','Mathematics'].map(sub=>{const present=Boolean(HISTORICAL_DATASETS[sub]?.chapters?.length);return `<option value="${sub}" ${sub===historySubject?'selected':''} ${present?'':'disabled'}>${sub}${present?'': ' · awaiting upload'}</option>`}).join('')}</select></div><div class="field"><label for="historyChapter">${esc(dataLabel)} chapter</label><select id="historyChapter">${data.chapters.map(c=>`<option value="${c.chapter_number}" ${c.chapter_number===chapter.chapter_number?'selected':''}>${String(c.chapter_number).padStart(2,'0')} · ${esc(c.title)}</option>`).join('')}</select></div><div class="field"><label for="historyYear">Focus year</label><select id="historyYear">${sourceYears.map(yr=>`<option value="${yr}" ${yr===y?'selected':''}>${yr}</option>`).join('')}</select></div><div class="field"><label for="historyTopicSelect">Subtopic detail</label><select id="historyTopicSelect">${topicList.map((t,i)=>`<option value="${i}" ${t.name===selectedTopic?.name?'selected':''}>${esc(t.name)}</option>`).join('')}</select></div></div><div class="chapter-meta" style="margin-top:12px"><span class="history-badge ${mapBadge}">${chapter.schedule_mapping_status==='core'?'Linked to QCT chapter':chapter.schedule_mapping_status==='support'?'Linked support topic':chapter.schedule_mapping_status==='extra'?'Marked extra in QCT schedule':'Historical-only chapter'}</span><span class="history-badge">${esc(historyScheduleLabel(chapter))}</span><span class="history-badge">Source PDF page ${historyCount(chapter.pdf_page)}</span></div><div class="history-legend" style="margin-top:12px">${difficultyLabels}</div></div>
 <div class="grid stats history-grid"><div class="stat-card card"><div class="stat-label">${y} chapter total · O</div><div class="stat-value">${historyCount(cTotal.total)}</div><div class="stat-foot">E ${historyCount(cTotal.easy)} · M ${historyCount(cTotal.moderate)} · T ${historyCount(cTotal.tough)}</div></div><div class="stat-card card"><div class="stat-label">All years · O</div><div class="stat-value">${chapterAllYears.total}</div><div class="stat-foot">E ${chapterAllYears.easy} · M ${chapterAllYears.moderate} · T ${chapterAllYears.tough}</div></div><div class="stat-card card"><div class="stat-label">2023–2025 · O</div><div class="stat-value">${recentTotal}</div><div class="stat-foot">Raw recent-year total</div></div><div class="stat-card card"><div class="stat-label">Top subtopic · 2023–25</div><div class="stat-value" style="font-size:15px;letter-spacing:-.3px;line-height:1.25">${esc(topTopic?.name||'—')}</div><div class="stat-foot">${topTopic?historySum(topTopic,recentYears.map(Number))+' source-counted questions':''}</div></div></div>
 <div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Chapter trend by year</h2><p class="sub">Bars show source-reported total (O) count; selected year is highlighted.</p></div><span class="tag">${esc(chapter.title)}</span></div><div class="history-bars">${bars}</div><div class="tiny" style="margin-top:10px">Raw annual counts; exposure differs between years. Bar height is scaled within this chapter only.</div></div><div class="card pad"><div class="card-header"><div><h2>Chapter annual E–M–T–O</h2><p class="sub">The full difficulty split for the chapter, across all available years.</p></div></div><div class="table-wrap history-table"><table class="history-annual-table"><thead><tr><th>Year</th><th>E</th><th>M</th><th>T</th><th>O / Total</th></tr></thead><tbody>${yearlyTotals}</tbody></table></div></div></div>
 <div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Complete subtopic E–M–T–O matrix</h2><p class="sub">Every subtopic × every year × all four reported buckets. Swipe horizontally to inspect older years on mobile.</p></div><span class="tag">${visibleTopics.length} / ${topicList.length} topics</span></div><div class="filters" style="margin-bottom:12px"><input id="historySearch" class="input" placeholder="Search subtopics…" value="${esc(historySearch)}"><select id="historySort"><option value="recent" ${historySort==='recent'?'selected':''}>Sort: 2023–2025 total</option><option value="latest" ${historySort==='latest'?'selected':''}>Sort: ${y} total</option><option value="all" ${historySort==='all'?'selected':''}>Sort: 2019–2025 total</option></select></div><div class="table-wrap history-table history-full-matrix"><table><thead><tr><th rowspan="2" class="history-sticky-topic">Subtopic</th>${years.map(yr=>`<th colspan="4" class="history-year-group">${yr}</th>`).join('')}</tr><tr>${years.map(()=>'<th>E</th><th>M</th><th>T</th><th>O</th>').join('')}</tr></thead><tbody>${matrixRows||`<tr><td colspan="29" class="empty">No matching subtopics.</td></tr>`}</tbody></table></div><div class="tiny" style="margin-top:10px">${difficultyLabels}. The original PDF uses “Moderate”, “Tough”, and “Overall”; this interface follows your preferred “Medium”, “Hard”, and “Total” wording.</div></div>
 <div class="card pad" style="margin-top:14px"><div class="card-header"><div><h2>Selected subtopic · annual detail</h2><p class="sub">${esc(selectedTopic?.name||'No topic selected')} · complete historical difficulty split.</p></div><span class="tag purple">${selectedTopic?historySum(selectedTopic,years.map(Number))+' total':'—'}</span></div>${selectedTopic?`<div class="table-wrap"><table style="min-width:540px"><thead><tr><th>Year</th><th>Easy</th><th>Medium</th><th>Hard</th><th>Total / Overall</th><th>Easy share</th></tr></thead><tbody>${selectedHistory}</tbody></table></div>`:`<div class="empty">No subtopic details available.</div>`}</div>
 <div class="history-notes" style="margin-top:14px"><div class="card pad"><div class="card-header"><div><h2>Recent trend in PYQs</h2><p class="sub">Publisher's summary from the supplied chapter page</p></div></div><div class="history-source-text">${esc(chapter.recent_trend||'').replace(/\.\s+/g,'.<br><br> ')||'No trend commentary on this page.'}</div></div><div class="card pad"><div class="card-header"><div><h2>Expert suggestion</h2><p class="sub">Preserved from the supplied PDF, not independently updated</p></div></div><div class="history-source-text">${esc(chapter.expert_suggestion||'').replace(/\.\s+/g,'.<br><br> ')||'No expert suggestion on this page.'}</div></div></div>
 ${sourceNotesHtml}${excludedHtml}
 <div class="notice" style="margin-top:14px"><b>Model boundary:</b> historical counts are stored separately from your personal test history and calibration. They are evidence for investigation and topic-practice planning, not direct predictions of question allocation. Use actual shift-level counts and denominators before turning them into future-paper probabilities.</div>
 <div class="footer-note" style="text-align:left">Source: ${sourceFile} · Source table figures are transcribed and arithmetically checked; the source's syllabus and study advice are retained as-is and are not independently verified.</div>`;
 document.getElementById('historySubject').addEventListener('change',e=>{const next=e.target.value;if(!HISTORICAL_DATASETS[next]?.chapters?.length){toast('That subject dataset has not been uploaded yet.');renderHistorical();return;}historySubject=next;const d=activeHistoryDataset();const first=firstMappedHistoryChapter(d);historyChapterNumber=first?.chapter_number??d.chapters[0].chapter_number;historyTopicName='';historySearch='';historyYear='2025';renderHistorical();});
 document.getElementById('historyChapter').addEventListener('change',e=>{historyChapterNumber=Number(e.target.value);historyTopicName='';historySearch='';renderHistorical();});
 document.getElementById('historyYear').addEventListener('change',e=>{historyYear=e.target.value;renderHistorical();});
 document.getElementById('historyTopicSelect').addEventListener('change',e=>{historyTopicName=topicList[Number(e.target.value)]?.name||'';renderHistorical();});
 document.getElementById('historySort').addEventListener('change',e=>{historySort=e.target.value;renderHistorical();});
 document.getElementById('historySearch').addEventListener('input',e=>{historySearch=e.target.value;const start=e.target.selectionStart;renderHistorical();const next=document.getElementById('historySearch');if(next){next.focus();try{next.setSelectionRange(start,start);}catch{}}});
}
function renderDataLegacy(){const root=document.getElementById('view-data');const c=CHAPTERS.length, core=CORE_CHAPTERS.length;root.innerHTML=`<div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Import feedback from ChatGPT</h2><p class="sub">Paste structured JSON. The app validates counts, resolves chapter names and computes every score.</p></div><span class="tag purple">NO API REQUIRED</span></div><label for="jsonImport">JSON payload</label><textarea id="jsonImport" rows="13" spellcheck="false" placeholder='Paste one test object or {"tests":[...]} here. Use the example below.'>${esc(importText)}</textarea><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:11px"><button class="btn primary" id="importJsonBtn">⇄ Validate & import</button><button class="btn" id="loadExampleBtn">Load example schema</button><button class="btn" id="clearJsonBtn">Clear</button></div><div id="importResult" style="margin-top:12px"></div><div class="notice" style="margin-top:14px">Import accepts <code>test_id</code>, <code>date</code>, <code>test_type</code>, <code>correct</code>, <code>wrong</code>, <code>unattempted</code>, <code>total_questions</code>, plus <code>chapter_results</code> and optional <code>question_errors</code>. See schema below.</div></div>
<div class="card pad"><div class="card-header"><div><h2>Backup & restore</h2><p class="sub">Keep your history portable and safe across browser changes.</p></div><span class="tag green">LOCAL FIRST</span></div><div class="chapter-list"><div class="chapter-row"><div><div class="chapter-name">Export all records</div><div class="chapter-meta">Settings, attempts, forecasts, raw chapter outcomes.</div></div><button class="btn small" data-action="export">Export JSON</button></div><div class="chapter-row"><div><div class="chapter-name">Restore backup</div><div class="chapter-meta">Loads a previously exported Loadout JSON backup.</div></div><button class="btn small" data-action="restore-file">Choose file</button></div><div class="chapter-row"><div><div class="chapter-name">Export attempt ledger</div><div class="chapter-meta">CSV for spreadsheets / external analysis.</div></div><button class="btn small" data-action="export-csv">Export CSV</button></div><div class="chapter-row"><div><div class="chapter-name">${window.Loadout?.native?.available?'Offline Android app':'Installable PWA'}</div><div class="chapter-meta">${window.Loadout?.native?.available?'The complete app and historical datasets are bundled in the APK. It runs without a server or internet. Personal records stay on-device and are mirrored to app-private storage.':'Requires HTTPS hosting or localhost; opening index.html as file will not enable service-worker installation.'}</div></div><span class="tag ${window.Loadout?.native?.available?'green':'amber'}">${window.Loadout?.native?.available?'OFFLINE':'HTTPS'}</span></div></div><input type="file" id="restoreFile" accept="application/json,.json" style="display:none"><div id="restore-preview" class="notice" style="display:none;margin-top:12px"></div><div class="divider" style="margin:16px 0"></div><div class="card-header"><div><h3 style="margin:0">Pre-restore safety snapshots</h3><p class="sub">Verified device-local snapshots created before each restore. Select one to review and restore it.</p></div><button class="btn small" type="button" data-action="refresh-snapshots">Refresh</button></div><div id="restore-snapshots" class="chapter-list"><div class="tiny">Loading saved snapshots…</div></div><div class="notice amber" style="margin-top:15px">${window.Loadout?.native?.available?'Records are stored locally and mirrored inside app-private storage. They are removed if you uninstall or clear app data; export a JSON backup before changing devices.':'Browser storage can be cleared by the operating system or browser. Export a JSON backup before changing devices.'}</div></div></div>
<div class="card pad" style="margin-bottom:14px"><div class="card-header"><div><h2>Mathematical engine settings</h2><p class="sub">These settings affect future calculations; previous raw outcomes remain unchanged.</p></div><button class="btn" id="saveSettings">Save settings</button></div>
<div class="settings-row"><div><strong>Recency weight α</strong><p>EMA update: newest test gets α weight; older evidence decays exponentially. Start at 0.35 and tune from prediction performance.</p></div><div class="settings-control"><input id="s-alpha" type="number" class="input" min="0.05" max="1" step="0.05" value="${state.settings.alpha}"></div></div>
<div class="settings-row"><div><strong>Prior strength k</strong><p>Equivalent pseudo-test count pulling small-sample chapter estimates toward the cohort mean. Higher values produce more conservative estimates.</p></div><div class="settings-control"><input id="s-prior" type="number" class="input" min="0" max="10" step="0.5" value="${state.settings.priorStrength}"></div></div>
<div class="settings-row"><div><strong>Questions per block test</strong><p>Default QPT/QFT prediction size. The schedule doesn't publish chapter-specific question allocation.</p></div><div class="settings-control"><input id="s-questions" type="number" class="input" min="1" max="200" value="${state.settings.blockQuestions}"></div></div>
<div class="settings-row"><div><strong>Default chapter-test size</strong><p>Initial value for the manual entry form; change per attempt to match actual Quizrr tests.</p></div><div class="settings-control"><input id="s-qctn" type="number" class="input" min="1" max="100" value="${state.settings.defaultQCTQuestions}"></div></div>
<div class="settings-row"><div><strong>Default chapter-test time (min)</strong><p>Initial value only; actual time taken is stored per attempt.</p></div><div class="settings-control"><input id="s-qcttime" type="number" class="input" min="1" max="300" value="${state.settings.defaultQCTMinutes}"></div></div>
<div class="settings-row"><div><strong>Scoring scheme</strong><p>Current model uses +4 for correct, −1 for wrong, 0 for unattempted. A wrong answer loses five marks versus a correct one; an unattempted answer loses four.</p></div><div class="settings-control"><span class="pill">+4 / −1 / 0</span></div></div>
</div>
<div class="two-col"><div class="card pad"><div class="card-header"><div><h2>Data contract for ChatGPT</h2><p class="sub">Tell ChatGPT to output this structure after each test.</p></div><button class="btn small" id="copySchema">Copy schema</button></div><pre id="schemaCode" style="white-space:pre-wrap;overflow-wrap:anywhere;background:#080e19;border:1px solid var(--border);padding:14px;border-radius:12px;color:#cbd6ed;font-size:10px;line-height:1.65">${esc(JSON.stringify({test_id:'REPLACE-WITH-REAL-TEST-ID',date:'2026-10-22',test_type:'QCT',title:'REPLACE WITH REAL TEST NAME',total_questions:15,duration_min:30,correct:10,wrong:2,unattempted:3,chapter_results:[{chapter:'Motion In One Dimension',total_questions:15,correct:10,wrong:2,unattempted:3,error_counts:{conceptual:0,recall:1,application:1,comparison:0,calculation:0,careless:0,time:0,unclassified:0},notes:'Add only evidence-supported diagnosis.'}],question_errors:[{chapter:'Motion In One Dimension',topic:'Relative motion',outcome:'wrong',category:'application',time_seconds:90,notes:'Optional concise post-mortem.'}]},null,2))}</pre><div class="notice" style="margin-top:12px">If only total score counts are known, import them. If chapter allocations or mistake categories aren't in the source, leave them out rather than asking ChatGPT to guess. App score = 4C − W.</div></div>
<div class="card pad"><div class="card-header"><div><h2>Schedule integrity</h2><p class="sub">Transcribed from the uploaded October Batch schedule PDF.</p></div><span class="tag">SOURCE MAP</span></div><div class="grid stats" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="stat-card"><div class="stat-label">QCT rows</div><div class="stat-value">${c}</div><div class="stat-foot">Planned tests total 471</div></div><div class="stat-card"><div class="stat-label">Core-filter rows</div><div class="stat-value">${core}</div><div class="stat-foot">Asterisk extras + support topic separated</div></div><div class="stat-card"><div class="stat-label">Part tests</div><div class="stat-value">16</div><div class="stat-foot">12 topic blocks + 4 checkpoints</div></div><div class="stat-card"><div class="stat-label">Full tests</div><div class="stat-value">30</div><div class="stat-foot">First upload 29 Nov 2026</div></div></div><div class="divider"></div><p class="sub">Chapter QCT planned counts from the schedule are retained as metadata, not treated as completed attempts. QPT chapter lists and QFT upload dates are preloaded. The schedule's footnote says dates may change.</p></div></div>
<div class="card pad" style="margin-bottom:14px"><div class="card-header"><div><h2>Mathematical reference</h2><p class="sub">The calculator is deterministic: the same records and settings yield the same answer.</p></div><span class="tag purple">FORMULAS</span></div><div class="chapter-list"><div class="chapter-row"><div><div class="chapter-name">Net marks</div><div class="chapter-meta">S = 4C − W; U has zero marks. Maximum = 4N.</div></div><div class="chapter-score"><strong>4C − W</strong><small>per test</small></div></div><div class="chapter-row"><div><div class="chapter-name">Scaled net score</div><div class="chapter-meta">P = 100S/(4N). It is a normalized test result, not literal concept mastery.</div></div><div class="chapter-score"><strong>0–100*</strong><small>can be negative</small></div></div><div class="chapter-row"><div><div class="chapter-name">Recency weighting</div><div class="chapter-meta">EMAₜ = αPₜ + (1−α)EMAₜ₋₁.</div></div><div class="chapter-score"><strong>α=${fmt(state.settings.alpha,2)}</strong><small>latest test weight</small></div></div><div class="chapter-row"><div><div class="chapter-name">Small-sample shrinkage</div><div class="chapter-meta">M = (m·EMA + k·μ)/(m+k), where μ is the overall core chapter-test baseline.</div></div><div class="chapter-score"><strong>k=${fmt(state.settings.priorStrength,1)}</strong><small>prior strength</small></div></div><div class="chapter-row"><div><div class="chapter-name">Raw block forecast</div><div class="chapter-meta">Ŝ = Nblock × mean(4Mⱼ/100) across chapters in the scheduled syllabus. Equal chapter weighting is an explicit fallback.</div></div><div class="chapter-score"><strong>N=${state.settings.blockQuestions}</strong><small>block questions</small></div></div><div class="chapter-row"><div><div class="chapter-name">Calibration + residual</div><div class="chapter-meta">Residual = actual − saved raw forecast. Bias correction / linear regression use only prior saved forecasts for the same test family.</div></div><div class="chapter-score"><strong>a + bŜ</strong><small>learned correction</small></div></div></div><div class="notice amber" style="margin-top:13px">Prediction decimals describe arithmetic precision, not guaranteed accuracy. Intervals remain provisional until enough comparable forecasts have been saved before tests and then graded.</div></div>
<div class="card pad"><div class="card-header"><div><h2>Danger zone</h2><p class="sub">This affects local records in this browser only.</p></div></div><div class="settings-row"><div><strong>Delete all records</strong><p>Clears all attempts, forecasts, and custom settings. Export a backup first; this cannot be undone.</p></div><button class="btn danger" id="resetAll">Reset data</button></div></div>`;
document.getElementById('jsonImport').addEventListener('input',e=>{importText=e.target.value});document.getElementById('importJsonBtn').addEventListener('click',()=>importJSON(document.getElementById('jsonImport').value));document.getElementById('loadExampleBtn').addEventListener('click',()=>{document.getElementById('jsonImport').value=JSON.stringify({test_id:'REPLACE-WITH-REAL-TEST-ID',date:dateTimeISO(),test_type:'QCT',title:'REPLACE WITH REAL TEST NAME',total_questions:15,duration_min:30,correct:10,wrong:2,unattempted:3,chapter_results:[{chapter:'Motion In One Dimension',total_questions:15,correct:10,wrong:2,unattempted:3,error_counts:{application:1,careless:1}}]},null,2);toast('Example schema loaded. Replace the values with real results before importing.');});document.getElementById('clearJsonBtn').addEventListener('click',()=>{document.getElementById('jsonImport').value='';document.getElementById('importResult').innerHTML='';});document.getElementById('saveSettings').addEventListener('click',saveSettings);document.getElementById('copySchema').addEventListener('click',()=>copyText(document.getElementById('schemaCode').textContent));document.getElementById('resetAll').addEventListener('click',resetAll);restoreFileHandler();}
function openTestModal(schedule=null){const modal=document.getElementById('testModal');document.getElementById('formError').style.display='none';document.getElementById('f-date').value=dateTimeISO();document.getElementById('f-type').value=schedule?(schedule.id.startsWith('QPT')?'QPT':'QFT'):'QCT';document.getElementById('f-id').value=schedule?schedule.id:'';document.getElementById('f-title').value=schedule?schedule.name:'';document.getElementById('f-chapter').value='';document.getElementById('f-n').value=schedule?state.settings.blockQuestions:state.settings.defaultQCTQuestions;document.getElementById('f-correct').value=0;document.getElementById('f-wrong').value=0;document.getElementById('f-unattempted').value=document.getElementById('f-n').value;document.getElementById('f-minutes').value=schedule?state.settings.blockMinutes:state.settings.defaultQCTMinutes;document.getElementById('f-subject').value='';document.getElementById('f-notes').value='';modal.classList.add('open');setTimeout(()=>document.getElementById('f-title').focus(),20)}
function closeModal(){document.getElementById('testModal').classList.remove('open')}
function initModal(){const sel=document.getElementById('f-chapter');sel.innerHTML='<option value="">Select a chapter…</option>'+CHAPTERS.map(c=>`<option value="${c.id}">${esc(c.subject)} · ${esc(c.name)}${c.status==='extra'?' *':c.status==='support'?' · support':''}</option>`).join('');document.getElementById('closeModal').addEventListener('click',closeModal);document.getElementById('cancelModal').addEventListener('click',closeModal);document.getElementById('testModal').addEventListener('click',e=>{if(e.target.id==='testModal')closeModal()});document.getElementById('f-type').addEventListener('change',e=>{const n=document.getElementById('f-n');if(e.target.value==='QPT'||e.target.value==='QFT'){if(Number(n.value)===Number(state.settings.defaultQCTQuestions))n.value=state.settings.blockQuestions;document.getElementById('f-minutes').value=state.settings.blockMinutes;}else{n.value=state.settings.defaultQCTQuestions;document.getElementById('f-minutes').value=state.settings.defaultQCTMinutes;}syncUnattempted()});['f-n','f-correct','f-wrong'].forEach(id=>document.getElementById(id).addEventListener('input',syncUnattempted));document.getElementById('testForm').addEventListener('submit',saveManualTest);document.getElementById('closeDetail').addEventListener('click',()=>document.getElementById('detailModal').classList.remove('open'));document.getElementById('detailModal').addEventListener('click',e=>{if(e.target.id==='detailModal')e.currentTarget.classList.remove('open')});document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();document.getElementById('detailModal').classList.remove('open')}})}
function syncUnattempted(){const n=Number(document.getElementById('f-n').value)||0,c=Number(document.getElementById('f-correct').value)||0,w=Number(document.getElementById('f-wrong').value)||0;document.getElementById('f-unattempted').value=Math.max(0,n-c-w)}
function renderData(){renderDataLegacy();renderLoadoutGovernance();renderBackupSnapshots();}
function renderLoadoutGovernance(){
 const root=document.getElementById('view-data'); if(!root||root.querySelector('#loadout-governance'))return;
 const profile=window.LOADOUT_EXAM_PROFILE||null;
 const counts=profile?Object.entries(profile.subjects).map(([name,value])=>`<div class="scale-item"><small>${esc(name.toUpperCase())}</small><strong>${value.unitCount} units</strong><small>Official Paper 1 headings</small></div>`).join(''):'';
 const card=document.createElement('section');card.id='loadout-governance';card.className='card pad';card.style.marginTop='14px';
 card.innerHTML=`<div class="card-header"><div><h2>Loadout Runtime & Observatory</h2><p class="sub">Owner-controlled runtime, data packs, recovery journal and local diagnostics</p></div><span class="tag purple">L-SEAA 1.8.0</span></div>
 <div class="grid stats" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))"><div class="stat-card"><div class="stat-label">Runtime API</div><div class="stat-value" id="obs-runtime-version">1.5.0</div><div class="stat-foot">Compatible API contract</div></div><div class="stat-card"><div class="stat-label">Native bridge</div><div class="stat-value" id="obs-native-status">Checking</div><div class="stat-foot">Android private storage</div></div><div class="stat-card"><div class="stat-label">Secure credentials</div><div class="stat-value" id="obs-keystore-status">Checking</div><div class="stat-foot">Android Keystore AES-GCM</div></div><div class="stat-card"><div class="stat-label">Update policy</div><div class="stat-value">Manual</div><div class="stat-foot">Owner commits or rolls back</div></div></div>
 <div class="notice" style="margin-top:12px">Resource updates are owner-signed Ed25519 <code>.lupdate</code> JSON packages. The LTL updater accepts guarded declarative data/resource changes and non-executable text-resource patches only; it never runs package-supplied scripts. For actual app/source logic changes, use the separate workstation-only <code>.lpatch</code> Source Repair Port, validate a staged repository copy, then rebuild the APK. Native/manifest changes are always APK-bound. Staging produces an impact report; commit remains manual.</div>
 <div class="card pad" style="margin-top:12px"><div class="card-header"><div><h3>Visible Port Directory</h3><p class="sub">Named, inspectable interfaces. These are logical application ports, not listening TCP sockets.</p></div><span class="tag green">LOCAL FIRST</span></div><div id="obs-port-directory-list" class="chapter-list"><div class="chapter-row"><div><div class="chapter-name">USB / ADB ingress</div><div class="chapter-meta">Debug APK only · signed .lupdate, .lreg and .lfix · Android host authorization · no LAN listener.</div></div><span class="tag">DEVICE</span></div><div class="chapter-row"><div><div class="chapter-name">Visual Repair Port</div><div class="chapter-meta">Signed .lfix · bounded UI tokens · in-app staging, preview by review and manual commit/rollback.</div></div><span class="tag green">APP</span></div><div class="chapter-row"><div><div class="chapter-name">Source Repair Port</div><div class="chapter-meta">Signed .lpatch · computer-side CLI only · exact file hashes/anchors · staged repository checks · APK rebuild for shipped code.</div></div><span class="tag">HOST</span></div><div class="chapter-row"><div><div class="chapter-name">Feature service ports</div><div class="chapter-meta">Versioned first-party service names, declared dependencies and storage namespaces listed below.</div></div><span class="tag">MODULE API</span></div><div class="chapter-row"><div><div class="chapter-name">Native bridge</div><div class="chapter-meta">Compiled Capacitor service contracts; native implementation changes require an APK update.</div></div><span class="tag">APK</span></div><div class="chapter-row"><div><div class="chapter-name">AI provider</div><div class="chapter-meta">Outbound HTTPS only when you explicitly send a request; only selected context is transmitted.</div></div><span class="tag">OPT-IN</span></div><div class="chapter-row"><div><div class="chapter-name">Backup / data interchange</div><div class="chapter-meta">Owner-triggered local export/import/restore; snapshots and validation before destructive restore.</div></div><span class="tag">LOCAL DATA</span></div></div></div>
 <div class="card pad" style="margin-top:12px" id="obs-repair-console"><div class="card-header"><div><h3>Visual Repair Port</h3><p class="sub">Upload a signed <code>.lfix</code> repair file. The app verifies it, shows exactly which UI tokens change, then waits for your Commit or Roll Back decision.</p></div><div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap"><button class="btn small" id="obs-export-repair-context" type="button">Export Repair Context</button><span class="tag purple">.LFIX</span></div></div><div class="chapter-row"><div><div class="chapter-name">Stage a visual repair file</div><div class="chapter-meta">A screenshot is used to diagnose the issue outside the app; it is not embedded in the repair package. Signed repair files are limited to approved spacing, sizing, typography and overflow tokens.</div></div><input id="loadout-repair-file" type="file" accept=".lfix,application/json" style="max-width:220px"></div><div class="notice" id="obs-repair-status" style="margin-top:8px">No visual repair staged in this session.</div><h4 style="margin:14px 0 6px">Awaiting your decision</h4><div id="obs-repair-pending" class="chapter-list"><div class="empty">No pending visual repairs.</div></div><details style="margin-top:10px"><summary style="cursor:pointer;color:var(--purple);font-weight:700">Active repairs & repair history</summary><div id="obs-repair-active" class="chapter-list" style="margin-top:8px"></div><div id="obs-repair-history" class="chapter-list" style="margin-top:8px"></div></details></div>
 <div class="card pad" style="margin-top:12px"><div class="card-header"><div><h3>Source Repair Port</h3><p class="sub">For broken logic, wrong calculations, data-flow errors, route bugs or native code—not visual token tuning.</p></div><span class="tag amber">HOST ONLY</span></div><p class="sub">This port is deliberately not exposed inside the Android app. On the development computer, a signed <code>.lpatch</code> is verified against the owner trust store, applied to a complete staging copy only when the source-file SHA-256 and unique anchor match, then checked with tests, source validation and the historical data audit. A separate CLI commit writes the repair; a normal GitHub Actions/APK build is still required for the phone.</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;background:#080e19;border:1px solid var(--border);padding:12px;border-radius:10px;font-size:11px">npm run repair:port -- inspect fix.lpatch
npm run repair:port -- stage fix.lpatch
npm run repair:port -- commit REPAIR-ID
# Later, if needed:
npm run repair:port -- rollback REPAIR-ID</pre><p class="tiny">No arbitrary shell commands, eval endpoint, LAN listener or remote filesystem editor is exposed to the phone.</p></div>
 <div class="chapter-list" style="margin-top:12px"><div class="chapter-row"><div><div class="chapter-name">Stage signed resource update</div><div class="chapter-meta">Select an owner-signed .lupdate JSON file. Staging verifies signatures, dependencies and LTL preconditions; it does not activate it.</div></div><div><input id="loadout-update-file" type="file" accept=".lupdate,.json,application/json" style="max-width:220px"></div></div><div id="loadout-update-result" class="notice" style="margin-top:8px">No update staged in this session.</div><div id="loadout-pending-updates" style="margin-top:8px"></div></div>
 <div class="card pad" style="margin-top:12px"><div class="card-header"><div><h3>Authenticated Development Port</h3><p class="sub">Debug builds only · USB/ADB transport · Android-authorized host pairing · no LAN listener or remote shell.</p></div><span class="tag amber" id="obs-devport-badge">Checking</span></div><div class="notice" id="obs-devport-status">Checking native Development Port…</div><div class="chapter-row" style="margin-top:10px"><div><div class="chapter-name">Import private registry catalog</div><div class="chapter-meta">Signed .lreg catalog only. Module code remains APK-bundled; imported catalogs cannot add executable modules.</div></div><input id="loadout-registry-file" type="file" accept=".lreg,application/json" style="max-width:220px"></div><div class="notice" id="obs-registry-status" style="margin-top:8px">Loading private registry…</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button class="btn small" id="obs-devport-refresh">Refresh inbox</button><button class="btn small" id="obs-cache-refresh">Refresh offline package cache</button><button class="btn small" id="obs-registry-reset">Reset to APK-bundled registry</button></div><div id="obs-devport-inbox" class="chapter-list" style="margin-top:8px"></div><details style="margin-top:10px"><summary style="cursor:pointer;color:var(--purple);font-weight:700">Verified offline package cache</summary><div id="obs-package-cache" class="chapter-list" style="margin-top:8px"></div></details></div>
 <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px"><button class="btn small" id="obs-refresh">Refresh status</button><button class="btn small" id="obs-export-diagnostics">Export local diagnostics</button><button class="btn small" id="obs-clear-diagnostics">Clear diagnostics</button><button class="btn small" id="obs-export-runtime">Export runtime report</button></div>
 <details style="margin-top:14px"><summary style="cursor:pointer;color:var(--purple);font-weight:700">Official JEE Main 2027 Paper 1 syllabus profile</summary><p class="sub" style="margin:9px 0">Source: National Testing Agency · Syllabus 2027 · Paper 1 (B.E./B.Tech.). The profile records top-level unit headings, not verified subtopic-to-legacy-chapter mapping.</p><div class="forecast-scale">${counts}</div><p class="tiny">${esc(profile?.source?.documentTitle||'Official NTA profile unavailable')} · Retrieved ${esc(profile?.source?.retrievedAt||'—')}</p><a href="${esc(profile?.source?.pdfUrl||'#')}" target="_blank" rel="noopener noreferrer">Open official NTA syllabus PDF ↗</a><p class="notice amber" style="margin-top:9px">Mapping status: ${esc(profile?.mapping?.status||'not loaded')}. The existing historical chapter catalogue is preserved as legacy metadata until an explicit reviewed mapping is completed. This official profile does not silently rewrite old records.</p></details>
 <details style="margin-top:12px"><summary style="cursor:pointer;color:var(--purple);font-weight:700">Module registry & current implementation boundaries</summary><div id="obs-module-registry" style="margin-top:8px"></div></details>`;
 root.appendChild(card);
 renderObservatoryRegistry(); refreshLoadoutObservatory(); renderPendingLoadoutUpdates(); renderRepairPort();
 document.getElementById('obs-refresh').onclick=()=>{refreshLoadoutObservatory();renderPendingLoadoutUpdates();};
 document.getElementById('obs-export-diagnostics').onclick=async()=>{try{const rows=await window.Loadout?.diagnostics?.read?.()||[];downloadBlob(JSON.stringify({app:'Loadout',exportedAt:new Date().toISOString(),diagnostics:rows},null,2),`loadout-diagnostics-${dateTimeISO()}.json`,'application/json');toast('Local diagnostic export created.');}catch(e){toast('Diagnostic export failed: '+e.message);}};
 document.getElementById('obs-clear-diagnostics').onclick=async()=>{if(!confirm('Delete the local diagnostic journal only? Study records, chats, test history and backups will remain untouched.'))return;await window.Loadout?.diagnostics?.clear?.();toast('Diagnostics cleared.');};
 document.getElementById('obs-export-runtime').onclick=async()=>{try{const [runtime,pending,repairs,repairHistory,diagnostics]=await Promise.all([window.Loadout?.port?.inspectRuntime?.()||{},window.Loadout?.updates?.pending?.()||[],window.Loadout?.repairs?.pending?.()||[],window.Loadout?.repairs?.journal?.()||[],window.Loadout?.diagnostics?.read?.()||[]]);downloadBlob(JSON.stringify({appId:'app.loadout.jee',exportedAt:new Date().toISOString(),runtime,pendingUpdates:pending,pendingRepairs:repairs,repairHistory,diagnosticCount:diagnostics.length,examProfile:profile?.profileId||null},null,2),`loadout-runtime-report-${dateTimeISO()}.json`,'application/json');}catch(e){toast('Runtime report failed: '+e.message);}};
 document.getElementById('obs-clear-diagnostics').disabled=!window.Loadout?.diagnostics;
 document.getElementById('loadout-update-file').addEventListener('change',stageLoadoutUpdate);
 document.getElementById('loadout-repair-file').addEventListener('change',stageLoadoutRepair);
 document.getElementById('obs-export-repair-context').onclick=exportLoadoutRepairContext;
 document.getElementById('obs-devport-refresh').onclick=refreshDevelopmentPort;
 document.getElementById('obs-cache-refresh').onclick=renderLoadoutPackageCache;
 document.getElementById('loadout-registry-file').addEventListener('change',importLoadoutRegistry);
 document.getElementById('obs-registry-reset').onclick=async()=>{if(!confirm('Discard the imported registry snapshot and return to the private catalog bundled in this APK?'))return;try{await window.Loadout.registry.resetToBundled();await refreshLoadoutObservatory();renderObservatoryRegistry();toast('Bundled private registry restored.');}catch(error){toast('Registry reset failed: '+error.message);}};
 refreshDevelopmentPort(); renderLoadoutPackageCache(); refreshLoadoutObservatory();
}
function renderObservatoryRegistry(){const root=document.getElementById('obs-module-registry');if(!root)return;const modules=window.LOADOUT_MODULE_REGISTRY||[];root.innerHTML=modules.map(m=>{const services=(m.services||[]).map(x=>`<code>${esc(x)}</code>`).join(' · ')||'none declared';const reads=(m.storageRead||[]).map(x=>`<code>${esc(x)}</code>`).join(' · ')||'none';const writes=(m.storageWrite||[]).map(x=>`<code>${esc(x)}</code>`).join(' · ')||'none';const deps=(m.dependencies||[]).map(x=>`<code>${esc(x)}</code>`).join(' · ')||'none';return `<div class="card pad" style="margin:8px 0"><div class="card-header"><div><div class="chapter-name">${esc(m.name)}</div><div class="chapter-meta">${esc(m.id)} · v${esc(m.version)} · route <code>${esc(m.route)}</code> · ${esc(m.entry)}</div></div><span class="tag">${m.offline?'OFFLINE':'NETWORK'}</span></div><div class="tiny"><b>Provides:</b> ${services}</div><div class="tiny" style="margin-top:5px"><b>Reads:</b> ${reads}</div><div class="tiny" style="margin-top:5px"><b>Writes:</b> ${writes}</div><div class="tiny" style="margin-top:5px"><b>Dependencies:</b> ${deps}</div><div class="tiny" style="margin-top:7px">${esc(m.description||'')}</div></div>`;}).join('')+'<p class="tiny" style="margin-top:8px">The registry exposes actual declared service and storage contracts. A declared feature module is not automatically a separately replaceable Android package: screen rendering still uses the legacy compatibility adapter where stated by its module description. Native implementations remain APK-bound. No public marketplace or dynamic executable hot-loading is enabled.</p>';}

async function refreshLoadoutObservatory(){if(!window.Loadout)return;try{const [status,info]=await Promise.all([window.Loadout.port.status(),window.Loadout.native.info()]);const nativeEl=document.getElementById('obs-native-status'),keyEl=document.getElementById('obs-keystore-status');if(nativeEl)nativeEl.textContent=status.native?'Available':'Web fallback';if(keyEl)keyEl.textContent=status.secureCredentials?'Available':'Unavailable';const version=document.getElementById('obs-runtime-version');if(version)version.textContent=status.runtimeApi;const count=document.getElementById('obs-cache-count');if(count)count.textContent=String(status.cachedPackageCount||0);const registryNode=document.getElementById('obs-registry-status');if(registryNode)registryNode.textContent=`${status.registry?.registryId||'Private registry'} · revision ${status.registry?.revision??'—'} · ${status.registry?.moduleCount??0} first-party modules · offline ${status.registry?.offline?'ready':'unavailable'}.`;await renderRepairPort(); }catch(e){await window.Loadout.diagnostics.record('warn','observatory-refresh-failed',{message:e.message});}}
async function refreshDevelopmentPort(){const statusNode=document.getElementById('obs-devport-status'),badge=document.getElementById('obs-devport-badge'),root=document.getElementById('obs-devport-inbox');if(!statusNode||!window.Loadout)return;try{const status=await window.Loadout.native.developmentPortStatus();if(!status.available||!status.enabled){if(badge){badge.textContent='DISABLED';badge.className='tag amber';}statusNode.textContent='Development Port is unavailable in this build. It is intentionally limited to debuggable APKs; ordinary production use has no listener or remote execution endpoint.';root.innerHTML='<div class="empty">No debug ADB/USB inbox is available in this build. You can still select a signed package using the file picker above.</div>';return;}if(badge){badge.textContent='ADB / USB READY';badge.className='tag green';}statusNode.textContent=`Paired transport: Android Debug Bridge host authorization. Inbox: ${status.inbox}. Maximum package size: ${Math.round(status.maximumPackageBytes/1024/1024)} MiB. Network listener: none. Remote execution: disabled.`;const files=await window.Loadout.port.developmentInbox();root.innerHTML=files.length?files.map(f=>`<div class="chapter-row"><div><div class="chapter-name">${esc(f.name)}</div><div class="chapter-meta">${(f.bytes/1024).toFixed(1)} KiB · ${new Date(f.modifiedAt).toLocaleString()}</div></div><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small primary" data-port-stage="${esc(f.name)}">Verify & stage</button><button class="btn small danger" data-port-delete="${esc(f.name)}">Delete</button></div></div>`).join(''):'<div class="empty">Inbox is empty. Use scripts/dev-port.mjs push to transfer an owner-signed package over an authorized USB/ADB connection.</div>';root.querySelectorAll('[data-port-stage]').forEach(button=>button.onclick=async()=>{button.disabled=true;try{const result=await window.Loadout.port.stageDevelopmentInboxPackage(button.dataset.portStage);if(result.state==='registry-imported'){toast(`Signed private registry revision ${result.revision} imported.`);await refreshLoadoutObservatory();renderObservatoryRegistry();}else if(result.repairId){toast(`Visual repair ${result.repairId} verified and staged. Review it in the Visual Repair Port.`);const repairStatus=document.getElementById('obs-repair-status');if(repairStatus)repairStatus.textContent=`${result.title} · ${result.fixCount} bounded UI fix(es) · signer ${result.signer}. Awaiting manual decision.`;await renderRepairPort();}else{toast(`Signature verified; ${result.transactionId} staged for manual review.`);await renderPendingLoadoutUpdates();await renderLoadoutPackageCache();}}catch(error){toast('Package rejected: '+error.message);await window.Loadout.diagnostics.record('warn','development-port-package-rejected',{message:error.message,filename:button.dataset.portStage});}finally{button.disabled=false;}});root.querySelectorAll('[data-port-delete]').forEach(button=>button.onclick=async()=>{if(!confirm(`Delete ${button.dataset.portDelete} from the Development Port inbox? Cached/staged packages are not affected.`))return;try{await window.Loadout.port.removeDevelopmentInboxPackage(button.dataset.portDelete);await refreshDevelopmentPort();}catch(error){toast('Delete failed: '+error.message);}});}catch(error){statusNode.textContent='Development Port status unavailable: '+error.message;root.innerHTML='<div class="empty">Could not read the native USB/ADB inbox.</div>';}}
async function renderLoadoutPackageCache(){const root=document.getElementById('obs-package-cache');if(!root||!window.Loadout)return;try{const rows=await window.Loadout.port.cachedPackages();root.innerHTML=rows.length?rows.map(row=>`<div class="chapter-row"><div><div class="chapter-name">${esc(row.updateId)}</div><div class="chapter-meta">Signer ${esc(row.signer)} · ${(Number(row.bytes||0)/1024).toFixed(1)} KiB · ${new Date(row.savedAt).toLocaleString()}</div><div class="tiny">SHA-256 ${esc(row.digest)}</div></div><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small primary" data-cache-stage="${esc(row.updateId)}">Re-stage offline</button><button class="btn small danger" data-cache-delete="${esc(row.updateId)}">Remove cache</button></div></div>`).join(''):'<div class="empty">No signed packages cached yet. Verified package imports are retained for offline re-staging.</div>';root.querySelectorAll('[data-cache-stage]').forEach(button=>button.onclick=async()=>{button.disabled=true;try{const result=await window.Loadout.port.stageCachedPackage(button.dataset.cacheStage);toast(`Cached package verified and staged as ${result.transactionId}.`);await renderPendingLoadoutUpdates();}catch(error){toast('Offline re-stage failed: '+error.message);}finally{button.disabled=false;}});root.querySelectorAll('[data-cache-delete]').forEach(button=>button.onclick=async()=>{if(!confirm(`Remove cached package ${button.dataset.cacheDelete}? This does not undo an already committed update.`))return;await window.Loadout.port.removeCachedPackage(button.dataset.cacheDelete);await renderLoadoutPackageCache();});}catch(error){root.textContent='Package cache unavailable: '+error.message;}}
async function exportLoadoutRepairContext(){try{const [runtime,repairs,diagnostics]=await Promise.all([window.Loadout?.port?.inspectRuntime?.()||{},window.Loadout?.repairs?.journal?.()||[],window.Loadout?.diagnostics?.read?.()||[]]);const context={formatVersion:'1.0',kind:'loadout-repair-context',exportedAt:new Date().toISOString(),app:{appId:'app.loadout.jee',version:'1.8.0',androidVersionCode:11,runtimeApi:'1.5.0'},runtime,modules:(window.LOADOUT_MODULE_REGISTRY||[]).map(m=>({id:m.id,name:m.name,version:m.version,route:m.route,services:m.services||[],storageRead:m.storageRead||[],storageWrite:m.storageWrite||[]})),repairHistory:repairs,diagnostics:diagnostics.slice(-100).map(row=>({at:row.at,level:row.level,event:row.event}))};downloadBlob(JSON.stringify(context,null,2),`loadout-repair-context-${dateTimeISO()}.json`,'application/json');toast('Repair Context exported. Upload it with the screenshot; diagnostic details and private study/chat contents are excluded.');}catch(error){toast('Repair Context export failed: '+error.message);}}
async function stageLoadoutRepair(event){const input=event.target,file=input.files?.[0],status=document.getElementById('obs-repair-status');if(!file||!status)return;try{if(file.size>1024*1024)throw new Error('Visual repair package exceeds 1 MiB.');if(!window.Loadout?.repairs)throw new Error('Visual Repair Port is unavailable in this build.');const pkg=JSON.parse(await file.text());const verified=await window.Loadout.repairs.verify(pkg);const staged=await window.Loadout.repairs.stage(pkg,'local-file');status.className='notice amber';status.textContent=`Verified ${verified.title} (${verified.fixCount} fix(es)) from ${verified.signer}; staged as ${staged.repairId}. Review the exact affected scopes/tokens below before committing.`;await renderRepairPort();toast('Visual repair verified and staged; nothing has changed on screen yet.');}catch(error){status.className='notice red';status.textContent='Visual repair rejected: '+error.message;await window.Loadout?.diagnostics?.record?.('warn','ui-repair-package-rejected',{message:error.message,filename:file.name});}finally{input.value='';}}
async function renderRepairPort(){const pendingRoot=document.getElementById('obs-repair-pending'),activeRoot=document.getElementById('obs-repair-active'),historyRoot=document.getElementById('obs-repair-history');if(!pendingRoot||!window.Loadout?.repairs)return;try{const [pending,history,active]=await Promise.all([window.Loadout.repairs.pending(),window.Loadout.repairs.journal(),window.Loadout.repairs.active()]);const modules=new Map((window.LOADOUT_MODULE_REGISTRY||[]).map(m=>[m.id,m.name]));const label=id=>id==='global'?'Application shell':modules.get(id)||id;pendingRoot.innerHTML=pending.length?pending.map(tx=>`<div class="card pad" style="margin:8px 0"><div class="card-header"><div><h4 style="margin:0">${esc(tx.title)}</h4><p class="sub">${esc(tx.repairId)} · signer ${esc(tx.signer)} · ${tx.fixCount} change(s)</p></div><span class="tag amber">AWAITING DECISION</span></div><p class="tiny">${esc(tx.description||'')}</p><div class="chapter-list">${tx.fixes.map(f=>`<div class="chapter-row"><div><div class="chapter-name">${esc(label(f.scope))}</div><div class="chapter-meta"><code>${esc(f.scope)}</code> · token <code>${esc(f.token)}</code> · new value <b>${esc(String(f.value))}</b></div><div class="tiny">${esc(f.reason||'No additional reason supplied.')}</div></div></div>`).join('')}</div><div class="notice" style="margin-top:8px">Staging has not changed the UI. Commit activates these scoped values; Roll Back discards this staged decision.</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button class="btn small primary" data-repair-commit="${esc(tx.repairId)}">Commit repair</button><button class="btn small danger" data-repair-rollback="${esc(tx.repairId)}">Roll Back</button></div></div>`).join(''):'<div class="empty">No pending visual repairs. A verified .lfix arrives here after local import or USB/ADB transfer.</div>';const activeRows=Object.entries(active||{}).flatMap(([scope,values])=>Object.entries(values||{}).map(([token,value])=>({scope,token,value})));activeRoot.innerHTML='<div class="tiny"><b>Currently active scoped UI tokens</b></div>'+(activeRows.length?activeRows.map(r=>`<div class="chapter-row"><div><div class="chapter-name">${esc(label(r.scope))}</div><div class="chapter-meta"><code>${esc(r.token)}</code> = <b>${esc(String(r.value))}</b></div></div><span class="tag green">ACTIVE</span></div>`).join(''):'<div class="empty">No active visual token overrides. Original design defaults are in use.</div>');historyRoot.innerHTML='<div class="tiny" style="margin:10px 0 6px"><b>Repair journal</b></div>'+(history.length?history.slice().reverse().map(r=>`<div class="chapter-row"><div><div class="chapter-name">${esc(r.title)}</div><div class="chapter-meta">${esc(r.repairId)} · ${esc(r.signer)} · ${r.fixCount} fix(es)</div></div><span class="tag">${esc(String(r.state).toUpperCase())}</span></div>`).join(''):'<div class="empty">No repair journal entries.</div>');pendingRoot.querySelectorAll('[data-repair-commit]').forEach(button=>button.onclick=async()=>{const id=button.dataset.repairCommit;if(!confirm(`Commit visual repair ${id}? This applies only the listed approved UI tokens. You can roll it back later unless a newer repair has changed the active set.`))return;button.disabled=true;try{const result=await window.Loadout.repairs.commit(id);toast(`Repair committed; ${result.applied} UI token(s) applied.`);const status=document.getElementById('obs-repair-status');if(status)status.textContent=`Repair ${id} committed. The active UI tokens are listed below.`;await renderRepairPort();}catch(error){toast('Repair commit failed: '+error.message);}finally{button.disabled=false;}});pendingRoot.querySelectorAll('[data-repair-rollback]').forEach(button=>button.onclick=async()=>{const id=button.dataset.repairRollback;if(!confirm(`Roll back or discard visual repair ${id}?`))return;button.disabled=true;try{await window.Loadout.repairs.rollback(id);toast('Visual repair rolled back.');await renderRepairPort();}catch(error){toast('Repair rollback failed: '+error.message);}finally{button.disabled=false;}});}catch(error){pendingRoot.textContent='Could not read Visual Repair Port state: '+error.message;}}
async function importLoadoutRegistry(event){const input=event.target,file=input.files?.[0],status=document.getElementById('obs-registry-status');if(!file||!status)return;try{if(file.size>10*1024*1024)throw new Error('Registry package exceeds 10 MiB.');const pkg=JSON.parse(await file.text());const result=await window.Loadout.registry.importSignedPackage(pkg);status.className='notice green';status.textContent=`Signature verified. Private registry revision ${result.revision} imported from ${result.signer}; ${result.moduleCount} bundled modules retained.`;toast('Private registry catalog updated.');await refreshLoadoutObservatory();renderObservatoryRegistry();}catch(error){status.className='notice red';status.textContent='Registry package rejected: '+error.message;await window.Loadout?.diagnostics?.record?.('warn','registry-import-rejected',{message:error.message,filename:file.name});}finally{input.value='';}}
async function renderPendingLoadoutUpdates(){const root=document.getElementById('loadout-pending-updates');if(!root||!window.Loadout)return;try{const pending=await window.Loadout.updates.pending();root.innerHTML=pending.length?pending.map(x=>{const i=x.impact||{},counts=i.counts||{},summary=Object.entries(counts).map(([k,v])=>`${k} × ${v}`).join(' · ')||'No transformations';const risks=(i.riskLevels||[]).map(v=>v.toUpperCase()).join(', ')||'none';const resources=(i.resources||[]).map(r=>`${esc(String(r.action||'').toUpperCase())} ${esc(r.namespace||'')}/${esc(r.path||'')} (${Number(r.bytes)||0} B)`).join('<br>')||`${x.resources} resource(s)`;return `<div class="card pad" style="margin-top:9px"><div class="card-header"><div><h3>${esc(x.updateId)}</h3><p class="sub">${esc(x.id)} · signer ${esc(x.signer)}</p></div><span class="tag amber">AWAITING APPROVAL</span></div><div class="notice"><b>Impact summary</b><br>${esc(summary)}<br><span class="tiny">Risk: ${esc(risks)} · ${i.operationCount||0} operation(s) · ${x.resources} resource(s) · APK required: ${i.activationRequiresApk?'yes':'no'}</span></div><div class="tiny" style="margin-top:8px">${resources}</div><div class="tiny" style="margin-top:6px">Manual decision only. No active files or user study records are changed during staging.</div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:12px"><button class="btn small primary" data-tx-commit="${esc(x.id)}">Commit</button><button class="btn small danger" data-tx-rollback="${esc(x.id)}">Roll Back</button></div></div>`;}).join(''):'<div class="empty"><strong>No pending update</strong>Staged packages appear here and require an explicit decision.</div>';root.querySelectorAll('[data-tx-commit]').forEach(b=>b.onclick=async()=>{if(!confirm(`Commit transaction ${b.dataset.txCommit}? Review the impact report above. The owner decision activates the signed data/resource changes; executable code is not hot-loaded.`))return;try{await window.Loadout.updates.commit(b.dataset.txCommit);toast('Update committed and staged resource health checks passed.');await renderPendingLoadoutUpdates();}catch(e){toast('Commit failed: '+e.message);}});root.querySelectorAll('[data-tx-rollback]').forEach(b=>b.onclick=async()=>{if(!confirm(`Roll back/discard transaction ${b.dataset.txRollback}?`))return;try{await window.Loadout.updates.rollback(b.dataset.txRollback);toast('Update rolled back.');await renderPendingLoadoutUpdates();}catch(e){toast('Rollback failed: '+e.message);}});}catch(e){root.textContent='Could not read pending transactions: '+e.message;}}
async function stageLoadoutUpdate(event){const input=event.target,file=input.files?.[0],out=document.getElementById('loadout-update-result');if(!file||!out)return;try{if(file.size>10*1024*1024)throw new Error('Update file exceeds 10 MiB import limit.');const pkg=JSON.parse(await file.text());const result=await window.Loadout.updates.stage(pkg);out.className='notice green';out.textContent=`Signature verified. Transaction ${result.transactionId} is staged; nothing has been activated. ${result.impact?.operationCount||0} LTL operation(s), ${result.impact?.resources?.length||0} resource(s). Review the impact report and choose Commit or Roll Back.`;toast('Signed update staged; manual decision required.');await renderPendingLoadoutUpdates();}catch(e){out.className='notice red';out.textContent='Update rejected: '+e.message;await window.Loadout?.diagnostics?.record?.('warn','update-import-rejected',{message:e.message,filename:file.name});}finally{input.value='';}}
function saveManualTest(e){e.preventDefault();const v=id=>document.getElementById(id).value;const type=v('f-type'),testId=v('f-id').trim()||`${type}-${Date.now()}`,date=v('f-date'),title=v('f-title').trim(),n=Number(v('f-n')),correct=Number(v('f-correct')),wrong=Number(v('f-wrong')),unattempted=Number(v('f-unattempted')),minutes=Number(v('f-minutes')||0),cid=v('f-chapter');const error=document.getElementById('formError');const module=window.LoadoutModules?.testLedger;if(!module){error.style.display='block';error.textContent='Test Ledger module is unavailable. No record was saved.';return;}let counts;try{counts=module.validateCounts({n,correct,wrong,unattempted});}catch(err){error.style.display='block';error.textContent=err.message;return;}const ch=cid?CHAP_BY_ID[cid]:null;if(type==='QCT'&&!ch){error.style.display='block';error.textContent='Choose the chapter for a chapter-wise test, so the result updates the right chapter.';return;}const f=linkedForecast(testId,type);try{const attempt=module.createAttempt({testId,date,type,title,...counts,minutes,subject:ch?ch.subject:(v('f-subject')||null),notes:v('f-notes').trim(),chapterResults:ch?[{chapterId:ch.id,n,correct,wrong,unattempted,errorCounts:{},questionErrors:[]}]:[],prediction:f?{...f,attachedAt:new Date().toISOString()}:null},state.settings,state.attempts);state.attempts.push(attempt);}catch(err){error.style.display='block';error.textContent=err.message;return;}persist();closeModal();renderCurrent();toast(f?'Result saved and prior forecast linked.':'Test result saved. Add chapter outcomes through JSON import for mixed tests.');}
function makeChapterResult(raw,defaultSubject){const name=raw.chapter??raw.chapter_name??raw.name??raw.chapterId??raw.chapter_id;const ch=CHAP_BY_ID[name]||resolveChapter(name,raw.subject||defaultSubject);if(!ch) return {error:`Could not resolve chapter “${name||'(missing)'}”. Use the exact schedule name or its ID.`};const n=Number(raw.total_questions??raw.n??raw.questions??((Number(raw.correct)||0)+(Number(raw.wrong)||0)+(Number(raw.unattempted)||0)));const c=Number(raw.correct??raw.C??0),w=Number(raw.wrong??raw.W??0),u=Number(raw.unattempted??raw.skipped??raw.U??Math.max(0,n-c-w));if(!Number.isInteger(n)||n<1||![c,w,u].every(x=>Number.isInteger(x)&&x>=0)||c+w+u!==n)return {error:`Invalid counts for ${ch.name}: C + W + U must equal N.`};const errorCounts={};const source=raw.error_counts||raw.errorCounts||raw.errors||{};Object.entries(source).forEach(([k,v])=>{const kk=mapTag(k);if(kk)errorCounts[kk]=(errorCounts[kk]||0)+(Number(v)||0)});const questionErrors=(raw.question_errors||raw.questionErrors||[]).map(normalizeQuestionError).filter(Boolean);if(Array.isArray(raw.error_categories))raw.error_categories.forEach(tag=>{const k=mapTag(tag);if(k)errorCounts[k]=(errorCounts[k]||0)+1});return {chapterId:ch.id,n,correct:c,wrong:w,unattempted:u,errorCounts,questionErrors,notes:raw.notes||'',topics:raw.topics||raw.topic||null};}
function mapTag(value){const n=norm(value);const lookup={conceptual:'conceptual','conceptual model':'conceptual',recall:'recall','memory / recall':'recall','application':'application','application mechanism':'application','mechanism':'application','comparison':'comparison','comparison order':'comparison','ordering':'comparison','calculation':'calculation','arithmetic':'calculation','careless':'careless','careless reading':'careless','reading':'careless','time':'time','time selection':'time','time management':'time','unclassified':'unclassified','unknown':'unclassified'};return lookup[n]||null}
function normalizeQuestionError(raw){if(!raw||typeof raw!=='object')return null;const ch=resolveChapter(raw.chapter||raw.chapter_name,raw.subject);const outcome=norm(raw.outcome||raw.status);const cat=mapTag(raw.category||raw.error_category||raw.reason)||'unclassified';return {chapterId:ch?ch.id:null,topic:raw.topic||null,outcome:['wrong','incorrect','error'].includes(outcome)?'wrong':['unattempted','skipped','not attempted'].includes(outcome)?'unattempted':outcome||'unknown',category:cat,timeSeconds:Number(raw.time_seconds??raw.timeSeconds)||null,notes:raw.notes||''}}
function normalizeSubjectResults(raw){if(!Array.isArray(raw))return [];const out=[];raw.forEach(x=>{if(!x||typeof x!=='object')return;const subject=SUBJECTS.find(s=>s.toLowerCase()===String(x.subject||x.name||'').toLowerCase());if(!subject)return;const n=Number(x.total_questions??x.n??x.questions??0);const c=Number(x.correct??x.C??0),w=Number(x.wrong??x.W??0),u=Number(x.unattempted??x.skipped??x.U??Math.max(0,n-c-w));if(Number.isInteger(n)&&n>0&&[c,w,u].every(v=>Number.isInteger(v)&&v>=0)&&c+w+u===n)out.push({subject,n,correct:c,wrong:w,unattempted:u,score:scoreOf(c,w),maxMarks:n*state.settings.correctMarks});});return out;}
function normalizeTest(raw,force=false){if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('Each test must be a JSON object.');const testId=String(raw.test_id??raw.testId??raw.id??'').trim();if(!testId)throw new Error('Each test needs a unique test_id.');if(/^(REPLACE|EXAMPLE|PLACEHOLDER)/i.test(testId))throw new Error('Replace the placeholder test_id with the real test ID before importing. Example data is never stored as a real result.');const date=String(raw.date??raw.attempt_date??dateTimeISO()).slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(date))throw new Error(`Invalid date for ${testId}. Use YYYY-MM-DD.`);let type=String(raw.test_type??raw.type??'OTHER').toUpperCase();if(type==='CHAPTERWISE'||type==='CHAPTER')type='QCT';if(type==='PART'||type==='PART TEST')type='QPT';if(type==='FULL'||type==='FULL TEST')type='QFT';if(!['QCT','QPT','QFT','HFT','OTHER'].includes(type))type='OTHER';const correct=Number(raw.correct??raw.C??0),wrong=Number(raw.wrong??raw.W??0),n=Number(raw.total_questions??raw.n??raw.questions??((Number(raw.correct)||0)+(Number(raw.wrong)||0)+(Number(raw.unattempted)||0))),unattempted=Number(raw.unattempted??raw.skipped??raw.U??Math.max(0,n-correct-wrong));if(!Number.isInteger(n)||n<1||!Number.isInteger(correct)||!Number.isInteger(wrong)||!Number.isInteger(unattempted)||[correct,wrong,unattempted].some(x=>x<0)||correct+wrong+unattempted!==n)throw new Error(`Invalid C/W/U counts for ${testId}. Require C + W + U = total_questions.`);const subject=raw.subject&&SUBJECTS.some(s=>s.toLowerCase()===String(raw.subject).toLowerCase())?SUBJECTS.find(s=>s.toLowerCase()===String(raw.subject).toLowerCase()):null;let chapterResults=[];for(const r of (raw.chapter_results||raw.chapterResults||[])){const x=makeChapterResult(r,subject);if(x.error)throw new Error(`${testId}: ${x.error}`);chapterResults.push(x);}const topChapter=raw.chapter_id||raw.chapterId||raw.chapter||raw.chapter_name;if(topChapter&&!chapterResults.length){const x=makeChapterResult({chapter:topChapter,total_questions:n,correct,wrong,unattempted,error_counts:raw.error_counts||raw.errorCounts,question_errors:raw.question_errors||raw.questionErrors,notes:raw.notes},subject);if(x.error)throw new Error(`${testId}: ${x.error}`);chapterResults.push(x);}const errors=(raw.question_errors||raw.questionErrors||[]).map(normalizeQuestionError).filter(Boolean);errors.forEach(err=>{if(err.chapterId){const target=chapterResults.find(r=>r.chapterId===err.chapterId);if(target){target.questionErrors=target.questionErrors||[];target.questionErrors.push(err);}}});const subjectResults=normalizeSubjectResults(raw.subject_results||raw.subjectResults||[]);return {id:String(raw.record_id||raw.recordId||testId),testId,date,type,title:String(raw.title??raw.name??testId),n,correct,wrong,unattempted,minutes:Number(raw.duration_min??raw.minutes??raw.time_taken_min)||null,score:scoreOf(correct,wrong),maxMarks:n*state.settings.correctMarks,subject,notes:String(raw.notes||''),chapterResults,questionErrors:errors,subjectResults,prediction:null,createdAt:new Date().toISOString()};}
function importJSON(text){const result=document.getElementById('importResult');try{const parsed=JSON.parse(text);const rows=Array.isArray(parsed)?parsed:(Array.isArray(parsed.tests)?parsed.tests:[parsed]);if(!rows.length)throw new Error('No test objects found.');const normalized=rows.map(x=>normalizeTest(x));const seen=new Set(state.attempts.filter(a=>a.score!=null).map(a=>String(a.testId).toUpperCase()));const dup=normalized.filter(a=>seen.has(a.testId.toUpperCase()));const batchIds=normalized.map(a=>a.testId.toUpperCase());const repeated=batchIds.filter((id,i)=>batchIds.indexOf(id)!==i);if(dup.length||repeated.length)throw new Error(`Duplicate test_id(s) detected: ${[...new Set([...dup.map(a=>a.testId),...repeated])].join(', ')}. Use unique attempt IDs or remove duplicates from the import.`);normalized.forEach(a=>{const f=linkedForecast(a.testId,a.type);if(f)a.prediction={...f,attachedAt:new Date().toISOString()};});state.attempts.push(...normalized);persist();importText=text;result.innerHTML=`<div class="notice green"><b>Imported ${normalized.length} test${normalized.length===1?'':'s'} successfully.</b><br>Saved ${normalized.reduce((s,a)=>s+a.chapterResults.length,0)} chapter-level result row(s). Total scores calculated by Loadout. ${normalized.reduce((s,a)=>s+(a.chapterResults.some(r=>r.errorCounts&&Object.keys(r.errorCounts).length)?1:0),0)} or more diagnostic records may include error tags; unprovided diagnoses remain unknown.</div>`;toast(`Imported ${normalized.length} test record(s).`);renderDashboard();}catch(e){result.innerHTML=`<div class="notice red"><b>Import rejected — no records were added.</b><br>${esc(e.message||String(e))}</div>`;}}
function saveSettings(){const alpha=Number(document.getElementById('s-alpha').value),prior=Number(document.getElementById('s-prior').value),qn=Number(document.getElementById('s-questions').value),qctn=Number(document.getElementById('s-qctn').value),qcttime=Number(document.getElementById('s-qcttime').value);if(!(alpha>=.05&&alpha<=1)||!(prior>=0&&prior<=10)||!(Number.isInteger(qn)&&qn>=1&&qn<=200)||!(Number.isInteger(qctn)&&qctn>=1&&qctn<=100)||!(Number.isFinite(qcttime)&&qcttime>0&&qcttime<=300)){toast('One or more settings are outside the allowed range.');return;}state.settings.alpha=alpha;state.settings.priorStrength=prior;state.settings.blockQuestions=qn;state.settings.defaultQCTQuestions=qctn;state.settings.defaultQCTMinutes=qcttime;persist();renderData();toast('Settings saved. All derived estimates now use the new settings.');}
function saveForecast(id){const type=id.startsWith('QPT')?'QPT':'QFT';const p=predict(type,id);if(!p)return;const existing=state.forecasts.findIndex(f=>f.testId===id&&f.type===type);const forecast={id:`forecast-${id}`,testId:id,type,date:p.sched.date,title:p.sched.name,savedOn:dateTimeISO(),raw:p.raw,calibrated:p.calibrated,lower:p.lower,upper:p.upper,half:p.half,confidence:p.confidence,covered:p.covered,totalChapters:p.chapters.length,chapterIds:p.chapters.map(x=>x.chapter.id),questionCount:p.questionCount,calibration:{n:p.calibration.n,method:p.calibration.method},assumptions:'Equal chapter weight for QPT; core-chapter average for QFT. QCT records update chapter mastery.'};if(existing>=0)state.forecasts[existing]=forecast;else state.forecasts.push(forecast);persist();renderForecasts();toast('Forecast snapshot saved. Log the result under the same ID to grade it.');}
async function exportJSON(){try{await flushPersistedState();await window.Loadout?.storage?.flush?.();const {createBackup}=await import('./runtime/backup-manager.mjs');const out=await createBackup({settings:state.settings,attempts:state.attempts,forecasts:state.forecasts,chat:window.exportLoadoutChatData?window.exportLoadoutChatData():null,examProfileId:'jee-main-2027-paper-1'},{sourceAppVersion:'1.8.0',sourceSchedule:'Most Relevant JEE Main 2027 Test Series — October Batch (Droppers)'});await downloadBlob(JSON.stringify(out,null,2),`loadout-jee-2027-backup-${dateTimeISO()}.json`,'application/json');toast('Integrity-checked backup exported. Provider credentials are excluded; API keys remain device-local.');}catch(error){toast('Backup export failed: '+error.message);window.Loadout?.diagnostics?.record?.('error','backup-export-failed',{message:error.message});}}
async function downloadBlob(content,name,type){if(window.Loadout?.native?.saveFileBase64){try{const bytes=new TextEncoder().encode(String(content));let binary='';for(let i=0;i<bytes.length;i+=0x6000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x6000));const result=await window.Loadout.native.saveFileBase64(name,type,btoa(binary));if(result?.ok){toast(`Saved ${name} to ${result.location||'Downloads/Loadout'}.`);return;}if(window.Loadout.native.available){toast('Android file export is unavailable in this build.');return;}}catch(err){console.error('Native export failed',err);toast('Native export failed: '+(err.message||'unknown error'));return;}}const b=new Blob([content],{type});const url=URL.createObjectURL(b);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function exportCSV(){const cols=['test_id','date','type','title','total_questions','correct','wrong','unattempted','score','max_marks','minutes','subject','predicted_raw','prediction_residual','chapter_results'];const rows=[cols,...state.attempts.map(a=>[a.testId,a.date,a.type,a.title,a.n,a.correct,a.wrong,a.unattempted,a.score,a.maxMarks,a.minutes,a.subject||'',a.prediction?.raw??'',a.score!=null&&a.prediction?a.score-a.prediction.raw:'',(a.chapterResults||[]).map(r=>`${CHAP_BY_ID[r.chapterId]?.name||r.chapterId}:${r.correct}/${r.wrong}/${r.unattempted}`).join(';')])];const csv=rows.map(row=>row.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\r\n');downloadBlob('\ufeff'+csv,`loadout-jee-2027-ledger-${dateTimeISO()}.csv`,'text/csv;charset=utf-8');toast('CSV exported.');}
function restoreFile(){document.getElementById('restoreFile').click();}
function restoreFileHandler(){
 const fileInput=document.getElementById('restoreFile');if(!fileInput)return;
 fileInput.onchange=async e=>{
  const file=e.target.files&&e.target.files[0];if(!file)return;
  try{
   if(file.size>30*1024*1024)throw new Error('Backup exceeds the 30 MiB import limit.');
   const {validateBackup}=await import('./runtime/backup-manager.mjs');
   const backup=await validateBackup(JSON.parse(await file.text()));
   window.pendingLoadoutRestore=backup;
   const panel=document.getElementById('restore-preview');
   if(!panel)throw new Error('Restore preview panel is unavailable.');
   panel.style.display='block';
   panel.innerHTML=`<div class="card-header"><div><h3 style="margin:0">Backup validated</h3><p class="sub">Schema ${backup.schemaVersion} · ${backup.integrityVerified?'SHA-256 integrity verified':'Legacy backup; no checksum was available'} · ${esc(backup.exportedAt||'Export date unknown')}</p></div><span class="tag green">READY</span></div><div class="forecast-scale"><div class="scale-item"><small>TEST ATTEMPTS</small><strong>${backup.attempts.length}</strong></div><div class="scale-item"><small>FORECASTS</small><strong>${backup.forecasts.length}</strong></div><div class="scale-item"><small>CHAT CONVERSATIONS</small><strong>${backup.chat?.conversations?.length||(backup.chat?.messages?.length?1:0)||0}</strong></div></div><p class="sub">Choose whether to replace existing study records or merge imported attempts and forecasts. Provider credentials are never imported. A verified pre-restore snapshot is saved before changes.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary small" id="restore-replace" type="button">Replace current records</button><button class="btn small" id="restore-merge" type="button">Merge with current records</button><button class="btn small" id="restore-cancel" type="button">Cancel</button></div><div id="restore-progress" class="tiny" style="margin-top:9px"></div>`;
   document.getElementById('restore-replace').onclick=()=>applyPendingRestore('replace');
   document.getElementById('restore-merge').onclick=()=>applyPendingRestore('merge');
   document.getElementById('restore-cancel').onclick=()=>{window.pendingLoadoutRestore=null;panel.style.display='none';panel.innerHTML='';};
  }catch(error){toast('Restore validation failed: '+error.message);window.Loadout?.diagnostics?.record?.('warn','backup-validation-failed',{message:error.message});}
  finally{e.target.value='';}
 };
}
async function applyPendingRestore(mode){
 const backup=window.pendingLoadoutRestore;if(!backup)return;
 const panel=document.getElementById('restore-preview');const progress=document.getElementById('restore-progress');
 const previousState=structuredClone(state);const previousChat=window.exportLoadoutChatData?window.exportLoadoutChatData():null;
 const chatIncluded=!!backup.chat;const action=mode==='replace'?'replace':'merge';
 if(!confirm(`${action.toUpperCase()} ${backup.attempts.length} imported attempts and ${backup.forecasts.length} forecasts? ${mode==='replace'?'Current study records will be replaced.':'Existing records will be retained and matching IDs updated.'} A pre-restore snapshot will be verified first. ${chatIncluded?'Included chat history will also be restored.':'Existing chat history will remain unchanged.'} Credentials are never imported.`))return;
 try{
  if(progress)progress.textContent='Creating and verifying pre-restore snapshot…';
  const {createBackup,applyBackupToState,mergeChatBackup,verifyBackupReadback}=await import('./runtime/backup-manager.mjs');
  const snapshot=await createBackup({settings:previousState.settings,attempts:previousState.attempts,forecasts:previousState.forecasts,chat:previousChat,examProfileId:'jee-main-2027-paper-1'},{sourceAppVersion:'1.8.0',sourceSchedule:'Pre-restore safety snapshot'});
  const snapshotJson=JSON.stringify(snapshot);const snapshotId='pre-restore-'+Date.now();
  let snapshotStored=false;
  if(window.Loadout?.storage){
   const store=await window.Loadout.storage.create({namespace:'backups',name:snapshotId,lifetime:'persistent'});
   await store.set(snapshot);
   await window.Loadout.storage.flush();
   const check=await store.get();
   if(!check)throw new Error('Private pre-restore snapshot is missing after write. Restore was not applied.');
   await verifyBackupReadback(snapshot,check);
   snapshotStored=true;
  }else{
   const key='loadout.'+snapshotId;localStorage.setItem(key,snapshotJson);
   if(localStorage.getItem(key)!==snapshotJson)throw new Error('Browser pre-restore snapshot did not verify. Restore was not applied.');
   const index=JSON.parse(localStorage.getItem('loadout-pre-restore-index')||'[]');index.push(key);localStorage.setItem('loadout-pre-restore-index',JSON.stringify(index.slice(-50)));snapshotStored=true;
  }
  if(!snapshotStored)throw new Error('No verified pre-restore snapshot was created.');
  if(progress)progress.textContent='Applying validated records…';
  state=applyBackupToState(previousState,backup,mode);
  if(chatIncluded){const nextChat=mode==='merge'?mergeChatBackup(previousChat,backup.chat):backup.chat;window.importLoadoutChatData(nextChat);}
  if(!persist())throw new Error('Study state could not be written to local storage.');
  await window.Loadout?.storage?.flush?.();
  if(window.Loadout?.storage){const store=await window.Loadout.storage.create({namespace:'legacy',name:'main-state',lifetime:'persistent'});const mirror=await store.get();if(!mirror||stableJson(mirror)!==stableJson(state))throw new Error('Restored state failed exact app-private mirror verification.');}
  window.pendingLoadoutRestore=null;if(panel){panel.style.display='none';panel.innerHTML='';}
  renderCurrent();toast(`Backup ${mode==='replace'?'restored':'merged'} successfully. Pre-restore snapshot retained as ${snapshotId}.`);
  await window.Loadout?.diagnostics?.record?.('recovery','backup-restore-completed',{mode,attempts:state.attempts.length,forecasts:state.forecasts.length,chatIncluded,snapshotId,schemaVersion:backup.schemaVersion});
 }catch(error){
  state=previousState;
  if(previousChat&&window.importLoadoutChatData){try{window.importLoadoutChatData(previousChat);}catch(rollbackError){window.Loadout?.diagnostics?.record?.('error','chat-restore-compensation-failed',{message:rollbackError.message});}}
  const compensationSaved=persist();try{await window.Loadout?.storage?.flush?.();}catch(flushError){window.Loadout?.diagnostics?.record?.('error','restore-compensation-flush-failed',{message:flushError.message});}
  if(!compensationSaved)error.rollbackPersistenceFailed=true;
  if(progress)progress.textContent=(error.rollbackPersistenceFailed?'Restore failed and the previous state could not be durably re-saved. Export or recover the verified pre-restore snapshot. ':'Restore failed; previous state was reinstated. ')+error.message;
  window.Loadout?.diagnostics?.record?.('error','backup-restore-failed',{mode,message:error.message});
  toast('Restore failed: '+error.message);
 }
}
async function renderBackupSnapshots(){
 const root=document.getElementById('restore-snapshots');if(!root)return;
 root.innerHTML='<div class="tiny">Checking verified local snapshots…</div>';
 try{
  const names=(await window.Loadout?.storage?.list?.('backups')||[]).filter(name=>/^pre-restore-\d+$/.test(name)).sort((a,b)=>Number(b.slice(12))-Number(a.slice(12)));
  if(!names.length){root.innerHTML='<div class="empty"><strong>No safety snapshots yet</strong>A snapshot is created automatically before the next restore.</div>';return;}
  const rows=[];
  for(const name of names){
   try{const store=await window.Loadout.storage.create({namespace:'backups',name,lifetime:'persistent'});const item=await store.get();if(!item)continue;const {validateBackup}=await import('./runtime/backup-manager.mjs');const checked=await validateBackup(item);if(!checked.integrityVerified)continue;rows.push({name,backup:checked});}catch(error){window.Loadout?.diagnostics?.record?.('warn','backup-snapshot-invalid',{name,message:error.message});}
  }
  root.innerHTML=rows.length?rows.map(row=>`<div class="chapter-row"><div><div class="chapter-name">${esc(row.backup.exportedAt||row.name)}</div><div class="chapter-meta">${row.backup.attempts.length} attempts · ${row.backup.forecasts.length} forecasts · checksum verified</div></div><button class="btn small" type="button" data-action="restore-snapshot" data-id="${esc(row.name)}">Review restore</button></div>`).join(''):'<div class="empty"><strong>No valid safety snapshots</strong>Stored snapshot files were missing or failed integrity verification.</div>';
 }catch(error){root.innerHTML=`<div class="notice amber">Could not list local safety snapshots: ${esc(error.message)}</div>`;}
}
async function restoreSavedSnapshot(name){
 if(!/^pre-restore-\d+$/.test(String(name||'')))return;
 try{
  const store=await window.Loadout.storage.create({namespace:'backups',name,lifetime:'persistent'});const payload=await store.get();
  const {validateBackup}=await import('./runtime/backup-manager.mjs');const backup=await validateBackup(payload);
  if(!backup.integrityVerified)throw new Error('This snapshot does not have a verifiable integrity checksum.');
  window.pendingLoadoutRestore=backup;
  const panel=document.getElementById('restore-preview');if(!panel)throw new Error('Restore preview panel is unavailable.');
  panel.style.display='block';panel.innerHTML=`<div class="card-header"><div><h3 style="margin:0">Safety snapshot verified</h3><p class="sub">${esc(backup.exportedAt||name)} · SHA-256 checksum verified</p></div><span class="tag green">VERIFIED</span></div><p class="sub">${backup.attempts.length} attempts and ${backup.forecasts.length} forecasts will replace the current study records. The current state will first be snapshotted again.</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn primary small" id="restore-snapshot-apply" type="button">Restore this snapshot</button><button class="btn small" id="restore-snapshot-cancel" type="button">Cancel</button></div><div id="restore-progress" class="tiny" style="margin-top:9px"></div>`;
  document.getElementById('restore-snapshot-apply').onclick=()=>applyPendingRestore('replace');
  document.getElementById('restore-snapshot-cancel').onclick=()=>{window.pendingLoadoutRestore=null;panel.style.display='none';panel.innerHTML='';};
 }catch(error){toast('Safety snapshot could not be opened: '+error.message);window.Loadout?.diagnostics?.record?.('error','backup-snapshot-restore-open-failed',{name,message:error.message});}
}
function resetAll(){if(!confirm('Delete ALL test history, forecasts, and settings stored by Loadout in this browser? Export a backup first.'))return;if(!confirm('Final confirmation: this cannot be undone. Continue?'))return;state=structuredClone(DEFAULTS);persist();renderCurrent();toast('Local records reset.');}
function copyText(text){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(text).then(()=>toast('Copied to clipboard.')).catch(()=>fallbackCopy(text));else fallbackCopy(text)}function fallbackCopy(text){const t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();try{document.execCommand('copy');toast('Copied.')}catch(e){toast('Copy failed; select and copy manually.')}t.remove()}
function openChapterDetail(id){const c=CHAP_BY_ID[id];if(!c)return;const s=chapterStats(c);document.getElementById('detailTitle').textContent=c.name;document.getElementById('detailSubtitle').textContent=`${c.subject} · ${c.tests} planned QCTs · ${c.status==='extra'?'Beyond JEE Main (starred in source)':c.status==='support'?'Support topic':'Core catalog row'}`;const errorHtml=TAGS.map(t=>`<div class="bar-row"><div class="bar-name">${TAG_LABELS[t]}</div><div class="progress"><span style="width:${Math.min(100,(s.errorMap[t]||0)*20)}%;background:${(s.errorMap[t]||0)?'var(--amber)':'#526078'}"></span></div><div class="bar-value">${s.errorMap[t]||0}</div></div>`).join('');document.getElementById('detailBody').innerHTML=`<div class="grid stats" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="stat-card card"><div class="stat-label">Mastery index</div><div class="stat-value">${s.mastery==null?'—':fmt(s.mastery,1)}</div><div class="stat-foot">${s.confidence} evidence</div></div><div class="stat-card card"><div class="stat-label">Completed QCTs</div><div class="stat-value">${s.count}<span class="muted" style="font-size:13px"> / ${c.tests}</span></div><div class="stat-foot">${s.transferCount} mixed-test observations, separately weighted</div></div><div class="stat-card card"><div class="stat-label">Raw mean</div><div class="stat-value">${s.rawAvg==null?'—':fmt(s.rawAvg,1)}</div><div class="stat-foot">Scaled net marks per test</div></div><div class="stat-card card"><div class="stat-label">Consistency σ</div><div class="stat-value">${s.sd==null?'—':fmt(s.sd,1)}</div><div class="stat-foot">Sample standard deviation in pp</div></div></div><div class="card pad" style="margin-top:13px"><div class="card-header"><div><h2>Last attempts</h2><p class="sub">Chronological result history for this chapter</p></div><button class="btn small" data-action="log-chapter" data-id="${c.id}">＋ Log QCT</button></div>${s.attempts.length?`<div class="table-wrap"><table><thead><tr><th>Test / date</th><th>C/W/U</th><th>Score</th><th>Scaled</th><th>Time</th></tr></thead><tbody>${s.attempts.slice().reverse().map(a=>`<tr><td>${esc(a.title||a.testId)}<div class="tiny">${dateFmt(a.date)}</div></td><td>${a.correct}/${a.wrong}/${a.unattempted}</td><td>${scoreOf(a.correct,a.wrong)} / ${a.n*state.settings.correctMarks}</td><td>${fmt(a.scaled,1)}</td><td>${a.minutes??'—'} min</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><strong>No attempts logged</strong>Log a QCT or import a chapter-level result.</div>`}</div><div class="card pad" style="margin-top:13px"><div class="card-header"><div><h2>Error profile</h2><p class="sub">Only explicit imported classifications count as classified errors.</p></div></div><div class="bar-list">${errorHtml}</div><div class="divider"></div><div class="notice">Estimated uncorrected loss: <b>${s.count?fmt(s.lost,0):'—'} marks</b> across recorded attempts, where wrong answers cost 5 marks relative to correct and unattempted questions cost 4. This is historical opportunity cost, not a guaranteed recoverable amount.</div></div>`;document.getElementById('detailModal').classList.add('open')}
function openTestDetail(id){const a=state.attempts.find(x=>x.id===id);if(!a)return;document.getElementById('detailTitle').textContent=a.title||a.testId;document.getElementById('detailSubtitle').textContent=`${a.testId} · ${a.type} · ${dateFmt(a.date)}`;document.getElementById('detailBody').innerHTML=`<div class="grid stats" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="stat-card card"><div class="stat-label">Net score</div><div class="stat-value">${a.score==null?'Pending':fmt(a.score,0)}</div><div class="stat-foot">${a.score==null?'Forecast only':`${a.maxMarks} max marks`}</div></div><div class="stat-card card"><div class="stat-label">Correct / wrong / unattempted</div><div class="stat-value">${a.score==null?'—':`${a.correct}/${a.wrong}/${a.unattempted}`}</div><div class="stat-foot">${a.n} total questions · ${a.minutes??'—'} min</div></div></div><div class="card pad" style="margin-top:13px"><h2>Prediction record</h2>${a.prediction?`<div class="forecast-scale"><div class="scale-item"><small>RAW PREDICTION</small><strong>${fmt(a.prediction.raw,1)}</strong></div><div class="scale-item"><small>ACTUAL</small><strong>${a.score==null?'Pending':fmt(a.score,0)}</strong></div><div class="scale-item"><small>RESIDUAL</small><strong>${a.score==null?'—':fmt(a.score-a.prediction.raw,1)}</strong></div></div>`:`<p class="sub" style="margin-top:10px">No pre-test forecast attached. This result updates chapter estimates only, if chapter-level rows are available.</p>`}</div>${a.score!=null?`<div class="notice amber" style="margin-top:13px"><b>Theoretical score ceiling: ${fmt(Math.min(a.maxMarks,a.score+5*a.wrong+4*a.unattempted),0)} / ${a.maxMarks}</b> if every wrong and unattempted question had instead become correct. This is an opportunity-cost ceiling, not a realistic forecast of recoverable marks.</div>`:''}<div class="card pad" style="margin-top:13px"><div class="card-header"><div><h2>Chapter-level data</h2><p class="sub">Imported data supplied to the mathematical engine</p></div></div>${a.chapterResults?.length?`<div class="table-wrap"><table><thead><tr><th>Chapter</th><th>C/W/U</th><th>Score</th><th>Scaled</th><th>Error tags</th></tr></thead><tbody>${a.chapterResults.map(r=>`<tr><td>${esc(CHAP_BY_ID[r.chapterId]?.name||r.chapterId)}</td><td>${r.correct}/${r.wrong}/${r.unattempted}</td><td>${scoreOf(r.correct,r.wrong)}/${r.n*state.settings.correctMarks}</td><td>${fmt(scorePercent(scoreOf(r.correct,r.wrong),r.n),1)}</td><td>${Object.entries(r.errorCounts||{}).filter(([,n])=>n).map(([tag,n])=>`${esc(TAG_LABELS[tag]||tag)}: ${n}`).join('<br>')||'Not classified'}</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><strong>No chapter-level breakdown attached</strong>For a mixed test, re-import with chapter_results if you know the actual chapter allocation. Avoid guessing it.</div>`}</div>${a.subjectResults&&a.subjectResults.length?`<div class="card pad" style="margin-top:13px"><h2>Subject split</h2><div class="forecast-scale">${a.subjectResults.map(sr=>`<div class="scale-item"><small>${esc(sr.subject.toUpperCase())}</small><strong>${fmt(sr.score,0)} / ${sr.maxMarks}</strong><small>${sr.correct}C · ${sr.wrong}W · ${sr.unattempted}U</small></div>`).join('')}</div></div>`:''}${a.notes?`<div class="notice" style="margin-top:13px">${esc(a.notes)}</div>`:''}<div class="modal-footer"><button class="btn danger" data-action="delete-test" data-id="${a.id}">Delete record</button><button class="btn" id="detailDone">Close</button></div>`;document.getElementById('detailModal').classList.add('open');const d=document.getElementById('detailDone');if(d)d.addEventListener('click',()=>document.getElementById('detailModal').classList.remove('open'))}
function deleteTest(id){const a=state.attempts.find(x=>x.id===id);if(!a)return;if(!confirm(`Delete test record “${a.title||a.testId}”? This also removes its contribution to historical estimates.`))return;const module=window.LoadoutModules?.testLedger;if(!module){toast('Test Ledger module is unavailable. Nothing was deleted.');return;}const result=module.removeAttempt(state.attempts,id);if(!result.removed)return;state.attempts=result.attempts;persist();document.getElementById('detailModal').classList.remove('open');renderCurrent();toast('Test record deleted.');}
document.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(!el)return;const action=el.dataset.action,id=el.dataset.id;if(action==='log')openTestModal();else if(action==='import')switchView('data');else if(action==='forecast')switchView('forecasts');else if(action==='tests')switchView('tests');else if(action==='chapters')switchView('chapters');else if(action==='forecast-schedule'){forecastType=id.startsWith('QPT')?'QPT':'QFT';forecastId=id;switchView('forecasts');}else if(action==='save-forecast')saveForecast(id);else if(action==='log-schedule'){const s=getSchedule(id.startsWith('QPT')?'QPT':'QFT',id);openTestModal(s);}else if(action==='chapter-detail')openChapterDetail(id);else if(action==='log-chapter'){const c=CHAP_BY_ID[id];document.getElementById('detailModal').classList.remove('open');openTestModal();document.getElementById('f-chapter').value=id;document.getElementById('f-type').value='QCT';document.getElementById('f-title').value=`${c.name} — Test ${chapterStats(c).count+1}`;document.getElementById('f-n').value=state.settings.defaultQCTQuestions;document.getElementById('f-unattempted').value=state.settings.defaultQCTQuestions;}else if(action==='test-detail')openTestDetail(id);else if(action==='delete-test')deleteTest(id);else if(action==='history-topic'){const c=historyChapterByNumber(historyChapterNumber);const topic=c?.topics?.[Number(el.dataset.index)];if(topic){historyTopicName=topic.name;renderHistorical();}}else if(action==='history-chapter'){historyChapterNumber=Number(id);historyTopicName='';switchView('historical');}else if(action==='export')exportJSON();else if(action==='export-csv')exportCSV();else if(action==='restore-file')restoreFile();else if(action==='refresh-snapshots')renderBackupSnapshots();else if(action==='restore-snapshot')restoreSavedSnapshot(id);});
window.loadoutHandleNativeBack=function(){const modal=document.getElementById('detailModal');if(modal&&modal.classList.contains('open')){modal.classList.remove('open');return true;}if(currentView!=='dashboard'){switchView('dashboard');return true;}return false;};
window.LoadoutLegacyStateSnapshot=()=>JSON.parse(JSON.stringify(state));
window.LoadoutLegacyViews=Object.freeze({dashboard:renderDashboard,chapters:renderChapters,historical:renderHistorical,tests:renderTests,forecasts:renderForecasts,dataSettings:renderData,renderAiCoach:renderChatbot});
function init(){if(window.Loadout?.native?.available){document.documentElement.classList.add('native-app','loadout-recovery-pending');const b=document.getElementById('installApp');if(b)b.style.display='none';}navWiring();initModal();document.getElementById('f-type').dispatchEvent(new Event('change'));window.LoadoutFeatureRuntime?.initialize({legacy:window.LoadoutLegacyViews});renderCurrent();hydrateLegacyPrivateState().then(async()=>{if(!mainStateRecoveryGate.status().blocked&&window.LoadoutDatabase){try{const raw=localStorage.getItem(STORAGE_KEY);await window.LoadoutDatabase.bootstrap(state,raw);await window.LoadoutDatabase.verify();window.Loadout?.diagnostics?.record?.('info','structured-database-bootstrap-complete',{schemaVersion:window.LoadoutDatabase.schemaVersion,attempts:state.attempts.length,forecasts:state.forecasts.length});if(currentView==='data')window.LoadoutDatabase.attachSettingsPanel();}catch(error){window.Loadout?.diagnostics?.record?.('warn','structured-database-bootstrap-failed',{message:error.message});}}});const installBtn=document.getElementById('installApp');if(installBtn)installBtn.addEventListener('click',async()=>{if(!installPromptEvent){toast('To install, open the hosted HTTPS page in your browser menu and choose Install app / Add to Home screen.');return;}installPromptEvent.prompt();const choice=await installPromptEvent.userChoice;installPromptEvent=null;installBtn.style.display='none';if(choice&&choice.outcome==='accepted')toast('Installation started.');});if('serviceWorker'in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./sw.js').then(()=>{}).catch(e=>console.warn('Service worker unavailable',e));}
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPromptEvent=event;const button=document.getElementById('installApp');if(button)button.style.display='inline-flex';});window.addEventListener('appinstalled',()=>{const button=document.getElementById('installApp');if(button)button.style.display='none';installPromptEvent=null;});
/* AI Coach is registered before app initialization below. */

/* ========== AI Coach · Step 0.75.5 ========== */
const AI_COACH = window.LoadoutModules?.aiCoach;
if (!AI_COACH) throw new Error('Loadout AI Coach feature module did not load.');
const CHAT_STORAGE_KEY = 'loadout_chat_v4';
const PREVIOUS_CHAT_KEYS = ['loadout_chat_v3', 'loadout_chat_v2', 'loadout_chat_v1', 'loadout_chat_keystore_pending_v1'];
const CHAT_MIRROR_NAME = 'chat-state-v4';
const CHAT_CORRUPT_MARKER_KEY = 'loadout_chat_corrupt_quarantine_v1';
const CHAT_PROVIDER_ORDER = [...AI_COACH.providerIds];
const CHAT_PROVIDERS = AI_COACH.providers;
const DEFAULT_SYSTEM = AI_COACH.defaultSystemPrompt;
const sessionChatSecrets = new Map();
const secureChatSecrets = new Set();
const secureChatOrigins = new Map();
const unboundChatSecrets = new Set();
let chatSourceKey = null;
let chatCorruptRaw = null;
let chatCorruptSourceKey = null;
let chatCorruptArchives = [];
let chatCorruptQuarantineVerified = false;
let chatCorruptExportedThisSession = false;
let chatCorruptExportConfirmed = false;
let chatState = loadChatState();
let chatMigrationReady = false;
let chatMigrationNotice = 'Checking local conversation history and secure credential storage…';
let chatSaveChain = Promise.resolve();
let activeChatRequest = null;

function chatId(prefix='id') {
  return `${prefix}-${globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,12)}`}`;
}
function stableChatJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stableChatJson).join(',') + ']';
  return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stableChatJson(value[key])).join(',') + '}';
}
function rememberCorruptChatRecord(sourceKey, raw) {
  if (!sourceKey || typeof raw !== 'string' || chatCorruptArchives.some(record => record.sourceKey === sourceKey)) return;
  chatCorruptArchives.push({ sourceKey, raw });
  if (chatCorruptRaw === null) { chatCorruptRaw = raw; chatCorruptSourceKey = sourceKey; }
}
function detectCorruptLegacyChatRecord() {
  // Scan every known generation, including v4, even if a newer readable store exists.
  // Any malformed record is preserved and is never silently overwritten/deleted.
  for (const key of [CHAT_STORAGE_KEY, ...PREVIOUS_CHAT_KEYS]) {
    let raw;
    try { raw = localStorage.getItem(key); } catch (_) { return; }
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object' || (!Array.isArray(parsed.conversations) && !Array.isArray(parsed.messages))) throw new Error('Chat record shape is invalid.');
    } catch (_) { rememberCorruptChatRecord(key, raw); }
  }
  try {
    const marker = JSON.parse(localStorage.getItem(CHAT_CORRUPT_MARKER_KEY) || 'null');
    const sourceKeys = Array.isArray(marker?.sourceKeys) ? marker.sourceKeys : (marker?.sourceKey ? [marker.sourceKey] : []);
    for (const key of sourceKeys) {
      if (![CHAT_STORAGE_KEY, ...PREVIOUS_CHAT_KEYS].includes(key) || chatCorruptArchives.some(record => record.sourceKey === key)) continue;
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      try {
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object' || (!Array.isArray(parsed.conversations) && !Array.isArray(parsed.messages))) throw new Error('Chat record shape is invalid.');
      } catch (_) { rememberCorruptChatRecord(key, raw); }
    }
  } catch (_) { /* A malformed marker never authorises deletion of legacy data. */ }
}
async function restorePrivateCorruptChatArchives() {
  if (!window.Loadout?.storage) return;
  // Do not depend on the localStorage marker to discover archives: the marker write
  // itself may have failed after a private-file write succeeded. Probe every fixed,
  // known legacy key. Missing stores return null; no user-controlled path is read.
  for (const sourceKey of [CHAT_STORAGE_KEY, ...PREVIOUS_CHAT_KEYS]) {
    if (chatCorruptArchives.some(record => record.sourceKey === sourceKey)) continue;
    try {
      const store = await window.Loadout.storage.create({ namespace: 'legacy-recovery', name: `corrupt-chat-${sourceKey}`, lifetime: 'persistent' });
      const raw = await store.get();
      if (typeof raw === 'string') rememberCorruptChatRecord(sourceKey, raw);
    } catch (error) {
      await window.Loadout?.diagnostics?.record?.('warn', 'chat-private-quarantine-restore-failed', { sourceKey, errorType: error.name });
    }
  }
}
function loadChatState() {
  detectCorruptLegacyChatRecord();
  for (const key of [CHAT_STORAGE_KEY, ...PREVIOUS_CHAT_KEYS]) {
    let raw;
    try { raw = localStorage.getItem(key); } catch (_) { break; }
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object' || (!Array.isArray(parsed.conversations) && !Array.isArray(parsed.messages))) throw new Error('Chat record shape is invalid.');
      chatSourceKey = key;
      return AI_COACH.normalizeState(parsed);
    } catch (error) {
      rememberCorruptChatRecord(key, raw);
      window.Loadout?.diagnostics?.record?.('warn', 'chat-store-invalid', { store: key, errorType: error.name });
    }
  }
  return AI_COACH.normalizeState({ provider: 'gemini', conversations: [] });
}
function legacyCredentialInventory() {
  const found = {};
  for (const key of PREVIOUS_CHAT_KEYS) {
    try {
      const raw = localStorage.getItem(key); if (!raw) continue;
      const data = JSON.parse(raw);
      for (const [providerId, profile] of Object.entries(data.profiles || {})) {
        if (CHAT_PROVIDERS[providerId] && typeof profile?.apiKey === 'string' && profile.apiKey.trim()) found[providerId] = profile.apiKey.trim();
      }
      if (key === 'loadout_chat_v1' && typeof data.apiKey === 'string' && data.apiKey.trim()) {
        const providerId = /generativelanguage\.googleapis\.com/i.test(String(data.baseUrl || '')) ? 'gemini' : 'custom';
        found[providerId] = data.apiKey.trim();
      }
    } catch (_) { /* Preserve unreadable legacy bytes; recovery is handled separately. */ }
  }
  return found;
}
function legacyCredentialOrigins() {
  const origins = {};
  for (const key of PREVIOUS_CHAT_KEYS) {
    try {
      const raw = localStorage.getItem(key); if (!raw) continue;
      const data = JSON.parse(raw);
      for (const [providerId, profile] of Object.entries(data.profiles || {})) {
        if (!CHAT_PROVIDERS[providerId] || typeof profile?.apiKey !== 'string' || !profile.apiKey.trim()) continue;
        try { origins[providerId] = new URL(profile.baseUrl || CHAT_PROVIDERS[providerId].baseUrl).origin; } catch (_) {}
      }
      if (key === 'loadout_chat_v1' && typeof data.apiKey === 'string' && data.apiKey.trim()) {
        const providerId = /generativelanguage\.googleapis\.com/i.test(String(data.baseUrl || '')) ? 'gemini' : 'custom';
        try { origins[providerId] = new URL(data.baseUrl || CHAT_PROVIDERS[providerId].baseUrl).origin; } catch (_) {}
      }
    } catch (_) { /* Leave the origin unbound; never guess an endpoint for a legacy secret. */ }
  }
  return origins;
}
function providerOrigin(providerId) {
  try { return new URL(chatProfile(providerId).baseUrl).origin; } catch (_) { return ''; }
}
function secureChatCredentialMatches(providerId) {
  return secureChatSecrets.has(providerId) && !!providerOrigin(providerId) && secureChatOrigins.get(providerId) === providerOrigin(providerId);
}
function chatStorageSnapshot() { return AI_COACH.chatStorageSnapshot(chatState); }
async function persistChatState() {
  if (!chatMigrationReady) throw new Error('Conversation storage is still being verified.');
  const wouldOverwriteCorruptV4 = chatCorruptArchives.some(record => record.sourceKey === CHAT_STORAGE_KEY);
  if (wouldOverwriteCorruptV4 && !chatCorruptQuarantineVerified && !chatCorruptExportConfirmed) {
    throw new Error('The existing v4 chat record is unreadable and has not been verified in private recovery storage. Export the original archive and explicitly confirm before replacing it.');
  }
  const snapshot = chatStorageSnapshot();
  const serialized = JSON.stringify(snapshot);
  const operation = async () => {
    localStorage.setItem(CHAT_STORAGE_KEY, serialized);
    if (localStorage.getItem(CHAT_STORAGE_KEY) !== serialized) throw new Error('Local conversation read-back verification failed.');
    if (window.Loadout?.storage) {
      const result = await window.Loadout.storage.mirror('legacy', CHAT_MIRROR_NAME, snapshot);
      if (result?.verified !== true) throw new Error('Private conversation mirror did not verify.');
      await window.Loadout.storage.flush();
      const mirror = await window.Loadout.storage.readMirror('legacy', CHAT_MIRROR_NAME);
      if (!mirror || stableChatJson(mirror) !== stableChatJson(snapshot)) throw new Error('Private conversation mirror read-back mismatch.');
    }
    return true;
  };
  chatSaveChain = chatSaveChain.catch(() => {}).then(operation);
  return chatSaveChain;
}
function saveChatState() {
  return persistChatState().catch(error => {
    window.Loadout?.diagnostics?.record?.('error', 'chat-history-persist-failed', { errorType: error.name });
    const status = document.getElementById('chat-status');
    if (status) { status.textContent = `Conversation save failed: ${error.message}. Do not clear app data; export a backup when storage is available.`; status.className = 'chat-status err'; }
    return false;
  });
}
function activeConversation() {
  let conversation = chatState.conversations.find(row => row.id === chatState.activeConversationId);
  if (!conversation) {
    conversation = chatState.conversations[0] || AI_COACH.newConversation();
    if (!chatState.conversations.length) chatState.conversations.push(conversation);
    chatState.activeConversationId = conversation.id;
  }
  return conversation;
}
function chatMessages() { return activeConversation().messages; }
function cloneChatStateForRollback() {
  // chatState is already normalised and contains no credentials; clone exact data for rollback.
  return JSON.parse(JSON.stringify(chatState));
}
function touchConversation() {
  const conversation = activeConversation();
  conversation.updatedAt = new Date().toISOString();
  if (conversation.title === 'New conversation') {
    const first = conversation.messages.find(message => message.role === 'user');
    if (first) conversation.title = messageText(first.content).replace(/\s+/g, ' ').slice(0, 48) || 'New conversation';
  }
  return saveChatState();
}
async function rollbackChatMutation(previous, message) {
  chatState = previous;
  // Attempt to put the last verified state back into local storage. If the private mirror
  // remains unavailable, the startup recovery gate will archive the divergent mirror.
  await saveChatState();
  if (currentView === 'chatbot') renderChatbot();
  if (message) setChatStatus(message, 'err');
  return false;
}
function chatProfile(providerId) { return AI_COACH.normalizeProfile(providerId, chatState.profiles?.[providerId]); }
function chatCredentialAvailable(providerId) { return secureChatCredentialMatches(providerId) || sessionChatSecrets.has(providerId); }
async function removeLegacyCredentialCopies(providerId) {
  for (const key of PREVIOUS_CHAT_KEYS) {
    try {
      const raw = localStorage.getItem(key); if (!raw) continue;
      const data = JSON.parse(raw);
      if (data.profiles?.[providerId]) data.profiles[providerId].apiKey = '';
      let legacyV1Provider = null;
      if (key === 'loadout_chat_v1') {
        legacyV1Provider = /generativelanguage\.googleapis\.com/i.test(String(data.baseUrl || '')) ? 'gemini' : 'custom';
        if (legacyV1Provider === providerId) data.apiKey = '';
      }
      localStorage.setItem(key, JSON.stringify(data));
      const check = JSON.parse(localStorage.getItem(key));
      if (check.profiles?.[providerId]?.apiKey || (key === 'loadout_chat_v1' && legacyV1Provider === providerId && check.apiKey)) throw new Error('Legacy credential read-back failed.');
    } catch (error) {
      window.Loadout?.diagnostics?.record?.('warn', 'legacy-chat-key-redaction-failed', { store: key, provider: providerId, errorType: error.name });
      throw error;
    }
  }
}
async function finalizeLegacyChatMigrationIfSafe() {
  if (chatCorruptArchives.length || Object.keys(legacyCredentialInventory()).length) return false;
  if (!(await saveChatState())) return false;
  for (const key of PREVIOUS_CHAT_KEYS) {
    try { localStorage.removeItem(key); } catch (_) { return false; }
  }
  chatMigrationNotice = window.Loadout?.secrets?.available
    ? 'Conversation history verified. Provider credentials use Android Keystore.'
    : 'Conversation history verified. Browser provider credentials are session-memory-only.';
  return true;
}

async function initializeChatStorage() {
  await window.LoadoutReady?.catch(() => {});
  const streamRecovery = AI_COACH.recoverInterruptedStreams(chatState);
  chatState = streamRecovery.state;
  if (streamRecovery.interruptedCount) chatMigrationNotice = `${streamRecovery.interruptedCount} interrupted AI response(s) were recovered as stopped messages. You can retry the previous question.`;
  await restorePrivateCorruptChatArchives();
  if (chatCorruptArchives.length) {
    const sourceKeys = chatCorruptArchives.map(record => record.sourceKey);
    try {
      const marker = JSON.stringify({ version: 2, sourceKeys, detectedAt: new Date().toISOString() });
      localStorage.setItem(CHAT_CORRUPT_MARKER_KEY, marker);
      if (localStorage.getItem(CHAT_CORRUPT_MARKER_KEY) !== marker) throw new Error('Corrupt-record marker read-back failed.');
    } catch (error) { await window.Loadout?.diagnostics?.record?.('warn', 'chat-corrupt-marker-write-failed', { errorType: error.name }); }
    if (window.Loadout?.storage) {
      chatCorruptQuarantineVerified = true;
      for (const record of chatCorruptArchives) {
        try {
          const name = `corrupt-chat-${record.sourceKey}`;
          const quarantine = await window.Loadout.storage.create({ namespace: 'legacy-recovery', name, lifetime: 'persistent' });
          const existing = await quarantine.get();
          if (existing == null) await quarantine.set(record.raw);
          const verified = await quarantine.get();
          if (verified !== record.raw) throw new Error('Private corrupt-chat quarantine read-back mismatch.');
        } catch (error) {
          chatCorruptQuarantineVerified = false;
          await window.Loadout?.diagnostics?.record?.('warn', 'chat-store-quarantine-failed', { sourceKey: record.sourceKey, errorType: error.name });
        }
      }
    }
    chatMigrationNotice = chatCorruptQuarantineVerified
      ? `${chatCorruptArchives.length} unreadable legacy chat archive(s) were copied and verified in private recovery storage. Their original bytes remain exportable below.`
      : `${chatCorruptArchives.length} unreadable legacy chat archive(s) remain preserved. Export them below; a damaged v4 record will not be overwritten until you explicitly confirm the export.`;
  }
  const legacyCredentials = legacyCredentialInventory();
  const legacyOrigins = legacyCredentialOrigins();
  const secure = !!window.Loadout?.secrets?.available;
  let allLegacyKeysSecured = true;
  if (secure) {
    for (const [providerId, secret] of Object.entries(legacyCredentials)) {
      try {
        const origin = legacyOrigins[providerId];
        if (!origin) throw new Error('The legacy provider endpoint could not be recovered safely; re-enter the key and save it for the configured HTTPS endpoint.');
        await window.Loadout.secrets.set(`ai-${providerId}`, secret, origin);
        if (!(await window.Loadout.secrets.has(`ai-${providerId}`, origin))) throw new Error('Keystore origin-binding read-back check failed.');
        secureChatSecrets.add(providerId); secureChatOrigins.set(providerId, origin); unboundChatSecrets.delete(providerId);
      } catch (error) {
        allLegacyKeysSecured = false;
        chatMigrationNotice = `A legacy ${CHAT_PROVIDERS[providerId].name} credential could not be migrated to Android Keystore. Its original local record has been preserved; re-enter the key in Provider settings.`;
        await window.Loadout?.diagnostics?.record?.('warn', 'legacy-chat-key-migration-failed', { provider: providerId, errorType: error.name });
      }
    }
    for (const providerId of CHAT_PROVIDER_ORDER) {
      try {
        const status = await window.Loadout.secrets.status(`ai-${providerId}`);
        const configuredOrigin = providerOrigin(providerId);
        if (status.available && status.originBound && status.origin === configuredOrigin) {
          secureChatSecrets.add(providerId); secureChatOrigins.set(providerId, status.origin); unboundChatSecrets.delete(providerId);
        } else if (status.available) {
          secureChatSecrets.delete(providerId); secureChatOrigins.delete(providerId); unboundChatSecrets.add(providerId);
        }
      } catch (_) { /* unavailable key remains unavailable */ }
    }
  } else if (Object.keys(legacyCredentials).length) {
    allLegacyKeysSecured = false;
    chatMigrationNotice = 'A legacy provider credential remains in the untouched pre-upgrade chat backup because Android Keystore is unavailable. It is not used automatically. Re-enter it on a trusted Android installation and save it securely.';
  }
  chatMigrationReady = true;
  const saved = await saveChatState();
  if (saved && allLegacyKeysSecured && chatCorruptArchives.length === 0) {
    for (const key of PREVIOUS_CHAT_KEYS) {
      try { localStorage.removeItem(key); } catch (_) { /* Best effort after verified v4 + private mirror. */ }
    }
    chatMigrationNotice = secure ? 'Conversation history verified. Provider credentials use Android Keystore.' : 'Conversation history verified. New browser-session credentials are memory-only.';
  } else if (saved && chatCorruptArchives.length) {
    // Never remove or overwrite an unreadable predecessor store, even if v4 is usable.
    chatMigrationNotice = chatCorruptQuarantineVerified
      ? `Current conversations are available. ${chatCorruptArchives.length} unreadable legacy archive(s) are separately preserved in private recovery storage and remain exportable below.`
      : `Current conversations are available. ${chatCorruptArchives.length} unreadable legacy archive(s) remain in original storage and are exportable below.`;
  } else if (!saved) {
    chatMigrationReady = false;
    chatMigrationNotice = 'Chat migration could not be fully verified. Existing chat records have been preserved and editing is temporarily disabled.';
  }
  if (currentView === 'chatbot') renderChatbot();
}
async function hydrateChatFromPrivateMirror() {
  if (!window.Loadout?.storage || chatSourceKey || localStorage.getItem(CHAT_STORAGE_KEY)) return;
  try {
    const recovered = await window.Loadout.storage.readMirror('legacy', CHAT_MIRROR_NAME);
    if (recovered && (Array.isArray(recovered.conversations) || Array.isArray(recovered.messages))) {
      chatState = AI_COACH.recoverInterruptedStreams(recovered).state;
      chatMigrationReady = true;
      if (await saveChatState()) {
        await window.Loadout?.diagnostics?.record?.('recovery', 'chat-history-restored-from-private-mirror', { conversations: chatState.conversations.length });
      }
    }
  } catch (error) {
    await window.Loadout?.diagnostics?.record?.('warn', 'chat-history-mirror-recovery-failed', { errorType: error.name });
  }
}

function providerStatusText() {
  const id = chatState.provider;
  if (secureChatCredentialMatches(id)) return 'Credential stored in Android Keystore and cryptographically bound to this HTTPS provider origin; the key never enters JavaScript for requests.';
  if (unboundChatSecrets.has(id) || secureChatSecrets.has(id)) return 'A stored credential is unbound or belongs to a different endpoint. Re-enter and save the key for this exact HTTPS origin before sending.';
  if (sessionChatSecrets.has(id)) return 'Credential is held in memory for this session only and disappears when the app closes.';
  return 'No credential configured for this provider.';
}
function selectedStudyContext() {
  const chapters = (Array.isArray(CHAPTERS) ? CHAPTERS : []).map(chapter => {
    let mastery = null;
    try { const stats = chapterStats(chapter); mastery = Number.isFinite(stats.mastery) ? stats.mastery : null; } catch (_) {}
    return { subject: chapter.subject, status: chapter.status, mastery };
  });
  return AI_COACH.buildStudyContext(chatState.preferences, { chapters, attempts: state.attempts || [] });
}
function updateContextPreview() {
  const preview = document.getElementById('chat-context-preview');
  if (!preview) return;
  const context = selectedStudyContext();
  const history = chatHistoryForRequest();
  const nextMessage = String(document.getElementById('chat-input')?.value || '').trim();
  const sections = [
    `PROVIDER: ${CHAT_PROVIDERS[chatState.provider]?.name || chatState.provider}`,
    `MODEL: ${chatProfile(chatState.provider).model}`,
    `SYSTEM INSTRUCTIONS:\n${DEFAULT_SYSTEM}`,
    `OWNER-SELECTED LOCAL STUDY CONTEXT:\n${context || '[None selected]'}`,
    `RECENT CONVERSATION HISTORY (${history.length} message(s)):\n${history.map(item => `${item.role.toUpperCase()}: ${item.content}`).join('\n\n') || '[No previous messages]'}`,
    `NEXT MESSAGE:\n${nextMessage || '[Type a message to preview it]'}`,
    'NOT INCLUDED: provider API key, other conversations, unselected study records, backup files, and unrelated app-private data.'
  ];
  preview.textContent = sections.join('\n\n---\n\n').slice(0, 300000);
}
function chatHistoryForRequest() {
  const conversation = activeConversation();
  const valid = conversation.messages.filter(message => ['user', 'assistant'].includes(message.role) && (!message.status || message.status === 'complete'));
  return AI_COACH.selectHistory(valid, chatState.preferences.historyMessages, Math.max(1200, chatState.preferences.historyMessages * 800));
}
function parseProviderError(data, status) {
  const message = data?.error?.message || data?.message || data?.detail || data?.error?.status || `HTTP ${status}`;
  return AI_COACH.redactProviderError(message);
}
async function readResponseText(response, providerId, onDelta) {
  const contentType = response.headers?.get?.('content-type') || '';
  if (!contentType.includes('text/event-stream')) {
    const text = await response.text(); let json;
    try { json = JSON.parse(text); } catch (_) { throw new Error('Provider returned an unreadable non-streaming response.'); }
    if (!response.ok) throw new Error(parseProviderError(json, response.status));
    const answer = AI_COACH.parseProviderResponse(providerId, json);
    if (answer) onDelta(answer);
    return;
  }
  const parser = AI_COACH.createSseParser(providerId, onDelta);
  if (response.body?.getReader) {
    const reader = response.body.getReader(); const decoder = new TextDecoder();
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      parser.push(decoder.decode(value, { stream: true }));
    }
    parser.push(decoder.decode()); parser.finish();
  } else {
    const text = await response.text(); parser.push(text); parser.finish();
  }
}
async function invokeChatProvider(providerId, messages, signal, onDelta, onRequestStart) {
  const profile = chatProfile(providerId);
  const context = selectedStudyContext();
  const request = AI_COACH.buildProviderRequest(providerId, profile, messages, DEFAULT_SYSTEM, context, chatState.preferences.maxOutputTokens);
  const requestId = chatId('ai');
  if (typeof onRequestStart === 'function') onRequestStart(requestId);
  if (window.Loadout?.aiTransport?.nativeAvailable && secureChatCredentialMatches(providerId)) {
    const nativeStreamBody = { ...request.body };
    const nativeUrl = providerId === 'gemini' ? request.url.replace(':generateContent', ':streamGenerateContent?alt=sse') : request.url;
    if (providerId !== 'gemini') nativeStreamBody.stream = true;
    let nativeStreamCharacters = 0;
    const result = await window.Loadout.aiTransport.request({
      credentialId: `ai-${providerId}`, requestId, url: nativeUrl,
      body: JSON.stringify(nativeStreamBody), authMode: request.authMode, headers: request.headers,
      providerKind: providerId === 'gemini' ? 'gemini' : 'openai', stream: true, signal,
      onChunk: delta => { nativeStreamCharacters += String(delta || '').length; onDelta(delta); }
    });
    if (signal.aborted) throw new DOMException('Generation stopped.', 'AbortError');
    if (result.streamed) {
      if (!nativeStreamCharacters) throw new Error('Provider completed its streaming response without any text.');
      return requestId;
    }
    let data; try { data = JSON.parse(result.body || '{}'); } catch (_) { throw new Error('Provider returned invalid JSON.'); }
    if (Number(result.status) < 200 || Number(result.status) >= 300) throw new Error(parseProviderError(data, result.status));
    const answer = AI_COACH.parseProviderResponse(providerId, data);
    if (!answer) throw new Error('Provider returned an empty or unsupported response.');
    onDelta(answer);
    return requestId;
  }
  const key = sessionChatSecrets.get(providerId);
  if (!key) throw new Error('No usable provider credential is available. Enter the key and save it in Android Keystore, or use a temporary browser session.');
  const url = providerId === 'gemini' ? request.url.replace(':generateContent', ':streamGenerateContent?alt=sse') : request.url;
  if (providerId !== 'gemini') request.body.stream = true;
  const headers = { 'Content-Type': 'application/json', 'Accept': 'text/event-stream, application/json' };
  if (request.authMode === 'google-api-key') headers['x-goog-api-key'] = key;
  else headers.Authorization = `Bearer ${key}`;
  for (const [header, value] of Object.entries(request.headers || {})) headers[header] = value;
  const response = await fetch(url, { method: 'POST', headers, body: JSON.stringify(request.body), signal, redirect: 'error', cache: 'no-store' });
  if (!response.ok) {
    let data = {};
    try { data = await response.clone().json(); } catch (_) {
      try { data = { message: (await response.text()).slice(0, 2000) }; } catch (_) {}
    }
    throw new Error(parseProviderError(data, response.status));
  }
  await readResponseText(response, providerId, onDelta);
  return requestId;
}
async function testChatProviderConnection() {
  const providerId = chatState.provider;
  if (!chatCredentialAvailable(providerId)) { setChatStatus('Configure and save this provider credential before testing.', 'err'); return; }
  if (!confirm(`Send one minimal test request to ${CHAT_PROVIDERS[providerId].name}? No conversation history or study data will be included. The provider may consume a small amount of quota.`)) return;
  const profile = chatProfile(providerId);
  const request = AI_COACH.buildConnectionTestRequest(providerId, profile);
  const requestId = chatId('ai-test');
  const controller = new AbortController();
  const started = Date.now();
  const button = document.getElementById('chat-test-provider');
  if (button) button.disabled = true;
  setChatStatus(`Testing ${CHAT_PROVIDERS[providerId].name}. No chat history or study context is being sent…`);
  let timedOut = false;
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, 30000);
  try {
    let data;
    if (window.Loadout?.aiTransport?.nativeAvailable && secureChatCredentialMatches(providerId)) {
      const result = await window.Loadout.aiTransport.request({ credentialId: `ai-${providerId}`, requestId, url: request.url, body: JSON.stringify(request.body), authMode: request.authMode, headers: request.headers, stream: false, signal: controller.signal });
      if (Number(result.status) < 200 || Number(result.status) >= 300) {
        let errorData = {}; try { errorData = JSON.parse(result.body || '{}'); } catch (_) {}
        throw new Error(parseProviderError(errorData, result.status));
      }
      data = JSON.parse(result.body || '{}');
    } else {
      const key = sessionChatSecrets.get(providerId);
      if (!key) throw new Error('The credential is not available in Android Keystore or this browser session.');
      const headers = { 'Content-Type': 'application/json', 'Accept': 'application/json' };
      if (request.authMode === 'google-api-key') headers['x-goog-api-key'] = key;
      else headers.Authorization = `Bearer ${key}`;
      Object.assign(headers, request.headers || {});
      const response = await fetch(request.url, { method: 'POST', headers, body: JSON.stringify(request.body), signal: controller.signal, redirect: 'error', cache: 'no-store' });
      data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(parseProviderError(data, response.status));
    }
    const answer = AI_COACH.parseProviderResponse(providerId, data);
    if (!answer) throw new Error('Provider returned no text in the connection test response.');
    const elapsed = Date.now() - started;
    setChatStatus(`Connection successful · ${CHAT_PROVIDERS[providerId].name} · ${elapsed} ms. No conversation was created.`, 'ok');
    await window.Loadout?.diagnostics?.record?.('info', 'ai-coach-provider-connection-tested', { provider: providerId, success: true, elapsedMs: elapsed });
  } catch (error) {
    const message = timedOut || error.name === 'AbortError' ? 'Connection test timed out after 30 seconds.' : error.message;
    setChatStatus(`Connection test failed: ${message}`, 'err');
    await window.Loadout?.diagnostics?.record?.('warn', 'ai-coach-provider-connection-tested', { provider: providerId, success: false, errorType: error.name });
  } finally {
    clearTimeout(timeout);
    if (button) button.disabled = false;
  }
}
function availableProviderCandidates() {
  const selected = chatState.provider;
  const available = CHAT_PROVIDER_ORDER.filter(id => chatCredentialAvailable(id));
  if (!chatState.autoFallback) return available.includes(selected) ? [selected] : [];
  return [selected, ...available.filter(id => id !== selected)].filter((id, index, rows) => available.includes(id) && rows.indexOf(id) === index);
}
function setChatStatus(message, type='') {
  const status = document.getElementById('chat-status');
  if (status) { status.textContent = String(message || ''); status.className = `chat-status ${type}`.trim(); }
}
function scheduleChatStreamPaint(request) {
  if (!request || request.paintTimer) return;
  request.paintTimer = setTimeout(() => {
    request.paintTimer = null;
    if (activeChatRequest === request) paintMessages(false);
  }, 50);
}
function scheduleChatStreamPersistence(request) {
  if (!request) return;
  request.streamDirty = true;
  if (request.streamTimer || request.streamSavePending) return;
  request.streamTimer = setTimeout(() => {
    request.streamTimer = null;
    request.streamDirty = false;
    request.streamSavePending = saveChatState().then(saved => {
      if (!saved) {
        request.persistenceFailed = true;
        request.stopReason = 'persistence-failed';
        if (activeChatRequest === request) request.controller.abort();
      }
      return saved;
    }).finally(() => {
      request.streamSavePending = null;
      if (request.streamDirty && activeChatRequest === request) scheduleChatStreamPersistence(request);
    });
  }, 1200);
}
async function flushChatStreamPersistence(request) {
  if (!request) return true;
  if (request.paintTimer) { clearTimeout(request.paintTimer); request.paintTimer = null; }
  while (true) {
    if (request.streamTimer) { clearTimeout(request.streamTimer); request.streamTimer = null; }
    if (request.streamSavePending) { await request.streamSavePending; continue; }
    if (!request.streamDirty) return !request.persistenceFailed;
    request.streamDirty = false;
    if (!(await saveChatState())) request.persistenceFailed = true;
  }
}
async function sendChat(textOverride = null, existingUserMessage = false) {
  const input = document.getElementById('chat-input');
  if (!input) return;
  const text = String(textOverride ?? input.value ?? '').trim();
  if (!text || activeChatRequest) return;
  const candidates = availableProviderCandidates();
  if (!candidates.length) { setChatStatus('Save a provider credential first. On Android it is encrypted by Keystore; in a browser it is session-only.', 'err'); return; }
  if (!existingUserMessage) {
    input.value = '';
    chatMessages().push({ id: chatId('msg'), role: 'user', content: text, createdAt: new Date().toISOString(), status: 'complete' });
  }
  const conversation = activeConversation();
  const assistant = { id: chatId('msg'), role: 'assistant', content: '', createdAt: new Date().toISOString(), status: 'streaming' };
  conversation.messages.push(assistant);
  if (!(await touchConversation())) {
    assistant.status = 'error'; assistant.content = 'Message was not sent because local conversation storage could not be verified. Your draft remains visible; restore storage before retrying.';
    paintMessages(); setChatStatus('Message not sent: local conversation storage verification failed.', 'err');
    return;
  }
  paintMessages();
  const controller = new AbortController();
  const requestState = { controller, requestId: null, assistantId: assistant.id, nativeRequestIds: [], streamDirty: false, streamTimer: null, streamSavePending: null, paintTimer: null, persistenceFailed: false, streamLimitReached: false, stopReason: null };
  activeChatRequest = requestState;
  const sendButton = document.getElementById('chat-send'); const stopButton = document.getElementById('chat-stop');
  if (sendButton) sendButton.disabled = true; if (stopButton) stopButton.disabled = false;
  setChatStatus('Generating with the selected provider…');
  const history = chatHistoryForRequest();
  const failures = []; let succeeded = false; let chosenProvider = null;
  try {
    for (const providerId of candidates) {
      if (controller.signal.aborted) break;
      let streamed = false;
      try {
        const requestId = await invokeChatProvider(providerId, history, controller.signal, delta => {
          if (controller.signal.aborted) return;
          streamed = true;
          const appended = AI_COACH.appendStreamText(assistant.content, String(delta || ''));
          assistant.content = appended.content;
          assistant.provider = providerId;
          scheduleChatStreamPersistence(requestState);
          scheduleChatStreamPaint(requestState);
          if (appended.truncated) {
            requestState.streamLimitReached = true;
            requestState.stopReason = 'response-limit';
            controller.abort();
          }
        }, requestId => { requestState.requestId = requestId; requestState.providerId = providerId; });
        activeChatRequest.requestId = requestId; chosenProvider = providerId; succeeded = true; break;
      } catch (error) {
        if (controller.signal.aborted || error.name === 'AbortError') break;
        failures.push(`${CHAT_PROVIDERS[providerId].name}: ${error.message}`);
        if (streamed || !chatState.autoFallback) break;
      }
    }
  } finally {
    await flushChatStreamPersistence(requestState);
    const wasAborted = controller.signal.aborted;
    activeChatRequest = null;
    if (sendButton) sendButton.disabled = false; if (stopButton) stopButton.disabled = true;
    if (requestState.persistenceFailed) {
      assistant.status = 'cancelled';
      setChatStatus('Generation stopped because a streamed save could not be verified. The last visible partial answer may not be durable; export a backup before leaving.', 'err');
    } else if (requestState.streamLimitReached) {
      assistant.status = 'cancelled';
      setChatStatus('Response reached the 200,000-character safety limit and was stopped. The partial answer was retained.', '');
    } else if (wasAborted) {
      assistant.status = 'cancelled';
      if (!assistant.content) assistant.content = 'Generation stopped. You can retry from the last user message.';
      setChatStatus('Generation stopped. The partial response and previous messages remain local.', '');
    } else if (succeeded) {
      assistant.status = 'complete';
      setChatStatus(`Reply received via ${CHAT_PROVIDERS[chosenProvider].name}.`, 'ok');
    } else {
      assistant.status = 'error';
      assistant.content = `Provider request failed.\n\n${failures.join('\n') || 'The request did not complete.'}`;
      setChatStatus(failures[failures.length - 1] || 'Provider request failed.', 'err');
    }
    const finalChatSaved = await touchConversation();
    if (!finalChatSaved) setChatStatus('Reply is visible but conversation persistence verification failed. Export a backup before leaving this screen.', 'err');
    else if (requestState.persistenceFailed) setChatStatus('A periodic stream save failed, but the final conversation state was subsequently saved and verified.', 'warn');
    paintMessages();
    await window.Loadout?.diagnostics?.record?.(succeeded ? 'info' : wasAborted ? 'info' : 'warn', 'ai-coach-request-finished', {
      provider: chosenProvider || candidates[0], success: succeeded, cancelled: wasAborted, fallbackCount: Math.max(0, failures.length), responseCharacters: assistant.content.length
    });
  }
}
async function stopChatGeneration() {
  const active = activeChatRequest;
  if (!active) return;
  active.controller.abort();
}
async function handleChatMessageAction(messageId, action) {
  const messages = chatMessages(); const index = messages.findIndex(message => message.id === messageId); if (index < 0) return;
  const message = messages[index];
  if (action === 'copy') { copyText(messageText(message.content)); return; }
  if (action === 'delete') {
    const previous = cloneChatStateForRollback();
    messages.splice(index, 1);
    if (!(await touchConversation())) { await rollbackChatMutation(previous, 'Message deletion was not saved. The previous conversation was restored.'); return; }
    paintMessages(); return;
  }
  if (action === 'edit' && message.role === 'user') {
    const revised = prompt('Edit this user message and resend:', messageText(message.content));
    if (revised == null || !revised.trim()) return;
    const previous = cloneChatStateForRollback();
    message.content = revised.trim(); message.status = 'complete'; messages.splice(index + 1);
    if (!(await touchConversation())) { await rollbackChatMutation(previous, 'Message edit was not saved. The previous conversation was restored; no request was sent.'); return; }
    paintMessages(); await sendChat(revised.trim(), true); return;
  }
  if (AI_COACH.canRetryMessage(message, action)) {
    let userIndex = index - 1; while (userIndex >= 0 && messages[userIndex].role !== 'user') userIndex--;
    if (userIndex < 0) return;
    const previous = cloneChatStateForRollback();
    const promptText = messageText(messages[userIndex].content); messages.splice(userIndex + 1);
    if (!(await touchConversation())) { await rollbackChatMutation(previous, 'Retry preparation was not saved. The previous conversation was restored; no request was sent.'); return; }
    paintMessages(); await sendChat(promptText, true);
  }
}
function downloadUnreadableChatArchive() {
  if (!chatCorruptArchives.length) { setChatStatus('No unreadable legacy chat archive is available.', ''); return; }
  if (!confirm('Export the original unreadable legacy chat bytes? The archive may contain old provider credentials. The export can contain several local records. Keep it private and do not upload or share it.')) return;
  const payload = { format: 'loadout-corrupt-chat-archive', formatVersion: 1, exportedAt: new Date().toISOString(), records: chatCorruptArchives.map(record => ({ sourceKey: record.sourceKey, raw: record.raw })) };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = `loadout-corrupt-chat-archive-${new Date().toISOString().slice(0,10)}.json`; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  chatCorruptExportedThisSession = true;
  const acknowledgement = document.getElementById('chat-ack-corrupt-export');
  if (acknowledgement) acknowledgement.disabled = false;
  setChatStatus('Original unreadable chat archive exported. The local original and any verified private quarantine copies were retained.', 'ok');
}
async function acknowledgeCorruptChatExport() {
  if (!chatCorruptArchives.length || !chatCorruptExportedThisSession) return;
  if (!confirm('Confirm that you saved the exported archive somewhere private and can open it. Loadout may now replace the unreadable active v4 record with a fresh verified store. This does not delete your exported backup.')) return;
  chatCorruptExportConfirmed = true;
  chatMigrationReady = true;
  if (!(await saveChatState())) {
    chatCorruptExportConfirmed = false;
    chatMigrationReady = false;
    setChatStatus('The new chat store could not be verified. The original archive remains preserved; do not clear app data.', 'err');
    return;
  }
  for (const record of chatCorruptArchives) {
    if (record.sourceKey === CHAT_STORAGE_KEY) continue; // The key now contains the verified v4 state.
    try { localStorage.removeItem(record.sourceKey); } catch (_) {}
  }
  try { localStorage.removeItem(CHAT_CORRUPT_MARKER_KEY); } catch (_) {}
  chatCorruptArchives = []; chatCorruptRaw = null; chatCorruptSourceKey = null;
  chatCorruptExportConfirmed = false; chatCorruptExportedThisSession = false;
  chatMigrationNotice = 'AI Coach history is now writable. The unreadable predecessor archive was explicitly exported and preserved outside the app.';
  renderChatbot(); setChatStatus(chatMigrationNotice, 'ok');
}
function downloadChatBackup() {
  const payload = { format: 'loadout-ai-coach-backup', formatVersion: 1, exportedAt: new Date().toISOString(), data: chatStorageSnapshot() };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = `loadout-ai-coach-${new Date().toISOString().slice(0,10)}.json`; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function importChatBackupFile(file) {
  if (!file) return;
  if (file.size > 24 * 1024 * 1024) throw new Error('Chat backup exceeds the 24 MiB import limit.');
  const parsed = JSON.parse(await file.text());
  const data = parsed?.format === 'loadout-ai-coach-backup' ? parsed.data : parsed;
  if (!data || (!Array.isArray(data.conversations) && !Array.isArray(data.messages))) throw new Error('The selected file is not a valid Loadout AI Coach backup.');
  const imported = AI_COACH.recoverInterruptedStreams(data).state;
  if (!confirm(`Replace ${chatState.conversations.length} local conversations with ${imported.conversations.length} imported conversations? Provider credentials are not included in backups.`)) return;
  const previous = chatState; chatState = imported;
  if (!(await saveChatState())) { chatState = previous; await saveChatState(); throw new Error('Import could not be verified; previous conversations were restored.'); }
  renderChatbot(); setChatStatus('Conversation backup imported and verified. Provider keys must be configured separately.', 'ok');
}
async function clearAllChatHistory() {
  const count = chatState.conversations.reduce((total, conversation) => total + conversation.messages.length, 0);
  if (!confirm(`Delete ALL ${chatState.conversations.length} conversations and ${count} messages? Provider endpoint/model settings and secure API credentials will remain. This action cannot be undone unless you export first.`)) return;
  const previous = chatState;
  chatState = AI_COACH.normalizeState({ ...chatState, conversations: [], activeConversationId: '' });
  if (!(await saveChatState())) {
    chatState = previous;
    await saveChatState();
    setChatStatus('All-history deletion could not be verified. Previous conversations were restored.', 'err');
    return;
  }
  renderChatbot();
  setChatStatus('All conversation history was deleted. Provider settings and credentials were retained.', 'ok');
}
window.clearLoadoutChat = async function () {
  const conversation = activeConversation();
  if (!confirm(`Clear all ${conversation.messages.length} messages in “${conversation.title}”? Other conversations and provider settings will remain.`)) return;
  const previous = cloneChatStateForRollback();
  conversation.messages = [];
  if (!(await touchConversation())) { await rollbackChatMutation(previous, 'Conversation clearing was not saved. The previous messages were restored.'); return; }
  if (currentView === 'chatbot') renderChatbot();
  setChatStatus('This conversation was cleared. Other conversations and provider settings were retained.', 'ok');
};
window.exportLoadoutChatData = () => chatStorageSnapshot();
window.importLoadoutChatData = async input => {
  const imported = AI_COACH.normalizeState(input);
  const previous = chatState; chatState = imported;
  if (!(await saveChatState())) { chatState = previous; throw new Error('Imported chat data could not be verified.'); }
  if (currentView === 'chatbot') renderChatbot();
};
function refreshChatConversationSelect(filter='') {
  const select = document.getElementById('chat-conversation'); if (!select) return;
  const rows = AI_COACH.searchConversations(chatState.conversations, filter);
  select.innerHTML = rows.map(conversation => `<option value="${escapeHtml(conversation.id)}" ${conversation.id === chatState.activeConversationId ? 'selected' : ''}>${escapeHtml(conversation.title)}</option>`).join('');
}
function renderChatbot() {
  const root = document.getElementById('view-chatbot'); if (!root) return;
  const profile = chatProfile(chatState.provider);
  const providerOptions = CHAT_PROVIDER_ORDER.map(id => `<option value="${id}" ${chatState.provider === id ? 'selected' : ''}>${escapeHtml(CHAT_PROVIDERS[id].name)}</option>`).join('');
  const conversationOptions = AI_COACH.searchConversations(chatState.conversations, '').map(conversation => `<option value="${escapeHtml(conversation.id)}" ${conversation.id === chatState.activeConversationId ? 'selected' : ''}>${escapeHtml(conversation.title)}</option>`).join('');
  const credentialNotice = window.Loadout?.secrets?.available
    ? 'Android Keystore credential encryption is available. Provider secrets are passed from native storage directly to HTTPS requests.'
    : 'Browser mode: provider credentials exist in JavaScript memory only for this session; they are never written to localStorage.';
  root.innerHTML = `<div class="card pad" style="padding:0;overflow:hidden"><div class="chat-shell">
    <div class="chat-header" style="align-items:flex-start;flex-direction:column;gap:12px">
      <div><h3>✦ AI Coach · JEE Main</h3><p>First-principles mentor · Local conversation history · Explicit context sharing</p></div>
      <div class="chat-toolbar"><input id="chat-conversation-search" placeholder="Search conversations" aria-label="Search conversations"><select id="chat-conversation" aria-label="Conversation">${conversationOptions}</select><button class="btn small" id="chat-new" type="button">＋ New</button><button class="btn small" id="chat-rename" type="button">Rename</button><button class="btn small danger" id="chat-delete-conversation" type="button">Delete conversation</button></div>
      <details class="chat-settings" open><summary>Provider and model</summary>
        <div class="chat-provider-grid"><select id="chat-provider" aria-label="AI provider">${providerOptions}</select><input id="chat-base" type="url" aria-label="API base URL" placeholder="HTTPS API base URL" value="${escapeHtml(profile.baseUrl)}"><input id="chat-model" type="text" aria-label="Model ID" placeholder="Model ID" value="${escapeHtml(profile.model)}"><input id="chat-key" type="password" aria-label="API key" placeholder="Enter API key · never stored in chat history" value="" autocomplete="new-password" spellcheck="false"><button class="btn small primary" id="chat-save-provider" type="button">Save provider / key</button><button class="btn small" id="chat-test-provider" type="button">Test connection</button><button class="btn small" id="chat-clear-key" type="button">Clear key</button></div>
        <div class="chat-meta"><label><input id="chat-auto-fallback" type="checkbox" ${chatState.autoFallback ? 'checked' : ''}> Auto-fallback to configured providers</label><span id="chat-provider-note">${escapeHtml(CHAT_PROVIDERS[chatState.provider].note)}</span><a id="chat-key-link" href="${escapeHtml(CHAT_PROVIDERS[chatState.provider].keyUrl || '#')}" target="_blank" rel="noopener noreferrer" ${CHAT_PROVIDERS[chatState.provider].keyUrl ? '' : 'hidden'}>Get API key ↗</a></div>
        <div id="chat-provider-security" class="tiny">${escapeHtml(credentialNotice)} ${escapeHtml(providerStatusText())}</div>
      </details>
      <details class="chat-settings"><summary>Context and response controls</summary>
        <div class="chat-meta"><label><input id="chat-context-summary" type="checkbox" ${chatState.preferences.includeStudySummary ? 'checked' : ''}> Include locally calculated study summary</label><label><input id="chat-context-tests" type="checkbox" ${chatState.preferences.includeRecentTests ? 'checked' : ''}> Include latest five test records</label></div>
        <div class="chat-provider-grid"><label>History messages <input id="chat-history-count" type="number" min="2" max="80" value="${chatState.preferences.historyMessages}"></label><label>Max output tokens <input id="chat-output-tokens" type="number" min="128" max="8192" step="128" value="${chatState.preferences.maxOutputTokens}"></label></div>
        <details><summary>Preview the information sent with your next request</summary><pre id="chat-context-preview" class="chat-context-preview"></pre></details>
      </details>
      <details class="chat-settings"><summary>Privacy, backup and portability</summary><p class="tiny">Messages stay on this device unless you press Send. Only the selected conversation history, your new message, the JEE Main system instructions and the explicitly checked local context are sent to the selected provider. Chat backups contain messages and non-secret provider settings, never API keys.</p><div class="chat-toolbar"><button class="btn small" id="chat-export" type="button">Export conversations</button><button class="btn small" id="chat-import-trigger" type="button">Import backup</button>${chatCorruptArchives.length ? '<button class="btn small danger" id="chat-export-corrupt" type="button">Export unreadable legacy archive(s)</button><button class="btn small" id="chat-ack-corrupt-export" type="button" disabled>Confirm saved export &amp; continue</button>' : ''}<button class="btn small danger" id="chat-clear-all" type="button">Clear all history</button><input id="chat-import-file" type="file" accept="application/json,.json" hidden></div></details>
    </div>
    <div class="chat-messages" id="chat-messages" aria-live="polite" aria-label="Conversation messages"></div>
    <div class="chat-suggestions" id="chat-suggestions"><button type="button" data-prompt="Explain a JEE Main Physics concept from first principles and show where students usually go wrong.">First-principles explanation</button><button type="button" data-prompt="Help me prioritise JEE Main chapters using my recorded test evidence. Ask for missing evidence instead of guessing.">Evidence-based priorities</button><button type="button" data-prompt="Give me a compact 7-day JEE Main revision plan for Organic Chemistry.">Organic revision plan</button><button type="button" data-prompt="Analyse this mock test and separate conceptual, calculation, reading and time-management errors.">Mock analysis</button></div>
    <div class="chat-status" id="chat-status">${escapeHtml(chatMigrationNotice)}</div>
    <div class="chat-input-row"><textarea id="chat-input" rows="2" placeholder="Ask a JEE Main concept question, strategy question, or paste a problem…" ${chatMigrationReady ? '' : 'disabled'}></textarea><button class="btn primary" id="chat-send" type="button" ${chatMigrationReady ? '' : 'disabled'}>Send ↗</button><button class="btn" id="chat-stop" type="button" disabled>Stop</button></div>
    <div class="chat-footer"><button class="btn small" id="chat-clear-current" type="button">Clear this conversation</button><span class="tiny">Offline history · No automatic data upload</span></div>
  </div></div>`;
  paintMessages(); updateContextPreview();
  document.getElementById('chat-conversation').onchange = event => { chatState.activeConversationId = event.target.value; void saveChatState(); renderChatbot(); };
  document.getElementById('chat-conversation-search').oninput = event => refreshChatConversationSelect(event.target.value);
  document.getElementById('chat-new').onclick = async () => { const conversation = AI_COACH.newConversation(); chatState.conversations.unshift(conversation); chatState.activeConversationId = conversation.id; await saveChatState(); renderChatbot(); };
  document.getElementById('chat-rename').onclick = async () => {
    const conversation = activeConversation(); const title = prompt('Conversation name:', conversation.title);
    if (!title || !title.trim()) return;
    const previous = cloneChatStateForRollback(); conversation.title = title.trim().slice(0, 100);
    if (!(await touchConversation())) { await rollbackChatMutation(previous, 'Rename was not saved. The previous title was restored.'); return; }
    renderChatbot();
  };
  document.getElementById('chat-delete-conversation').onclick = async () => {
    const conversation = activeConversation();
    if (!confirm(`Delete conversation “${conversation.title}” and its ${conversation.messages.length} messages?`)) return;
    const previous = cloneChatStateForRollback();
    chatState.conversations = chatState.conversations.filter(row => row.id !== conversation.id);
    if (!chatState.conversations.length) chatState.conversations = [AI_COACH.newConversation()];
    chatState.activeConversationId = chatState.conversations[0].id;
    if (!(await saveChatState())) { await rollbackChatMutation(previous, 'Conversation deletion was not saved. The previous conversation list was restored.'); return; }
    renderChatbot();
  };
  document.getElementById('chat-provider').onchange = async event => { chatState.provider = event.target.value; await saveChatState(); renderChatbot(); };
  document.getElementById('chat-auto-fallback').onchange = event => { chatState.autoFallback = !!event.target.checked; void saveChatState(); };
  const saveProvider = document.getElementById('chat-save-provider');
  saveProvider.onclick = async () => {
    const id = chatState.provider; const input = document.getElementById('chat-key'); const entered = input.value.trim();
    const url = document.getElementById('chat-base').value.trim() || CHAT_PROVIDERS[id].baseUrl;
    const model = document.getElementById('chat-model').value.trim() || CHAT_PROVIDERS[id].model;
    let normalizedBaseUrl;
    try { normalizedBaseUrl = AI_COACH.validateProviderBaseUrl(url); }
    catch (error) { setChatStatus(error.message, 'err'); return; }
    chatState.profiles[id] = { baseUrl: normalizedBaseUrl, model };
    try {
      if (entered) {
        if (window.Loadout?.secrets?.available) {
          await window.Loadout.secrets.set(`ai-${id}`, entered, parsed.origin);
          if (!(await window.Loadout.secrets.has(`ai-${id}`, parsed.origin))) throw new Error('Keystore origin-binding read-back check failed.');
          secureChatSecrets.add(id); secureChatOrigins.set(id, parsed.origin); unboundChatSecrets.delete(id); sessionChatSecrets.delete(id);
          await removeLegacyCredentialCopies(id);
        } else {
          sessionChatSecrets.set(id, entered);
          await removeLegacyCredentialCopies(id);
          setChatStatus('Credential saved to memory for this session only. Its previous plain legacy copy was redacted; closing the app will discard this session credential.', '');
        }
      }
      if (!(await saveChatState())) throw new Error('Provider profile could not be persisted and verified.');
      if (entered && !(await finalizeLegacyChatMigrationIfSafe()) && chatCorruptRaw) {
        setChatStatus('New credential is configured, but an unreadable legacy chat record remains quarantined for recovery.', '');
      }
      input.value = ''; document.getElementById('chat-provider-security').textContent = `${providerStatusText()} Provider URL and model saved; no API key is present in chat history.`;
      setChatStatus(entered ? (secureChatCredentialMatches(id) ? 'Provider credential encrypted, verified and bound to this HTTPS endpoint in Android Keystore.' : 'Provider available for this browser session only.') : (secureChatSecrets.has(id) && !secureChatCredentialMatches(id) ? 'Provider endpoint changed. Re-enter and save the key to bind it to the new endpoint.' : 'Provider settings saved. Existing credential retained.'), 'ok');
      toast('Provider settings saved.');
    } catch (error) { input.value = ''; setChatStatus(`Provider settings were not fully saved: ${error.message}`, 'err'); }
  };
  document.getElementById('chat-test-provider').onclick = () => { void testChatProviderConnection(); };
  document.getElementById('chat-clear-key').onclick = async () => {
    const id = chatState.provider;
    if (!confirm(`Delete the saved ${CHAT_PROVIDERS[id].name} credential from this device and any retained legacy copy?`)) return;
    try {
      sessionChatSecrets.delete(id);
      if (window.Loadout?.secrets?.available) { await window.Loadout.secrets.delete(`ai-${id}`); secureChatSecrets.delete(id); secureChatOrigins.delete(id); unboundChatSecrets.delete(id); }
      await removeLegacyCredentialCopies(id);
      setChatStatus('Provider credential deleted. Conversation history was not changed.', 'ok');
      renderChatbot();
    } catch (error) { setChatStatus(`Credential deletion failed: ${error.message}`, 'err'); }
  };
  document.getElementById('chat-context-summary').onchange = event => { chatState.preferences.includeStudySummary = !!event.target.checked; void saveChatState(); updateContextPreview(); };
  document.getElementById('chat-context-tests').onchange = event => { chatState.preferences.includeRecentTests = !!event.target.checked; void saveChatState(); updateContextPreview(); };
  document.getElementById('chat-history-count').onchange = event => { chatState.preferences.historyMessages = Math.max(2, Math.min(80, Number(event.target.value) || 24)); event.target.value = chatState.preferences.historyMessages; void saveChatState(); };
  document.getElementById('chat-output-tokens').onchange = event => { chatState.preferences.maxOutputTokens = Math.max(128, Math.min(8192, Number(event.target.value) || 2048)); event.target.value = chatState.preferences.maxOutputTokens; void saveChatState(); };
  document.getElementById('chat-export').onclick = downloadChatBackup;
  document.getElementById('chat-export-corrupt')?.addEventListener('click', downloadUnreadableChatArchive);
  document.getElementById('chat-ack-corrupt-export')?.addEventListener('click', () => { void acknowledgeCorruptChatExport(); });
  document.getElementById('chat-clear-all').onclick = () => { void clearAllChatHistory(); };
  document.getElementById('chat-import-trigger').onclick = () => document.getElementById('chat-import-file').click();
  document.getElementById('chat-import-file').onchange = async event => { try { await importChatBackupFile(event.target.files?.[0]); } catch (error) { setChatStatus(`Import failed: ${error.message}`, 'err'); } finally { event.target.value = ''; } };
  document.getElementById('chat-send').onclick = () => sendChat();
  document.getElementById('chat-stop').onclick = () => { void stopChatGeneration(); };
  document.getElementById('chat-input').addEventListener('input', updateContextPreview);
  document.getElementById('chat-input').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendChat(); } });
  document.querySelectorAll('#chat-suggestions button').forEach(button => { button.onclick = () => { document.getElementById('chat-input').value = button.dataset.prompt; sendChat(); }; });
  document.getElementById('chat-clear-current').onclick = () => window.clearLoadoutChat();
  document.getElementById('chat-messages')?.addEventListener('click', event => { const button = event.target.closest('[data-message-action]'); if (button) void handleChatMessageAction(button.dataset.messageId, button.dataset.messageAction); });
}
function escapeHtml(value) { return AI_COACH.escapeHtml(value); }
function safeMarkdown(source) { return AI_COACH.renderMarkdown(messageText(source)); }
function paintMessages(scroll = true) {
  const box = document.getElementById('chat-messages'); if (!box) return;
  const messages = chatMessages();
  if (!messages.length) {
    box.innerHTML = '<div class="msg system">Start a conversation. History stays local until you explicitly send a request to a configured provider.</div>';
    return;
  }
  box.innerHTML = messages.map(message => {
    const role = message.role === 'user' ? 'You' : message.role === 'assistant' ? 'Coach' : 'System';
    const cls = message.role === 'user' ? 'user' : message.role === 'assistant' ? 'assistant' : 'system';
    const actions = [`<button class="btn small" data-message-action="copy" data-message-id="${escapeHtml(message.id)}">Copy</button>`, `<button class="btn small" data-message-action="delete" data-message-id="${escapeHtml(message.id)}">Delete</button>`];
    if (message.role === 'user') actions.push(`<button class="btn small" data-message-action="edit" data-message-id="${escapeHtml(message.id)}">Edit &amp; resend</button>`);
    if (message.role === 'assistant' && message.status === 'complete') actions.push(`<button class="btn small" data-message-action="regenerate" data-message-id="${escapeHtml(message.id)}">Regenerate</button>`);
    if (message.role === 'assistant' && (message.status === 'error' || message.status === 'cancelled')) actions.push(`<button class="btn small" data-message-action="retry" data-message-id="${escapeHtml(message.id)}">Retry</button>`);
    const statusLabel = message.status === 'streaming' ? '<span class="tiny">Generating…</span>' : message.status === 'error' ? '<span class="tiny" style="color:var(--red)">Request failed</span>' : message.status === 'cancelled' ? '<span class="tiny">Stopped</span>' : '';
    const content = message.content ? safeMarkdown(message.content) : (message.status === 'streaming' ? '<div class="typing"><span></span><span></span><span></span></div>' : '');
    return `<article class="msg ${cls}" data-message-id="${escapeHtml(message.id)}"><div class="role"><span>${role}${message.provider ? ` · ${escapeHtml(CHAT_PROVIDERS[message.provider]?.name || message.provider)}` : ''}</span><span class="chat-message-actions">${actions.join('')}</span></div><div class="chat-message-content">${content}</div><div class="tiny chat-message-time">${statusLabel} ${escapeHtml(new Date(message.createdAt || Date.now()).toLocaleString())}</div></article>`;
  }).join('');
  const mathRoots = box.querySelectorAll('.chat-message-content');
  mathRoots.forEach(element => AI_COACH.renderMath(element));
  if (scroll) box.scrollTop = box.scrollHeight;
}
function messageText(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(part => typeof part === 'string' ? part : (part && (part.text || part.content) || '')).join('');
  if (content && typeof content === 'object') return content.text || content.content || JSON.stringify(content);
  return '';
}

async function initializeAiCoach() {
  await hydrateChatFromPrivateMirror();
  await initializeChatStorage();
  if (currentView === 'chatbot') renderChatbot();
}
window.LoadoutReady?.then(async () => { try { const result = await window.Loadout?.repairs?.applyActive?.(); if (result?.applied) console.info('Loadout visual repairs applied:', result.applied); } catch (error) { await window.Loadout?.diagnostics?.record?.('warn','ui-repair-reapply-failed',{message:error.message}); } await initializeAiCoach(); }).catch(error => {
  chatMigrationNotice = `AI Coach storage initialisation failed: ${error.message}`;
  setChatStatus(chatMigrationNotice, 'err');
});

// Start only after the AI Coach module and its secure storage/migration code are defined.
init();
