package __PACKAGE__;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONObject;
import org.json.JSONArray;
import android.content.pm.PackageInfo;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.net.URI;
import java.net.URL;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.net.ssl.HttpsURLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Semaphore;
import java.util.Set;

@CapacitorPlugin(name = "LoadoutCore")
public class LoadoutCorePlugin extends Plugin {
    private static final Pattern SAFE = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$");
    private static final int MAX_BYTES = 32 * 1024 * 1024;
    private static final String KEYSTORE_ALIAS = "loadout.credentials.aesgcm.v1";
    private static final int MAX_AI_REQUEST_BYTES = 2 * 1024 * 1024;
    private static final int MAX_AI_RESPONSE_BYTES = 4 * 1024 * 1024;
    private final ExecutorService aiExecutor = Executors.newFixedThreadPool(2);
    private final ConcurrentHashMap<String, HttpsURLConnection> activeAiRequests = new ConcurrentHashMap<>();
    private final Set<String> pendingAiRequests = ConcurrentHashMap.newKeySet();
    private final Set<String> cancelledAiRequests = ConcurrentHashMap.newKeySet();
    private final Semaphore aiRequestSlots = new Semaphore(4);

    private boolean safe(String value) { return value != null && SAFE.matcher(value).matches() && !".".equals(value) && !"..".equals(value); }

    private File namespaceDir(String namespace) throws Exception {
        if (!safe(namespace)) throw new Exception("Invalid storage namespace");
        File base = new File(getContext().getFilesDir(), "loadout");
        File dir = new File(base, namespace);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create private storage directory");
        String basePath = base.getCanonicalPath() + File.separator;
        if (!dir.getCanonicalPath().startsWith(basePath)) throw new Exception("Storage path escaped private root");
        return dir;
    }

    private File target(String namespace, String key) throws Exception {
        if (!safe(key)) throw new Exception("Invalid storage key");
        File dir = namespaceDir(namespace);
        File file = new File(dir, key);
        if (!file.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) throw new Exception("Storage path escaped namespace");
        return file;
    }

    @PluginMethod
    public void saveFileBase64(PluginCall call) {
        Uri createdUri = null;
        try {
            String name = call.getString("fileName");
            String mimeType = call.getString("mimeType");
            if (mimeType == null || mimeType.trim().isEmpty()) mimeType = "application/octet-stream";
            String encoded = call.getString("base64");
            if (name == null || !name.matches("^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$") || name.contains("..")) {
                throw new Exception("Invalid export filename");
            }
            if (encoded == null) throw new Exception("Missing export content");
            // Enforce an encoded-size ceiling before Base64 decoding allocates the output buffer.
            if (encoded.length() > 42 * 1024 * 1024) throw new Exception("Export exceeds the 30 MiB limit");
            if (!mimeType.matches("^[A-Za-z0-9][A-Za-z0-9!#$&^_.+-]{0,63}/[A-Za-z0-9][A-Za-z0-9!#$&^_.+-]{0,63}$")) {
                throw new Exception("Invalid MIME type");
            }
            byte[] data = Base64.decode(encoded, Base64.DEFAULT);
            if (data.length > 30 * 1024 * 1024) throw new Exception("Export exceeds the 30 MiB limit");

            JSObject result = new JSObject();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = getContext().getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Loadout/");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                createdUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (createdUri == null) throw new Exception("Android could not create the Downloads export record");
                try (OutputStream output = resolver.openOutputStream(createdUri, "w")) {
                    if (output == null) throw new Exception("Android could not open the export destination");
                    output.write(data);
                    output.flush();
                }
                ContentValues published = new ContentValues();
                published.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(createdUri, published, null, null);
                result.put("uri", createdUri.toString());
                result.put("location", "Downloads/Loadout/" + name);
            } else {
                File external = getContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (external == null) throw new Exception("App-specific external storage is unavailable");
                File directory = new File(external, "Loadout");
                if (!directory.exists() && !directory.mkdirs()) throw new Exception("Could not create export directory");
                File destination = new File(directory, name);
                if (destination.exists()) {
                    String stem = name;
                    String extension = "";
                    int dot = name.lastIndexOf('.');
                    if (dot > 0) { stem = name.substring(0, dot); extension = name.substring(dot); }
                    int suffix = 1;
                    do { destination = new File(directory, stem + "-" + suffix++ + extension); } while (destination.exists() && suffix < 1000);
                    if (destination.exists()) throw new Exception("Could not allocate a unique export filename");
                }
                File temporary = new File(directory, destination.getName() + ".tmp");
                try (FileOutputStream output = new FileOutputStream(temporary)) { output.write(data); output.getFD().sync(); }
                if (!temporary.renameTo(destination)) throw new Exception("Could not finish the export file");
                result.put("uri", Uri.fromFile(destination).toString());
                result.put("location", "App files/Downloads/Loadout/" + destination.getName());
            }
            result.put("ok", true);
            result.put("bytes", data.length);
            call.resolve(result);
        } catch (Exception error) {
            if (createdUri != null) {
                try { getContext().getContentResolver().delete(createdUri, null, null); } catch (Exception ignored) { }
            }
            call.reject("File export failed: " + error.getMessage(), error);
        }
    }

    @PluginMethod
    public void getRuntimeInfo(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("available", true);
        ret.put("platform", "android");
        ret.put("androidApi", Build.VERSION.SDK_INT);
        ret.put("androidRelease", Build.VERSION.RELEASE);
        ret.put("deviceModel", Build.MANUFACTURER + " " + Build.MODEL);
        try {
            PackageInfo info = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            ret.put("packageName", getContext().getPackageName());
            ret.put("versionName", info.versionName == null ? "" : info.versionName);
            ret.put("versionCode", Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode);
        } catch (Exception ignored) { ret.put("packageName", getContext().getPackageName()); }
        call.resolve(ret);
    }

    @PluginMethod
    public void readPrivateFile(PluginCall call) {
        try {
            String namespace = call.getString("namespace");
            String key = call.getString("key");
            File file = target(namespace, key);
            if (!file.exists()) {
                File backup = new File(file.getParentFile(), file.getName() + ".previous");
                if (backup.exists()) backup.renameTo(file);
            }
            if (!file.exists()) { JSObject result = new JSObject(); result.put("value", (String) null); call.resolve(result); return; }
            if (file.length() > MAX_BYTES) throw new Exception("Stored item exceeds read limit");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (FileInputStream in = new FileInputStream(file)) {
                byte[] buffer = new byte[8192]; int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
            JSObject result = new JSObject();
            result.put("value", new String(out.toByteArray(), StandardCharsets.UTF_8));
            call.resolve(result);
        } catch (Exception error) { call.reject("Native read failed: " + error.getMessage(), error); }
    }

    @PluginMethod
    public void writePrivateFile(PluginCall call) {
        try {
            String namespace = call.getString("namespace");
            String key = call.getString("key");
            String value = call.getString("value");
            if (value == null) throw new Exception("Missing value");
            byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_BYTES) throw new Exception("Stored item exceeds 32 MiB limit");
            File file = target(namespace, key);
            File recovery = new File(file.getParentFile(), file.getName() + ".previous");
            if (!file.exists() && recovery.exists()) recovery.renameTo(file);
            File temp = new File(file.getParentFile(), file.getName() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) { out.write(bytes); out.getFD().sync(); }
            File backup = new File(file.getParentFile(), file.getName() + ".previous");
            if (backup.exists() && !backup.delete()) throw new Exception("Could not clear stale storage backup");
            boolean hadPrevious = file.exists();
            if (hadPrevious && !file.renameTo(backup)) throw new Exception("Could not preserve previous storage item");
            if (!temp.renameTo(file)) {
                if (hadPrevious) backup.renameTo(file);
                throw new Exception("Atomic storage activation failed");
            }
            if (backup.exists()) backup.delete();
            JSObject result = new JSObject(); result.put("ok", true); result.put("bytes", bytes.length); call.resolve(result);
        } catch (Exception error) { call.reject("Native write failed: " + error.getMessage(), error); }
    }

    @PluginMethod
    public void deletePrivateFile(PluginCall call) {
        try {
            File file = target(call.getString("namespace"), call.getString("key"));
            File backup = new File(file.getParentFile(), file.getName() + ".previous");
            File temp = new File(file.getParentFile(), file.getName() + ".tmp");
            boolean deleted = (!file.exists() || file.delete()) && (!backup.exists() || backup.delete()) && (!temp.exists() || temp.delete());
            JSObject result = new JSObject(); result.put("ok", deleted); call.resolve(result);
        } catch (Exception error) { call.reject("Native delete failed: " + error.getMessage(), error); }
    }


    private SecretKey credentialKey(boolean createIfMissing) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEYSTORE_ALIAS)) {
            return (SecretKey) keyStore.getKey(KEYSTORE_ALIAS, null);
        }
        File credentialDir = new File(new File(getContext().getFilesDir(), "loadout"), "credentials");
        File[] existingRecords = credentialDir.listFiles();
        if (existingRecords != null) {
            for (File record : existingRecords) {
                if (record.isFile() && record.getName().matches("^s_[a-f0-9]{64}(?:\\.(?:tmp|previous))?$")) {
                    throw new Exception("Credential encryption key is missing while encrypted records still exist; refusing to generate a replacement key that would strand other credentials");
                }
            }
        }
        if (!createIfMissing) throw new Exception("Credential encryption key is missing; refusing to generate a replacement for existing ciphertext");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private String secretFileKey(String id) throws Exception {
        if (!safe(id)) throw new Exception("Invalid credential identifier");
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(id.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder("s_");
        for (byte b : digest) out.append(String.format(java.util.Locale.ROOT, "%02x", b));
        return out.toString();
    }

    @PluginMethod
    public void setSecret(PluginCall call) {
        try {
            String id = call.getString("id");
            if (!safe(id)) throw new Exception("Invalid credential identifier");
            String value = call.getString("value");
            if (value == null) throw new Exception("Missing credential value");
            if (value.getBytes(StandardCharsets.UTF_8).length > 32768) throw new Exception("Credential exceeds 32 KiB limit");
            String originInput = call.getString("origin");
            // Saving a credential is local work: do not require DNS or network availability.
            // Live endpoint/DNS checks happen only when a provider request is actually sent.
            URI credentialUri = new URI(originInput);
            if (credentialUri.getRawQuery() != null) throw new Exception("Provider base URL must not contain query parameters");
            String origin = normalizedAiOrigin(originInput);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, credentialKey(true));
            cipher.updateAAD((id + "|" + origin).getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            byte[] ciphertext = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            byte[] combined = new byte[iv.length + ciphertext.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(ciphertext, 0, combined, iv.length, ciphertext.length);
            String encrypted = Base64.encodeToString(combined, Base64.NO_WRAP);
            JSONObject record = new JSONObject();
            record.put("version", 2);
            record.put("origin", origin);
            record.put("ciphertext", encrypted);
            byte[] recordBytes = record.toString().getBytes(StandardCharsets.UTF_8);
            File file = target("credentials", secretFileKey(id));
            File temp = new File(file.getParentFile(), file.getName() + ".tmp");
            File backup = new File(file.getParentFile(), file.getName() + ".previous");
            try (FileOutputStream out = new FileOutputStream(temp)) { out.write(recordBytes); out.getFD().sync(); }
            if (backup.exists() && !backup.delete()) throw new Exception("Could not clear stale credential backup");
            boolean hadPrevious = file.exists();
            if (hadPrevious && !file.renameTo(backup)) throw new Exception("Could not preserve previous credential record");
            if (!temp.renameTo(file)) {
                if (hadPrevious) backup.renameTo(file);
                throw new Exception("Atomic credential activation failed");
            }
            if (backup.exists()) backup.delete();
            JSObject result = new JSObject(); result.put("ok", true); result.put("encrypted", true); call.resolve(result);
        } catch (Exception error) { call.reject("Secure credential save failed: " + error.getMessage(), error); }
    }

    private String normalizedAiOrigin(String address) throws Exception {
        URI uri = new URI(address);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getFragment() != null) {
            throw new Exception("AI credential origin must be an HTTPS origin");
        }
        String host = uri.getHost().toLowerCase(java.util.Locale.ROOT);
        int port = uri.getPort() < 0 ? 443 : uri.getPort();
        return "https://" + host + (port == 443 ? "" : ":" + port);
    }

    private String readSecretValue(String id, String requestUrl) throws Exception {
        if (!safe(id)) throw new Exception("Invalid credential identifier");
        File file = target("credentials", secretFileKey(id));
        if (!file.exists()) {
            File previous = new File(file.getParentFile(), file.getName() + ".previous");
            if (previous.exists() && !previous.renameTo(file)) throw new Exception("Could not recover previous credential record");
        }
        if (!file.exists()) return null;
        if (file.length() > 65536) throw new Exception("Encrypted credential record exceeds limit");
        byte[] encoded = new byte[(int) file.length()];
        try (FileInputStream in = new FileInputStream(file)) {
            int offset = 0, count;
            while (offset < encoded.length && (count = in.read(encoded, offset, encoded.length - offset)) != -1) offset += count;
            if (offset != encoded.length) throw new Exception("Credential record read was incomplete");
        }
        JSONObject record = new JSONObject(new String(encoded, StandardCharsets.UTF_8));
        if (record.optInt("version", 0) != 2) throw new Exception("Legacy credential is not endpoint-bound; re-enter and save this provider key");
        String origin = record.optString("origin", "");
        String expectedOrigin = normalizedAiOrigin(requestUrl);
        if (origin.isEmpty() || !origin.equals(expectedOrigin)) throw new Exception("Credential is bound to a different provider endpoint; re-enter and save the key for this endpoint");
        byte[] combined = Base64.decode(record.getString("ciphertext"), Base64.NO_WRAP);
        if (combined.length <= 12 + 16) throw new Exception("Encrypted credential record is malformed");
        byte[] iv = new byte[12]; byte[] ciphertext = new byte[combined.length - 12];
        System.arraycopy(combined, 0, iv, 0, 12); System.arraycopy(combined, 12, ciphertext, 0, ciphertext.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, credentialKey(false), new GCMParameterSpec(128, iv));
        cipher.updateAAD((id + "|" + origin).getBytes(StandardCharsets.UTF_8));
        return new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
    }

    @PluginMethod
    public void hasSecret(PluginCall call) {
        try {
            String id = call.getString("id");
            File file = target("credentials", secretFileKey(id));
            File previous = new File(file.getParentFile(), file.getName() + ".previous");
            if (!file.isFile() && previous.isFile()) { previous.renameTo(file); }
            JSObject result = new JSObject();
            boolean available = file.isFile();
            boolean originBound = false;
            String origin = "";
            if (available && file.length() <= 65536) {
                try (FileInputStream in = new FileInputStream(file)) {
                    byte[] bytes = new byte[(int) file.length()];
                    int offset = 0, count;
                    while (offset < bytes.length && (count = in.read(bytes, offset, bytes.length - offset)) != -1) offset += count;
                    if (offset != bytes.length) throw new Exception("Credential status read was incomplete");
                    JSONObject record = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
                    originBound = record.optInt("version", 0) == 2;
                    origin = originBound ? record.optString("origin", "") : "";
                    originBound = originBound && !origin.isEmpty();
                } catch (Exception ignored) { originBound = false; origin = ""; }
            }
            result.put("available", available);
            result.put("originBound", originBound);
            if (originBound) result.put("origin", origin);
            call.resolve(result);
        } catch (Exception error) { call.reject("Secure credential status check failed: " + error.getMessage(), error); }
    }

    private void validateAiEndpoint(String address) throws Exception {
        URI uri = new URI(address);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getFragment() != null) {
            throw new Exception("AI provider endpoint must be an HTTPS URL without embedded credentials or fragments");
        }
        String host = uri.getHost().toLowerCase(java.util.Locale.ROOT);
        String query = uri.getRawQuery();
        if (query != null && !"alt=sse".equals(query)) throw new Exception("Provider endpoint query parameters are not supported; only Gemini alt=sse streaming is allowed");
        if ("localhost".equals(host) || host.endsWith(".localhost") || host.endsWith(".local")) throw new Exception("Local-network provider endpoints are not supported by the secure transport");
        InetAddress[] resolved = InetAddress.getAllByName(host);
        if (resolved.length == 0) throw new Exception("Provider hostname did not resolve");
        for (InetAddress addressValue : resolved) {
            if (addressValue.isAnyLocalAddress() || addressValue.isLoopbackAddress() || addressValue.isLinkLocalAddress() || addressValue.isSiteLocalAddress() || addressValue.isMulticastAddress()) {
                throw new Exception("Provider hostname resolves to a private or non-routable address");
            }
        }
    }

    private String readBounded(InputStream input, int maxBytes) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count; int total = 0;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > maxBytes) throw new Exception("AI provider response exceeded the 4 MiB safety limit");
                out.write(buffer, 0, count);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String extractAiStreamText(String providerKind, String jsonData) throws Exception {
        JSONObject event = new JSONObject(jsonData);
        if (event.has("error") && !event.isNull("error")) throw new Exception("Provider returned an error during streaming");
        StringBuilder text = new StringBuilder();
        if ("gemini".equals(providerKind)) {
            JSONArray candidates = event.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return "";
            JSONObject content = candidates.optJSONObject(0) == null ? null : candidates.optJSONObject(0).optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            if (parts == null) return "";
            for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.optJSONObject(i);
                if (part != null) text.append(part.optString("text", ""));
            }
            return text.toString();
        }
        JSONArray choices = event.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject delta = choice == null ? null : choice.optJSONObject("delta");
        if (delta == null) return "";
        Object value = delta.opt("content");
        if (value instanceof String) return (String) value;
        if (value instanceof JSONArray) {
            JSONArray parts = (JSONArray) value;
            for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.optJSONObject(i);
                if (part != null) text.append(part.optString("text", ""));
            }
        }
        return text.toString();
    }

    private int readAiEventStream(InputStream input, String requestId, String providerKind) throws Exception {
        if (input == null) throw new Exception("Provider returned an empty streaming response");
        int bytesRead = 0;
        StringBuilder eventData = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (cancelledAiRequests.contains(requestId)) throw new CancellationException("AI request cancelled");
                bytesRead += line.getBytes(StandardCharsets.UTF_8).length + 1;
                if (bytesRead > MAX_AI_RESPONSE_BYTES) throw new Exception("AI provider stream exceeded the 4 MiB safety limit");
                if (line.isEmpty()) {
                    String data = eventData.toString().trim();
                    eventData.setLength(0);
                    if (!data.isEmpty() && !"[DONE]".equals(data)) {
                        String delta = extractAiStreamText(providerKind, data);
                        if (!delta.isEmpty()) {
                            JSObject chunk = new JSObject();
                            chunk.put("requestId", requestId);
                            chunk.put("text", delta);
                            notifyListeners("aiProviderChunk", chunk);
                        }
                    }
                } else if (line.startsWith("data:")) {
                    if (eventData.length() > 0) eventData.append('\n');
                    eventData.append(line.substring(5).trim());
                }
            }
        }
        String finalData = eventData.toString().trim();
        if (!finalData.isEmpty() && !"[DONE]".equals(finalData)) {
            String delta = extractAiStreamText(providerKind, finalData);
            if (!delta.isEmpty()) {
                JSObject chunk = new JSObject();
                chunk.put("requestId", requestId);
                chunk.put("text", delta);
                notifyListeners("aiProviderChunk", chunk);
            }
        }
        if (cancelledAiRequests.contains(requestId)) throw new CancellationException("AI request cancelled");
        return bytesRead;
    }

    @PluginMethod
    public void requestAiProvider(PluginCall call) {
        String requestId = call.getString("requestId");
        String credentialId = call.getString("credentialId");
        String address = call.getString("url");
        String body = call.getString("body");
        String authMode = call.getString("authMode");
        if (authMode == null || authMode.isEmpty()) authMode = "bearer";
        String providerKind = "gemini".equals(call.getString("providerKind")) ? "gemini" : "openai";
        boolean stream = call.getData().optBoolean("stream", false);
        JSONObject extraHeaders = call.getData().optJSONObject("headers");
        if (requestId == null || !requestId.matches("^[A-Za-z0-9._-]{1,96}$") || !safe(credentialId)) { call.reject("Invalid AI request or credential identifier"); return; }
        if (body == null || body.getBytes(StandardCharsets.UTF_8).length > MAX_AI_REQUEST_BYTES) { call.reject("AI provider request body is missing or exceeds 2 MiB"); return; }
        if (!("bearer".equals(authMode) || "google-api-key".equals(authMode))) { call.reject("Unsupported AI authentication mode"); return; }
        if (!aiRequestSlots.tryAcquire()) { call.reject("Too many pending AI requests; stop or wait for an active request"); return; }
        if (!pendingAiRequests.add(requestId)) { aiRequestSlots.release(); call.reject("AI request ID is already pending or active"); return; }
        try {
        aiExecutor.execute(() -> {
            HttpsURLConnection connection = null;
            try {
                if (activeAiRequests.containsKey(requestId)) throw new Exception("AI request ID is already active");
                if (cancelledAiRequests.contains(requestId)) throw new CancellationException("AI request cancelled");
                validateAiEndpoint(address);
                String credential = readSecretValue(credentialId, address);
                if (credential == null || credential.trim().isEmpty()) throw new Exception("No securely stored provider credential was found");
                connection = (HttpsURLConnection) new URL(address).openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(120000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Accept", stream ? "text/event-stream, application/json" : "application/json");
                if ("bearer".equals(authMode)) connection.setRequestProperty("Authorization", "Bearer " + credential.trim());
                else connection.setRequestProperty("x-goog-api-key", credential.trim());
                if (extraHeaders != null && extraHeaders.has("HTTP-Referer")) connection.setRequestProperty("HTTP-Referer", "https://loadout.local");
                if (extraHeaders != null && extraHeaders.has("X-Title")) connection.setRequestProperty("X-Title", "Loadout JEE Main");
                activeAiRequests.put(requestId, connection);
                if (cancelledAiRequests.contains(requestId)) throw new CancellationException("AI request cancelled");
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body.getBytes(StandardCharsets.UTF_8)); output.flush();
                }
                if (cancelledAiRequests.contains(requestId)) throw new CancellationException("AI request cancelled");
                int status = connection.getResponseCode();
                InputStream response = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                String contentType = connection.getContentType() == null ? "" : connection.getContentType();
                boolean streamed = stream && status >= 200 && status < 300 && contentType.toLowerCase(java.util.Locale.ROOT).contains("text/event-stream");
                String responseBody = "";
                if (streamed) readAiEventStream(response, requestId, providerKind);
                else responseBody = readBounded(response, MAX_AI_RESPONSE_BYTES);
                JSObject result = new JSObject();
                result.put("status", status); result.put("body", responseBody);
                result.put("contentType", contentType);
                result.put("requestId", requestId);
                result.put("streamed", streamed);
                call.resolve(result);
            } catch (Exception error) {
                // Never include request bodies, credentials, or full provider URLs in diagnostics/errors.
                call.reject("AI provider transport failed: " + error.getClass().getSimpleName() + ": " + error.getMessage(), error);
            } finally {
                activeAiRequests.remove(requestId);
                pendingAiRequests.remove(requestId);
                cancelledAiRequests.remove(requestId);
                if (connection != null) connection.disconnect();
                aiRequestSlots.release();
            }
        });
        } catch (RuntimeException rejected) {
            pendingAiRequests.remove(requestId);
            cancelledAiRequests.remove(requestId);
            aiRequestSlots.release();
            call.reject("AI request could not be scheduled: " + rejected.getClass().getSimpleName(), rejected);
        }
    }

    @PluginMethod
    public void cancelAiProviderRequest(PluginCall call) {
        String requestId = call.getString("requestId");
        if (requestId == null || !requestId.matches("^[A-Za-z0-9._-]{1,96}$")) { call.reject("Invalid AI request identifier"); return; }
        boolean knownRequest = pendingAiRequests.contains(requestId);
        if (knownRequest) cancelledAiRequests.add(requestId);
        HttpsURLConnection connection = activeAiRequests.remove(requestId);
        if (connection != null) connection.disconnect();
        JSObject result = new JSObject(); result.put("cancelled", knownRequest); call.resolve(result);
    }

    @PluginMethod
    public void deleteSecret(PluginCall call) {
        try {
            File file = target("credentials", secretFileKey(call.getString("id")));
            File previous = new File(file.getParentFile(), file.getName() + ".previous");
            File temp = new File(file.getParentFile(), file.getName() + ".tmp");
            boolean deleted = (!file.exists() || file.delete()) && (!previous.exists() || previous.delete()) && (!temp.exists() || temp.delete());
            JSObject result = new JSObject(); result.put("ok", deleted); call.resolve(result);
        } catch (Exception error) { call.reject("Secure credential delete failed: " + error.getMessage(), error); }
    }

    private SQLiteDatabase openLoadoutDatabase(String name) throws Exception {
        if (!"loadout-main".equals(name)) throw new Exception("Database name is not in the native allowlist");
        File file = getContext().getDatabasePath(name + ".db");
        File parent = file.getParentFile();
        if (parent == null || (!parent.exists() && !parent.mkdirs())) throw new Exception("Could not create private database directory");
        SQLiteDatabase database = SQLiteDatabase.openOrCreateDatabase(file, null);
        database.setForeignKeyConstraintsEnabled(true);
        return database;
    }

    private String migrationChecksum(int version, String id, JSArray statements) throws Exception {
        StringBuilder canonical = new StringBuilder().append(version).append('|').append(id).append('|');
        for (int i = 0; i < statements.length(); i++) {
            if (i > 0) canonical.append('\n');
            canonical.append(statements.getString(i));
        }
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(canonical.toString().getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte value : digest) hex.append(String.format(java.util.Locale.ROOT, "%02x", value));
        return hex.toString();
    }

    private String validateSql(String sql, String allowedStart) throws Exception {
        if (sql == null || sql.length() == 0 || sql.length() > 20000 || sql.indexOf('\0') >= 0 || sql.contains("--") || sql.contains("/*") || sql.contains("*/") || sql.contains(";")) {
            throw new Exception("SQL statement is empty, oversized, multi-statement or contains a comment delimiter");
        }
        String normalized = sql.trim();
        if (!normalized.matches("(?is)^(?:" + allowedStart + ")\\b.*$")) throw new Exception("SQL operation is not permitted by the database contract");
        String upper = normalized.toUpperCase(java.util.Locale.ROOT);
        if (upper.contains("ATTACH ") || upper.contains("DETACH ") || upper.contains("LOAD_EXTENSION") || upper.contains("WRITABLE_SCHEMA") || upper.contains("VACUUM") || upper.contains("BEGIN ") || upper.contains("COMMIT") || upper.contains("ROLLBACK")) {
            throw new Exception("Unsafe SQL operation rejected");
        }
        return normalized;
    }

    private String validateBatchSql(String sql) throws Exception {
        String normalized = validateSql(sql, "INSERT OR REPLACE INTO|INSERT INTO|DELETE FROM");
        String shape = normalized.replaceAll("\\s+", " ").toUpperCase(java.util.Locale.ROOT);
        // These are the only DML statements issued by database.js. Exact column order and
        // placeholder arity prevent the WebView from repurposing the bridge as a general SQL writer.
        String[] allowed = new String[]{
            "INSERT OR REPLACE INTO APP_STATE(STATE_KEY,SCHEMA_VERSION,PAYLOAD_JSON,PAYLOAD_SHA256,UPDATED_AT,REVISION,SOURCE_KIND)VALUES(?,?,?,?,?,?,?)",
            "INSERT INTO TEST_ATTEMPTS(ID,TEST_ID,DATE,TYPE,SCORE,N,CORRECT,WRONG,UNATTEMPTED,MINUTES,PAYLOAD_JSON,CREATED_AT,SOURCE_KIND)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            "INSERT INTO FORECASTS(ID,TEST_ID,TYPE,DATE,RAW_SCORE,CALIBRATED_SCORE,PAYLOAD_JSON,CREATED_AT,SOURCE_KIND)VALUES(?,?,?,?,?,?,?,?,?)",
            "INSERT OR REPLACE INTO LEGACY_IMPORTS(SOURCE_KEY,SOURCE_SHA256,RECORD_COUNT,IMPORTED_AT)VALUES(?,?,?,?)",
            "INSERT INTO RECOVERY_SNAPSHOTS(ID,SOURCE_KEY,PAYLOAD_JSON,PAYLOAD_SHA256,CREATED_AT,REASON)VALUES(?,?,?,?,?,?)",
            "INSERT INTO MIGRATION_CONFLICTS(ID,RECORD_KEY,LOCAL_SHA256,DATABASE_SHA256,CREATED_AT,RESOLUTION)VALUES(?,?,?,?,?,?)",
            "INSERT OR REPLACE INTO MODULE_RECORDS(MODULE_ID,RECORD_KEY,SCHEMA_VERSION,PAYLOAD_JSON,PAYLOAD_SHA256,UPDATED_AT)VALUES(?,?,?,?,?,?)",
            "DELETE FROM TEST_ATTEMPTS",
            "DELETE FROM FORECASTS"
        };
        for (String candidate : allowed) if (candidate.equals(shape)) return normalized;
        throw new Exception("Database write statement is not an exact approved operation");
    }

    private JSArray copyJsonArray(JSONArray source) throws Exception {
        JSArray result = new JSArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) result.put(source.get(i));
        return result;
    }

    private Object[] sqlArguments(JSArray values) throws Exception {
        if (values == null) return new Object[0];
        List<Object> source = values.toList();
        if (source.size() > 256) throw new Exception("Too many SQL bind arguments");
        Object[] output = new Object[source.size()];
        for (int i = 0; i < source.size(); i++) {
            Object value = source.get(i);
            if (value == JSONObject.NULL) value = null;
            if (value instanceof Boolean) value = ((Boolean) value) ? 1 : 0;
            if (value != null && !(value instanceof String) && !(value instanceof Integer) && !(value instanceof Long) && !(value instanceof Short) && !(value instanceof Byte) && !(value instanceof Float) && !(value instanceof Double) && !(value instanceof byte[])) {
                throw new Exception("Unsupported SQL bind type at index " + i);
            }
            output[i] = value;
        }
        return output;
    }

    @PluginMethod
    public void databaseMigrate(PluginCall call) {
        SQLiteDatabase database = null;
        try {
            String name = call.getString("name");
            JSArray migrations = call.getArray("migrations");
            if (!"loadout-main".equals(name)) throw new Exception("Database name is not in the native allowlist");
            if (migrations == null || migrations.length() != 2) throw new Exception("Migration manifest does not match the compiled schema contract");
            database = openLoadoutDatabase(name);
            int migrationsApplied = 0;
            database.beginTransaction();
            try {
                int before = database.getVersion();
                boolean hasHistory = false;
                try (Cursor cursor = database.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations' LIMIT 1", null)) { hasHistory = cursor.moveToFirst(); }
                if (!hasHistory && before != 0) throw new Exception("Database version exists without migration history; refusing an unsafe implicit repair");
                database.execSQL("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY NOT NULL, migration_id TEXT NOT NULL UNIQUE, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)");
                int current = database.getVersion();
                int previousManifestVersion = 0;
                for (int i = 0; i < migrations.length(); i++) {
                    JSONObject migration = migrations.getJSONObject(i);
                    int version = migration.getInt("version");
                    String id = migration.getString("id");
                    JSArray statements = copyJsonArray(migration.getJSONArray("statements"));
                    if (version <= previousManifestVersion || !safe(id) || statements.length() < 1 || statements.length() > 100) throw new Exception("Migration manifest ordering or metadata is invalid");
                    previousManifestVersion = version;
                    String checksum = migrationChecksum(version, id, statements);
                    String expectedId = version == 1 ? "core-records-v1" : version == 2 ? "recovery-and-indexes-v2" : null;
                    String expectedChecksum = version == 1 ? "d50edc00ef2a57662980f9b400c135e63667a80d6129373d52a3dbe99dad35e3" : version == 2 ? "e772478fd9783c98bb61e51db99d62bcf60b5109eca671342f686de7eb204017" : null;
                    if (expectedId == null || !expectedId.equals(id) || !expectedChecksum.equals(checksum)) throw new Exception("Migration is not an exact match for the compiled native schema contract: " + id);
                    if (version <= current) {
                        try (Cursor cursor = database.rawQuery("SELECT migration_id, checksum FROM schema_migrations WHERE version=?", new String[]{String.valueOf(version)})) {
                            if (!cursor.moveToFirst() || !id.equals(cursor.getString(0)) || !checksum.equals(cursor.getString(1))) throw new Exception("Previously applied migration does not match this binary: " + id);
                        }
                        continue;
                    }
                    if (version != current + 1) throw new Exception("Database migrations must be applied in contiguous version order; expected " + (current + 1) + " but received " + version);
                    for (int j = 0; j < statements.length(); j++) {
                        String sql = validateSql(statements.getString(j), "CREATE TABLE|CREATE INDEX|ALTER TABLE");
                        database.execSQL(sql);
                    }
                    java.text.SimpleDateFormat appliedAtFormat = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.ROOT);
                    appliedAtFormat.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                    database.execSQL("INSERT INTO schema_migrations(version,migration_id,checksum,applied_at) VALUES(?,?,?,?)", new Object[]{version, id, checksum, appliedAtFormat.format(new java.util.Date())});
                    current = version;
                    database.setVersion(current);
                    migrationsApplied++;
                }
                if (current != previousManifestVersion) throw new Exception("Database is not at the current bundled migration version");
                // The migration ledger must be an exact set, not merely contain the rows we expect.
                // This rejects injected/future history rows and duplicate semantic versions.
                try (Cursor cursor = database.rawQuery("SELECT COUNT(*) FROM schema_migrations", null)) {
                    if (!cursor.moveToFirst() || cursor.getInt(0) != migrations.length()) {
                        throw new Exception("Database migration ledger contains missing or unexpected rows");
                    }
                }
                database.setTransactionSuccessful();
            } finally { database.endTransaction(); }
            JSObject result = new JSObject(); result.put("ok", true); result.put("schemaVersion", database.getVersion()); result.put("migrationsApplied", migrationsApplied); call.resolve(result);
        } catch (Exception error) { call.reject("SQLite migration failed: " + error.getMessage(), error); }
        finally { if (database != null && database.isOpen()) database.close(); }
    }

    @PluginMethod
    public void databaseExecuteBatch(PluginCall call) {
        SQLiteDatabase database = null;
        try {
            String name = call.getString("name");
            JSArray statements = call.getArray("statements");
            if (statements == null || statements.length() < 1 || statements.length() > 20000) throw new Exception("Database batch is empty or exceeds the record limit");
            database = openLoadoutDatabase(name);
            int completed = 0;
            database.beginTransaction();
            try {
                for (int i = 0; i < statements.length(); i++) {
                    JSONObject operation = statements.getJSONObject(i);
                    String sql = validateBatchSql(operation.getString("sql"));
                    JSArray args = copyJsonArray(operation.optJSONArray("args"));
                    database.execSQL(sql, sqlArguments(args));
                    completed++;
                }
                database.setTransactionSuccessful();
            } finally { database.endTransaction(); }
            JSObject result = new JSObject(); result.put("ok", true); result.put("statementsExecuted", completed); call.resolve(result);
        } catch (Exception error) { call.reject("SQLite transaction failed: " + error.getMessage(), error); }
        finally { if (database != null && database.isOpen()) database.close(); }
    }

    @PluginMethod
    public void databaseQuery(PluginCall call) {
        SQLiteDatabase database = null;
        try {
            String name = call.getString("name");
            String sql = validateSql(call.getString("sql"), "SELECT");
            String queryShape = sql.trim().replaceAll("\\s+", " ").toUpperCase(java.util.Locale.ROOT);
            boolean permitted =
                "SELECT STATE_KEY, SCHEMA_VERSION, PAYLOAD_JSON, PAYLOAD_SHA256, REVISION, UPDATED_AT, SOURCE_KIND FROM APP_STATE WHERE STATE_KEY = ?".equals(queryShape) ||
                "SELECT ID,PAYLOAD_JSON FROM TEST_ATTEMPTS".equals(queryShape) ||
                "SELECT ID,PAYLOAD_JSON FROM FORECASTS".equals(queryShape) ||
                "SELECT VERSION,MIGRATION_ID,CHECKSUM FROM SCHEMA_MIGRATIONS ORDER BY VERSION".equals(queryShape) ||
                "SELECT PAYLOAD_JSON,PAYLOAD_SHA256,SCHEMA_VERSION,UPDATED_AT FROM MODULE_RECORDS WHERE MODULE_ID=? AND RECORD_KEY=?".equals(queryShape);
            if (!permitted) throw new Exception("Database read query is not in the native allowlist");
            JSArray args = call.getArray("args");
            Object[] rawArgs = sqlArguments(args);
            String[] selectionArgs = new String[rawArgs.length];
            for (int i = 0; i < rawArgs.length; i++) selectionArgs[i] = rawArgs[i] == null ? null : String.valueOf(rawArgs[i]);
            database = openLoadoutDatabase(name);
            JSArray rows = new JSArray();
            int maximumRows = 10000;
            try (Cursor cursor = database.rawQuery(sql, selectionArgs)) {
                int count = 0;
                while (cursor.moveToNext()) {
                    if (++count > maximumRows) throw new Exception("Database query result exceeds 10,000 rows");
                    JSObject row = new JSObject();
                    for (int column = 0; column < cursor.getColumnCount(); column++) {
                        String key = cursor.getColumnName(column);
                        switch (cursor.getType(column)) {
                            case Cursor.FIELD_TYPE_NULL: row.put(key, (String) null); break;
                            case Cursor.FIELD_TYPE_INTEGER: row.put(key, cursor.getLong(column)); break;
                            case Cursor.FIELD_TYPE_FLOAT: row.put(key, cursor.getDouble(column)); break;
                            case Cursor.FIELD_TYPE_BLOB: row.put(key, Base64.encodeToString(cursor.getBlob(column), Base64.NO_WRAP)); break;
                            default: row.put(key, cursor.getString(column)); break;
                        }
                    }
                    rows.put(row);
                }
            }
            JSObject result = new JSObject(); result.put("rows", rows); call.resolve(result);
        } catch (Exception error) { call.reject("SQLite query failed: " + error.getMessage(), error); }
        finally { if (database != null && database.isOpen()) database.close(); }
    }

    @PluginMethod
    public void databaseInfo(PluginCall call) {
        SQLiteDatabase database = null;
        try {
            database = openLoadoutDatabase(call.getString("name"));
            File file = getContext().getDatabasePath(call.getString("name") + ".db");
            JSObject result = new JSObject(); result.put("available", true); result.put("schemaVersion", database.getVersion()); result.put("bytes", file.exists() ? file.length() : 0); result.put("private", true); result.put("journalMode", "WAL-capable"); call.resolve(result);
        } catch (Exception error) { call.reject("SQLite info failed: " + error.getMessage(), error); }
        finally { if (database != null && database.isOpen()) database.close(); }
    }

    @PluginMethod
    public void listPrivateFiles(PluginCall call) {
        try {
            File dir = namespaceDir(call.getString("namespace"));
            JSArray names = new JSArray();
            File[] files = dir.listFiles();
            if (files != null) for (File file : files) if (file.isFile() && safe(file.getName()) && !file.getName().endsWith(".tmp") && !file.getName().endsWith(".previous")) names.put(file.getName());
            JSObject result = new JSObject(); result.put("files", names); call.resolve(result);
        } catch (Exception error) { call.reject("Native list failed: " + error.getMessage(), error); }
    }


    // Development Port: debug-build-only ADB/USB package inbox. No network listener or
    // remote command execution is exposed by the application.
    private void requireDebuggableDevelopmentPort() throws Exception {
        if ((getContext().getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) == 0) {
            throw new Exception("Development Port is disabled in non-debuggable builds");
        }
    }

    private File developmentPortInbox() throws Exception {
        requireDebuggableDevelopmentPort();
        File externalRoot = getContext().getExternalFilesDir(null);
        if (externalRoot == null) throw new Exception("App-specific external storage is unavailable");
        File inbox = new File(externalRoot, "Loadout/devport/inbox");
        if (!inbox.exists() && !inbox.mkdirs()) throw new Exception("Could not create the Development Port inbox");
        String root = externalRoot.getCanonicalPath() + File.separator;
        if (!inbox.getCanonicalPath().startsWith(root)) throw new Exception("Development Port inbox escaped app-specific storage");
        return inbox.getCanonicalFile();
    }

    private boolean safeDevelopmentPackageName(String name) {
        return name != null && name.length() <= 120
            && name.matches("^[A-Za-z0-9][A-Za-z0-9._-]{0,95}\\.(?:lupdate|lreg|lfix)$")
            && !name.contains("..");
    }

    @PluginMethod
    public void getDevelopmentPortStatus(PluginCall call) {
        JSObject result = new JSObject();
        boolean debug = (getContext().getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        result.put("available", debug);
        result.put("enabled", debug);
        result.put("transport", "adb-usb");
        result.put("authentication", "Android Debug Bridge host authorization");
        result.put("networkListener", false);
        result.put("remoteExecution", false);
        result.put("inbox", "Android/data/app.loadout.jee/files/Loadout/devport/inbox");
        result.put("packageExtensions", new JSArray().put(".lupdate").put(".lreg").put(".lfix"));
        result.put("maximumPackageBytes", 10 * 1024 * 1024);
        call.resolve(result);
    }

    @PluginMethod
    public void listDevelopmentPortPackages(PluginCall call) {
        try {
            File inbox = developmentPortInbox();
            File[] files = inbox.listFiles();
            List<File> accepted = new ArrayList<>();
            if (files != null) {
                for (File file : files) {
                    if (!file.isFile() || !safeDevelopmentPackageName(file.getName()) || file.length() > 10L * 1024L * 1024L) continue;
                    if (!file.getCanonicalFile().getParentFile().equals(inbox)) continue;
                    accepted.add(file);
                }
            }
            accepted.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            if (accepted.size() > 100) throw new Exception("Development Port inbox contains more than 100 package files; remove old files first");
            JSArray rows = new JSArray();
            for (File file : accepted) {
                JSObject row = new JSObject();
                row.put("name", file.getName());
                row.put("bytes", file.length());
                row.put("modifiedAt", file.lastModified());
                rows.put(row);
            }
            JSObject result = new JSObject(); result.put("packages", rows); result.put("count", rows.length()); call.resolve(result);
        } catch (Exception error) { call.reject("Development Port inbox listing failed: " + error.getMessage(), error); }
    }

    @PluginMethod
    public void readDevelopmentPortPackage(PluginCall call) {
        try {
            String name = call.getString("name");
            if (!safeDevelopmentPackageName(name)) throw new Exception("Invalid Development Port package filename");
            File inbox = developmentPortInbox();
            File file = new File(inbox, name).getCanonicalFile();
            if (!file.getParentFile().equals(inbox) || !file.isFile()) throw new Exception("Package file is not present in the Development Port inbox");
            if (file.length() < 2 || file.length() > 10L * 1024L * 1024L) throw new Exception("Package file is empty or exceeds 10 MiB");
            byte[] content = new byte[(int) file.length()];
            try (FileInputStream input = new FileInputStream(file)) {
                int offset = 0, count;
                while (offset < content.length && (count = input.read(content, offset, content.length - offset)) != -1) offset += count;
                if (offset != content.length) throw new Exception("Development Port package read was incomplete");
            }
            String text = new String(content, StandardCharsets.UTF_8);
            JSObject result = new JSObject(); result.put("name", name); result.put("bytes", content.length); result.put("packageText", text); call.resolve(result);
        } catch (Exception error) { call.reject("Development Port package read failed: " + error.getMessage(), error); }
    }

    @PluginMethod
    public void deleteDevelopmentPortPackage(PluginCall call) {
        try {
            String name = call.getString("name");
            if (!safeDevelopmentPackageName(name)) throw new Exception("Invalid Development Port package filename");
            File inbox = developmentPortInbox();
            File file = new File(inbox, name).getCanonicalFile();
            if (!file.getParentFile().equals(inbox)) throw new Exception("Package path escaped the Development Port inbox");
            boolean removed = !file.exists() || (file.isFile() && file.delete());
            if (!removed) throw new Exception("Could not delete imported package from the Development Port inbox");
            JSObject result = new JSObject(); result.put("ok", true); result.put("name", name); call.resolve(result);
        } catch (Exception error) { call.reject("Development Port package deletion failed: " + error.getMessage(), error); }
    }

    @PluginMethod
    public void getNativeExtensionInventory(PluginCall call) {
        JSObject extension = new JSObject();
        extension.put("id", "loadout.native.core");
        extension.put("version", "1.0.0");
        extension.put("apiVersion", 1);
        extension.put("implementation", "compiled-capacitor-plugin");
        extension.put("state", "active");
        extension.put("privilegeModel", "host-application-privileges");
        extension.put("restartPolicy", "apk-update-or-process-restart");
        extension.put("dynamicLoading", false);
        extension.put("deactivation", "not-supported-for-permanent-core");
        JSArray extensions = new JSArray(); extensions.put(extension);
        JSObject result = new JSObject();
        result.put("apiVersion", 1);
        result.put("extensions", extensions);
        result.put("dynamicDexJarLoading", false);
        result.put("nativeLibraryHotSwap", false);
        result.put("nativeChangesRequireApk", true);
        call.resolve(result);
    }

}
