# Structured database foundation

The executable logical schema and migration statements live in `www/runtime/database-schema.js`; the browser/native database service is in `www/runtime/database.js`; canonical state validation and row projection functions are in `www/runtime/database-model.js`.

Android uses the app-private SQLite database `loadout-main` through `native/android/LoadoutCorePlugin.java`. That plugin embeds the exact approved migration IDs/checksums and restricts queries/writes. Browser/PWA uses IndexedDB with matching logical stores. The original `loadout-jee-2027-v1` localStorage state remains the active application source of truth for release 1.5.0; the database is a verified additive mirror. See `documentation/ARCHITECTURE.md`, `documentation/DATA_DICTIONARY.md`, and ADR 0008/0009 before changing this boundary.
