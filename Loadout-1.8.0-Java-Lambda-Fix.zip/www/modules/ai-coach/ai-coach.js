/* Loadout AI Coach feature module.
 * JEE Main-only domain, offline conversation management, bounded context selection,
 * provider request contracts and safe Markdown rendering. Provider secrets are never
 * part of this module's persistent state or request payload objects.
 */
(function (global) {
  'use strict';
  const root = global.window || global;
  root.LoadoutModules = root.LoadoutModules || {};
  if (root.LoadoutModules.aiCoach) return;

  const VERSION = '1.0.0';
  const RUNTIME_API = '1.5.0';
  const MAX_CONVERSATIONS = 500;
  const MAX_MESSAGES_PER_CONVERSATION = 5000;
  const MAX_MESSAGE_CHARS = 200000;
  const MAX_CHAT_STORAGE_BYTES = 24 * 1024 * 1024;
  const PROVIDERS = Object.freeze({
    gemini: Object.freeze({ name: 'Google Gemini', kind: 'gemini', baseUrl: 'https://generativelanguage.googleapis.com/v1beta', model: 'gemini-3.8-flash', keyUrl: 'https://aistudio.google.com/apikey', note: 'Model and quota availability depend on your Google project.' }),
    groq: Object.freeze({ name: 'Groq', kind: 'openai', baseUrl: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-20b', keyUrl: 'https://console.groq.com/keys', note: 'Rate limits and model availability depend on your account.' }),
    openrouter: Object.freeze({ name: 'OpenRouter', kind: 'openai', baseUrl: 'https://openrouter.ai/api/v1', model: 'openrouter/free', keyUrl: 'https://openrouter.ai/keys', note: 'Free model availability and capacity can change.' }),
    huggingface: Object.freeze({ name: 'Hugging Face', kind: 'openai', baseUrl: 'https://router.huggingface.co/v1', model: 'deepseek-ai/DeepSeek-V4.1-Flash:fastest', keyUrl: 'https://huggingface.co/settings/tokens', note: 'Credits and availability depend on your account.' }),
    cerebras: Object.freeze({ name: 'Cerebras', kind: 'openai', baseUrl: 'https://api.cerebras.ai/v1', model: 'zai-glm-4.7', keyUrl: 'https://cloud.cerebras.ai/', note: 'Trial credits and model access can change.' }),
    custom: Object.freeze({ name: 'Custom OpenAI-compatible API', kind: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini', keyUrl: '', note: 'Must implement the OpenAI Chat Completions format over HTTPS.' })
  });
  const PROVIDER_IDS = Object.freeze(Object.keys(PROVIDERS));
  const DEFAULT_SYSTEM = `You are Loadout AI Coach, a JEE Main-only mentor for the selected examination cycle.
You help with Physics, Chemistry and Mathematics at JEE Main depth. Explain concepts from first principles, show derivations and assumptions, solve JEE Main-style questions step by step, identify common traps, and help prioritise chapters and revision.
Use only study records and context explicitly attached to the current request. Do not imply access to the user's database, question bank, saved conversations, files, or official notices unless their relevant content is included in the request.
Never invent question counts, PYQ frequencies, syllabus status, scores, statistics, rank predictions, or provider capabilities. Distinguish official facts, supplied data, calculations, and estimates. When a question is ambiguous, state the assumption or ask one focused question. Prefer logically complete explanations over unsupported assertions.`;

  function id(prefix) {
    const random = root.crypto && typeof root.crypto.randomUUID === 'function'
      ? root.crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
    return `${prefix}-${random}`;
  }
  function textOf(value) {
    if (typeof value === 'string') return value;
    if (Array.isArray(value)) return value.map(part => typeof part === 'string' ? part : part && (part.text || part.content) || '').join('');
    if (value && typeof value === 'object') return String(value.text || value.content || '');
    return '';
  }
  function safeDate(value, fallback) {
    const date = new Date(value || fallback || Date.now());
    return Number.isFinite(date.getTime()) ? date.toISOString() : new Date().toISOString();
  }
  function newConversation(title = 'New conversation') {
    const now = new Date().toISOString();
    return { id: id('conv'), title: String(title).slice(0, 100), createdAt: now, updatedAt: now, messages: [] };
  }
  function normalizeConversations(saved) {
    let rows = Array.isArray(saved && saved.conversations) ? saved.conversations :
      (Array.isArray(saved && saved.messages) ? [{ id: 'conversation-imported', title: 'Imported conversation', messages: saved.messages }] : []);
    rows = rows.slice(0, MAX_CONVERSATIONS).filter(row => row && typeof row === 'object' && Array.isArray(row.messages)).map((row, index) => {
      const seen = new Set();
      const messages = row.messages.slice(-MAX_MESSAGES_PER_CONVERSATION).filter(message => message && ['user', 'assistant', 'system'].includes(message.role)).map(message => {
        let messageId = String(message.id || id('msg')).slice(0, 128);
        if (seen.has(messageId)) messageId = id('msg');
        seen.add(messageId);
        const status = ['complete', 'streaming', 'cancelled', 'error'].includes(message.status) ? message.status : 'complete';
        return {
          id: messageId,
          role: message.role,
          content: textOf(message.content).slice(0, MAX_MESSAGE_CHARS),
          createdAt: safeDate(message.createdAt),
          status,
          ...(message.provider && PROVIDERS[message.provider] ? { provider: message.provider } : {}),
          ...(message.kind === 'error' ? { kind: 'error' } : {})
        };
      });
      return {
        id: String(row.id || `conversation-${index + 1}`).slice(0, 128),
        title: String(row.title || 'Conversation').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 100) || 'Conversation',
        createdAt: safeDate(row.createdAt),
        updatedAt: safeDate(row.updatedAt || row.createdAt),
        messages
      };
    });
    if (!rows.length) rows = [newConversation()];
    const ids = new Set();
    for (const row of rows) {
      if (ids.has(row.id)) row.id = id('conv');
      ids.add(row.id);
    }
    return rows;
  }
  function validateProviderBaseUrl(value) {
    let parsed;
    try { parsed = new URL(String(value || '').trim()); }
    catch (_) { throw new Error('Provider base URL is invalid.'); }
    if (parsed.protocol !== 'https:') throw new Error('Provider endpoints must use HTTPS.');
    if (parsed.search) throw new Error('Provider base URLs must not contain query parameters.');
    if (parsed.username || parsed.password || parsed.hash) throw new Error('Provider URL must not contain credentials or a fragment.');
    if (parsed.href.length > 500) throw new Error('Provider base URL is too long.');
    return parsed.href.replace(/\/$/, '');
  }
  function normalizeProfile(providerId, profile) {
    const provider = PROVIDERS[providerId] || PROVIDERS.custom;
    const p = profile && typeof profile === 'object' ? profile : {};
    return {
      baseUrl: String(p.baseUrl || provider.baseUrl).trim().slice(0, 500),
      model: String(p.model || provider.model).trim().slice(0, 160)
    };
  }
  function canRetryMessage(message, action) {
    if (!message || message.role !== 'assistant') return false;
    if (action === 'regenerate') return message.status === 'complete';
    if (action === 'retry') return message.status === 'error' || message.status === 'cancelled';
    return false;
  }
  function redactProviderError(value) {
    return String(value == null ? '' : value)
      .replace(/Bearer\s+[^\s"']+/gi, 'Bearer [redacted]')
      .replace(/AIza[0-9A-Za-z_-]{20,}/g, '[redacted]')
      .replace(/\bsk-(?:or-v1-)?[A-Za-z0-9_-]{16,}/g, '[redacted]')
      .replace(/\bhf_[A-Za-z0-9]{16,}/g, '[redacted]')
      .replace(/\bgsk_[A-Za-z0-9]{16,}/g, '[redacted]')
      .slice(0, 1200);
  }
  function normalizeState(saved) {
    const rawProfiles = saved && saved.profiles && typeof saved.profiles === 'object' ? saved.profiles : {};
    const profiles = {};
    for (const providerId of PROVIDER_IDS) profiles[providerId] = normalizeProfile(providerId, rawProfiles[providerId]);
    const conversations = normalizeConversations(saved || {});
    const requestedActive = String(saved && saved.activeConversationId || '');
    return {
      schemaVersion: 4,
      provider: PROVIDERS[saved && saved.provider] ? saved.provider : 'gemini',
      profiles,
      autoFallback: !!(saved && saved.autoFallback),
      preferences: {
        historyMessages: clampInteger(saved && saved.preferences && saved.preferences.historyMessages, 2, 80, 24),
        maxOutputTokens: clampInteger(saved && saved.preferences && saved.preferences.maxOutputTokens, 128, 8192, 2048),
        includeStudySummary: !!(saved && saved.preferences && saved.preferences.includeStudySummary),
        includeRecentTests: !!(saved && saved.preferences && saved.preferences.includeRecentTests)
      },
      conversations,
      activeConversationId: conversations.some(row => row.id === requestedActive) ? requestedActive : conversations[0].id
    };
  }
  function clampInteger(value, min, max, fallback) {
    const n = Number(value);
    return Number.isInteger(n) ? Math.max(min, Math.min(max, n)) : fallback;
  }
  function chatStorageSnapshot(state) {
    const normalized = normalizeState(state);
    // Explicit whitelist: provider keys and unknown import fields never leave memory.
    const snapshot = {
      schemaVersion: 4,
      provider: normalized.provider,
      profiles: normalized.profiles,
      autoFallback: normalized.autoFallback,
      preferences: normalized.preferences,
      conversations: normalized.conversations,
      activeConversationId: normalized.activeConversationId
    };
    const bytes = new TextEncoder().encode(JSON.stringify(snapshot)).length;
    if (bytes > MAX_CHAT_STORAGE_BYTES) throw new Error(`AI Coach history is ${Math.ceil(bytes / 1048576)} MiB; the safe local storage limit is 24 MiB. Export a backup and archive older conversations before continuing.`);
    return snapshot;
  }
  function appendStreamText(current, delta, maxChars = MAX_MESSAGE_CHARS) {
    const existing = textOf(current);
    const incoming = textOf(delta);
    const limit = clampInteger(maxChars, 1, MAX_MESSAGE_CHARS, MAX_MESSAGE_CHARS);
    const remaining = Math.max(0, limit - existing.length);
    return { content: existing + incoming.slice(0, remaining), truncated: incoming.length > remaining };
  }
  function recoverInterruptedStreams(saved) {
    const state = normalizeState(saved || {});
    let interruptedCount = 0;
    for (const conversation of state.conversations) {
      for (const message of conversation.messages) {
        if (message.status !== 'streaming') continue;
        message.status = 'cancelled';
        if (!message.content) message.content = 'Generation was interrupted before a response was saved. Retry the previous question.';
        interruptedCount++;
      }
    }
    return { state, interruptedCount };
  }
  function searchConversations(conversations, query) {
    const term = String(query || '').trim().toLocaleLowerCase();
    const rows = Array.isArray(conversations) ? conversations : [];
    return rows.filter(conversation => !term || `${conversation.title} ${conversation.messages.map(message => textOf(message.content)).join(' ')}`.toLocaleLowerCase().includes(term))
      .sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
  }
  function estimateTokens(value) {
    // Conservative UI estimate only; provider tokenisers are model-specific.
    return Math.max(1, Math.ceil(String(value || '').length / 3.6));
  }
  function selectHistory(messages, maxMessages, maxTokens) {
    const source = (Array.isArray(messages) ? messages : []).filter(message => message && ['user', 'assistant'].includes(message.role));
    const count = clampInteger(maxMessages, 2, 80, 24);
    const budget = clampInteger(maxTokens, 128, 100000, 8000);
    const selected = [];
    let used = 0;
    for (let index = source.length - 1; index >= 0 && selected.length < count; index--) {
      const message = source[index];
      const content = textOf(message.content);
      const tokens = estimateTokens(content) + 8;
      if (selected.length && used + tokens > budget) break;
      if (!selected.length && tokens > budget) {
        selected.unshift({ role: message.role, content: content.slice(-budget * 3) });
        break;
      }
      selected.unshift({ role: message.role, content });
      used += tokens;
    }
    return selected;
  }
  function buildStudyContext(options, source) {
    const prefs = options || {};
    const data = source || {};
    const parts = [];
    if (prefs.includeStudySummary) {
      const subjects = ['Physics', 'Chemistry', 'Mathematics'];
      const chapters = Array.isArray(data.chapters) ? data.chapters : [];
      const attempts = Array.isArray(data.attempts) ? data.attempts : [];
      const rows = subjects.map(subject => {
        const subjectChapters = chapters.filter(chapter => chapter.subject === subject);
        const completed = subjectChapters.filter(chapter => chapter.status === 'completed').length;
        const hasEvidence = subjectChapters.filter(chapter => Number.isFinite(chapter.mastery)).length;
        return `${subject}: ${subjectChapters.length} catalogued chapters; ${completed} marked completed; ${hasEvidence} with mastery evidence`;
      });
      parts.push(`STUDY SNAPSHOT (locally calculated; ${attempts.length} recorded test attempts):\n${rows.join('\n')}`);
    }
    if (prefs.includeRecentTests) {
      const attempts = (Array.isArray(data.attempts) ? data.attempts : []).slice().sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))).slice(0, 5);
      const rows = attempts.map(item => `${String(item.date || 'Undated').slice(0, 10)} | ${String(item.type || 'OTHER')} | ${String(item.testId || item.title || item.id || 'Unnamed')} | ${Number(item.correct) || 0}C/${Number(item.wrong) || 0}W/${Number(item.unattempted) || 0}U | score ${item.score == null ? 'pending' : Number(item.score)} / ${item.maxMarks == null ? 'unknown' : Number(item.maxMarks)}`);
      parts.push(`RECENT TEST RECORDS (maximum five; supplied local records, not independently verified):\n${rows.length ? rows.join('\n') : 'No test attempts are recorded.'}`);
    }
    return parts.join('\n\n');
  }
  function buildProviderRequest(providerId, profile, messages, systemPrompt, context, outputTokens) {
    const provider = PROVIDERS[providerId];
    if (!provider) throw new Error('Unknown AI provider.');
    const config = normalizeProfile(providerId, profile);
    const base = validateProviderBaseUrl(config.baseUrl);
    const prompt = String(systemPrompt || DEFAULT_SYSTEM) + (context ? `\n\nOWNER-SELECTED LOCAL CONTEXT:\n${context}` : '');
    const history = (Array.isArray(messages) ? messages : []).filter(item => item && ['user', 'assistant'].includes(item.role)).map(item => ({ role: item.role, content: textOf(item.content) }));
    const outputLimit = clampInteger(outputTokens, 128, 8192, 2048);
    if (provider.kind === 'gemini') {
      const model = config.model || provider.model;
      return {
        url: `${base}/models/${encodeURIComponent(model)}:generateContent`,
        authMode: 'google-api-key',
        headers: {},
        body: {
          systemInstruction: { parts: [{ text: prompt }] },
          contents: history.map(item => ({ role: item.role === 'assistant' ? 'model' : 'user', parts: [{ text: item.content }] })),
          generationConfig: { maxOutputTokens: outputLimit }
        }
      };
    }
    const url = /\/chat\/completions$/i.test(base) ? base : `${base}/chat/completions`;
    const headers = providerId === 'openrouter' ? { 'HTTP-Referer': 'https://loadout.local', 'X-Title': 'Loadout JEE Main' } : {};
    return {
      url, authMode: 'bearer', headers,
      body: { model: config.model || provider.model, messages: [{ role: 'system', content: prompt }, ...history], max_tokens: outputLimit }
    };
  }
  function buildConnectionTestRequest(providerId, profile) {
    return buildProviderRequest(
      providerId,
      profile,
      [{ role: 'user', content: 'Reply with exactly: LOADOUT_CONNECTION_OK' }],
      'You are verifying an API connection. Reply exactly with the requested confirmation text and nothing else.',
      '',
      128
    );
  }

  function parseProviderResponse(providerId, data) {
    const provider = PROVIDERS[providerId];
    if (!provider) throw new Error('Unknown AI provider.');
    if (provider.kind === 'gemini') {
      const answer = (data && data.candidates || []).flatMap(candidate => (candidate.content && candidate.content.parts || []).map(part => part.text || '')).join('\n').trim();
      if (!answer && data && data.promptFeedback && data.promptFeedback.blockReason) throw new Error(`Prompt blocked: ${data.promptFeedback.blockReason}`);
      return answer;
    }
    const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    return (typeof content === 'string' ? content : Array.isArray(content) ? textOf(content) : data && (data.output_text || data.response) || '').trim();
  }
  function createSseParser(providerId, onText) {
    let pending = '';
    let finished = false;
    function consumeLine(line) {
      if (!line || line.startsWith(':')) return;
      const match = line.match(/^data:\s?(.*)$/);
      if (!match) return;
      const value = match[1];
      if (value === '[DONE]') { finished = true; return; }
      let event;
      try { event = JSON.parse(value); } catch (_) { return; }
      let delta = '';
      if (PROVIDERS[providerId] && PROVIDERS[providerId].kind === 'gemini') {
        delta = (event.candidates || []).flatMap(candidate => candidate.content && candidate.content.parts || []).map(part => part.text || '').join('');
      } else {
        const choice = event.choices && event.choices[0];
        const content = choice && choice.delta && choice.delta.content;
        delta = typeof content === 'string' ? content : Array.isArray(content) ? textOf(content) : '';
        if (!delta && choice && choice.message) delta = textOf(choice.message.content);
      }
      if (delta) onText(delta);
      if (event.error) throw new Error(event.error.message || 'Provider stream error.');
    }
    return {
      push(chunk) {
        if (finished) return;
        pending += String(chunk || '');
        let newline;
        while ((newline = pending.indexOf('\n')) >= 0) {
          const line = pending.slice(0, newline).replace(/\r$/, '');
          pending = pending.slice(newline + 1);
          consumeLine(line);
        }
      },
      finish() { if (pending.trim()) consumeLine(pending.replace(/\r$/, '')); pending = ''; },
      get done() { return finished; }
    };
  }
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function safeHref(value) {
    const raw = String(value || '').trim();
    try {
      const url = new URL(raw);
      return ['https:', 'http:', 'mailto:'].includes(url.protocol) ? url.href : null;
    } catch (_) { return null; }
  }
  function renderInline(raw) {
    let value = escapeHtml(raw);
    const protectedParts = [];
    const hold = html => { const token = `\u0000${protectedParts.length}\u0000`; protectedParts.push(html); return token; };
    value = value.replace(/`([^`\n]+)`/g, (_, code) => hold(`<code>${code}</code>`));
    value = value.replace(/!?\[([^\]]+)\]\(([^\s)]+)(?:\s+"([^"]*)")?\)/g, (whole, label, href, title) => {
      if (whole.startsWith('!')) return hold(`<span class="chat-image-omitted">[Image omitted: ${label}]</span>`);
      const safe = safeHref(href.replace(/&amp;/g, '&'));
      return safe ? hold(`<a href="${escapeHtml(safe)}" target="_blank" rel="noopener noreferrer"${title ? ` title="${escapeHtml(title)}"` : ''}>${label}</a>`) : label;
    });
    value = value.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^_\n]+)__/g, '<strong>$1</strong>')
      .replace(/~~([^~\n]+)~~/g, '<del>$1</del>')
      .replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
    value = value.replace(/\u0000(\d+)\u0000/g, (_, index) => protectedParts[Number(index)] || '');
    return value;
  }
  function renderMarkdown(source) {
    const input = String(source == null ? '' : source).replace(/\r\n?/g, '\n').slice(0, MAX_MESSAGE_CHARS);
    const lines = input.split('\n');
    const out = [];
    const splitTable = row => row.trim().replace(/^\|/, '').replace(/\|$/, '').split(/(?<!\\)\|/).map(cell => cell.replace(/\\\|/g, '|').trim());
    const isSeparator = row => /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(row);
    const listMarker = line => {
      const match = String(line || '').match(/^([ \t]*)([-*+]|\d+[.)])\s+(.+)$/);
      if (!match) return null;
      return { indent: match[1].replace(/\t/g, '  ').length, type: /^\d/.test(match[2]) ? 'ol' : 'ul', content: match[3] };
    };
    function parseListAt(start, indent, type) {
      let index = start;
      const items = [];
      while (index < lines.length) {
        const marker = listMarker(lines[index]);
        if (!marker) break;
        if (marker.indent < indent) break;
        if (marker.indent > indent) {
          if (!items.length) break;
          const nested = parseListAt(index, marker.indent, marker.type);
          if (nested.next === index) break;
          items[items.length - 1] += nested.html;
          index = nested.next;
          continue;
        }
        if (marker.type !== type) break;
        items.push(renderInline(marker.content));
        index++;
      }
      return { html: items.length ? `<${type}>${items.map(item => `<li>${item}</li>`).join('')}</${type}>` : '', next: index };
    }
    let index = 0;
    while (index < lines.length) {
      const line = lines[index];
      if (!line.trim()) { index++; continue; }
      const fence = line.match(/^\s*```\s*([A-Za-z0-9_+.-]{0,32})\s*$/);
      if (fence) {
        const language = fence[1]; const code = []; index++;
        while (index < lines.length && !/^\s*```\s*$/.test(lines[index])) code.push(lines[index++]);
        if (index < lines.length) index++;
        out.push(`<pre class="chat-code"><code${language ? ` class="language-${escapeHtml(language)}"` : ''}>${escapeHtml(code.join('\n'))}</code></pre>`);
        continue;
      }
      const heading = line.match(/^\s*(#{1,6})\s+(.+)$/);
      if (heading) { const level = heading[1].length; out.push(`<h${level}>${renderInline(heading[2])}</h${level}>`); index++; continue; }
      if (/^\s*(---+|\*\*\*+|___+)\s*$/.test(line)) { out.push('<hr>'); index++; continue; }
      if (/^\s*>\s?/.test(line)) {
        const quote = [];
        while (index < lines.length && /^\s*>\s?/.test(lines[index])) quote.push(renderInline(lines[index++].replace(/^\s*>\s?/, '')));
        out.push(`<blockquote>${quote.map(item => `<p>${item}</p>`).join('')}</blockquote>`); continue;
      }
      const marker = listMarker(line);
      if (marker) {
        const list = parseListAt(index, marker.indent, marker.type);
        if (list.next === index) { out.push(`<p>${renderInline(line)}</p>`); index++; }
        else { out.push(list.html); index = list.next; }
        continue;
      }
      if (line.includes('|') && index + 1 < lines.length && isSeparator(lines[index + 1])) {
        const table = [line]; index += 2;
        while (index < lines.length && lines[index].includes('|') && lines[index].trim()) table.push(lines[index++]);
        const headers = splitTable(table[0]);
        out.push(`<div class="table-wrap"><table><thead><tr>${headers.map(cell => `<th>${renderInline(cell)}</th>`).join('')}</tr></thead><tbody>${table.slice(1).filter(row => !isSeparator(row)).map(row => `<tr>${splitTable(row).map(cell => `<td>${renderInline(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
        continue;
      }
      const paragraph = [line]; index++;
      while (index < lines.length && lines[index].trim() && !/^\s*(#{1,6})\s+/.test(lines[index]) && !/^\s*```/.test(lines[index]) && !/^\s*>/.test(lines[index]) && !listMarker(lines[index]) && !/^\s*(---+|\*\*\*+|___+)\s*$/.test(lines[index])) paragraph.push(lines[index++]);
      out.push(`<p>${paragraph.map(renderInline).join('<br>')}</p>`);
    }
    return out.join('\n');
  }
  function renderMath(element) {
    if (!element) return { rendered: false, reason: 'no-element' };
    if (typeof root.renderMathInElement !== 'function') return { rendered: false, reason: 'offline-renderer-not-installed' };
    const delimiters = [
      { left: '$$', right: '$$', display: true },
      { left: '\\[', right: '\\]', display: true },
      { left: '\\(', right: '\\)', display: false },
      { left: '$', right: '$', display: false }
    ];
    try {
      root.renderMathInElement(element, { delimiters, throwOnError: false, strict: 'ignore', trust: false, ignoredTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'option'] });
      return { rendered: true };
    } catch (error) { return { rendered: false, reason: error.message || 'math-render-failed' }; }
  }

  let registered = false;
  const module = {
    id: 'loadout.ai-coach', name: 'AI Coach', version: VERSION, runtimeApi: RUNTIME_API,
    providers: PROVIDERS, providerIds: PROVIDER_IDS, defaultSystemPrompt: DEFAULT_SYSTEM,
    newConversation, normalizeConversations, normalizeState, normalizeProfile, validateProviderBaseUrl, canRetryMessage, redactProviderError, chatStorageSnapshot,
    searchConversations, estimateTokens, selectHistory, buildStudyContext, buildProviderRequest,
    appendStreamText, recoverInterruptedStreams, parseProviderResponse, buildConnectionTestRequest, createSseParser, renderMarkdown, renderMath, escapeHtml,
    registerFeature() {
      if (!root.LoadoutFeatureRuntime || registered) return false;
      root.LoadoutFeatureRuntime.register({
        id: 'loadout.ai-coach', name: 'AI Coach', version: VERSION, runtimeApi: RUNTIME_API, route: 'chatbot', offline: true,
        services: {
          'ai-coach.conversations.normalize': normalizeConversations,
          'ai-coach.conversations.search': searchConversations,
          'ai-coach.context.build': buildStudyContext,
          'ai-coach.context.selectHistory': selectHistory,
          'ai-coach.provider.buildRequest': buildProviderRequest,
          'ai-coach.provider.buildConnectionTestRequest': buildConnectionTestRequest,
          'ai-coach.markdown.render': renderMarkdown,
          'ai-coach.math.render': renderMath
        },
        render(context) { context && context.legacy && typeof context.legacy.renderAiCoach === 'function' && context.legacy.renderAiCoach(); },
        onActivate(context) { context && context.onAiCoachActivate && context.onAiCoachActivate(); },
        onDeactivate(context) { context && context.onAiCoachDeactivate && context.onAiCoachDeactivate(); }
      });
      registered = true;
      return true;
    }
  };
  root.LoadoutModules.aiCoach = Object.freeze(module);
  if (root.LoadoutFeatureRuntime) module.registerFeature();
})(typeof window !== 'undefined' ? window : globalThis);
