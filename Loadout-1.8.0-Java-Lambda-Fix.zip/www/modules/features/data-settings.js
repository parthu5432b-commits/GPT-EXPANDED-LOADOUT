(function (global) {
  'use strict';
  const database = global.LoadoutDatabase;
  const service = async (name, ...args) => {
    if (!database || typeof database[name] !== 'function') throw new Error('Structured database service is unavailable.');
    return database[name].apply(database, args);
  };
  const backup = async (method, ...args) => {
    const module = await import('../../runtime/backup-manager.mjs');
    if (typeof module[method] !== 'function') throw new Error(`Backup service is unavailable: ${method}`);
    return module[method](...args);
  };
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.data-settings', name: 'Data & Settings', version: '1.3.0', runtimeApi: '1.5.0', route: 'data', offline: true,
    services: {
      'backup.create': (...args) => backup('createBackup', ...args),
      'backup.validate': (...args) => backup('validateBackup', ...args),
      'backup.merge': (...args) => backup('applyBackupToState', ...args),
      'database.initialize': (...args) => service('initialize', ...args),
      'database.bootstrap': (...args) => service('bootstrap', ...args),
      'database.verify': (...args) => service('verify', ...args),
      'database.sync': (...args) => service('enqueueSync', ...args),
      'database.status': (...args) => service('status', ...args)
    },
    render: ctx => ctx.legacy.dataSettings()
  });
})(window);
