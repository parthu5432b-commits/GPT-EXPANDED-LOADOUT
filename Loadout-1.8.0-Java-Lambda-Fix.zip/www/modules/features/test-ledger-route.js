(function (global) {
  'use strict';
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.test-ledger', name: 'Test Ledger', version: '1.2.0', runtimeApi: '1.5.0', route: 'tests', offline: true,
    dependencies: [],
    services: { 'test-ledger.validateCounts': global.LoadoutModules.testLedger.validateCounts, 'test-ledger.createAttempt': global.LoadoutModules.testLedger.createAttempt, 'test-ledger.removeAttempt': global.LoadoutModules.testLedger.removeAttempt },
    render: ctx => ctx.legacy.tests()
  });
})(window);
