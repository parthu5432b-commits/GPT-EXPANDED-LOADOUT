(function (global) {
  'use strict';
  const normalize = value => String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/\*/g, '').replace(/[–—]/g, '-').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
  function resolveChapter(value, chapters, aliases, byId, subject) {
    if (!value) return null;
    if (byId[value]) return byId[value];
    const key = normalize(value);
    const alias = aliases[key];
    if (alias && byId[alias]) return byId[alias];
    let candidates = chapters.filter(c => (!subject || c.subject.toLowerCase() === String(subject).toLowerCase()) && (normalize(c.name) === key || normalize(c.subject + ' ' + c.name) === key));
    if (candidates.length) return candidates[0];
    candidates = chapters.filter(c => (!subject || c.subject.toLowerCase() === String(subject).toLowerCase()) && (key.includes(normalize(c.name)) || normalize(c.name).includes(key)) && key.length > 4);
    return candidates.length === 1 ? candidates[0] : null;
  }
  function chapterAttempts(chapter, attempts, observationWeight) {
    const result = [];
    for (const test of attempts) for (const row of (test.chapterResults || [])) {
      if (row.chapterId === chapter.id && row.n > 0) result.push({ ...row, date: test.date, testId: test.testId, title: test.title, type: test.type, weight: observationWeight[test.type] ?? .35, testKey: test.id, globalScore: test.score });
    }
    return result.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  }
  global.LoadoutModules = global.LoadoutModules || {};
  global.LoadoutModules.chapterMap = Object.freeze({ normalize, resolveChapter, chapterAttempts });
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.chapter-map', name: 'Chapter Map', version: '1.1.0', runtimeApi: '1.5.0', route: 'chapters', offline: true,
    services: { 'chapter-map.normalize': normalize, 'chapter-map.resolve': resolveChapter, 'chapter-map.attempts': chapterAttempts, 'chapter-intelligence.calculateStats': global.LoadoutModules.chapterIntelligence.calculateStats, 'chapter-intelligence.calculateBaseline': global.LoadoutModules.chapterIntelligence.calculateBaseline },
    render: ctx => ctx.legacy.chapters()
  });
})(window);
