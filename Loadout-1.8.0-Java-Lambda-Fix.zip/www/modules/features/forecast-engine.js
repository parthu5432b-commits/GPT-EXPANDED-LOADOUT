(function (global) {
  'use strict';
  function regressionFor(type, attempts) {
    const data = (attempts || []).filter(a => a.prediction && a.prediction.type === type && Number.isFinite(a.prediction.raw) && Number.isFinite(a.score));
    if (!data.length) return { n: 0, a: 0, b: 1, mae: null, sd: null, method: 'Uncalibrated' };
    const errors = data.map(d => d.score - d.prediction.raw);
    const mae = errors.reduce((s, x) => s + Math.abs(x), 0) / errors.length;
    const meanErr = errors.reduce((s, x) => s + x, 0) / errors.length;
    let a = meanErr, b = 1, method = 'Mean-bias correction';
    if (data.length >= 8) {
      const mx = data.reduce((s, d) => s + d.prediction.raw, 0) / data.length;
      const my = data.reduce((s, d) => s + d.score, 0) / data.length;
      const den = data.reduce((s, d) => s + (d.prediction.raw - mx) ** 2, 0);
      if (den > 1e-6) {
        b = data.reduce((s, d) => s + (d.prediction.raw - mx) * (d.score - my), 0) / den;
        a = my - b * mx; method = 'Linear calibration';
      }
    }
    const calibratedErrors = data.map(d => d.score - (Number.isFinite(d.prediction.calibrated) ? d.prediction.calibrated : d.prediction.raw));
    const meanCal = calibratedErrors.reduce((s, x) => s + x, 0) / calibratedErrors.length;
    const sd = calibratedErrors.length > 1 ? Math.sqrt(calibratedErrors.reduce((s, x) => s + (x - meanCal) ** 2, 0) / (calibratedErrors.length - 1)) : null;
    return { n: data.length, a, b, mae, sd, method };
  }
  function predict({ type, id, schedule, chapters, settings, chapterStats, regression }) {
    if (!schedule) return null;
    let selected = type === 'QPT' ? (schedule.chapterIds || []).map(x => chapters.byId[x]).filter(Boolean) : chapters.all;
    selected = selected.filter(c => c.status === 'core');
    const baseline = chapters.globalBaseline;
    const per = selected.map(chapter => {
      const s = chapterStats(chapter), mastery = s.mastery == null ? baseline : s.mastery;
      return { chapter, mastery, count: s.count, observations: s.observations, transferCount: s.transferCount, confidence: s.confidence, meanMarksPerQ: settings.correctMarks * mastery / 100 };
    });
    const questionCount = Number(settings.blockQuestions);
    const raw = per.length ? questionCount * per.reduce((sum, p) => sum + p.meanMarksPerQ, 0) / per.length : 0;
    const cal = regression;
    const calibrated = cal.n >= 2 ? cal.a + cal.b * raw : raw;
    const residual = cal.sd;
    const half = cal.n >= 8 && residual != null ? Math.max(10, 1.65 * residual) : cal.n >= 4 && residual != null ? Math.max(15, 1.5 * residual) : Math.max(18, questionCount * .3);
    const dataCount = per.filter(p => p.observations > 0).length;
    const coverage = per.length ? dataCount / per.length : 0;
    let confidence = cal.n >= 8 && coverage > .75 ? 'High' : cal.n >= 4 && coverage > .5 ? 'Medium' : 'Low';
    if (coverage < .3) confidence = 'Low';
    const clipped = Math.max(-questionCount, Math.min(questionCount * 4, calibrated));
    return { type, id, sched: schedule, chapters: per, raw, calibrated: clipped, lower: Math.max(-questionCount, clipped - half), upper: Math.min(questionCount * 4, clipped + half), half, covered: dataCount, coverage, confidence, calibration: cal, questionCount };
  }
  global.LoadoutModules = global.LoadoutModules || {};
  global.LoadoutModules.forecastEngine = Object.freeze({ regressionFor, predict });
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.forecast-engine', name: 'Forecast Lab', version: '1.1.0', runtimeApi: '1.5.0', route: 'forecasts', offline: true,
    services: { 'forecast.regressionFor': regressionFor, 'forecast.predict': predict },
    render: ctx => ctx.legacy.forecasts()
  });
})(window);
