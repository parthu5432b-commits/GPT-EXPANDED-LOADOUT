(function (global) {
  'use strict';
  function scoreOf(correct, wrong, settings) { return Number(correct || 0) * Number(settings.correctMarks) + Number(wrong || 0) * Number(settings.wrongMarks); }
  function scorePercent(score, count, settings) { return count > 0 ? 100 * score / (Number(settings.correctMarks) * count) : null; }
  function calculateBaseline(chapters, attempts, observationWeight, settings) {
    let weighted = 0, totalWeight = 0;
    for (const chapter of chapters) for (const attempt of global.LoadoutModules.chapterMap.chapterAttempts(chapter, attempts, observationWeight)) {
      if (attempt.n > 0) {
        const weight = attempt.weight ?? 1;
        weighted += scorePercent(scoreOf(attempt.correct, attempt.wrong, settings), attempt.n, settings) * weight;
        totalWeight += weight;
      }
    }
    return totalWeight ? weighted / totalWeight : 50;
  }
  function calculateStats({ chapter, attempts, baseline, settings, tags, recoverability, hours }) {
    if (!attempts.length) return { chapter, attempts: [], count: 0, observations: 0, transferCount: 0, effectiveCount: 0, rawAvg: null, ema: null, mastery: null, sd: null, trend: null, confidence: 'Unmeasured', last: null, wrong: 0, unattempted: 0, lost: 0, errorMap: {}, priority: 0 };
    const per = attempts.map(attempt => ({ ...attempt, scaled: scorePercent(scoreOf(attempt.correct, attempt.wrong, settings), attempt.n, settings), score: scoreOf(attempt.correct, attempt.wrong, settings), weight: attempt.weight ?? 1 }));
    const rawAvg = per.reduce((sum, attempt) => sum + attempt.scaled, 0) / per.length;
    let ema = per[0].scaled, effectiveCount = per[0].weight;
    const alpha = Number(settings.alpha) || .35;
    for (let i = 1; i < per.length; i++) {
      const weight = per[i].weight, aEff = 1 - Math.pow(1 - alpha, weight);
      ema = aEff * per[i].scaled + (1 - aEff) * ema;
      effectiveCount += weight;
    }
    const k = Math.max(0, Number(settings.priorStrength) || 0);
    const mastery = (effectiveCount * ema + k * baseline) / (effectiveCount + k || 1);
    const sd = per.length > 1 ? Math.sqrt(per.reduce((sum, attempt) => sum + (attempt.scaled - rawAvg) ** 2, 0) / (per.length - 1)) : null;
    const trend = per.length > 1 ? per[per.length - 1].scaled - per[per.length - 2].scaled : null;
    const wrong = per.reduce((sum, attempt) => sum + attempt.wrong, 0);
    const unattempted = per.reduce((sum, attempt) => sum + attempt.unattempted, 0);
    const lost = per.reduce((sum, attempt) => sum + 5 * attempt.wrong + 4 * attempt.unattempted, 0);
    const errorMap = {};
    per.forEach(attempt => {
      const recorded = attempt.errorCounts || {}, questionMap = {};
      (attempt.questionErrors || []).forEach(error => { const tag = tags.includes(error.category) ? error.category : 'unclassified'; questionMap[tag] = (questionMap[tag] || 0) + 1; });
      tags.forEach(tag => { const count = Math.max(Number(recorded[tag]) || 0, questionMap[tag] || 0); errorMap[tag] = (errorMap[tag] || 0) + count; });
    });
    let categorized = Object.values(errorMap).reduce((sum, value) => sum + value, 0);
    if (!categorized && lost) { errorMap.unclassified = Math.ceil(lost / 4); categorized = errorMap.unclassified; }
    let priority = 0;
    tags.forEach(tag => { const count = errorMap[tag] || 0, lostMarks = tag === 'unclassified' ? lost * .65 : count * 4.5; priority += lostMarks * recoverability[tag] / hours[tag]; });
    const qctCount = per.filter(attempt => attempt.type === 'QCT').length, transferCount = per.length - qctCount;
    let confidence = effectiveCount >= 7 ? 'High' : effectiveCount >= 4 ? 'Medium' : effectiveCount >= 1 ? 'Low' : 'Unmeasured';
    if (sd != null && sd > 28) confidence = effectiveCount >= 4 ? 'Low / volatile' : confidence;
    return { chapter, attempts: per, count: qctCount, observations: per.length, transferCount, effectiveCount, rawAvg, ema, mastery, sd, trend, confidence, last: per[per.length - 1], wrong, unattempted, lost, errorMap, priority };
  }
  global.LoadoutModules = global.LoadoutModules || {};
  global.LoadoutModules.chapterIntelligence = Object.freeze({ scoreOf, scorePercent, calculateBaseline, calculateStats });
})(window);
