(function (global) {
  'use strict';
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.command-center', name: 'Command Center', version: '1.1.0', runtimeApi: '1.5.0', route: 'dashboard', offline: true,
    services: { 'dashboard.summary': global.LoadoutModules.dashboardAnalytics.calculateSummary },
    render: ctx => ctx.legacy.dashboard()
  });
})(window);
