(function (global) {
  'use strict';
  function datasetFor(subject, datasets) { return datasets && Object.prototype.hasOwnProperty.call(datasets, subject) ? datasets[subject] : null; }
  function filterRows(rows, query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return (rows || []).slice();
    return (rows || []).filter(row => `${row.topic || row.name || ''} ${row.subtopic || ''} ${row.chapter_name || ''}`.toLowerCase().includes(q));
  }
  global.LoadoutModules = global.LoadoutModules || {};
  global.LoadoutModules.pyqIntelligence = Object.freeze({ datasetFor, filterRows });
  global.LoadoutFeatureRuntime.register({
    id: 'loadout.pyq-intelligence', name: 'PYQ Intelligence', version: '1.1.0', runtimeApi: '1.5.0', route: 'historical', offline: true,
    services: { 'pyq.datasetFor': datasetFor, 'pyq.filterRows': filterRows },
    render: ctx => ctx.legacy.historical()
  });
})(window);
