(function (global) {
  'use strict';
  function calculateSummary({ attempts, chapterRows, chapterStats, baseline, today }) {
    const completed = attempts.filter(attempt => attempt.score !== null && attempt.score !== undefined).sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    const last = completed.slice(-1)[0], predictions = completed.filter(attempt => attempt.prediction);
    const errors = predictions.map(attempt => attempt.score - attempt.prediction.raw);
    const mae = errors.length ? errors.reduce((sum, error) => sum + Math.abs(error), 0) / errors.length : null;
    const tested = chapterRows.filter(chapter => chapterStats(chapter).observations > 0).length;
    const xp = completed.reduce((sum, attempt) => {
      const categories = Math.max((attempt.questionErrors || []).length, (attempt.chapterResults || []).reduce((total, row) => total + Math.max((row.questionErrors || []).length, Object.values(row.errorCounts || {}).reduce((n, value) => n + (Number(value) || 0), 0)), 0));
      return sum + 25 + Math.min(20, categories * 2) + Math.min(10, (attempt.chapterResults || []).length * 2);
    }, 0);
    const ranks = [{ name: 'Recruit', min: 0, next: 150 }, { name: 'Bronze', min: 150, next: 400 }, { name: 'Silver', min: 400, next: 800 }, { name: 'Gold', min: 800, next: 1500 }, { name: 'Platinum', min: 1500, next: 2500 }, { name: 'Diamond', min: 2500, next: 5000 }];
    const rank = [...ranks].reverse().find(item => xp >= item.min) || ranks[0], nextRank = ranks.find(item => item.min > xp);
    const days = [...new Set(completed.map(attempt => attempt.date).filter(Boolean))].sort();
    let streak = 0;
    if (days.length) {
      const dayMs = 86400000, target = new Date(today + 'T12:00:00').getTime(), lastMs = new Date(days[days.length - 1] + 'T12:00:00').getTime();
      if (target - lastMs <= dayMs * 1.6) {
        streak = 1;
        for (let i = days.length - 2; i >= 0; i--) {
          const currentMs = new Date(days[i] + 'T12:00:00').getTime(), nextMs = new Date(days[i + 1] + 'T12:00:00').getTime();
          if (nextMs - currentMs <= dayMs * 1.1) streak++; else break;
        }
      }
    }
    return { comp: completed, last, preds: predictions, mae, tested, avg: baseline, unscored: attempts.length - completed.length, xp, rank, nextRank, streak };
  }
  global.LoadoutModules = global.LoadoutModules || {};
  global.LoadoutModules.dashboardAnalytics = Object.freeze({ calculateSummary });
})(window);
