/*
 * Loadout Test Ledger feature module — v1.2.0
 * Extracts test-record validation and score construction from the legacy UI.
 * It does not change the historical score formula or infer missing chapter splits.
 */
(function (global) {
  'use strict';
  const root = global.LoadoutModules = global.LoadoutModules || {};
  if (root.testLedger) return;

  function validateCounts({ n, correct, wrong, unattempted }) {
    const values = { n, correct, wrong, unattempted };
    for (const [key, value] of Object.entries(values)) {
      if (!Number.isInteger(Number(value)) || Number(value) < (key === 'n' ? 1 : 0)) {
        throw new Error(`${key} must be a ${key === 'n' ? 'positive' : 'non-negative'} integer.`);
      }
    }
    if (Number(correct) + Number(wrong) + Number(unattempted) !== Number(n)) {
      throw new Error('Correct + wrong + unattempted must equal total questions.');
    }
    return { n: Number(n), correct: Number(correct), wrong: Number(wrong), unattempted: Number(unattempted) };
  }

  function createAttempt(draft, settings, existingAttempts = []) {
    if (!draft || typeof draft !== 'object' || !settings || typeof settings !== 'object') {
      throw new Error('A test draft and scoring settings are required.');
    }
    const counts = validateCounts(draft);
    const testId = String(draft.testId || '').trim();
    if (!testId) throw new Error('A test ID is required.');
    if (!Array.isArray(existingAttempts)) throw new Error('Existing attempts must be an array.');
    if (existingAttempts.some(attempt => String(attempt.testId || '').toUpperCase() === testId.toUpperCase() && attempt.score != null)) {
      throw new Error('A completed attempt with this test ID already exists. Use a unique attempt ID.');
    }
    const correctMarks = Number(settings.correctMarks);
    const wrongMarks = Number(settings.wrongMarks);
    if (!Number.isFinite(correctMarks) || !Number.isFinite(wrongMarks)) throw new Error('Scoring settings are invalid.');
    const minutes = Number(draft.minutes || 0);
    if (!Number.isFinite(minutes) || minutes < 0) throw new Error('Time spent must be a non-negative number.');
    const id = String(draft.id || (global.crypto?.randomUUID ? global.crypto.randomUUID() : `attempt-${Date.now()}`));
    const score = counts.correct * correctMarks + counts.wrong * wrongMarks;
    return {
      id,
      testId,
      date: String(draft.date || ''),
      type: String(draft.type || 'OTHER'),
      title: String(draft.title || ''),
      ...counts,
      minutes,
      score,
      maxMarks: counts.n * correctMarks,
      subject: draft.subject || null,
      notes: String(draft.notes || ''),
      chapterResults: Array.isArray(draft.chapterResults) ? draft.chapterResults : [],
      prediction: draft.prediction ? { ...draft.prediction } : null,
      createdAt: String(draft.createdAt || new Date().toISOString())
    };
  }

  function removeAttempt(attempts, id) {
    if (!Array.isArray(attempts)) throw new Error('Attempts must be an array.');
    const index = attempts.findIndex(attempt => String(attempt.id) === String(id));
    if (index < 0) return { removed: false, attempts: attempts.slice(), record: null };
    const next = attempts.slice();
    const [record] = next.splice(index, 1);
    return { removed: true, attempts: next, record };
  }

  root.testLedger = Object.freeze({
    id: 'loadout.test-ledger',
    version: '1.2.0',
    validateCounts,
    createAttempt,
    removeAttempt
  });
})(window);
