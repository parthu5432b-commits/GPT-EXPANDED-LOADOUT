/* Loadout shell cache; bump on every release to invalidate stale navigation/data scripts. */
const CACHE = 'loadout-jee-2027-shell-v19-repair-ports-1-8-0';
const SHELL = [
  './', './index.html', './runtime/module-registry.js', './runtime/ltl-engine.js', './runtime/repair-engine.js', './runtime/loadout-runtime.js', './runtime/recovery-gate.js', './runtime/feature-runtime.js', './runtime/database-schema.js', './runtime/database-model.js', './runtime/database.js', './runtime/backup-manager.mjs', './runtime/trust-store.json', './runtime/registry-catalog.json', './modules/test-ledger.js', './modules/features/chapter-intelligence.js', './modules/features/dashboard-analytics.js', './modules/features/command-center.js', './modules/features/chapter-map.js', './modules/features/pyq-intelligence.js', './modules/features/forecast-engine.js', './modules/features/test-ledger-route.js', './modules/features/data-settings.js', './modules/ai-coach/ai-coach.js', './vendor/katex/katex.min.css', './vendor/katex/katex.min.js', './vendor/katex/contrib/mhchem.min.js', './vendor/katex/contrib/auto-render.min.js', './vendor/katex/vendor-manifest.json', './data/jee-main-2027-profile.js', './data/exam-profiles/jee-main-2027.json', './app.js', './physics-history.js', './chemistry-history.js', './mathematics-history.js',
  './manifest.webmanifest', './assets/ic_launcher.png', './assets/icon-192.png', './assets/icon-512.png',
  './data/physics_historical_trends.json', './data/chemistry_historical_trends.json', './data/mathematics_historical_trends.json', './data/excluded_topics.json', './data/source_audit.json'
];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(SHELL);
    const manifestResponse = await fetch('./vendor/katex/vendor-manifest.json', { cache: 'no-store' });
    if (!manifestResponse.ok) throw new Error('Local KaTeX asset manifest is missing; offline math renderer cannot be installed.');
    const manifest = await manifestResponse.json();
    const vendorAssets = (Array.isArray(manifest.files) ? manifest.files : []).map(file => String(file.path || '')).filter(file => file && !file.startsWith('/') && !file.split('/').includes('..')).map(file => `./vendor/katex/${file}`);
    if (!vendorAssets.length) throw new Error('Local KaTeX asset manifest is empty.');
    await cache.addAll(vendorAssets);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => {
    if (response && response.ok) {
      const copy = response.clone();
      caches.open(CACHE).then(cache => cache.put(req, copy));
    }
    return response;
  }).catch(() => caches.match('./index.html'))));
});
