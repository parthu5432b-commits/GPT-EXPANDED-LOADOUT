/* Loadout structured database 1.5.0.
 * Android uses app-private SQLite through LoadoutCore; browser/PWA uses IndexedDB.
 * The legacy JSON state remains the compatibility authority during this migration phase.
 */
(function (global) {
  'use strict';
  if (global.LoadoutDatabase) return;
  const SCHEMA = global.LoadoutDatabaseSchema;
  const MODEL = global.LoadoutDatabaseModel;
  if (!SCHEMA || !MODEL) throw new Error('Loadout database schema/model was not loaded.');
  const SOURCE_KEY = 'loadout-jee-2027-v1';
  const STATE_KEY = 'main-study-state';
  const IDB_STORES = ['app_state', 'test_attempts', 'forecasts', 'module_records', 'legacy_imports', 'migration_history', 'recovery_snapshots', 'migration_conflicts'];
  let backend = null;
  let db = null;
  let initialization = null;
  let operationQueue = Promise.resolve();
  let lastError = null;
  let lastSync = null;
  let initializedAt = null;

  async function hash(text) {
    if (!global.crypto?.subtle) throw new Error('WebCrypto SHA-256 is required for database integrity checks.');
    const digest = await global.crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(text)));
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function validateState(state) { return MODEL.validateState(state); }
  function enqueue(operation) {
    const next = operationQueue.catch(() => {}).then(operation);
    operationQueue = next.catch(error => { lastError = String(error?.message || error); });
    return next;
  }
  function nativeSupported() {
    return !!global.Loadout?.native?.databaseAvailable;
  }
  function openIndexedDb() {
    if (!global.indexedDB) throw new Error('Neither native SQLite nor IndexedDB is available. No database migration was performed.');
    return new Promise((resolve, reject) => {
      let request;
      try { request = global.indexedDB.open(SCHEMA.name, SCHEMA.version); }
      catch (error) { reject(error); return; }
      request.onupgradeneeded = event => {
        const database = request.result;
        if (event.oldVersion < 1) {
          database.createObjectStore('app_state', { keyPath: 'state_key' });
          const attempts = database.createObjectStore('test_attempts', { keyPath: 'id' });
          attempts.createIndex('date', 'date', { unique: false });
          attempts.createIndex('type_date', ['type', 'date'], { unique: false });
          database.createObjectStore('forecasts', { keyPath: 'id' }).createIndex('test_type', ['test_id', 'type'], { unique: false });
          database.createObjectStore('module_records', { keyPath: ['module_id', 'record_key'] }).createIndex('updated_at', 'updated_at', { unique: false });
          database.createObjectStore('legacy_imports', { keyPath: 'source_key' });
          database.createObjectStore('migration_history', { keyPath: 'version' });
        }
        if (event.oldVersion < 2) {
          database.createObjectStore('recovery_snapshots', { keyPath: 'id' });
          database.createObjectStore('migration_conflicts', { keyPath: 'id' });
        }
      };
      request.onerror = () => reject(request.error || new Error('IndexedDB open failed.'));
      request.onblocked = () => reject(new Error('IndexedDB upgrade is blocked by another open Loadout tab. Close older tabs and retry.'));
      request.onsuccess = () => {
        db = request.result;
        db.onversionchange = () => { db.close(); db = null; backend = null; initialization = null; };
        resolve(db);
      };
    });
  }
  function beginTransaction(stores, mode = 'readonly') {
    const tx = db.transaction(stores, mode);
    const done = new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error || new Error('Database transaction failed.'));
      tx.onabort = () => reject(tx.error || new Error('Database transaction aborted.'));
    });
    return { tx, done };
  }
  async function ensureBackend() {
    if (backend) return backend;
    if (initialization) return initialization;
    initialization = (async () => {
      if (nativeSupported()) {
        const result = await global.Loadout.native.databaseMigrate(SCHEMA.name, SCHEMA.migrations);
        if (Number(result.schemaVersion) !== SCHEMA.version) throw new Error(`SQLite schema mismatch: expected ${SCHEMA.version}, found ${result.schemaVersion}.`);
        backend = 'sqlite';
      } else {
        await openIndexedDb();
        backend = 'indexeddb';
        const historyRows = await Promise.all(SCHEMA.migrations.map(async migration => ({
          version: migration.version,
          migration_id: migration.id,
          checksum: await hash(`${migration.version}|${migration.id}|${migration.statements.join('\n')}`),
          applied_at: new Date().toISOString()
        })));
        const { tx, done } = beginTransaction(['migration_history'], 'readwrite');
        const store = tx.objectStore('migration_history');
        let historyError = null;
        const historyRequest = store.getAll();
        historyRequest.onsuccess = () => {
          try {
            const existing = new Map((historyRequest.result || []).map(row => [Number(row.version), row]));
            for (const row of existing.values()) {
              const expected = historyRows.find(candidate => candidate.version === row.version);
              if (!expected || expected.migration_id !== row.migration_id || expected.checksum !== row.checksum) {
                throw new Error(`IndexedDB migration history mismatch at version ${row.version}; refusing to continue.`);
              }
            }
            for (const row of historyRows) if (!existing.has(row.version)) store.put(row);
          } catch (error) {
            historyError = error;
            try { tx.abort(); } catch (_) { /* transaction already completed */ }
          }
        };
        await done.catch(error => { if (historyError) throw historyError; throw error; });
      }
      initializedAt = new Date().toISOString();
      return backend;
    })().catch(error => { initialization = null; backend = null; lastError = String(error?.message || error); throw error; });
    return initialization;
  }
  function dbQuery(sql, args = []) { return global.Loadout.native.databaseQuery(SCHEMA.name, sql, args); }
  function dbBatch(statements) { return global.Loadout.native.databaseExecuteBatch(SCHEMA.name, statements); }
  async function nativeGetState() {
    const result = await dbQuery('SELECT state_key, schema_version, payload_json, payload_sha256, revision, updated_at, source_kind FROM app_state WHERE state_key = ?', [STATE_KEY]);
    return result.rows?.[0] || null;
  }
  async function idbGetState() {
    const { tx, done } = beginTransaction(['app_state'], 'readonly');
    const request = tx.objectStore('app_state').get(STATE_KEY);
    const value = await new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result || null); request.onerror = () => reject(request.error); });
    await done;
    return value;
  }
  async function archiveConflict(existing, currentHash, reason) {
    if (!existing) return null;
    const existingPayload = String(existing.payload_json || '');
    const actualHash = await hash(existingPayload);
    if (actualHash !== existing.payload_sha256) throw new Error('The existing database study-state row failed its checksum. It was not overwritten.');
    const id = `db-conflict-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const now = new Date().toISOString();
    if (backend === 'sqlite') {
      await dbBatch([
        { sql: 'INSERT INTO recovery_snapshots(id, source_key, payload_json, payload_sha256, created_at, reason) VALUES(?,?,?,?,?,?)', args: [id, STATE_KEY, existingPayload, actualHash, now, reason] },
        { sql: 'INSERT INTO migration_conflicts(id, record_key, local_sha256, database_sha256, created_at, resolution) VALUES(?,?,?,?,?,?)', args: [id, STATE_KEY, currentHash, actualHash, now, 'archived-before-legacy-reconciliation'] }
      ]);
    } else {
      const { tx, done } = beginTransaction(['recovery_snapshots', 'migration_conflicts'], 'readwrite');
      tx.objectStore('recovery_snapshots').put({ id, source_key: STATE_KEY, payload_json: existingPayload, payload_sha256: actualHash, created_at: now, reason });
      tx.objectStore('migration_conflicts').put({ id, record_key: STATE_KEY, local_sha256: currentHash, database_sha256: actualHash, created_at: now, resolution: 'archived-before-legacy-reconciliation' });
      await done;
    }
    return id;
  }
  function buildStatements(validated, sourceKind, revision) {
    const now = new Date().toISOString();
    const payloadHashPromise = hash(validated.payloadJson);
    return payloadHashPromise.then(payloadHash => {
      const statements = [
        { sql: 'INSERT OR REPLACE INTO app_state(state_key, schema_version, payload_json, payload_sha256, updated_at, revision, source_kind) VALUES(?,?,?,?,?,?,?)', args: [STATE_KEY, 1, validated.payloadJson, payloadHash, now, revision, sourceKind] },
        { sql: 'DELETE FROM test_attempts', args: [] },
        { sql: 'DELETE FROM forecasts', args: [] }
      ];
      for (const attempt of validated.state.attempts) {
        const row = MODEL.attemptRow(attempt, sourceKind, now);
        statements.push({ sql: 'INSERT INTO test_attempts(id,test_id,date,type,score,n,correct,wrong,unattempted,minutes,payload_json,created_at,source_kind) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', args: [row.id,row.test_id,row.date,row.type,row.score,row.n,row.correct,row.wrong,row.unattempted,row.minutes,row.payload_json,row.created_at,row.source_kind] });
      }
      for (const forecast of validated.state.forecasts) {
        const row = MODEL.forecastRow(forecast, sourceKind, now);
        statements.push({ sql: 'INSERT INTO forecasts(id,test_id,type,date,raw_score,calibrated_score,payload_json,created_at,source_kind) VALUES(?,?,?,?,?,?,?,?,?)', args: [row.id,row.test_id,row.type,row.date,row.raw_score,row.calibrated_score,row.payload_json,row.created_at,row.source_kind] });
      }
      statements.push({ sql: 'INSERT OR REPLACE INTO legacy_imports(source_key,source_sha256,record_count,imported_at) VALUES(?,?,?,?)', args: [SOURCE_KEY, payloadHash, validated.attemptCount + validated.forecastCount, now] });
      return { statements, payloadHash, now };
    });
  }
  async function writeState(validated, sourceKind) {
    const previous = backend === 'sqlite' ? await nativeGetState() : await idbGetState();
    const previousRevision = Number(previous?.revision || 0);
    if (!Number.isSafeInteger(previousRevision) || previousRevision < 0 || previousRevision >= Number.MAX_SAFE_INTEGER) {
      throw new Error('Structured study-state revision is invalid or exhausted; refusing to overwrite it.');
    }
    const revision = previousRevision + 1;
    const built = await buildStatements(validated, sourceKind, revision);
    if (backend === 'sqlite') await dbBatch(built.statements);
    else {
      const names = ['app_state', 'test_attempts', 'forecasts', 'legacy_imports'];
      const { tx, done } = beginTransaction(names, 'readwrite');
      tx.objectStore('app_state').put({ state_key: STATE_KEY, schema_version: 1, payload_json: validated.payloadJson, payload_sha256: built.payloadHash, updated_at: built.now, revision, source_kind: sourceKind });
      const attemptStore = tx.objectStore('test_attempts'); attemptStore.clear();
      for (const item of validated.state.attempts) attemptStore.put(MODEL.attemptRow(item, sourceKind, built.now));
      const forecastStore = tx.objectStore('forecasts'); forecastStore.clear();
      for (const item of validated.state.forecasts) forecastStore.put(MODEL.forecastRow(item, sourceKind, built.now));
      tx.objectStore('legacy_imports').put({ source_key: SOURCE_KEY, source_sha256: built.payloadHash, record_count: validated.attemptCount + validated.forecastCount, imported_at: built.now });
      await done;
    }
    // A successful SQL/IDB commit is not enough: read every index back and compare it
    // with the canonical JSON before reporting the write as verified.
    const verification = await verifyInternal();
    if (verification.sha256 !== built.payloadHash || verification.attempts !== validated.attemptCount || verification.forecasts !== validated.forecastCount) {
      throw new Error('Structured database read-back does not match the canonical study state.');
    }
    lastSync = { at: built.now, attempts: validated.attemptCount, forecasts: validated.forecastCount, sha256: built.payloadHash, sourceKind, revision };
    lastError = null;
    return { ...lastSync, verified: true };
  }
  async function bootstrapInternal(state, sourceRaw) {
    await ensureBackend();
    const validated = validateState(state);
    const currentHash = await hash(validated.payloadJson);
    const existing = backend === 'sqlite' ? await nativeGetState() : await idbGetState();
    if (existing && existing.payload_json !== validated.payloadJson) await archiveConflict(existing, currentHash, 'Database state differed from validated localStorage state during compatibility bootstrap.');
    const sourceHash = typeof sourceRaw === 'string' ? await hash(sourceRaw) : currentHash;
    const result = await writeState(validated, existing ? 'legacy-reconciled' : 'legacy-import');
    if (backend === 'sqlite') {
      await dbBatch([{ sql: 'INSERT OR REPLACE INTO legacy_imports(source_key,source_sha256,record_count,imported_at) VALUES(?,?,?,?)', args: [SOURCE_KEY, sourceHash, validated.attemptCount + validated.forecastCount, new Date().toISOString()] }]);
    } else {
      const { tx, done } = beginTransaction(['legacy_imports'], 'readwrite');
      tx.objectStore('legacy_imports').put({ source_key: SOURCE_KEY, source_sha256: sourceHash, record_count: validated.attemptCount + validated.forecastCount, imported_at: new Date().toISOString() });
      await done;
    }
    return { ...result, backend, schemaVersion: SCHEMA.version, archivedConflict: !!existing && existing.payload_json !== validated.payloadJson };
  }
  async function migrationLedger() {
    const expected = await Promise.all(SCHEMA.migrations.map(async migration => ({
      version: migration.version,
      migration_id: migration.id,
      checksum: await hash(`${migration.version}|${migration.id}|${migration.statements.join('\n')}`)
    })));
    let actual;
    if (backend === 'sqlite') {
      const result = await dbQuery('SELECT version,migration_id,checksum FROM schema_migrations ORDER BY version', []);
      actual = result.rows || [];
    } else {
      const { tx, done } = beginTransaction(['migration_history'], 'readonly');
      const request = tx.objectStore('migration_history').getAll();
      actual = await new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error || new Error('Could not read IndexedDB migration ledger.'));
      });
      await done;
    }
    if (actual.length !== expected.length) throw new Error('Migration history contains missing or unexpected entries.');
    for (let index = 0; index < expected.length; index++) {
      const got = actual[index], wanted = expected[index];
      if (Number(got.version) !== wanted.version || got.migration_id !== wanted.migration_id || got.checksum !== wanted.checksum) {
        throw new Error(`Migration history integrity mismatch at schema version ${wanted.version}.`);
      }
    }
    return expected.length;
  }
  function verifyRecordRows(actualRows, expectedRows, label) {
    if (actualRows.length !== expectedRows.length) throw new Error(`${label} row count does not match the canonical study-state payload.`);
    const expected = new Map(expectedRows.map(item => [String(item.id), JSON.stringify(item)]));
    for (const row of actualRows) {
      const id = String(row.id || '');
      const canonical = expected.get(id);
      if (canonical == null) throw new Error(`${label} contains an unexpected record ID: ${id}.`);
      if (String(row.payload_json || '') !== canonical) throw new Error(`${label} payload mismatch for record ${id}.`);
      expected.delete(id);
    }
    if (expected.size) throw new Error(`${label} is missing ${expected.size} canonical records.`);
  }
  async function verifyInternal() {
    await ensureBackend();
    let row, attemptRows, forecastRows;
    if (backend === 'sqlite') {
      const [stateResult, attemptsResult, forecastsResult] = await Promise.all([
        nativeGetState(),
        dbQuery('SELECT id,payload_json FROM test_attempts', []),
        dbQuery('SELECT id,payload_json FROM forecasts', [])
      ]);
      row = stateResult;
      attemptRows = attemptsResult.rows || [];
      forecastRows = forecastsResult.rows || [];
    } else {
      const { tx, done } = beginTransaction(['app_state', 'test_attempts', 'forecasts'], 'readonly');
      const read = (store, key = null) => new Promise((resolve, reject) => {
        const request = key == null ? tx.objectStore(store).getAll() : tx.objectStore(store).get(key);
        request.onsuccess = () => resolve(request.result || (key == null ? [] : null));
        request.onerror = () => reject(request.error || new Error(`Could not read ${store}.`));
      });
      [row, attemptRows, forecastRows] = await Promise.all([
        read('app_state', STATE_KEY), read('test_attempts'), read('forecasts')
      ]);
      await done;
    }
    if (!row) throw new Error('No structured study-state row exists yet.');
    const actualHash = await hash(String(row.payload_json || ''));
    if (actualHash !== row.payload_sha256) throw new Error('Structured study-state checksum mismatch.');
    let state;
    try { state = JSON.parse(row.payload_json); }
    catch { throw new Error('Structured study-state JSON is malformed.'); }
    const validated = validateState(state);
    verifyRecordRows(attemptRows, validated.state.attempts, 'Test-attempt index');
    verifyRecordRows(forecastRows, validated.state.forecasts, 'Forecast index');
    const migrations = await migrationLedger();
    return {
      ok: true, backend, schemaVersion: SCHEMA.version,
      attempts: attemptRows.length, forecasts: forecastRows.length,
      migrations, sha256: actualHash, updatedAt: row.updated_at || null
    };
  }
  const Database = Object.freeze({
    version: '1.5.0', schemaVersion: SCHEMA.version,
    async initialize() { return enqueue(() => ensureBackend()); },
    async bootstrap(state, raw) { return enqueue(() => bootstrapInternal(state, raw)); },
    enqueueSync(state) { const snapshot = clone(state); return enqueue(async () => { await ensureBackend(); const validated = validateState(snapshot); return writeState(validated, 'application-save'); }); },
    async flush() { await operationQueue; if (lastError) throw new Error(lastError); return true; },
    async verify() { await operationQueue; return verifyInternal(); },
    async status() {
      await operationQueue.catch(() => {});
      let info = null;
      if (backend === 'sqlite' && global.Loadout?.native?.databaseInfo) info = await global.Loadout.native.databaseInfo(SCHEMA.name).catch(() => null);
      return { backend: backend || 'not-initialized', schemaVersion: backend ? SCHEMA.version : 0, targetSchemaVersion: SCHEMA.version, initializedAt, lastSync: lastSync ? { ...lastSync } : null, lastError, native: nativeSupported(), androidInfo: info };
    },
    async addModuleRecord(moduleId, recordKey, payload, schemaVersion = 1) {
      if (!/^[a-z][a-z0-9.-]{2,95}$/.test(String(moduleId)) || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/.test(String(recordKey))) throw new Error('Invalid module record address.');
      const json = JSON.stringify(payload), digest = await hash(json), updated = new Date().toISOString();
      return enqueue(async () => {
        await ensureBackend();
        if (backend === 'sqlite') await dbBatch([{ sql: 'INSERT OR REPLACE INTO module_records(module_id,record_key,schema_version,payload_json,payload_sha256,updated_at) VALUES(?,?,?,?,?,?)', args: [moduleId, recordKey, Number(schemaVersion), json, digest, updated] }]);
        else { const { tx, done } = beginTransaction(['module_records'], 'readwrite'); tx.objectStore('module_records').put({ module_id: moduleId, record_key: recordKey, schema_version: Number(schemaVersion), payload_json: json, payload_sha256: digest, updated_at: updated }); await done; }
        return { moduleId, recordKey, sha256: digest, updatedAt: updated };
      });
    },
    async getModuleRecord(moduleId, recordKey) {
      await operationQueue; await ensureBackend();
      let row;
      if (backend === 'sqlite') { const result = await dbQuery('SELECT payload_json,payload_sha256,schema_version,updated_at FROM module_records WHERE module_id=? AND record_key=?', [moduleId, recordKey]); row = result.rows?.[0]; }
      else { const { tx, done } = beginTransaction(['module_records'], 'readonly'), request = tx.objectStore('module_records').get([moduleId, recordKey]); row = await new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); await done; }
      if (!row) return null;
      if (await hash(row.payload_json) !== row.payload_sha256) throw new Error('Module record checksum mismatch.');
      return JSON.parse(row.payload_json);
    },
    async attachSettingsPanel() {
      const root = document.getElementById('view-data');
      if (!root || document.getElementById('loadout-db-status')) return;
      const panel = document.createElement('section'); panel.id = 'loadout-db-status'; panel.className = 'card pad'; panel.style.marginTop = '16px';
      panel.innerHTML = '<div class="card-header"><div><h2>Structured database & migration foundation</h2><p class="sub">A versioned local database now mirrors study records. Legacy localStorage and the verified private recovery mirror remain intact during this compatibility phase.</p></div><span class="tag purple">SCHEMA V2</span></div><div class="forecast-scale" id="loadout-db-metrics"><div class="scale-item"><small>BACKEND</small><strong>Checking…</strong></div><div class="scale-item"><small>STUDY RECORDS</small><strong>—</strong></div><div class="scale-item"><small>LAST SYNC</small><strong>—</strong></div></div><div id="loadout-db-message" class="notice" role="status">Migration foundation initializes after legacy state recovery.</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn small" id="loadout-db-verify" type="button">Verify database</button><button class="btn primary small" id="loadout-db-sync" type="button">Sync current study data</button></div>';
      root.appendChild(panel);
      const message = panel.querySelector('#loadout-db-message'), metrics = panel.querySelector('#loadout-db-metrics');
      const refresh = async () => {
        try {
          const state = await Database.status();
          const verified = state.backend === 'not-initialized' ? null : await Database.verify();
          metrics.innerHTML = `<div class="scale-item"><small>BACKEND</small><strong>${state.backend === 'sqlite' ? 'Android SQLite' : state.backend === 'indexeddb' ? 'IndexedDB' : 'Not ready'}</strong></div><div class="scale-item"><small>TEST ATTEMPTS</small><strong>${verified ? verified.attempts : state.lastSync?.attempts ?? '—'}</strong></div><div class="scale-item"><small>FORECASTS</small><strong>${verified ? verified.forecasts : state.lastSync?.forecasts ?? '—'}</strong></div>`;
          message.textContent = verified ? `Verified · schema ${verified.schemaVersion} · ${verified.migrations} migration records · ${verified.sha256.slice(0, 16)}…` : (state.lastError || 'Database is ready; run a sync after legacy recovery completes.');
          message.className = 'notice ' + (verified ? 'green' : '');
        } catch (error) { message.textContent = `Database verification needs attention: ${error.message}`; message.className = 'notice red'; }
      };
      panel.querySelector('#loadout-db-verify').addEventListener('click', refresh);
      panel.querySelector('#loadout-db-sync').addEventListener('click', async () => {
        const snapshot = global.LoadoutLegacyStateSnapshot?.();
        if (!snapshot) { message.textContent = 'Current study state is not available from the legacy adapter.'; return; }
        try { await Database.enqueueSync(snapshot); await Database.flush(); await refresh(); message.textContent = 'Current study records synchronized and checksummed.'; }
        catch (error) { message.textContent = `Synchronization failed; legacy data remains unchanged: ${error.message}`; message.className = 'notice red'; }
      });
      refresh();
    }
  });
  global.LoadoutDatabase = Database;
})(window);
