/* Loadout LTL declarative engine — browser-safe mirror of src/core/ltl.js. */
(function (global) {
  'use strict';
  if (global.LoadoutLtlEngine) return;
  const OPS = new Set(['ADD','REPLACE','PATCH','PATCH_SOURCE','REMOVE','MOVE','RENAME','RECONFIGURE','REWIRE','MIGRATE','CHANGE_POLICY','INSTALL_DEPENDENCY','REMOVE_DEPENDENCY','VALIDATE','ACTIVATE']);
  const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
  const BAD_KEYS = new Set(['__proto__','prototype','constructor']);
  const clone = value => JSON.parse(JSON.stringify(value));
  const stable = value => value === null || typeof value !== 'object' ? JSON.stringify(value) : Array.isArray(value) ? '[' + value.map(stable).join(',') + ']' : '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
  const safePath = value => typeof value === 'string' && !!value && value.length <= 240 && !value.startsWith('/') && !value.includes('\\') && !value.includes('\0') && !/^[A-Za-z]:/.test(value) && value.split('/').every(p => p && p !== '.' && p !== '..');
  const bytes = value => new TextEncoder().encode(String(value));
  async function hash(value) {
    if (!global.crypto?.subtle) throw new Error('WebCrypto SHA-256 unavailable; transformation refused.');
    return Array.from(new Uint8Array(await global.crypto.subtle.digest('SHA-256', bytes(value))), b => b.toString(16).padStart(2, '0')).join('');
  }
  function metadata(op, nested = false) {
    if (!op || typeof op !== 'object' || Array.isArray(op)) throw new Error('LTL operation must be an object.');
    const kind = String(op.op || '').toUpperCase();
    if (!OPS.has(kind)) throw new Error('Unsupported LTL operation: ' + (kind || '(missing)'));
    if (!SAFE_ID.test(String(op.id || ''))) throw new Error('Every LTL operation needs a unique safe id.');
    if (typeof op.description !== 'string' || !op.description.trim() || op.description.length > 500) throw new Error(op.id + ': audit description is required.');
    if (!['low','medium','high','critical'].includes(String(op.risk || '').toLowerCase())) throw new Error(op.id + ': invalid risk classification.');
    if (!Array.isArray(op.dependencies || []) || (op.dependencies || []).some(x => !SAFE_ID.test(String(x)))) throw new Error(op.id + ': dependencies must be safe operation IDs.');
    if (nested && (op.dependencies || []).length) throw new Error(op.id + ': nested migration steps cannot depend on outer operations.');
    if (!Array.isArray(op.validation || []) || (op.validation || []).some(x => typeof x !== 'string' || !x.trim())) throw new Error(op.id + ': validation must be an array.');
    if (typeof op.failureAction !== 'string' || !op.failureAction.trim() || typeof op.recovery !== 'string' || !op.recovery.trim()) throw new Error(op.id + ': failureAction and recovery are required.');
    return kind;
  }
  function order(operations) {
    if (!Array.isArray(operations) || operations.length > 500) throw new Error('Transformations must be an array of at most 500 operations.');
    const byId = new Map();
    operations.forEach(op => { metadata(op); if (byId.has(op.id)) throw new Error('Duplicate LTL operation ID: ' + op.id); byId.set(op.id, op); });
    const result = [], visiting = new Set(), visited = new Set();
    function visit(id) {
      if (visited.has(id)) return;
      if (visiting.has(id)) throw new Error('LTL dependency cycle detected at ' + id + '.');
      const op = byId.get(id); if (!op) throw new Error('LTL dependency references missing operation: ' + id);
      visiting.add(id); (op.dependencies || []).forEach(visit); visiting.delete(id); visited.add(id); result.push(op);
    }
    byId.forEach((_, id) => visit(id)); return result;
  }
  function parts(pointer) {
    if (typeof pointer !== 'string' || !pointer.startsWith('/') || pointer === '/') throw new Error('JSON pointer must identify a non-root path.');
    const result = pointer.slice(1).split('/').map(p => { if (/~(?![01])/.test(p)) throw new Error('Invalid JSON pointer escape.'); return p.replace(/~1/g,'/').replace(/~0/g,'~'); });
    if (result.some(p => BAD_KEYS.has(p))) throw new Error('Unsafe JSON pointer key rejected.'); return result;
  }
  function idx(key, length, end = false) { if (!/^(0|[1-9]\d*)$/.test(String(key))) throw new Error('Invalid array index: ' + key); const n = Number(key); if (!Number.isSafeInteger(n) || n < 0 || n > length || (!end && n === length)) throw new Error('Array index out of range: ' + key); return n; }
  function locate(root, pointer) { const p = parts(pointer); let node = root; for (const key of p.slice(0,-1)) { if (Array.isArray(node)) node = node[idx(key,node.length)]; else if (node && typeof node === 'object' && Object.hasOwn(node,key)) node = node[key]; else throw new Error('LTL path does not exist: ' + pointer); } if (!node || typeof node !== 'object') throw new Error('LTL parent is not an object or array.'); return { node, key:p[p.length-1] }; }
  function read(root, pointer) { const {node,key}=locate(root,pointer); if(Array.isArray(node))return node[idx(key,node.length)]; if(!Object.hasOwn(node,key))throw new Error('LTL path does not exist: '+pointer); return node[key]; }
  function write(root,pointer,value,mode) { const {node,key}=locate(root,pointer); if(Array.isArray(node)){if(mode==='add')node.splice(idx(key,node.length,true),0,clone(value));else if(mode==='replace')node[idx(key,node.length)]=clone(value);else throw new Error('Unsupported array write mode.');return;} const exists=Object.hasOwn(node,key); if(mode==='add'&&exists)throw new Error('ADD target already exists: '+pointer); if(mode==='replace'&&!exists)throw new Error('REPLACE target missing: '+pointer); node[key]=clone(value); }
  function remove(root,pointer) { const {node,key}=locate(root,pointer); if(Array.isArray(node))node.splice(idx(key,node.length),1);else{if(!Object.hasOwn(node,key))throw new Error('REMOVE target missing: '+pointer);delete node[key];} }
  async function applyOne(state, files, op, nested = false) {
    const kind=metadata(op,nested);
    if(op.expectedStateSha256 && await hash(stable(state))!==String(op.expectedStateSha256).toLowerCase())throw new Error(op.id+': state precondition hash mismatch.');
    if(op.precondition?.path){const v=read(state,op.precondition.path);if(Object.hasOwn(op.precondition,'equals')&&stable(v)!==stable(op.precondition.equals))throw new Error(op.id+': value precondition failed.');if(op.precondition.sha256&&await hash(stable(v))!==String(op.precondition.sha256).toLowerCase())throw new Error(op.id+': value hash precondition failed.');}
    if(kind==='ACTIVATE')return;
    if(kind==='VALIDATE'){const a=op.assert;if(!a||typeof a!=='object'||typeof a.path!=='string'||!a.path)throw new Error(op.id+': VALIDATE requires assertion with JSON Pointer path.');if(a.path){const v=read(state,a.path);if(Object.hasOwn(a,'equals')&&stable(v)!==stable(a.equals))throw new Error(op.id+': equality assertion failed.');if(a.type==='array'&&!Array.isArray(v))throw new Error(op.id+': expected array.');if(a.type==='object'&&(!v||typeof v!=='object'||Array.isArray(v)))throw new Error(op.id+': expected object.');if(Number.isInteger(a.minLength)&&(!Array.isArray(v)||v.length<a.minLength))throw new Error(op.id+': minimum length assertion failed.');if(a.sha256&&await hash(stable(v))!==String(a.sha256).toLowerCase())throw new Error(op.id+': assertion hash mismatch.');}return;}
    if(kind==='PATCH_SOURCE'){if(!safePath(op.file)||/\.(?:m?js|cjs|jsx|ts|tsx|jar|dex|so|class)$/i.test(op.file)||typeof files[op.file]!=='string')throw new Error('PATCH_SOURCE may only target a staged non-executable text resource.');if(await hash(files[op.file])!==String(op.expectedSha256||'').toLowerCase())throw new Error('PATCH_SOURCE preimage SHA-256 mismatch.');if(typeof op.anchor!=='string'||!op.anchor||typeof op.replacement!=='string')throw new Error('PATCH_SOURCE requires anchor and replacement.');const count=files[op.file].split(op.anchor).length-1;if(count!==Number(op.expectedOccurrences??1))throw new Error('PATCH_SOURCE anchor match count failed.');const next=files[op.file].split(op.anchor).join(op.replacement);if(op.resultSha256&&await hash(next)!==String(op.resultSha256).toLowerCase())throw new Error('PATCH_SOURCE postimage hash mismatch.');files[op.file]=next;return;}
    if(kind==='MIGRATE'){if(!Array.isArray(op.steps)||!op.steps.length||op.steps.length>100)throw new Error(op.id+': MIGRATE requires 1–100 declarative steps.');const ids=new Set();for(const step of op.steps){const sub=metadata(step,true);if(['MIGRATE','ACTIVATE','VALIDATE'].includes(sub)||ids.has(step.id))throw new Error(op.id+': unsupported or duplicate nested migration step.');ids.add(step.id);await applyOne(state,files,step,true);}return;}
    if(kind==='INSTALL_DEPENDENCY'||kind==='REMOVE_DEPENDENCY'){const id=String(op.dependencyId||'');if(!SAFE_ID.test(id))throw new Error(op.id+': dependencyId required.');state.dependencies=state.dependencies||{};if(kind==='INSTALL_DEPENDENCY'){if(!/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(String(op.version||'')))throw new Error(op.id+': dependency version must be semver.');state.dependencies[id]=op.version;}else{if(!Object.hasOwn(state.dependencies,id))throw new Error(op.id+': dependency is not installed.');const declared=Object.entries(state.moduleDependencies||{}).filter(([,deps])=>Array.isArray(deps)&&deps.includes(id)).map(([moduleId])=>moduleId);const claimed=Array.isArray(op.requiredBy)?op.requiredBy:[];if([...new Set([...declared,...claimed])].length)throw new Error(op.id+': dependency is still required.');delete state.dependencies[id];}return;}
    const prefixes={RECONFIGURE:'/settings',CHANGE_POLICY:'/policies',REWIRE:'/dependencies'};
    if(prefixes[kind])op=Object.assign({},op,{path:prefixes[kind]+(op.path||'')});
    if(['REMOVE'].includes(kind)||(kind==='PATCH'&&op.action==='remove')){remove(state,op.path);return;}
    if(kind==='PATCH'&&op.action==='append'){const target=read(state,op.path);if(!Array.isArray(target))throw new Error('PATCH append target must be an array.');target.push(clone(op.value));return;}
    if(kind==='PATCH'&&op.action==='merge'){const target=read(state,op.path);if(!target||typeof target!=='object'||Array.isArray(target)||!op.value||typeof op.value!=='object'||Array.isArray(op.value))throw new Error('PATCH merge requires objects.');for(const [k,v]of Object.entries(op.value)){if(BAD_KEYS.has(k))throw new Error('Unsafe merge key rejected.');target[k]=clone(v);}return;}
    if(kind==='ADD'||kind==='REPLACE'||kind==='PATCH'||prefixes[kind]){if(kind==='PATCH'&&op.action!=='set')throw new Error('PATCH action must be set, append, merge or remove.');write(state,op.path,op.value,kind==='ADD'?'add':kind==='REPLACE'?'replace':'set');return;}
    if(kind==='MOVE'||kind==='RENAME'){if(op.from===op.to||String(op.to||'').startsWith(String(op.from||'')+'/'))throw new Error('MOVE/RENAME cannot target itself or a descendant.');const value=clone(read(state,op.from));write(state,op.to,value,'add');remove(state,op.from);return;}
    throw new Error('Unsupported LTL operation: '+kind);
  }
  async function apply(config, files, operations) { const ordered=order(operations), state=clone(config), staged=clone(files);for(const op of ordered)await applyOne(state,staged,op);const counts={},targets=new Set(),risks=new Set();ordered.forEach(op=>{const k=String(op.op).toUpperCase();counts[k]=(counts[k]||0)+1;risks.add(String(op.risk).toLowerCase());if(op.path)targets.add(op.path);if(op.file)targets.add(op.file);});return {config:state,files:staged,orderedOperationIds:ordered.map(op=>op.id),impact:{operationCount:ordered.length,counts,targets:[...targets].sort(),riskLevels:[...risks],manualApprovalRequired:true,executableCodeLoading:false}}; }
  global.LoadoutLtlEngine=Object.freeze({apply,order,stable,safePath,operations:[...OPS]});
})(window);
