/**
 * Loadout backup format and merge policy.
 * Schema 3 is checksummed; schema 1/2 remain readable for backward compatibility.
 * Credentials are intentionally outside this format and remain device-local.
 */
export const BACKUP_FORMAT = 'loadout-backup';
export const BACKUP_SCHEMA_VERSION = 3;
export const MAX_BACKUP_BYTES = 30 * 1024 * 1024;

function safeClone(value, depth = 0) {
  if (depth > 60) throw new Error('Backup data exceeds the maximum nesting depth.');
  if (value === undefined) return null;
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('Backup contains a non-finite number.');
    return value;
  }
  if (Array.isArray(value)) return value.map(item => safeClone(item, depth + 1));
  if (typeof value !== 'object' || Object.getPrototypeOf(value) !== Object.prototype) {
    throw new Error('Backup contains an unsupported value.');
  }
  const result = {};
  for (const [key, item] of Object.entries(value)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new Error('Backup contains an unsafe object key.');
    if (item !== undefined) result[key] = safeClone(item, depth + 1);
  }
  return result;
}

function stable(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stable(value[key])).join(',') + '}';
}

async function sha256(text) {
  if (!globalThis.crypto?.subtle) throw new Error('SHA-256 verification is unavailable in this environment.');
  const data = new TextEncoder().encode(text);
  const digest = await globalThis.crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

function validateRecords(settings, attempts, forecasts) {
  if (!settings || typeof settings !== 'object' || Array.isArray(settings)) throw new Error('Backup is missing valid settings.');
  if (!Array.isArray(attempts)) throw new Error('Backup is missing the attempts array.');
  if (!Array.isArray(forecasts)) throw new Error('Backup is missing the forecasts array.');
  for (const record of attempts) {
    if (!record || typeof record !== 'object' || Array.isArray(record)) throw new Error('Invalid test record in backup.');
    const fields = ['n', 'correct', 'wrong', 'unattempted'];
    if (fields.every(field => record[field] != null)) {
      for (const field of fields) {
        if (!Number.isInteger(record[field]) || record[field] < 0) throw new Error(`Invalid ${field} value in backup record ${record.testId || record.id || '(unknown)'}.`);
      }
      if (record.correct + record.wrong + record.unattempted !== record.n) {
        throw new Error(`Invalid C/W/U totals in backup record ${record.testId || record.id || '(unknown)'}.`);
      }
    }
  }
}

function normalizeLegacy(input) {
  const attempts = input.attempts ?? input.appState?.attempts;
  const settings = input.settings ?? input.appState?.settings;
  const forecasts = input.forecasts ?? input.appState?.forecasts ?? [];
  validateRecords(settings, attempts, forecasts);
  const chat = input.chat == null ? null : safeClone(input.chat);
  if (chat && !Array.isArray(chat.conversations) && !Array.isArray(chat.messages)) {
    throw new Error('Backup chat payload is malformed.');
  }
  return {
    schemaVersion: Number(input.schemaVersion || 1),
    exportedAt: input.exportedAt || null,
    settings: safeClone(settings),
    attempts: safeClone(attempts),
    forecasts: safeClone(forecasts),
    chat,
    examProfileId: input.examProfileId || null,
    integrityVerified: false,
    legacy: true
  };
}

export async function createBackup({ settings, attempts, forecasts = [], chat = null, examProfileId = 'jee-main-2027-paper-1', sourceSchedule = null } = {}, metadata = {}) {
  const safeSettings = safeClone(settings);
  const safeAttempts = safeClone(attempts);
  const safeForecasts = safeClone(forecasts);
  const safeChat = chat == null ? null : safeClone(chat);
  validateRecords(safeSettings, safeAttempts, safeForecasts);
  if (safeChat && !Array.isArray(safeChat.conversations) && !Array.isArray(safeChat.messages)) {
    throw new Error('Chat export is malformed.');
  }
  const core = {
    app: BACKUP_FORMAT,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    sourceAppVersion: String(metadata.sourceAppVersion || '1.8.0'),
    sourceSchedule: sourceSchedule ? String(sourceSchedule) : null,
    payload: {
      settings: safeSettings,
      attempts: safeAttempts,
      forecasts: safeForecasts,
      chat: safeChat,
      examProfileId: examProfileId || null
    }
  };
  const digest = await sha256(stable(core));
  const output = { ...core, integrity: { algorithm: 'SHA-256', digest } };
  const encoded = JSON.stringify(output);
  if (new TextEncoder().encode(encoded).byteLength > MAX_BACKUP_BYTES) throw new Error('Backup exceeds the 30 MiB export limit.');
  return output;
}

export async function verifyBackupReadback(expectedSnapshot, storedSnapshot) {
  if (!expectedSnapshot || expectedSnapshot.app !== BACKUP_FORMAT || !expectedSnapshot.payload || !expectedSnapshot.integrity?.digest) {
    throw new Error('Expected safety snapshot is malformed.');
  }
  const checked = await validateBackup(storedSnapshot);
  if (!checked.integrityVerified) throw new Error('Stored safety snapshot has no verified integrity checksum.');
  const expected = expectedSnapshot.payload;
  for (const field of ['settings', 'attempts', 'forecasts', 'chat', 'examProfileId']) {
    if (stable(checked[field] ?? null) !== stable(expected[field] ?? null)) {
      throw new Error(`Stored safety snapshot payload mismatch in ${field}.`);
    }
  }
  return checked;
}

export async function validateBackup(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Backup must be a JSON object.');
  if (input.app !== BACKUP_FORMAT) throw new Error('This is not a Loadout backup.');
  const version = Number(input.schemaVersion || 1);
  if (version === 1 || version === 2) return normalizeLegacy(input);
  if (version !== BACKUP_SCHEMA_VERSION) throw new Error('Unsupported Loadout backup schema.');
  if (!input.payload || typeof input.payload !== 'object' || Array.isArray(input.payload)) throw new Error('Backup payload is missing.');
  if (!input.integrity || input.integrity.algorithm !== 'SHA-256' || !/^[a-f0-9]{64}$/i.test(String(input.integrity.digest || ''))) {
    throw new Error('Backup integrity metadata is missing or malformed.');
  }
  const { integrity, ...core } = safeClone(input);
  const actual = await sha256(stable(core));
  if (actual !== integrity.digest.toLowerCase()) throw new Error('Backup integrity check failed: the file has changed or is corrupted.');
  const payload = core.payload;
  validateRecords(payload.settings, payload.attempts, payload.forecasts);
  const chat = payload.chat == null ? null : safeClone(payload.chat);
  if (chat && !Array.isArray(chat.conversations) && !Array.isArray(chat.messages)) throw new Error('Backup chat payload is malformed.');
  return {
    schemaVersion: version,
    exportedAt: core.exportedAt || null,
    settings: safeClone(payload.settings),
    attempts: safeClone(payload.attempts),
    forecasts: safeClone(payload.forecasts),
    chat,
    examProfileId: payload.examProfileId || null,
    integrityVerified: true,
    legacy: false
  };
}

function attemptIdentity(record) {
  if (record?.id != null && String(record.id)) return 'id:' + String(record.id);
  return ['fallback', record?.type, record?.testId, record?.date, record?.title, record?.score, record?.n].map(x => String(x ?? '')).join('|');
}
function forecastIdentity(record) {
  if (record?.id != null && String(record.id)) return 'id:' + String(record.id);
  return ['fallback', record?.type, record?.testId, record?.date, record?.savedOn].map(x => String(x ?? '')).join('|');
}
function mergeByIdentity(current, incoming, identity) {
  const result = safeClone(current || []);
  const positions = new Map(result.map((record, index) => [identity(record), index]));
  for (const record of incoming || []) {
    const key = identity(record);
    if (positions.has(key)) result[positions.get(key)] = safeClone(record);
    else { positions.set(key, result.length); result.push(safeClone(record)); }
  }
  return result;
}

export function applyBackupToState(currentState, backup, mode = 'replace') {
  if (!['replace', 'merge'].includes(mode)) throw new Error('Restore mode must be replace or merge.');
  const current = safeClone(currentState);
  const incoming = safeClone(backup);
  if (mode === 'replace') {
    return {
      ...current,
      settings: { ...current.settings, ...incoming.settings },
      attempts: incoming.attempts,
      forecasts: incoming.forecasts
    };
  }
  return {
    ...current,
    settings: current.settings,
    attempts: mergeByIdentity(current.attempts, incoming.attempts, attemptIdentity),
    forecasts: mergeByIdentity(current.forecasts, incoming.forecasts, forecastIdentity)
  };
}

export function mergeChatBackup(currentChat, incomingChat) {
  if (!incomingChat) return currentChat ? safeClone(currentChat) : null;
  const current = currentChat ? safeClone(currentChat) : { provider: 'gemini', profiles: {}, conversations: [] };
  const incoming = safeClone(incomingChat);
  if (!Array.isArray(current.conversations) && Array.isArray(current.messages)) current.conversations = [{ id: 'conversation-imported-current', title: 'Imported conversation', messages: current.messages }];
  if (!Array.isArray(incoming.conversations) && Array.isArray(incoming.messages)) incoming.conversations = [{ id: 'conversation-imported', title: 'Imported conversation', messages: incoming.messages }];
  const conversations = safeClone(current.conversations || []);
  const currentIndex = new Map(conversations.map((item, index) => [String(item.id || item.title || 'conversation'), index]));
  for (const item of incoming.conversations || []) {
    const key = String(item.id || item.title || 'conversation');
    if (!currentIndex.has(key)) {
      currentIndex.set(key, conversations.length);
      conversations.push(safeClone(item));
      continue;
    }
    const index = currentIndex.get(key);
    const existing = conversations[index];
    if (new Date(item.updatedAt || item.createdAt || 0) > new Date(existing.updatedAt || existing.createdAt || 0)) {
      conversations[index] = safeClone(item);
    }
  }
  const profiles = { ...(current.profiles || {}), ...(incoming.profiles || {}) };
  for (const profile of Object.values(profiles)) if (profile && typeof profile === 'object') delete profile.apiKey;
  return {
    ...current,
    provider: incoming.provider || current.provider || 'gemini',
    profiles,
    autoFallback: incoming.autoFallback ?? current.autoFallback ?? false,
    conversations,
    activeConversationId: incoming.activeConversationId || current.activeConversationId || conversations[0]?.id || null
  };
}
