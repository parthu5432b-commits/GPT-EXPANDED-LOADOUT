/* Small fail-closed gate for the legacy synchronous state store. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.LoadoutRecoveryGate = api;
})(typeof window !== 'undefined' ? window : null, function () {
  function create() {
    let blocked = false;
    let original = null;
    let reason = null;
    return Object.freeze({
      block(raw, why) {
        blocked = true;
        original = typeof raw === 'string' ? raw : null;
        reason = String(why || 'Recovery copy has not been verified.');
        return Object.freeze({ blocked, hasOriginal: original !== null, reason });
      },
      resume(acknowledged) {
        if (!blocked) return Object.freeze({ resumed: true, original: null });
        if (acknowledged !== true) return Object.freeze({ resumed: false, original });
        const preserved = original;
        blocked = false;
        original = null;
        reason = null;
        return Object.freeze({ resumed: true, original: preserved });
      },
      status() {
        return Object.freeze({ blocked, hasOriginal: original !== null, reason });
      },
      originalText() { return original; }
    });
  }
  return Object.freeze({ create });
});
