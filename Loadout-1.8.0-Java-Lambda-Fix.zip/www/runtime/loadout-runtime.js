/* Loadout L-SEAA runtime 1.5.0
 * Local-first host services, secure credential bridge, diagnostics and owner-approved
 * signed data/resource-pack transactions. Executable code is intentionally not hot-loaded.
 */
(function (global) {
  'use strict';
  if (global.Loadout) return;

  const VERSION = '1.5.0';
  const RUNTIME_API = '1.5.0';
  const APP_ID = 'app.loadout.jee';
  const PREFIX = 'loadout.runtime.v2.';
  const listeners = new Map();
  const moduleStorage = new Map();
  const pendingWrites = new Map();
  const native = (() => {
    const cap = global.Capacitor;
    if (!cap) return null;
    const existing = cap.Plugins && (cap.Plugins.LoadoutCore || cap.Plugins.LoadoutNativeCore);
    if (existing) return existing;
    const available = typeof cap.isPluginAvailable === 'function' && cap.isPluginAvailable('LoadoutCore');
    return (available && typeof cap.registerPlugin === 'function' ? cap.registerPlugin('LoadoutCore') : null) || global.LoadoutCore || null;
  })();
  const clone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  const safeId = value => /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/.test(String(value || ''));
  const safePath = value => {
    const s = String(value || '');
    return !!s && s.length <= 240 && !s.startsWith('/') && !s.includes('\\') && !s.includes('\0') && !/^[A-Za-z]:/.test(s) && s.split('/').every(p => p && p !== '.' && p !== '..');
  };
  const bytes = value => new TextEncoder().encode(String(value));
  const base64ToBytes = value => Uint8Array.from(global.atob(value), c => c.charCodeAt(0));
  const bytesToHex = value => Array.from(new Uint8Array(value)).map(b => b.toString(16).padStart(2, '0')).join('');
  const stable = value => {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
  };
  async function sha256(value) {
    if (!global.crypto?.subtle) throw new Error('WebCrypto SHA-256 unavailable; update refused.');
    return bytesToHex(await global.crypto.subtle.digest('SHA-256', bytes(value)));
  }
  function pluginAvailable(method) { return !!native && typeof native[method] === 'function'; }

  const Native = {
    get available() { return !!native; },
    get secureCredentialsAvailable() { return pluginAvailable('setSecret') && pluginAvailable('hasSecret') && pluginAvailable('deleteSecret'); },
    async info() {
      if (!pluginAvailable('getRuntimeInfo')) return { available: false, platform: global.Capacitor?.getPlatform?.() || 'web' };
      return native.getRuntimeInfo();
    },
    async list(namespace) {
      if (!pluginAvailable('listPrivateFiles')) return [];
      const result = await native.listPrivateFiles({ namespace });
      return Array.isArray(result?.files) ? result.files : [];
    },
    async saveFileBase64(fileName, mimeType, base64) {
      if (!pluginAvailable('saveFileBase64')) return null;
      return native.saveFileBase64({ fileName, mimeType, base64 });
    },
    async developmentPortStatus() {
      if (!pluginAvailable('getDevelopmentPortStatus')) return { available: false, enabled: false, networkListener: false, remoteExecution: false };
      return native.getDevelopmentPortStatus();
    },
    async developmentPortPackages() {
      if (!pluginAvailable('listDevelopmentPortPackages')) return [];
      const result = await native.listDevelopmentPortPackages();
      return Array.isArray(result?.packages) ? result.packages : [];
    },
    async readDevelopmentPortPackage(name) {
      if (!pluginAvailable('readDevelopmentPortPackage')) throw new Error('Native Development Port inbox is unavailable.');
      return native.readDevelopmentPortPackage({ name });
    },
    async deleteDevelopmentPortPackage(name) {
      if (!pluginAvailable('deleteDevelopmentPortPackage')) return false;
      const result = await native.deleteDevelopmentPortPackage({ name });
      return !!result?.ok;
    },
    async nativeExtensionInventory() {
      if (!pluginAvailable('getNativeExtensionInventory')) return { apiVersion: 1, extensions: [], dynamicDexJarLoading: false, nativeChangesRequireApk: true };
      return native.getNativeExtensionInventory();
    },
    get databaseAvailable() {
      return pluginAvailable('databaseMigrate') && pluginAvailable('databaseQuery') && pluginAvailable('databaseExecuteBatch') && pluginAvailable('databaseInfo');
    },
    async databaseMigrate(name, migrations) {
      if (!this.databaseAvailable) throw new Error('Native SQLite bridge is unavailable.');
      return native.databaseMigrate({ name, migrations });
    },
    async databaseQuery(name, sql, args = []) {
      if (!this.databaseAvailable) throw new Error('Native SQLite bridge is unavailable.');
      return native.databaseQuery({ name, sql, args });
    },
    async databaseExecuteBatch(name, statements) {
      if (!this.databaseAvailable) throw new Error('Native SQLite bridge is unavailable.');
      return native.databaseExecuteBatch({ name, statements });
    },
    async databaseInfo(name) {
      if (!this.databaseAvailable) throw new Error('Native SQLite bridge is unavailable.');
      return native.databaseInfo({ name });
    }
  };

  async function nativeRead(namespace, key) {
    if (!pluginAvailable('readPrivateFile')) return null;
    const result = await native.readPrivateFile({ namespace, key });
    return result && result.value != null ? result.value : null;
  }
  async function nativeWrite(namespace, key, value) {
    if (!pluginAvailable('writePrivateFile')) return false;
    const result = await native.writePrivateFile({ namespace, key, value: String(value) });
    if (result?.ok === false) throw new Error(result.error || 'Native storage write failed.');
    return true;
  }
  async function nativeDelete(namespace, key) {
    if (!pluginAvailable('deletePrivateFile')) return false;
    await native.deletePrivateFile({ namespace, key });
    return true;
  }

  const Secrets = Object.freeze({
    get available() { return Native.secureCredentialsAvailable; },
    async set(id, value, origin) {
      if (!safeId(id)) throw new Error('Invalid credential identifier.');
      if (!Native.secureCredentialsAvailable) throw new Error('Android Keystore-backed credential storage is unavailable on this platform. The key was not saved.');
      const parsed = new URL(String(origin || ''));
      if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) throw new Error('Credential must be bound to an HTTPS origin only.');
      await native.setSecret({ id, value: String(value || ''), origin: parsed.origin });
      return true;
    },
    async status(id) {
      if (!safeId(id)) throw new Error('Invalid credential identifier.');
      if (!pluginAvailable('hasSecret')) return { available: false, originBound: false };
      const result = await native.hasSecret({ id });
      return { available: !!result?.available, originBound: !!result?.originBound, origin: result?.origin || '' };
    },
    async has(id, origin) {
      const result = await this.status(id);
      if (!result.available || !result.originBound) return false;
      if (!origin) return true;
      const parsed = new URL(String(origin));
      return parsed.protocol === 'https:' && parsed.origin === result.origin;
    },
    async delete(id) {
      if (!safeId(id)) throw new Error('Invalid credential identifier.');
      if (!Native.secureCredentialsAvailable) return false;
      await native.deleteSecret({ id });
      return true;
    }
  });

  const AITransport = Object.freeze({
    get nativeAvailable() { return pluginAvailable('requestAiProvider') && pluginAvailable('cancelAiProviderRequest') && Secrets.available; },
    async request(options) {
      if (!this.nativeAvailable) throw new Error('Secure Android AI transport is unavailable.');
      const request = options || {};
      if (!safeId(request.credentialId) || !safeId(request.requestId)) throw new Error('AI transport requires safe credential and request identifiers.');
      let listener = null;
      let abortHandler = null;
      if (typeof request.onChunk === 'function' && typeof native.addListener === 'function') {
        listener = await native.addListener('aiProviderChunk', event => {
          if (event && event.requestId === request.requestId && typeof event.text === 'string' && event.text) request.onChunk(event.text);
        });
      }
      try {
        if (request.signal?.aborted) {
          const abort = new Error('AI request cancelled before native dispatch.');
          abort.name = 'AbortError';
          throw abort;
        }
        if (request.signal && typeof request.signal.addEventListener === 'function') {
          abortHandler = () => { void AITransport.cancel(request.requestId).catch(() => false); };
          request.signal.addEventListener('abort', abortHandler, { once: true });
          // Recheck after listener registration so an abort cannot be lost at the boundary.
          if (request.signal.aborted) {
            abortHandler();
            const abort = new Error('AI request cancelled before native dispatch.');
            abort.name = 'AbortError';
            throw abort;
          }
        }
        const pending = native.requestAiProvider({
          credentialId: request.credentialId,
          requestId: request.requestId,
          url: String(request.url || ''),
          body: String(request.body || ''),
          authMode: request.authMode === 'google-api-key' ? 'google-api-key' : 'bearer',
          providerKind: request.providerKind === 'gemini' ? 'gemini' : 'openai',
          stream: !!request.stream,
          headers: request.headers || {}
        });
        // A signal may abort immediately after native dispatch; cancel that exact request ID.
        if (request.signal?.aborted && abortHandler) abortHandler();
        return await pending;
      } finally {
        if (request.signal && abortHandler && typeof request.signal.removeEventListener === 'function') request.signal.removeEventListener('abort', abortHandler);
        if (listener && typeof listener.remove === 'function') await listener.remove();
      }
    },
    async cancel(requestId) {
      if (!pluginAvailable('cancelAiProviderRequest')) return false;
      const result = await native.cancelAiProviderRequest({ requestId: String(requestId || '') });
      return !!result?.cancelled;
    }
  });

  function redact(value) {
    const secretKeys = /key|token|secret|password|authorization|credential|prompt|messagecontent/i;
    function walk(v) {
      if (Array.isArray(v)) return v.map(walk);
      if (!v || typeof v !== 'object') return v;
      const out = {};
      for (const [k, x] of Object.entries(v)) out[k] = secretKeys.test(k) ? '[REDACTED]' : walk(x);
      return out;
    }
    return walk(clone(value || {}));
  }
  const Diagnostics = Object.freeze({
    policy: 'balanced',
    async record(level, event, details) {
      if (!['error', 'warn', 'update', 'recovery', 'info'].includes(level)) return;
      const record = { at: new Date().toISOString(), level, event: String(event || 'event').slice(0, 100), details: redact(details) };
      try {
        let rows = [];
        const raw = await nativeRead('diagnostics', 'events.json') || localStorage.getItem(PREFIX + 'diagnostics');
        if (raw) { try { rows = JSON.parse(raw); } catch (_) { rows = []; } }
        if (!Array.isArray(rows)) rows = [];
        rows.push(record); rows = rows.slice(-500);
        let json = JSON.stringify(rows);
        while (json.length > 1_500_000 && rows.length > 1) { rows.shift(); json = JSON.stringify(rows); }
        if (!(await nativeWrite('diagnostics', 'events.json', json))) localStorage.setItem(PREFIX + 'diagnostics', json);
      } catch (_) { /* diagnostics must never break normal study workflows */ }
    },
    async read() {
      try {
        const raw = await nativeRead('diagnostics', 'events.json') || localStorage.getItem(PREFIX + 'diagnostics');
        const value = raw ? JSON.parse(raw) : [];
        return Array.isArray(value) ? value : [];
      } catch (_) { return []; }
    },
    async clear() {
      await nativeDelete('diagnostics', 'events.json');
      localStorage.removeItem(PREFIX + 'diagnostics');
    }
  });

  function storageKey(namespace, name) { return PREFIX + namespace + '.' + name; }
  function enqueueWrite(key, operation) {
    const previous = pendingWrites.get(key) || Promise.resolve();
    const next = previous.catch(() => {}).then(operation);
    pendingWrites.set(key, next);
    next.finally(() => { if (pendingWrites.get(key) === next) pendingWrites.delete(key); }).catch(() => {});
    return next;
  }
  const Storage = Object.freeze({
    async create(options) {
      const opts = Object.assign({ namespace: 'default', name: 'store', lifetime: 'persistent' }, options || {});
      if (!safeId(opts.namespace) || !safeId(opts.name)) throw new Error('Storage namespace and name must be safe identifiers.');
      if (!['volatile', 'session', 'module', 'ttl', 'persistent'].includes(opts.lifetime)) throw new Error('Unsupported storage lifetime.');
      if (opts.lifetime === 'ttl' && !(Number(opts.ttlMs) > 0)) throw new Error('ttl lifetime requires ttlMs > 0.');
      if (opts.lifetime === 'module' && !safeId(opts.moduleId)) throw new Error('module lifetime requires a safe moduleId.');
      const key = storageKey(opts.namespace, opts.name);
      let volatileValue;
      async function rawGet() {
        if (opts.lifetime === 'volatile') return volatileValue === undefined ? null : JSON.stringify(volatileValue);
        if (opts.lifetime === 'module') return moduleStorage.get(opts.moduleId)?.get(key) ?? null;
        if (opts.lifetime === 'session') return sessionStorage.getItem(key);
        return await nativeRead(opts.namespace, opts.name) ?? localStorage.getItem(key);
      }
      async function rawSet(raw) {
        if (opts.lifetime === 'volatile') { volatileValue = JSON.parse(raw); return; }
        if (opts.lifetime === 'module') {
          if (!moduleStorage.has(opts.moduleId)) moduleStorage.set(opts.moduleId, new Map());
          moduleStorage.get(opts.moduleId).set(key, raw);
          return;
        }
        if (opts.lifetime === 'session') { sessionStorage.setItem(key, raw); return; }
        if (!(await nativeWrite(opts.namespace, opts.name, raw))) localStorage.setItem(key, raw);
      }
      async function rawDelete() {
        if (opts.lifetime === 'volatile') { volatileValue = undefined; return; }
        if (opts.lifetime === 'module') { moduleStorage.get(opts.moduleId)?.delete(key); return; }
        if (opts.lifetime === 'session') { sessionStorage.removeItem(key); return; }
        await nativeDelete(opts.namespace, opts.name); localStorage.removeItem(key);
      }
      return Object.freeze({
        lifetime: opts.lifetime,
        async get() {
          const raw = await rawGet(); if (raw == null) return null;
          try { const item = JSON.parse(raw); if (opts.lifetime === 'ttl' && item.expiresAt && Date.now() >= item.expiresAt) { await rawDelete(); return null; } return item.value; }
          catch (_) { await rawDelete(); return null; }
        },
        async set(value) {
          const raw = JSON.stringify(opts.lifetime === 'ttl' ? { value, expiresAt: Date.now() + Number(opts.ttlMs) } : { value });
          await enqueueWrite(key, () => rawSet(raw));
          return true;
        },
        async delete() { await enqueueWrite(key, rawDelete); },
        async clear() { await enqueueWrite(key, rawDelete); }
      });
    },
    async flush() {
      // Wait until all writes already queued by legacy state/chat persistence have settled.
      while (pendingWrites.size) await Promise.allSettled(Array.from(pendingWrites.values()));
      return { pendingWrites: pendingWrites.size, flushedAt: new Date().toISOString() };
    },
    async mirror(namespace, name, value) {
      if (!safeId(namespace) || !safeId(name)) throw new Error('Invalid mirror address.');
      const key = 'mirror:' + storageKey(namespace, name);
      return enqueueWrite(key, async () => {
        const store = await Storage.create({ namespace, name, lifetime: 'persistent' });
        const snapshot = clone(value);
        await store.set(snapshot);
        return { namespace, name, verified: stable(await store.get()) === stable(snapshot) };
      });
    },
    async readMirror(namespace, name) {
      const store = await Storage.create({ namespace, name, lifetime: 'persistent' });
      return store.get();
    },
    async list(namespace) {
      if (!safeId(namespace)) throw new Error('Invalid storage namespace.');
      const names = new Set();
      if (pluginAvailable('listPrivateFiles')) {
        for (const name of await Native.list(namespace)) if (safeId(name)) names.add(name);
      } else {
        // PWA/browser fallback, and compatibility with an Android bridge version that
        // predates listPrivateFiles. Never report an empty native listing as authoritative
        // when that method is not actually present.
        const prefix = storageKey(namespace, '');
        for (let index = 0; index < localStorage.length; index++) {
          const key = localStorage.key(index);
          if (key && key.startsWith(prefix)) {
            const name = key.slice(prefix.length);
            if (safeId(name)) names.add(name);
          }
        }
      }
      return Array.from(names).sort();
    },
    async status() {
      return { native: Native.available, secureCredentials: Secrets.available, pendingWrites: pendingWrites.size, lifetimes: ['volatile','session','module','ttl','persistent'] };
    },
    async deactivateModule(moduleId) {
      if (!safeId(moduleId)) throw new Error('Invalid module identifier.');
      const bucket = moduleStorage.get(moduleId);
      const removed = bucket ? bucket.size : 0;
      moduleStorage.delete(moduleId);
      await Diagnostics.record('info', 'module-memory-storage-cleared', { moduleId, storesRemoved: removed });
      return { moduleId, storesRemoved: removed };
    }
  });

  const Events = Object.freeze({
    on(name, fn) { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(fn); return () => listeners.get(name)?.delete(fn); },
    emit(name, payload) { for (const fn of listeners.get(name) || []) { try { fn(payload); } catch (e) { Diagnostics.record('warn', 'event-listener-failed', { name, message: e.message }); } } }
  });

  async function managedRead(key, fallback) {
    const raw = await nativeRead('runtime', key) || localStorage.getItem(PREFIX + 'managed.' + key);
    if (!raw) return clone(fallback);
    try { return JSON.parse(raw); } catch (_) { throw new Error('Managed record is corrupt: ' + key); }
  }
  async function managedWrite(key, value) {
    const raw = JSON.stringify(value);
    if (!(await nativeWrite('runtime', key, raw))) localStorage.setItem(PREFIX + 'managed.' + key, raw);
  }
  async function managedDelete(key) { await nativeDelete('runtime', key); localStorage.removeItem(PREFIX + 'managed.' + key); }

  async function loadTrustStore() {
    const response = await fetch('./runtime/trust-store.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not read bundled update trust store.');
    const store = await response.json();
    if (store.schemaVersion !== 1 || store.algorithm !== 'Ed25519' || !Array.isArray(store.keys)) throw new Error('Invalid update trust-store schema.');
    return store;
  }
  async function verifyPackage(pkg) {
    if (!pkg || !pkg.manifest || !pkg.files || typeof pkg.files !== 'object' || Array.isArray(pkg.files)) throw new Error('Package requires manifest and files objects.');
    const m = pkg.manifest;
    if (m.formatVersion !== '1.0' || m.kind !== 'data-update' || m.target?.appId !== APP_ID || m.target?.runtimeApi !== RUNTIME_API) throw new Error('Unsupported package format, kind, target app or runtime API.');
    if (!safeId(m.updateId) || !Array.isArray(m.resources) || !Array.isArray(m.transformations || [])) throw new Error('Manifest shape is invalid.');
    if (Object.keys(pkg.files).length !== m.resources.length) throw new Error('Every file must be declared exactly once in resources.');
    let total = 0; const seen = new Set();
    const allowed = /\.(json|md|txt)$/i;
    for (const [name, content] of Object.entries(pkg.files)) {
      if (!safePath(name) || !allowed.test(name) || typeof content !== 'string') throw new Error('Unsafe, executable or non-text package resource rejected: ' + name);
      const size = bytes(content).length; if (size > 4 * 1024 * 1024) throw new Error('A resource exceeds 4 MiB.'); total += size;
      if (total > 8 * 1024 * 1024) throw new Error('Expanded package exceeds 8 MiB.');
    }
    for (const resource of m.resources) {
      if (!resource || !safePath(resource.path) || seen.has(resource.path) || !Object.prototype.hasOwnProperty.call(pkg.files, resource.path)) throw new Error('Resource descriptor is invalid.');
      seen.add(resource.path);
      if ((await sha256(pkg.files[resource.path])) !== String(resource.sha256 || '').toLowerCase()) throw new Error('Resource SHA-256 mismatch: ' + resource.path);
      if (resource.namespace && !safeId(resource.namespace)) throw new Error('Invalid resource namespace.');
    }
    const sig = m.signature;
    if (!sig || sig.algorithm !== 'Ed25519' || typeof sig.keyId !== 'string' || typeof sig.value !== 'string') throw new Error('Package is unsigned or uses an unsupported signature.');
    const trust = await loadTrustStore();
    const key = trust.keys.find(k => k.keyId === sig.keyId && k.algorithm === 'Ed25519' && typeof k.publicKey === 'string' && !k.revokedAt && k.status !== 'revoked');
    if (!key) throw new Error('Signer is not trusted or has been revoked by this installed Loadout build: ' + sig.keyId);
    const rawKey = base64ToBytes(key.publicKey); if (rawKey.length !== 32) throw new Error('Trusted Ed25519 key has invalid length.');
    if (!global.crypto?.subtle) throw new Error('WebCrypto signature verification unavailable; update rejected.');
    let imported;
    try { imported = await global.crypto.subtle.importKey('raw', rawKey, { name: 'Ed25519' }, false, ['verify']); }
    catch (_) { throw new Error('This Android WebView does not support Ed25519 WebCrypto verification. Update rejected safely.'); }
    const manifest = clone(m); delete manifest.signature;
    const orderedFiles = {}; Object.keys(pkg.files).sort().forEach(k => { orderedFiles[k] = pkg.files[k]; });
    const payload = 'LOADOUT-LUPDATE-1.0\n' + stable({ manifest, files: orderedFiles });
    const valid = await global.crypto.subtle.verify({ name: 'Ed25519' }, imported, base64ToBytes(sig.value), bytes(payload));
    if (!valid) throw new Error('Ed25519 package signature verification failed.');
    const installed = (await managedRead('config', { settings: {}, policies: {}, dependencies: {} })).dependencies || {};
    if (m.dependencies !== undefined) {
      if (!Array.isArray(m.dependencies) || m.dependencies.length > 100) throw new Error('Manifest dependencies must be an array of at most 100 entries.');
      const depIds = new Set();
      for (const dep of m.dependencies) {
        if (!dep || !safeId(dep.id) || !/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(String(dep.version || '')) || depIds.has(dep.id)) throw new Error('Invalid or duplicate dependency declaration.');
        depIds.add(dep.id);
        if (dep.required !== false && m.dependenciesRequired === true && installed[dep.id] !== dep.version) throw new Error('Required dependency is missing or mismatched: ' + dep.id + '@' + dep.version);
        if (installed[dep.id] && installed[dep.id] !== dep.version) throw new Error('Dependency version mismatch: ' + dep.id + ' requires ' + dep.version + ', installed ' + installed[dep.id]);
      }
    }
    const ltl = global.LoadoutLtlEngine;
    if (!ltl || typeof ltl.order !== 'function') throw new Error('LTL transformation engine is unavailable; update rejected.');
    const ordered = ltl.order(m.transformations || []);
    return { keyId: key.keyId, totalBytes: total, resourceCount: seen.size, operationCount: ordered.length, orderedOperationIds: ordered.map(op => op.id) };
  }


  const PackageCache = Object.freeze({
    async save(pkg) {
      const verified = await verifyPackage(pkg);
      const id = pkg.manifest.updateId;
      const recordKey = 'package-cache-' + id;
      const digest = await sha256(stable(pkg));
      const previous = await managedRead(recordKey, null);
      if (previous && previous.digest !== digest) throw new Error('A different signed package already occupies this immutable cache ID; use a new updateId.');
      const record = previous || { updateId: id, digest, signer: verified.keyId, savedAt: new Date().toISOString(), package: clone(pkg) };
      await managedWrite(recordKey, record);
      const index = await managedRead('package-cache-index', []);
      if (!index.some(row => row.updateId === id)) index.push({ updateId: id, digest, signer: verified.keyId, savedAt: record.savedAt, bytes: verified.totalBytes });
      await managedWrite('package-cache-index', index.slice(-100));
      return { updateId: id, digest, signer: verified.keyId, cached: true };
    },
    async list() { return (await managedRead('package-cache-index', [])).map(row => ({ ...row })); },
    async read(updateId) {
      if (!safeId(updateId)) throw new Error('Invalid cached update identifier.');
      const record = await managedRead('package-cache-' + updateId, null);
      if (!record || record.updateId !== updateId || !record.package) throw new Error('Cached package is not available.');
      const digest = await sha256(stable(record.package));
      if (digest !== record.digest) throw new Error('Cached package integrity check failed.');
      await verifyPackage(record.package);
      return clone(record.package);
    },
    async remove(updateId) {
      if (!safeId(updateId)) throw new Error('Invalid cached update identifier.');
      const index = await managedRead('package-cache-index', []);
      await managedDelete('package-cache-' + updateId);
      await managedWrite('package-cache-index', index.filter(row => row.updateId !== updateId));
      return true;
    }
  });

  async function verifyRegistryPackage(pkg) {
    if (!pkg || !pkg.manifest || !pkg.catalog) throw new Error('Registry package requires manifest and catalog objects.');
    const m = pkg.manifest, c = pkg.catalog;
    if (m.formatVersion !== '1.0' || m.kind !== 'module-registry' || m.target?.appId !== APP_ID || m.target?.runtimeApi !== RUNTIME_API || !safeId(m.registryId) || !Number.isSafeInteger(m.revision) || m.revision < 1) throw new Error('Registry package format, identity or target mismatch.');
    if (c.schemaVersion !== 1 || c.registryId !== m.registryId || c.revision !== m.revision || c.runtimeApi !== RUNTIME_API || c.ownerControlled !== true || c.publicMarketplace !== false || !Array.isArray(c.modules)) throw new Error('Registry catalog policy or metadata is invalid.');
    const content = clone(c); const suppliedHash = String(content.catalogSha256 || '').toLowerCase(); delete content.catalogSha256;
    if (!/^[a-f0-9]{64}$/.test(suppliedHash) || await sha256(stable(content)) !== suppliedHash) throw new Error('Registry catalog SHA-256 mismatch.');
    const installed = global.LOADOUT_MODULE_REGISTRY || [];
    if (c.modules.length !== installed.length) throw new Error('Registry package cannot add/remove executable modules; rebuild the APK for module-code changes.');
    const seen = new Set(), routes = new Set();
    for (const item of c.modules) {
      if (!item || !safeId(item.id) || !/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(String(item.version || '')) || typeof item.entry !== 'string' || !item.entry.startsWith('www/') || item.entry.includes('..') || typeof item.offline !== 'boolean' || !Array.isArray(item.services) || !Array.isArray(item.dependencies)) throw new Error('Invalid registry module descriptor.');
      if (seen.has(item.id) || routes.has(item.route)) throw new Error('Duplicate registry module or route.');
      seen.add(item.id); routes.add(item.route);
      const row = installed.find(module => module.id === item.id);
      if (!row) throw new Error(`Module is not bundled in this APK: ${item.id}`);
      if (item.version !== row.version || item.runtimeApi !== row.runtimeApi || item.route !== row.route || item.entry !== row.entry || item.offline !== row.offline || [...item.services].sort().join('|') !== [...(row.services || [])].sort().join('|')) throw new Error(`Registry descriptor mismatch for ${item.id}; executable module changes require an APK update.`);
      const expectedDeps = [...(row.dependencies || [])].sort((a,b) => String(typeof a === 'string' ? a : a.id).localeCompare(String(typeof b === 'string' ? b : b.id)));
      const suppliedDeps = [...item.dependencies].sort((a,b) => String(typeof a === 'string' ? a : a.id).localeCompare(String(typeof b === 'string' ? b : b.id)));
      if (stable(suppliedDeps) !== stable(expectedDeps)) throw new Error(`Registry dependency declaration mismatch for ${item.id}.`);
      for (const rawDependency of suppliedDeps) { const dep = typeof rawDependency === 'string' ? { id: rawDependency } : rawDependency; const target = installed.find(module => module.id === dep?.id); if (!target || (dep.version && target.version !== dep.version)) throw new Error(`Unresolved or incompatible dependency for ${item.id}: ${dep?.id || '(missing)'}.`); }
      if (!/^[a-f0-9]{64}$/.test(String(item.manifestSha256 || '')) || !/^[a-f0-9]{64}$/.test(String(item.entrySha256 || ''))) throw new Error(`Source integrity metadata is invalid for ${item.id}.`);
    }
    const sig = m.signature;
    if (!sig || sig.algorithm !== 'Ed25519' || !safeId(sig.keyId) || !/^[A-Za-z0-9+/]{86}==$/.test(String(sig.value || ''))) throw new Error('Registry package is unsigned or uses an unsupported signature.');
    const trust = await loadTrustStore();
    const key = trust.keys.find(row => row.keyId === sig.keyId && row.algorithm === 'Ed25519' && !row.revokedAt && row.status !== 'revoked');
    if (!key) throw new Error(`Registry signer is not trusted or has been revoked: ${sig.keyId}`);
    const raw = base64ToBytes(key.publicKey); if (raw.length !== 32) throw new Error('Registry signing key has an invalid length.');
    if (!global.crypto?.subtle) throw new Error('WebCrypto signature verification unavailable.');
    const imported = await global.crypto.subtle.importKey('raw', raw, { name: 'Ed25519' }, false, ['verify']);
    const manifest = clone(m); delete manifest.signature;
    const payload = 'LOADOUT-REGISTRY-1.0\n' + stable({ manifest, catalog: c });
    const valid = await global.crypto.subtle.verify({ name: 'Ed25519' }, imported, base64ToBytes(sig.value), bytes(payload));
    if (!valid) throw new Error('Private registry Ed25519 signature verification failed.');
    return { registryId: c.registryId, revision: c.revision, catalogSha256: suppliedHash, signer: sig.keyId, moduleCount: c.modules.length };
  }

  const Registry = Object.freeze({
    async bundled() {
      const response = await fetch('./runtime/registry-catalog.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('Bundled private registry catalog is unavailable.');
      const catalog = await response.json();
      if (catalog.schemaVersion !== 1 || catalog.ownerControlled !== true || catalog.publicMarketplace !== false || catalog.runtimeApi !== RUNTIME_API || !Array.isArray(catalog.modules)) throw new Error('Bundled private registry catalog is invalid.');
      const copy = clone(catalog); const digest = String(copy.catalogSha256 || ''); delete copy.catalogSha256;
      if (await sha256(stable(copy)) !== digest) throw new Error('Bundled private registry catalog integrity check failed.');
      for (const item of catalog.modules) {
        const row = (global.LOADOUT_MODULE_REGISTRY || []).find(module => module.id === item.id);
        if (!row || row.version !== item.version || row.entry !== item.entry || row.route !== item.route) throw new Error('Bundled registry does not match installed module code: ' + item.id);
      }
      return catalog;
    },
    async current() {
      const bundled = await Registry.bundled();
      const cached = await managedRead('registry-catalog-cache', null);
      if (!cached) return bundled;
      try {
        const verified = await verifyRegistryPackage(cached);
        return verified.revision > bundled.revision ? cached.catalog : bundled;
      } catch (error) {
        await Diagnostics.record('warn', 'registry-cache-rejected', { message: String(error.message || error) });
        return bundled;
      }
    },
    async importSignedPackage(pkg) {
      const result = await verifyRegistryPackage(pkg);
      const current = await Registry.current();
      if (result.revision <= current.revision) throw new Error('Registry revision must be newer than the active catalog.');
      await managedWrite('registry-catalog-cache', clone(pkg));
      const check = await verifyRegistryPackage(await managedRead('registry-catalog-cache', null));
      if (check.catalogSha256 !== result.catalogSha256) throw new Error('Persisted registry cache failed its read-back check.');
      await Diagnostics.record('update', 'private-registry-catalog-imported', { registryId: result.registryId, revision: result.revision, signer: result.signer, moduleCount: result.moduleCount });
      return result;
    },
    async resetToBundled() { await managedDelete('registry-catalog-cache'); return Registry.bundled(); },
    async status() { const current = await Registry.current(); return { registryId: current.registryId, revision: current.revision, moduleCount: current.modules.length, ownerControlled: current.ownerControlled, publicMarketplace: current.publicMarketplace, distribution: current.distribution || 'bundled-apk-plus-owner-signed-offline-import', networkRequired: false, offline: true }; }
  });

  const Updates = Object.freeze({
    async verify(pkg) { return verifyPackage(pkg); },
    async stage(pkg) {
      const verification = await verifyPackage(pkg);
      // Keep an immutable verified copy so the package can be reviewed/re-staged offline.
      await PackageCache.save(pkg);
      const m = pkg.manifest;
      const previousConfig = await managedRead('config', { settings: {}, policies: {}, dependencies: {} });
      const previousRegistry = await managedRead('active-resource-packs', {});
      const transformed = await global.LoadoutLtlEngine.apply(previousConfig, pkg.files, m.transformations || []);
      const files = transformed.files;
      const config = transformed.config;
      const txId = 'tx-' + Date.now().toString(36) + '-' + global.crypto.getRandomValues(new Uint32Array(1))[0].toString(36);
      const candidateRegistry = clone(previousRegistry);
      const resourceChanges = [];
      for (const resource of m.resources) {
        const fileKey = 'r_' + (await sha256(files[resource.path])).slice(0, 60);
        const packKey = resource.namespace || m.updateId;
        const registryKey = packKey + ':' + resource.path;
        const before = candidateRegistry[registryKey] || null;
        const after = { pack: packKey, path: resource.path, fileKey, sha256: await sha256(files[resource.path]), updateId: m.updateId, signer: verification.keyId, installedAt: new Date().toISOString() };
        candidateRegistry[registryKey] = after;
        resourceChanges.push({ action: before ? 'replace' : 'add', namespace: packKey, path: resource.path, previousSha256: before?.sha256 || null, candidateSha256: after.sha256, bytes: bytes(files[resource.path]).length });
      }
      const tx = {
        id: txId, updateId: m.updateId, kind: m.kind, state: 'awaiting-manual-decision', createdAt: new Date().toISOString(),
        signer: verification.keyId, target: clone(m.target), manifest: clone(m), files,
        previousRegistry, previousConfig, candidateConfig: config, candidateRegistry,
        impact: { ...transformed.impact, resources: resourceChanges, configChanged: stable(previousConfig) !== stable(config), dependenciesBefore: clone(previousConfig.dependencies || {}), dependenciesAfter: clone(config.dependencies || {}), manualApprovalRequired: true, activationRequiresApk: false },
        journal: [{ state: 'discovered', at: new Date().toISOString() }, { state: 'verified', at: new Date().toISOString() }, { state: 'planned', at: new Date().toISOString() }, { state: 'staged', at: new Date().toISOString() }, { state: 'awaiting-manual-decision', at: new Date().toISOString() }],
        validation: { passed: true, checks: ['manifest-schema','application-target','runtime-api','ed25519-signature','trusted-signer','resource-hashes','resource-paths','no-executable-code','operation-metadata','dependency-order','transformation-preconditions','transformation-postconditions','staged-impact-report'] }
      };
      await managedWrite('transaction-' + txId, tx);
      const index = await managedRead('transaction-index', []); index.push(txId); await managedWrite('transaction-index', index.slice(-200));
      const journal = await managedRead('transaction-journal', []); journal.push({ txId, updateId: m.updateId, state: tx.state, at: new Date().toISOString(), signer: verification.keyId, operationCount: verification.operationCount, resourceCount: verification.resourceCount }); await managedWrite('transaction-journal', journal.slice(-500));
      await Diagnostics.record('update', 'update-staged', { txId, updateId: m.updateId, signer: verification.keyId, resources: verification.resourceCount, operations: verification.operationCount });
      return { transactionId: txId, state: tx.state, requiresManualDecision: true, verification: tx.validation, impact: tx.impact };
    },
    async inspect(txId) { if (!safeId(txId)) throw new Error('Invalid transaction ID.'); return managedRead('transaction-' + txId, null); },
    async pending() {
      const index = await managedRead('transaction-index', []); const list = [];
      for (const id of index) { const tx = await managedRead('transaction-' + id, null); if (tx && tx.state === 'awaiting-manual-decision') list.push({ id, updateId: tx.updateId, createdAt: tx.createdAt, signer: tx.signer, resources: tx.manifest.resources.length, impact: tx.impact || null, validation: tx.validation || null }); }
      return list;
    },
    async listActive() { return Object.values(await managedRead('active-resource-packs', {})); },
    async journal() { return managedRead('transaction-journal', []); },
    async recover() {
      const index = await managedRead('transaction-index', []); const recovered = [];
      for (const id of index) {
        const tx = await managedRead('transaction-' + id, null);
        if (!tx || tx.state !== 'activating') continue;
        await managedWrite('active-resource-packs', tx.previousRegistry || {});
        await managedWrite('config', tx.previousConfig || { settings: {}, policies: {}, dependencies: {} });
        tx.state = 'activation-failed'; tx.decision = 'interrupted-activation-recovered'; tx.error = 'Activation was interrupted by process termination; previous known-good pointers were restored.';
        tx.recoveredAt = new Date().toISOString(); (tx.journal ||= []).push({ state: 'activation-failed', at: tx.recoveredAt, recovery: 'startup-pointer-restore' });
        await managedWrite('transaction-' + id, tx);
        recovered.push(id);
        await Diagnostics.record('recovery', 'interrupted-update-activation-recovered', { txId: id, updateId: tx.updateId });
      }
      if (recovered.length) {
        const journal = await managedRead('transaction-journal', []);
        recovered.forEach(txId => journal.push({ txId, state: 'activation-failed', at: new Date().toISOString(), recovery: 'startup-pointer-restore' }));
        await managedWrite('transaction-journal', journal.slice(-500));
      }
      return { recovered: recovered.length, transactionIds: recovered };
    },
    async readResource(packKey, resourcePath) {
      if (!safeId(packKey) || !safePath(resourcePath)) throw new Error('Invalid resource-pack address.');
      const registry = await managedRead('active-resource-packs', {});
      const entry = registry[packKey + ':' + resourcePath];
      if (!entry || !safeId(entry.fileKey)) throw new Error('Resource is not active.');
      const stored = await nativeRead('data-packs', entry.fileKey) || localStorage.getItem(PREFIX + 'pack.' + entry.fileKey);
      if (typeof stored !== 'string' || (await sha256(stored)) !== entry.sha256) throw new Error('Active resource is missing or failed its integrity check.');
      return stored;
    },
    async commit(txId) {
      if (!safeId(txId)) throw new Error('Invalid transaction ID.');
      const tx = await managedRead('transaction-' + txId, null);
      if (!tx || tx.state !== 'awaiting-manual-decision') throw new Error('Transaction is not awaiting an owner decision.');
      // Reject stale candidates before entering activation recovery; never roll back another update's state.
      const activeNow = await managedRead('active-resource-packs', {});
      const configNow = await managedRead('config', { settings: {}, policies: {}, dependencies: {} });
      if (stable(activeNow) !== stable(tx.previousRegistry) || stable(configNow) !== stable(tx.previousConfig)) throw new Error('This staged update is stale because another update changed active state. Re-stage it against the current version.');
      let activationStarted = false;
      try {
        tx.state = 'activating'; tx.activationStartedAt = new Date().toISOString(); (tx.journal ||= []).push({ state: 'activating', at: tx.activationStartedAt });
        await managedWrite('transaction-' + txId, tx);
        const activationJournal = await managedRead('transaction-journal', []); activationJournal.push({ txId, updateId: tx.updateId, state: 'activating', at: tx.activationStartedAt, signer: tx.signer }); await managedWrite('transaction-journal', activationJournal.slice(-500));
        activationStarted = true;
        for (const resource of tx.manifest.resources) {
          const fileKey = 'r_' + (await sha256(tx.files[resource.path])).slice(0, 60);
          const value = tx.files[resource.path];
          if (typeof value !== 'string') throw new Error('Staged resource disappeared: ' + resource.path);
          if (!(await nativeWrite('data-packs', fileKey, value))) localStorage.setItem(PREFIX + 'pack.' + fileKey, value);
          const stored = await nativeRead('data-packs', fileKey) || localStorage.getItem(PREFIX + 'pack.' + fileKey);
          const expected = tx.candidateRegistry[`${resource.namespace || tx.updateId}:${resource.path}`]?.sha256;
          if (typeof stored !== 'string' || !expected || (await sha256(stored)) !== expected) throw new Error('Activation health check failed for ' + resource.path);
        }
        await managedWrite('active-resource-packs', tx.candidateRegistry);
        await managedWrite('config', tx.candidateConfig);
        const activeCheck = await managedRead('active-resource-packs', {});
        const configCheck = await managedRead('config', {});
        if (stable(activeCheck) !== stable(tx.candidateRegistry) || stable(configCheck) !== stable(tx.candidateConfig)) throw new Error('Activation pointer health check failed.');
        tx.state = 'committed'; tx.decision = 'commit'; tx.committedAt = new Date().toISOString(); tx.files = {}; (tx.journal ||= []).push({ state: 'committed', at: tx.committedAt });
        await managedWrite('transaction-' + txId, tx);
        const journal = await managedRead('transaction-journal', []); journal.push({ txId, updateId: tx.updateId, state: 'committed', at: tx.committedAt, signer: tx.signer }); await managedWrite('transaction-journal', journal.slice(-500));
        await Diagnostics.record('update', 'update-committed', { txId, updateId: tx.updateId });
        Events.emit('update:committed', { txId, updateId: tx.updateId });
        return { transactionId: txId, state: tx.state };
      } catch (error) {
        if (activationStarted) {
          await managedWrite('active-resource-packs', tx.previousRegistry);
          await managedWrite('config', tx.previousConfig);
          tx.state = 'activation-failed'; tx.error = String(error.message || error); tx.decision = 'commit-failed'; (tx.journal ||= []).push({ state: 'activation-failed', at: new Date().toISOString(), error: tx.error });
          await managedWrite('transaction-' + txId, tx);
          await Diagnostics.record('recovery', 'update-activation-failed', { txId, message: tx.error });
        }
        throw error;
      }
    },
    async rollback(txId) {
      if (!safeId(txId)) throw new Error('Invalid transaction ID.');
      const tx = await managedRead('transaction-' + txId, null);
      if (!tx) throw new Error('Transaction not found.');
      if (tx.state === 'awaiting-manual-decision') {
        tx.state = 'rolled-back'; tx.decision = 'rollback'; tx.rolledBackAt = new Date().toISOString(); tx.files = {}; (tx.journal ||= []).push({ state: 'rolled-back', at: tx.rolledBackAt });
        await managedWrite('transaction-' + txId, tx);
        await Diagnostics.record('update', 'staged-update-discarded', { txId, updateId: tx.updateId });
        return { transactionId: txId, state: tx.state };
      }
      if (tx.state !== 'committed') throw new Error('Only staged or committed transactions can be rolled back.');
      const activeNow = await managedRead('active-resource-packs', {});
      const configNow = await managedRead('config', { settings: {}, policies: {}, dependencies: {} });
      if (stable(activeNow) !== stable(tx.candidateRegistry) || stable(configNow) !== stable(tx.candidateConfig)) throw new Error('Rollback refused: a later update has superseded this transaction. Roll back newer updates first.');
      await managedWrite('active-resource-packs', tx.previousRegistry);
      await managedWrite('config', tx.previousConfig);
      tx.state = 'rolled-back'; tx.decision = 'rollback'; tx.rolledBackAt = new Date().toISOString(); (tx.journal ||= []).push({ state: 'rolled-back', at: tx.rolledBackAt });
      await managedWrite('transaction-' + txId, tx);
      await Diagnostics.record('recovery', 'committed-resource-pack-rolled-back', { txId, updateId: tx.updateId });
      Events.emit('update:rolled-back', { txId, updateId: tx.updateId });
      return { transactionId: txId, state: tx.state, note: 'Previously installed immutable pack files are retained for recovery; user records are not changed.' };
    }
  });

  const Repairs = global.LoadoutRepairEngineFactory
    ? global.LoadoutRepairEngineFactory({ managedRead, managedWrite, loadTrustStore, diagnostics: Diagnostics })
    : null;

  const Port = Object.freeze({
    async status() {
      const [developmentPort, nativeExtensions, cachedPackages, registry] = await Promise.all([
        Native.developmentPortStatus().catch(() => ({ available: false, enabled: false, networkListener: false, remoteExecution: false })),
        Native.nativeExtensionInventory().catch(() => ({ apiVersion: 1, extensions: [], dynamicDexJarLoading: false, nativeChangesRequireApk: true })),
        PackageCache.list().catch(() => []), Registry.status().catch(() => ({ offline: true, revision: 0, moduleCount: 0 }))
      ]);
      return {
        appId: APP_ID, runtime: VERSION, runtimeApi: RUNTIME_API, native: Native.available,
        secureCredentials: Secrets.available, updateDecision: 'manual',
        updatePolicy: 'owner-signed-data-transformations-only',
        repairPolicy: 'signed-declarative-ui-token-repairs-only',
        sourceRepairPolicy: 'host-side-hash-guarded-patches-require-apk-rebuild',
        ltlOperations: global.LoadoutLtlEngine?.operations || [], manualApproval: true,
        transactionJournal: true, executableHotLoading: false,
        remoteDevelopmentPort: false, developmentPort, nativeExtensions,
        cachedPackageCount: cachedPackages.length, registry, modules: global.LoadoutFeatureRuntime?.list?.() || []
      };
    },
    stageUpdate(pkg) { return Updates.stage(pkg); },
    commit(txId) { return Updates.commit(txId); },
    rollback(txId) { return Updates.rollback(txId); },
    inspect(txId) { return Updates.inspect(txId); },
    pending() { return Updates.pending(); },
    journal() { return Updates.journal(); },
    cachedPackages() { return PackageCache.list(); },
    readCachedPackage(updateId) { return PackageCache.read(updateId); },
    async stageCachedPackage(updateId) { const pkg = await PackageCache.read(updateId); return Updates.stage(pkg); },
    removeCachedPackage(updateId) { return PackageCache.remove(updateId); },
    async developmentInbox() { return Native.developmentPortPackages(); },
    async stageDevelopmentInboxPackage(name) {
      if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}\.(?:lupdate|lreg|lfix)$/.test(String(name || '')) || String(name).includes('..')) throw new Error('Invalid Development Port package filename.');
      const row = await Native.readDevelopmentPortPackage(name);
      const pkg = JSON.parse(row.packageText);
      if (String(name).toLowerCase().endsWith('.lreg')) return { ...await Registry.importSignedPackage(pkg), state: 'registry-imported', source: 'adb-usb-inbox', filename: row.name, bytes: row.bytes };
      if (String(name).toLowerCase().endsWith('.lfix')) {
        if (!Repairs) throw new Error('Visual Repair Port is unavailable in this runtime.');
        return { ...await Repairs.stage(pkg, 'adb-usb-inbox'), source: 'adb-usb-inbox', filename: row.name, bytes: row.bytes };
      }
      const staged = await Updates.stage(pkg);
      return { ...staged, source: 'adb-usb-inbox', filename: row.name, bytes: row.bytes };
    },
    repairs: Repairs ? Object.freeze({
      verify(pkg) { return Repairs.verify(pkg); },
      stage(pkg, source = 'local-file') { return Repairs.stage(pkg, source); },
      commit(repairId) { return Repairs.commit(repairId); },
      rollback(repairId) { return Repairs.rollback(repairId); },
      pending() { return Repairs.pending(); },
      journal() { return Repairs.journal(); },
      active() { return Repairs.active(); },
      recover() { return Repairs.recover(); },
      applyActive() { return Repairs.applyActive(); },
      scopes: Repairs.scopes, tokens: Repairs.tokens
    }) : null,
    importRegistryPackage(pkg) { return Registry.importSignedPackage(pkg); },
    registryStatus() { return Registry.status(); },
    resetRegistry() { return Registry.resetToBundled(); },
    async removeDevelopmentInboxPackage(name) { return Native.deleteDevelopmentPortPackage(name); },
    async inspectRuntime() {
      const status = await Port.status();
      return {
        status, modules: clone(global.LOADOUT_MODULE_REGISTRY || []),
        loadedModules: global.LoadoutFeatureRuntime?.list?.() || [],
        updateJournal: (await Updates.journal()).slice(-100),
        repairJournal: Repairs ? await Repairs.journal() : [], activeRepairs: Repairs ? await Repairs.active() : {},
        cachedPackages: await PackageCache.list(), registry: await Registry.status(), remoteListener: false, remoteExecution: false
      };
    }
  });

  const Loadout = Object.freeze({ version: VERSION, runtimeApi: RUNTIME_API, appId: APP_ID, native: Native, secrets: Secrets, aiTransport: AITransport, storage: Storage, diagnostics: Diagnostics, events: Events, updates: Updates, packageCache: PackageCache, registry: Registry, repairs: Port.repairs, port: Port });
  global.Loadout = Loadout;
  global.LoadoutReady = (async () => {
    const info = await Native.info().catch(() => ({ available: false }));
    const recovery = await Updates.recover().catch(async error => { await Diagnostics.record('error', 'update-startup-recovery-failed', { message: String(error.message || error) }); return { recovered: 0, error: String(error.message || error) }; });
    const repairRecovery = await Repairs?.recover?.().catch(async error => { await Diagnostics.record('error', 'repair-startup-recovery-failed', { message: String(error.message || error) }); return [{ error: String(error.message || error) }]; }) || [];
    await Diagnostics.record('info', 'runtime-ready', { runtime: VERSION, runtimeApi: RUNTIME_API, native: !!info.available, androidApi: info.androidApi || null, recoveredTransactions: recovery.recovered || 0, recoveredRepairs: repairRecovery.length });
    return { runtime: VERSION, native: !!info.available, recovery, repairRecovery };
  })();
})(window);
