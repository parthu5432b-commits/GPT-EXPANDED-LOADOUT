/* Loadout first-party feature runtime 1.5.0.
 * Owns stable route/module identity and lifecycle. Feature code is bundled with the APK;
 * this registry never evaluates executable update packages.
 */
(function (global) {
  'use strict';
  if (global.LoadoutFeatureRuntime) return;
  const modules = new Map();
  const routes = new Map();
  const declaredRows = Array.isArray(global.LOADOUT_MODULE_REGISTRY) ? global.LOADOUT_MODULE_REGISTRY : [];
  const declared = new Map(declaredRows.map(item => [item.id, item]));
  let active = null;
  let initialized = false;
  let context = null;

  function safeId(value) { return /^[a-z][a-z0-9.-]{2,95}$/.test(String(value || '')); }
  function register(module) {
    if (!module || !safeId(module.id) || !/^[0-9]+\.[0-9]+\.[0-9]+$/.test(String(module.version || ''))) {
      throw new Error('Feature module requires a stable ID and semantic version.');
    }
    if (module.runtimeApi !== '1.5.0') throw new Error(`Feature ${module.id} requires runtime API 1.5.0.`);
    if (typeof module.render !== 'function' || !safeId(module.route)) throw new Error(`Feature ${module.id} requires a route and render function.`);
    if (modules.has(module.id) || routes.has(module.route)) throw new Error(`Duplicate feature identity or route: ${module.id}/${module.route}.`);
    const declaration = declared.get(module.id);
    if (!declaration || declaration.status !== 'feature-module') throw new Error(`Feature ${module.id} is not declared as an installable bundled feature module.`);
    if (declaration.version !== module.version || declaration.runtimeApi !== module.runtimeApi || declaration.route !== module.route) {
      throw new Error(`Feature ${module.id} does not match its versioned module registry declaration.`);
    }
    if (!!declaration.offline !== (module.offline !== false)) throw new Error(`Feature ${module.id} has an offline capability mismatch.`);
    const provided = Object.keys(module.services || {}).sort();
    const expected = [...(declaration.services || [])].sort();
    if (provided.join('|') !== expected.join('|')) throw new Error(`Feature ${module.id} service contract does not match the module registry.`);
    const record = Object.freeze({
      id: module.id, name: String(module.name || module.id), version: module.version,
      runtimeApi: module.runtimeApi, route: module.route,
      dependencies: Object.freeze([...(module.dependencies || [])]),
      services: Object.freeze({ ...(module.services || {}) }),
      render: module.render, onActivate: module.onActivate || (() => {}), onDeactivate: module.onDeactivate || (() => {}),
      offline: module.offline !== false
    });
    modules.set(record.id, record);
    routes.set(record.route, record);
    return record;
  }
  function initialize(nextContext) {
    if (initialized) { context = nextContext || context; return list(); }
    if (!declaredRows.length) throw new Error('The first-party module registry was not loaded before feature registration.');
    for (const item of modules.values()) {
      for (const dependency of item.dependencies) if (!modules.has(dependency)) throw new Error(`Feature ${item.id} has missing dependency ${dependency}.`);
    }
    const required = declaredRows.filter(item => item.status === 'feature-module');
    for (const item of required) if (!modules.has(item.id)) throw new Error(`Declared feature module ${item.id} did not register during startup.`);
    for (const item of modules.values()) {
      const duplicateService = Object.keys(item.services).find(name => {
        let occurrences = 0;
        for (const candidate of modules.values()) if (Object.prototype.hasOwnProperty.call(candidate.services, name)) occurrences++;
        return occurrences > 1;
      });
      if (duplicateService) throw new Error(`Feature service is registered more than once: ${duplicateService}.`);
    }
    context = nextContext || {};
    initialized = true;
    return list();
  }
  function render(route, nextContext) {
    if (!initialized) initialize(nextContext);
    else if (nextContext) context = nextContext;
    const target = routes.get(String(route || ''));
    if (!target) return false;
    const ctx = context || {};
    if (active?.id !== target.id) {
      const previous = active;
      if (previous) previous.onDeactivate(ctx);
      active = null;
      try {
        target.onActivate(ctx);
        active = target;
      } catch (error) {
        if (previous) {
          try { previous.onActivate(ctx); active = previous; }
          catch (recoveryError) { error.recoveryError = recoveryError; }
        }
        throw error;
      }
    }
    target.render(ctx);
    return true;
  }
  function getService(name) {
    for (const item of modules.values()) if (Object.prototype.hasOwnProperty.call(item.services, name)) return item.services[name];
    return null;
  }
  function list() {
    return [...modules.values()].map(({ id, name, version, runtimeApi, route, dependencies, offline }) => ({ id, name, version, runtimeApi, route, dependencies: [...dependencies], offline, active: active?.id === id }));
  }
  global.LoadoutFeatureRuntime = Object.freeze({ version: '1.5.0', register, initialize, render, getService, list, get activeModule() { return active?.id || null; } });
})(window);
