/* Loadout visual repair engine 1.0.
 * Signed declarative UI-token repairs only. No CSS text, selectors, HTML or executable code is accepted.
 */
(function (global) {
  'use strict';
  if (global.LoadoutRepairEngineFactory) return;

  const APP_ID = 'app.loadout.jee';
  const RUNTIME_API = '1.5.0';
  const APP_VERSION = '1.8.0';
  const PREFIX = 'loadout.runtime.v2.';
  const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
  const MAX_FIXES = 48;
  const MAX_BYTES = 1024 * 1024;
  const scopes = Object.freeze({
    global: { route: null, tokens: ['main-horizontal-padding', 'main-max-width', 'font-scale', 'line-height'] },
    'loadout.command-center': { route: 'dashboard', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] },
    'loadout.chapter-map': { route: 'chapters', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] },
    'loadout.pyq-intelligence': { route: 'historical', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] },
    'loadout.test-ledger': { route: 'tests', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] },
    'loadout.forecast-engine': { route: 'forecasts', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] },
    'loadout.ai-coach': { route: 'chatbot', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'chat-panel-max-height', 'chat-input-min-height'] },
    'loadout.data-settings': { route: 'data', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] }
  });
  const rules = Object.freeze({
    'main-horizontal-padding': { type: 'px', min: 8, max: 56 }, 'main-max-width': { type: 'px', min: 900, max: 1900 },
    'grid-gap': { type: 'px', min: 4, max: 36 }, 'card-padding': { type: 'px', min: 8, max: 36 },
    'card-radius': { type: 'px', min: 6, max: 32 }, 'font-scale': { type: 'number', min: .88, max: 1.15 },
    'line-height': { type: 'number', min: 1.25, max: 1.85 }, 'table-min-width': { type: 'px', min: 280, max: 1200 },
    'table-overflow': { type: 'enum', values: ['auto', 'scroll', 'hidden'] },
    'modal-max-height': { type: 'vh', min: 45, max: 95 }, 'chat-panel-max-height': { type: 'vh', min: 35, max: 82 },
    'chat-input-min-height': { type: 'px', min: 44, max: 160 }
  });

  const clone = value => JSON.parse(JSON.stringify(value));
  const stable = value => {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
    return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stable(value[key])).join(',') + '}';
  };
  const bytes = value => new TextEncoder().encode(String(value));
  const fromBase64 = value => Uint8Array.from(global.atob(value), c => c.charCodeAt(0));
  const sha256 = async value => {
    const digest = await global.crypto.subtle.digest('SHA-256', bytes(value));
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
  };
  function versionAtLeast(actual, required) { const a=String(actual).split(/[.+-]/).slice(0,3).map(Number), b=String(required).split(/[.+-]/).slice(0,3).map(Number); if(a.length!==3||b.length!==3||[...a,...b].some(n=>!Number.isFinite(n)))return false; for(let i=0;i<3;i++){if(a[i]>b[i])return true;if(a[i]<b[i])return false;}return true; }
  function validate(pkg) {
    if (!pkg || typeof pkg !== 'object' || Array.isArray(pkg) || Object.keys(pkg).some(key => key !== 'manifest') || !pkg.manifest || typeof pkg.manifest !== 'object') throw new Error('Repair package must contain only a manifest object.');
    const m = pkg.manifest;
    if (m.formatVersion !== '1.0' || m.kind !== 'ui-repair' || m.target?.appId !== APP_ID || m.target?.runtimeApi !== RUNTIME_API) throw new Error('Unsupported repair format, app identity or runtime API.');
    if (!SAFE_ID.test(String(m.repairId || '')) || typeof m.title !== 'string' || !m.title.trim() || m.title.length > 120 || typeof m.description !== 'string' || m.description.length > 1200 || !Number.isFinite(Date.parse(m.createdAt || ''))) throw new Error('Repair manifest metadata is invalid.');
    if (m.target.minimumAppVersion && !versionAtLeast(APP_VERSION, m.target.minimumAppVersion)) throw new Error(`Repair requires app version ${m.target.minimumAppVersion}; installed ${APP_VERSION}.`);
    if (m.target.screenshotId !== undefined && (typeof m.target.screenshotId !== 'string' || m.target.screenshotId.length > 96)) throw new Error('Invalid screenshot reference. A screenshot must not be embedded in a repair package.');
    if (Object.keys(m).some(key => !['formatVersion', 'kind', 'repairId', 'title', 'description', 'createdAt', 'sourceBuild', 'target', 'fixes', 'signature'].includes(key))) throw new Error('Repair manifest contains an unsupported field.');
    if (Object.keys(m.target).some(key => !['appId', 'runtimeApi', 'minimumAppVersion', 'screenshotId'].includes(key))) throw new Error('Repair target contains an unsupported field.');
    if (Object.keys(m).some(key => !['formatVersion','kind','repairId','title','description','createdAt','sourceBuild','target','fixes','signature'].includes(key))) throw new Error('Repair manifest contains an unsupported field.');
    if (m.sourceBuild !== undefined && (typeof m.sourceBuild !== 'string' || m.sourceBuild.length > 80)) throw new Error('Invalid source build metadata.');
    if (!Array.isArray(m.fixes) || m.fixes.length < 1 || m.fixes.length > MAX_FIXES) throw new Error(`Repair must contain 1–${MAX_FIXES} fixes.`);
    const ids = new Set();
    for (const fix of m.fixes) {
      if (!fix || typeof fix !== 'object' || Array.isArray(fix) || Object.keys(fix).some(key => !['id', 'op', 'scope', 'token', 'value', 'reason'].includes(key))) throw new Error('Repair fix has an invalid shape.');
      if (!SAFE_ID.test(String(fix.id || '')) || ids.has(fix.id)) throw new Error('Repair fix IDs must be unique safe identifiers.');
      ids.add(fix.id);
      const scope = scopes[fix.scope];
      if (fix.op !== 'SET_UI_TOKEN' || !scope || !scope.tokens.includes(fix.token)) throw new Error(`Unsupported repair target or token: ${fix.scope}/${fix.token}.`);
      const rule = rules[fix.token];
      if (rule.type === 'enum') {
        if (typeof fix.value !== 'string' || !rule.values.includes(fix.value)) throw new Error(`Invalid value for ${fix.token}.`);
      } else if (rule.type === 'number') {
        if (typeof fix.value !== 'number' || !Number.isFinite(fix.value) || fix.value < rule.min || fix.value > rule.max) throw new Error(`${fix.token} is outside its safe numeric range.`);
      } else {
        const suffix = rule.type;
        if (typeof fix.value !== 'string' || !(new RegExp('^(?:\\d+(?:\\.\\d+)?)' + suffix + '$')).test(fix.value)) throw new Error(`${fix.token} must be a bounded ${suffix} value.`);
        const n = Number.parseFloat(fix.value);
        if (n < rule.min || n > rule.max) throw new Error(`${fix.token} is outside its safe ${suffix} range.`);
      }
      if (fix.reason !== undefined && (typeof fix.reason !== 'string' || fix.reason.length > 300)) throw new Error('Repair reason must be short text.');
    }
    if (bytes(JSON.stringify(pkg)).length > MAX_BYTES) throw new Error('Repair package exceeds 1 MiB.');
    return { repairId: m.repairId, title: m.title, description: m.description, fixCount: m.fixes.length, signer: m.signature?.keyId || 'unverified' };
  }

  function cssName(token) { return '--loadout-repair-' + token; }
  function applyToDocument(active) {
    if (!global.document?.documentElement) return { applied: 0, deferred: true };
    const allTokens = Object.keys(rules);
    for (const element of [global.document.documentElement, ...Object.values(scopes).map(scope => scope.route && global.document.getElementById('view-' + scope.route)).filter(Boolean)]) {
      for (const token of allTokens) element.style.removeProperty(cssName(token));
    }
    let applied = 0;
    for (const [scopeId, values] of Object.entries(active || {})) {
      const scope = scopes[scopeId]; if (!scope) continue;
      const element = scope.route ? global.document.getElementById('view-' + scope.route) : global.document.documentElement;
      if (!element) continue;
      for (const [token, value] of Object.entries(values || {})) {
        if (!scope.tokens.includes(token)) continue;
        element.style.setProperty(cssName(token), String(value)); applied++;
      }
    }
    return { applied, deferred: false };
  }

  global.LoadoutRepairEngineFactory = function createLoadoutRepairEngine({ managedRead, managedWrite, loadTrustStore, diagnostics }) {
    const indexKey = 'repair-transaction-index';
    const activeKey = 'active-ui-repairs';
    async function verify(pkg) {
      const metadata = validate(pkg), m = pkg.manifest, sig = m.signature;
      if (!sig || sig.algorithm !== 'Ed25519' || typeof sig.keyId !== 'string' || !SAFE_ID.test(sig.keyId) || typeof sig.value !== 'string' || !/^[A-Za-z0-9+/]{86}==$/.test(sig.value)) throw new Error('Repair package is unsigned or uses an unsupported signature.');
      const trust = await loadTrustStore();
      const key = trust.keys.find(k => k.keyId === sig.keyId && k.algorithm === 'Ed25519' && typeof k.publicKey === 'string' && !k.revokedAt && k.status !== 'revoked');
      if (!key) throw new Error('Repair signer is not trusted or has been revoked by this installed build: ' + sig.keyId);
      if (!global.crypto?.subtle) throw new Error('WebCrypto signature verification unavailable; repair rejected.');
      let imported;
      try { const raw = fromBase64(key.publicKey); if (raw.length !== 32) throw new Error('Invalid key length.'); imported = await global.crypto.subtle.importKey('raw', raw, { name: 'Ed25519' }, false, ['verify']); }
      catch (_) { throw new Error('This Android WebView cannot verify Ed25519 signatures. Repair rejected safely.'); }
      const manifest = clone(m); delete manifest.signature;
      const payload = 'LOADOUT-LFIX-1.0\n' + stable(manifest);
      const valid = await global.crypto.subtle.verify({ name: 'Ed25519' }, imported, fromBase64(sig.value), bytes(payload));
      if (!valid) throw new Error('Repair Ed25519 signature verification failed.');
      return { ...metadata, signer: sig.keyId };
    }
    async function index() { const value = await managedRead(indexKey, []); if (!Array.isArray(value)) throw new Error('Repair transaction index is corrupt.'); return value; }
    async function stage(pkg, source = 'local-file') {
      const verification = await verify(pkg), m = pkg.manifest;
      const rows = await index();
      const existing = rows.find(row => row.repairId === m.repairId);
      const digest = await sha256(stable(pkg));
      if (existing) {
        const old = await managedRead('repair-transaction-' + m.repairId, null);
        if (old?.digest !== digest) throw new Error('A different package already uses this immutable repair ID.');
        throw new Error('This exact repair package has already been staged or completed.');
      }
      const previousActive = await managedRead(activeKey, {});
      const candidateActive = clone(previousActive);
      for (const fix of m.fixes) {
        candidateActive[fix.scope] ||= {};
        candidateActive[fix.scope][fix.token] = fix.value;
      }
      const tx = { repairId: m.repairId, title: m.title, description: m.description, signer: verification.signer, digest, source, fixes: clone(m.fixes), previousActive, candidateActive, state: 'awaiting-manual-decision', createdAt: new Date().toISOString(), journal: [{ state: 'staged', at: new Date().toISOString(), source }] };
      await managedWrite('repair-transaction-' + m.repairId, tx);
      rows.push({ repairId: m.repairId, title: m.title, state: tx.state, createdAt: tx.createdAt, signer: tx.signer, fixCount: m.fixes.length, digest });
      await managedWrite(indexKey, rows.slice(-200));
      await diagnostics?.record?.('update', 'ui-repair-staged', { repairId: m.repairId, fixCount: m.fixes.length, signer: tx.signer, source });
      return { repairId: m.repairId, state: tx.state, signer: tx.signer, fixCount: m.fixes.length, impact: m.fixes.map(({ scope, token, reason }) => ({ scope, token, reason: reason || '' })) };
    }
    async function readTx(id) {
      if (!SAFE_ID.test(String(id || ''))) throw new Error('Invalid repair ID.');
      const tx = await managedRead('repair-transaction-' + id, null);
      if (!tx || tx.repairId !== id) throw new Error('Repair transaction not found.');
      return tx;
    }
    async function commit(id) {
      const tx = await readTx(id);
      if (tx.state !== 'awaiting-manual-decision') throw new Error('Only a staged repair can be committed.');
      const active = await managedRead(activeKey, {});
      if (stable(active) !== stable(tx.previousActive)) throw new Error('A newer UI repair was committed after this package was staged. Re-stage against the current active repair state.');
      tx.state = 'activating';
      tx.activationStartedAt = new Date().toISOString();
      tx.journal.push({ state: 'activating', at: tx.activationStartedAt, approvedByOwner: true });
      await managedWrite('repair-transaction-' + id, tx);
      try {
        await managedWrite(activeKey, tx.candidateActive);
        const check = await managedRead(activeKey, {});
        if (stable(check) !== stable(tx.candidateActive)) throw new Error('Active repair read-back failed.');
        const applied = applyToDocument(check);
        tx.state = 'committed'; tx.committedAt = new Date().toISOString(); tx.journal.push({ state: 'committed', at: tx.committedAt, applied: applied.applied });
        await managedWrite('repair-transaction-' + id, tx);
        await diagnostics?.record?.('update', 'ui-repair-committed', { repairId: id, applied: applied.applied });
        return { repairId: id, state: tx.state, applied: applied.applied };
      } catch (error) {
        await managedWrite(activeKey, tx.previousActive);
        applyToDocument(tx.previousActive);
        tx.state = 'activation-failed'; tx.activationError = String(error.message || error).slice(0, 300); tx.failedAt = new Date().toISOString();
        tx.journal.push({ state: 'activation-failed', at: tx.failedAt, reason: tx.activationError });
        await managedWrite('repair-transaction-' + id, tx);
        await diagnostics?.record?.('error', 'ui-repair-activation-failed', { repairId: id, message: tx.activationError });
        throw new Error(`Visual repair activation failed; previous UI tokens were restored. ${error.message}`);
      }
    }
    async function rollback(id) {
      const tx = await readTx(id);
      if (tx.state === 'awaiting-manual-decision') {
        tx.state = 'rolled-back'; tx.rolledBackAt = new Date().toISOString(); tx.journal.push({ state: 'rolled-back', at: tx.rolledBackAt, reason: 'owner-rejected-before-activation' });
        await managedWrite('repair-transaction-' + id, tx);
        await diagnostics?.record?.('recovery', 'ui-repair-rejected', { repairId: id });
        return { repairId: id, state: tx.state };
      }
      if (tx.state !== 'committed') throw new Error('Only a staged or committed repair can be rolled back.');
      const active = await managedRead(activeKey, {});
      if (stable(active) !== stable(tx.candidateActive)) throw new Error('Rollback refused: a later UI repair changed the active repair set. Roll back newer repairs first.');
      tx.state = 'rolling-back'; tx.rollbackStartedAt = new Date().toISOString();
      tx.journal.push({ state: 'rolling-back', at: tx.rollbackStartedAt, approvedByOwner: true });
      await managedWrite('repair-transaction-' + id, tx);
      try {
        await managedWrite(activeKey, tx.previousActive);
        const check = await managedRead(activeKey, {});
        if (stable(check) !== stable(tx.previousActive)) throw new Error('Repair rollback read-back failed.');
        const applied = applyToDocument(check);
        tx.state = 'rolled-back'; tx.rolledBackAt = new Date().toISOString(); tx.journal.push({ state: 'rolled-back', at: tx.rolledBackAt, applied: applied.applied });
        await managedWrite('repair-transaction-' + id, tx);
        await diagnostics?.record?.('recovery', 'ui-repair-rolled-back', { repairId: id, applied: applied.applied });
        return { repairId: id, state: tx.state, applied: applied.applied };
      } catch (error) {
        await managedWrite(activeKey, tx.candidateActive);
        applyToDocument(tx.candidateActive);
        tx.state = 'rollback-failed'; tx.rollbackError = String(error.message || error).slice(0, 300); tx.failedAt = new Date().toISOString();
        tx.journal.push({ state: 'rollback-failed', at: tx.failedAt, reason: tx.rollbackError });
        await managedWrite('repair-transaction-' + id, tx);
        await diagnostics?.record?.('error', 'ui-repair-rollback-failed', { repairId: id, message: tx.rollbackError });
        throw new Error(`Visual repair rollback failed; the previously committed repair was restored. ${error.message}`);
      }
    }
    async function recover() {
      const rows = await index();
      const results = [];
      let active = await managedRead(activeKey, {});
      for (const row of rows) {
        const tx = await managedRead('repair-transaction-' + row.repairId, null);
        if (!tx || tx.repairId !== row.repairId) continue;
        if (tx.state === 'activating') {
          if (stable(active) === stable(tx.candidateActive)) {
            applyToDocument(active);
            tx.state = 'committed'; tx.committedAt = new Date().toISOString();
            tx.journal.push({ state: 'committed', at: tx.committedAt, recovered: true });
            results.push({ repairId: tx.repairId, recovered: 'commit' });
          } else {
            await managedWrite(activeKey, tx.previousActive); active = clone(tx.previousActive); applyToDocument(active);
            tx.state = 'activation-failed'; tx.failedAt = new Date().toISOString(); tx.activationError = 'Process stopped before the candidate active-token record was verified.';
            tx.journal.push({ state: 'activation-failed', at: tx.failedAt, recovered: true });
            results.push({ repairId: tx.repairId, recovered: 'restore-previous' });
          }
          await managedWrite('repair-transaction-' + tx.repairId, tx);
        } else if (tx.state === 'rolling-back') {
          if (stable(active) !== stable(tx.previousActive)) { await managedWrite(activeKey, tx.previousActive); active = clone(tx.previousActive); }
          applyToDocument(active);
          tx.state = 'rolled-back'; tx.rolledBackAt = new Date().toISOString(); tx.journal.push({ state: 'rolled-back', at: tx.rolledBackAt, recovered: true });
          await managedWrite('repair-transaction-' + tx.repairId, tx);
          results.push({ repairId: tx.repairId, recovered: 'rollback' });
        }
      }
      if (results.length) await diagnostics?.record?.('recovery', 'ui-repair-activation-recovered', { count: results.length, results });
      return results;
    }
    async function pending() {
      const rows = await index(), result = [];
      for (const row of rows) { const tx = await managedRead('repair-transaction-' + row.repairId, null); if (tx?.state === 'awaiting-manual-decision') result.push({ repairId: tx.repairId, title: tx.title, description: tx.description, signer: tx.signer, createdAt: tx.createdAt, fixCount: tx.fixes?.length || 0, fixes: clone(tx.fixes) }); }
      return result;
    }
    async function journal() {
      const rows = await index(), result = [];
      for (const row of rows) { const tx = await managedRead('repair-transaction-' + row.repairId, null); if (tx) result.push({ repairId: tx.repairId, title: tx.title, state: tx.state, signer: tx.signer, createdAt: tx.createdAt, committedAt: tx.committedAt || null, rolledBackAt: tx.rolledBackAt || null, fixCount: tx.fixes?.length || 0 }); }
      return result;
    }
    async function applyActive() { await recover(); const active = await managedRead(activeKey, {}); return applyToDocument(active); }
    async function active() { return clone(await managedRead(activeKey, {})); }
    return Object.freeze({ verify, stage, commit, rollback, pending, journal, recover, applyActive, active, scopes: clone(scopes), tokens: Object.keys(rules) });
  };
})(window);
