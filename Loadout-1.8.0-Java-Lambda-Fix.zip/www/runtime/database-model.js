/* Pure structured-database migration model. No I/O, DOM or native bridge access. */
(function (global) {
  'use strict';
  if (global.LoadoutDatabaseModel) return;
  const MAX_STATE_BYTES = 24 * 1024 * 1024;
  const MAX_RECORD_ROWS = 19990;

  function validateState(state) {
    if (!state || typeof state !== 'object' || Array.isArray(state) || !state.settings || typeof state.settings !== 'object' || !Array.isArray(state.attempts) || !Array.isArray(state.forecasts)) {
      throw new Error('Study state does not match the supported legacy schema. Database migration refused.');
    }
    const ids = new Set();
    for (const [index, attempt] of state.attempts.entries()) {
      if (!attempt || typeof attempt !== 'object' || !String(attempt.id || '').trim()) throw new Error(`Attempt ${index + 1} has no stable record ID.`);
      if (ids.has(String(attempt.id))) throw new Error(`Duplicate attempt record ID: ${attempt.id}.`);
      ids.add(String(attempt.id));
      for (const key of ['n', 'correct', 'wrong', 'unattempted']) {
        if (attempt[key] != null && (!Number.isInteger(Number(attempt[key])) || Number(attempt[key]) < 0)) throw new Error(`Attempt ${attempt.id} has invalid ${key}.`);
      }
      if (attempt.n != null && [attempt.correct, attempt.wrong, attempt.unattempted].every(value => value != null) && Number(attempt.correct) + Number(attempt.wrong) + Number(attempt.unattempted) !== Number(attempt.n)) {
        throw new Error(`Attempt ${attempt.id} violates C + W + U = N.`);
      }
    }
    const forecastIds = new Set();
    for (const [index, forecast] of state.forecasts.entries()) {
      if (!forecast || typeof forecast !== 'object' || !String(forecast.id || '').trim()) throw new Error(`Forecast ${index + 1} has no stable record ID.`);
      if (forecastIds.has(String(forecast.id))) throw new Error(`Duplicate forecast ID: ${forecast.id}.`);
      forecastIds.add(String(forecast.id));
    }
    if (state.attempts.length + state.forecasts.length > MAX_RECORD_ROWS) throw new Error(`Study state exceeds the safe atomic batch limit of ${MAX_RECORD_ROWS} structured records.`);
    const payloadJson = JSON.stringify(state);
    if (new TextEncoder().encode(payloadJson).length > MAX_STATE_BYTES) throw new Error('Study state exceeds the database migration size limit.');
    return {
      state: JSON.parse(payloadJson), payloadJson,
      attemptCount: state.attempts.length,
      forecastCount: state.forecasts.length
    };
  }

  function attemptRow(attempt, sourceKind, now) {
    return {
      id: String(attempt.id), test_id: String(attempt.testId || ''), date: attempt.date || null,
      type: String(attempt.type || 'OTHER'), score: attempt.score == null ? null : Number(attempt.score),
      n: attempt.n == null ? null : Number(attempt.n), correct: attempt.correct == null ? null : Number(attempt.correct),
      wrong: attempt.wrong == null ? null : Number(attempt.wrong),
      unattempted: attempt.unattempted == null ? null : Number(attempt.unattempted),
      minutes: attempt.minutes == null ? null : Number(attempt.minutes), payload_json: JSON.stringify(attempt),
      created_at: String(attempt.createdAt || now), source_kind: sourceKind
    };
  }

  function forecastRow(forecast, sourceKind, now) {
    return {
      id: String(forecast.id), test_id: String(forecast.testId || ''), type: String(forecast.type || 'OTHER'),
      date: forecast.date || null, raw_score: forecast.raw == null ? null : Number(forecast.raw),
      calibrated_score: forecast.calibrated == null ? null : Number(forecast.calibrated),
      payload_json: JSON.stringify(forecast), created_at: String(forecast.savedOn || now), source_kind: sourceKind
    };
  }

  global.LoadoutDatabaseModel = Object.freeze({
    maxStateBytes: MAX_STATE_BYTES,
    maxRecordRows: MAX_RECORD_ROWS,
    validateState,
    attemptRow,
    forecastRow
  });
})(window);
