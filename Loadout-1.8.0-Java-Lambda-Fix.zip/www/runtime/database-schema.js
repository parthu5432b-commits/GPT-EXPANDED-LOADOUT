/* Versioned Loadout database schema. The same migration manifest drives Android SQLite
 * and browser IndexedDB. Migrations are additive; legacy localStorage is never dropped.
 */
(function (global) {
  'use strict';
  if (global.LoadoutDatabaseSchema) return;
  const migrations = [
    {
      version: 1,
      id: 'core-records-v1',
      statements: [
        'CREATE TABLE app_state (state_key TEXT PRIMARY KEY NOT NULL, schema_version INTEGER NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL, updated_at TEXT NOT NULL)',
        'CREATE TABLE test_attempts (id TEXT PRIMARY KEY NOT NULL, test_id TEXT NOT NULL, date TEXT, type TEXT NOT NULL, score REAL, n INTEGER, correct INTEGER, wrong INTEGER, unattempted INTEGER, minutes REAL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL)',
        'CREATE TABLE forecasts (id TEXT PRIMARY KEY NOT NULL, test_id TEXT NOT NULL, type TEXT NOT NULL, date TEXT, raw_score REAL, calibrated_score REAL, payload_json TEXT NOT NULL, created_at TEXT NOT NULL)',
        'CREATE TABLE module_records (module_id TEXT NOT NULL, record_key TEXT NOT NULL, schema_version INTEGER NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY (module_id, record_key))',
        'CREATE TABLE legacy_imports (source_key TEXT PRIMARY KEY NOT NULL, source_sha256 TEXT NOT NULL, record_count INTEGER NOT NULL, imported_at TEXT NOT NULL)'
      ]
    },
    {
      version: 2,
      id: 'recovery-and-indexes-v2',
      statements: [
        "ALTER TABLE app_state ADD COLUMN revision INTEGER NOT NULL DEFAULT 1",
        "ALTER TABLE app_state ADD COLUMN source_kind TEXT NOT NULL DEFAULT 'legacy-migration'",
        "ALTER TABLE test_attempts ADD COLUMN source_kind TEXT NOT NULL DEFAULT 'legacy-migration'",
        "ALTER TABLE forecasts ADD COLUMN source_kind TEXT NOT NULL DEFAULT 'legacy-migration'",
        'CREATE TABLE recovery_snapshots (id TEXT PRIMARY KEY NOT NULL, source_key TEXT NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL, created_at TEXT NOT NULL, reason TEXT NOT NULL)',
        'CREATE TABLE migration_conflicts (id TEXT PRIMARY KEY NOT NULL, record_key TEXT NOT NULL, local_sha256 TEXT NOT NULL, database_sha256 TEXT NOT NULL, created_at TEXT NOT NULL, resolution TEXT NOT NULL)',
        'CREATE INDEX idx_test_attempts_date ON test_attempts(date)',
        'CREATE INDEX idx_test_attempts_type_date ON test_attempts(type, date)',
        'CREATE INDEX idx_forecasts_test_type ON forecasts(test_id, type)',
        'CREATE INDEX idx_module_records_updated ON module_records(updated_at)'
      ]
    }
  ];
  global.LoadoutDatabaseSchema = Object.freeze({ name: 'loadout-main', version: 2, migrations: Object.freeze(migrations.map(item => Object.freeze({ ...item, statements: Object.freeze(item.statements.slice()) }))) });
})(window);
