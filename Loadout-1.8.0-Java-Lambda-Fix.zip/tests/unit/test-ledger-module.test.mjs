import test from 'node:test';
import assert from 'node:assert/strict';
import '../support/load-browser-global.mjs';
import '../../www/modules/test-ledger.js';

const ledger = globalThis.LoadoutModules.testLedger;

test('Test Ledger module is registered with its stable identity', () => {
  assert.equal(ledger.id, 'loadout.test-ledger');
  assert.equal(ledger.version, '1.2.0');
});

test('validates C/W/U totals and non-negative integer counts', () => {
  assert.deepEqual(ledger.validateCounts({ n: 5, correct: 2, wrong: 1, unattempted: 2 }), { n: 5, correct: 2, wrong: 1, unattempted: 2 });
  assert.throws(() => ledger.validateCounts({ n: 5, correct: 2, wrong: 2, unattempted: 2 }), /must equal/);
  assert.throws(() => ledger.validateCounts({ n: 5, correct: -1, wrong: 1, unattempted: 5 }), /non-negative integer/);
});

test('creates a canonical test record using the existing configured scoring convention', () => {
  const attempt = ledger.createAttempt({ testId: 'QCT-23', date: '2026-11-18', type: 'QCT', n: 5, correct: 3, wrong: 1, unattempted: 1, minutes: 25 }, { correctMarks: 4, wrongMarks: -1 }, []);
  assert.equal(attempt.score, 11);
  assert.equal(attempt.maxMarks, 20);
  assert.equal(attempt.unattempted, 1);
});

test('rejects duplicate completed test IDs case-insensitively', () => {
  assert.throws(() => ledger.createAttempt({ testId: 'qct-1', n: 1, correct: 1, wrong: 0, unattempted: 0 }, { correctMarks: 4, wrongMarks: -1 }, [{ testId: 'QCT-1', score: 4 }]), /already exists/);
});

test('rejects missing IDs and invalid scoring settings', () => {
  assert.throws(() => ledger.createAttempt({ n: 1, correct: 1, wrong: 0, unattempted: 0 }, { correctMarks: 4, wrongMarks: -1 }, []), /test ID/);
  assert.throws(() => ledger.createAttempt({ testId: 'X', n: 1, correct: 1, wrong: 0, unattempted: 0 }, { correctMarks: NaN, wrongMarks: -1 }, []), /settings/);
});

test('removes only the requested attempt and reports missing IDs', () => {
  const records = [{ id: 'a' }, { id: 'b' }];
  const result = ledger.removeAttempt(records, 'a');
  assert.equal(result.removed, true);
  assert.deepEqual(result.attempts, [{ id: 'b' }]);
  assert.deepEqual(records, [{ id: 'a' }, { id: 'b' }]);
  assert.equal(ledger.removeAttempt(records, 'missing').removed, false);
});
