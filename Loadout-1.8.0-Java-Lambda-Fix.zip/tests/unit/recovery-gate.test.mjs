import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../../www/runtime/recovery-gate.js', import.meta.url), 'utf8');
function createGate() {
  const sandbox = { window: {} };
  vm.runInNewContext(source, sandbox, { filename: 'recovery-gate.js' });
  return sandbox.window.LoadoutRecoveryGate.create();
}

test('recovery gate blocks writes until explicit acknowledgement and preserves exact original bytes', () => {
  const gate = createGate();
  const original = '{ "broken" : "raw-bytes\n" }';
  assert.equal(gate.status().blocked, false);
  gate.block(original, 'Private archive verification failed');
  assert.equal(gate.status().blocked, true);
  assert.equal(gate.status().hasOriginal, true);
  assert.equal(gate.originalText(), original);
  const declined = gate.resume(false);
  assert.equal(declined.resumed, false);
  assert.equal(gate.status().blocked, true);
  assert.equal(gate.originalText(), original);
  const accepted = gate.resume(true);
  assert.equal(accepted.resumed, true);
  assert.equal(accepted.original, original);
  assert.equal(gate.status().blocked, false);
  assert.equal(gate.originalText(), null);
});

test('recovery gate can pause writes when original bytes cannot be safely read', () => {
  const gate = createGate();
  gate.block(null, 'Local read failed');
  assert.deepEqual({ ...gate.status() }, { blocked: true, hasOriginal: false, reason: 'Local read failed' });
  assert.equal(gate.resume(false).resumed, false);
  assert.equal(gate.status().blocked, true);
  assert.equal(gate.resume(true).resumed, true);
  assert.equal(gate.status().blocked, false);
});
