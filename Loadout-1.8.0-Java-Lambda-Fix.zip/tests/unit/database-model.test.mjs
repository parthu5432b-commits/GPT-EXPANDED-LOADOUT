import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
function loadDatabaseModel() {
  const sandbox = { TextEncoder };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const relative of ['www/runtime/database-schema.js', 'www/runtime/database-model.js']) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, relative), 'utf8'), sandbox, { filename: relative });
  }
  return sandbox;
}

const sample = () => ({
  settings: { correctMarks: 4, wrongMarks: -1 },
  attempts: [{ id: 'attempt-1', testId: 'QFT-01', date: '2026-11-18', type: 'QFT', score: 11, n: 4, correct: 3, wrong: 1, unattempted: 0, minutes: 30 }],
  forecasts: [{ id: 'forecast-1', testId: 'QFT-01', type: 'QFT', raw: 10, calibrated: 11 }]
});

test('schema migration manifest is sequential, immutable and adds recovery/index structures', () => {
  const app = loadDatabaseModel();
  const schema = app.LoadoutDatabaseSchema;
  assert.equal(schema.version, 2);
  assert.deepEqual(Array.from(schema.migrations, migration => migration.version), [1, 2]);
  assert.ok(schema.migrations[0].statements.some(sql => sql.startsWith('CREATE TABLE app_state')));
  assert.ok(schema.migrations[1].statements.some(sql => sql.startsWith('CREATE TABLE recovery_snapshots')));
  assert.ok(schema.migrations[1].statements.some(sql => sql.startsWith('CREATE INDEX idx_test_attempts_date')));
  assert.ok(Object.isFrozen(schema.migrations));
});

test('validates canonical legacy state and counts without mutating its source', () => {
  const app = loadDatabaseModel();
  const state = sample();
  const before = JSON.stringify(state);
  const result = app.LoadoutDatabaseModel.validateState(state);
  assert.equal(result.attemptCount, 1);
  assert.equal(result.forecastCount, 1);
  assert.equal(result.payloadJson, before);
  assert.notEqual(result.state, state);
  assert.equal(JSON.stringify(state), before);
});

test('rejects malformed state, duplicate IDs and inconsistent question accounting', () => {
  const app = loadDatabaseModel();
  const model = app.LoadoutDatabaseModel;
  assert.throws(() => model.validateState({ settings: {}, attempts: {}, forecasts: [] }), /legacy schema/);
  const duplicate = sample(); duplicate.attempts.push({ ...duplicate.attempts[0] });
  assert.throws(() => model.validateState(duplicate), /Duplicate attempt/);
  const invalid = sample(); invalid.attempts[0].wrong = 2;
  assert.throws(() => model.validateState(invalid), /C \+ W \+ U = N/);
  const forecastDuplicate = sample(); forecastDuplicate.forecasts.push({ ...forecastDuplicate.forecasts[0] });
  assert.throws(() => model.validateState(forecastDuplicate), /Duplicate forecast/);
});

test('enforces the atomic row limit and maps canonical records to indexed rows', () => {
  const app = loadDatabaseModel();
  const model = app.LoadoutDatabaseModel;
  const large = { settings: {}, attempts: [], forecasts: [] };
  for (let i = 0; i <= model.maxRecordRows; i++) large.attempts.push({ id: `a-${i}` });
  assert.throws(() => model.validateState(large), /atomic batch limit/);
  const state = sample();
  const attempt = model.attemptRow(state.attempts[0], 'migration-test', '2026-11-18T00:00:00.000Z');
  const forecast = model.forecastRow(state.forecasts[0], 'migration-test', '2026-11-18T00:00:00.000Z');
  assert.equal(attempt.test_id, 'QFT-01');
  assert.equal(attempt.source_kind, 'migration-test');
  assert.equal(JSON.parse(attempt.payload_json).id, 'attempt-1');
  assert.equal(forecast.raw_score, 10);
  assert.equal(forecast.calibrated_score, 11);
});

test('database runtime refuses to load if the schema or pure data model is absent', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/runtime/database.js'), 'utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  assert.throws(() => vm.runInContext(source, sandbox), /schema\/model was not loaded/);
});
