import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { registrySigningPayload, validateRegistryPackage, verifySignedRegistryPackage } from '../../src/core/private-registry.js';
import { stableStringify, sha256 } from '../../src/core/ltl.js';

const installed = JSON.parse(fs.readFileSync('modules/registry.json', 'utf8'));
const sourceCatalog = JSON.parse(fs.readFileSync('registry/catalog.json', 'utf8'));
function fixture() {
  const catalog = structuredClone(sourceCatalog);
  catalog.revision = 2;
  delete catalog.catalogSha256;
  catalog.catalogSha256 = sha256(stableStringify(catalog));
  const pair = crypto.generateKeyPairSync('ed25519');
  const der = pair.publicKey.export({ format: 'der', type: 'spki' });
  const raw = der.subarray(der.length - 32);
  const keyId = sha256(der).slice(0, 20);
  const pkg = { manifest: { formatVersion: '1.0', kind: 'module-registry', registryId: catalog.registryId, revision: 2, createdAt: new Date().toISOString(), target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0' } }, catalog };
  pkg.manifest.signature = { algorithm: 'Ed25519', keyId, value: crypto.sign(null, Buffer.from(registrySigningPayload(pkg)), pair.privateKey).toString('base64') };
  const trust = { schemaVersion: 1, algorithm: 'Ed25519', keys: [{ keyId, algorithm: 'Ed25519', publicKey: raw.toString('base64') }] };
  return { pkg, trust, keyId };
}

test('bundled private catalog hashes and mirrors the seven APK modules', () => {
  const catalog = sourceCatalog;
  const copy = structuredClone(catalog); const expected = copy.catalogSha256; delete copy.catalogSha256;
  assert.equal(sha256(stableStringify(copy)), expected);
  assert.equal(catalog.modules.length, installed.modules.length);
  for (const item of catalog.modules) {
    const row = installed.modules.find(entry => entry.id === item.id);
    assert.ok(row);
    assert.equal(row.version, item.version);
    assert.equal(row.entry, item.entry);
    assert.equal(row.route, item.route);
    assert.equal(item.manifestSha256.length, 64);
    assert.equal(item.entrySha256.length, 64);
  }
});

test('validates a registry package without permitting executable module changes', () => {
  const { pkg, trust, keyId } = fixture();
  const valid = validateRegistryPackage(pkg, installed);
  assert.equal(valid.valid, true);
  assert.equal(valid.moduleCount, 7);
  assert.equal(verifySignedRegistryPackage(pkg, trust, { installedRegistry: installed }).signer, keyId);
  const mismatch = structuredClone(pkg); mismatch.catalog.modules[0].version = '99.0.0';
  const copy = structuredClone(mismatch.catalog); delete copy.catalogSha256; mismatch.catalog.catalogSha256 = sha256(stableStringify(copy));
  assert.throws(() => validateRegistryPackage(mismatch, installed), /disagrees with APK-bundled/);
  const badDependency = structuredClone(pkg); badDependency.catalog.modules[0].dependencies = [{ id: 'loadout.missing', version: '1.0.0' }];
  const depCopy = structuredClone(badDependency.catalog); delete depCopy.catalogSha256; badDependency.catalog.catalogSha256 = sha256(stableStringify(depCopy));
  assert.throws(() => validateRegistryPackage(badDependency, installed), /dependency declaration mismatch/);
});

test('rejects untrusted, revoked, tampered, and non-first-party registry packages', () => {
  const { pkg, trust, keyId } = fixture();
  assert.throws(() => verifySignedRegistryPackage(pkg, { keys: [] }, { installedRegistry: installed }), /not trusted/);
  const revoked = structuredClone(trust); revoked.keys[0].status = 'revoked';
  assert.throws(() => verifySignedRegistryPackage(pkg, revoked, { installedRegistry: installed }), /revoked/);
  const tampered = structuredClone(pkg); tampered.catalog.modules[0].name = 'tampered';
  assert.throws(() => verifySignedRegistryPackage(tampered, trust, { installedRegistry: installed }), /SHA-256 mismatch/);
  const extra = structuredClone(pkg); extra.catalog.modules.push({ id: 'loadout.third-party', version: '1.0.0', runtimeApi: '1.5.0', route: 'third-party', entry: 'www/modules/third-party.js', offline: true, services: [], manifestSha256: 'a'.repeat(64), entrySha256: 'b'.repeat(64) });
  const extraHash = structuredClone(extra.catalog); delete extraHash.catalogSha256; extra.catalog.catalogSha256 = sha256(stableStringify(extraHash));
  assert.throws(() => validateRegistryPackage(extra, installed), /cannot add or remove/);
});
