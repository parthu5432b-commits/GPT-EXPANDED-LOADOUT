import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { webcrypto } from 'node:crypto';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
function loadAiCoach() {
  const sandbox = {
    console, Date, Math, Map, Set, Object, String, Number, Boolean, RegExp, Error,
    URL, URLSearchParams, Promise, Array, JSON, Intl, TextEncoder, TextDecoder,
    crypto: webcrypto
  };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  sandbox.LoadoutDatabase = { initialize() {}, bootstrap() {}, verify() {}, enqueueSync() {}, status() {} };
  const scripts = [
    'www/runtime/module-registry.js', 'www/runtime/feature-runtime.js',
    'www/modules/features/chapter-intelligence.js',
    'www/modules/features/chapter-map.js',
    'www/modules/features/dashboard-analytics.js',
    'www/modules/test-ledger.js',
    'www/modules/features/command-center.js',
    'www/modules/features/pyq-intelligence.js',
    'www/modules/features/forecast-engine.js',
    'www/modules/features/test-ledger-route.js',
    'www/modules/features/data-settings.js',
    'www/modules/ai-coach/ai-coach.js'
  ];
  for (const relative of scripts) vm.runInContext(fs.readFileSync(path.join(ROOT, relative), 'utf8'), sandbox, { filename: relative });
  return sandbox;
}

test('AI Coach registers as a versioned offline feature without frozen-module mutation', () => {
  const app = loadAiCoach();
  const modules = app.LoadoutFeatureRuntime.initialize({ legacy: { renderAiCoach() {} } });
  const ai = modules.find(item => item.id === 'loadout.ai-coach');
  assert.ok(ai);
  assert.equal(ai.route, 'chatbot');
  assert.equal(ai.runtimeApi, '1.5.0');
  assert.equal(ai.offline, true);
  assert.equal(app.LoadoutModules.aiCoach.registerFeature(), false);
});

test('AI Coach route delegates to the preserved chat UI adapter', () => {
  const app = loadAiCoach();
  const modules = app.LoadoutFeatureRuntime.initialize({});
  let rendered = 0;
  assert.equal(app.LoadoutFeatureRuntime.render('chatbot', { legacy: { renderAiCoach() { rendered++; } } }), true);
  assert.equal(rendered, 1);
  assert.equal(app.LoadoutFeatureRuntime.activeModule, 'loadout.ai-coach');
});

test('AI Coach persona is JEE Main-only and explicitly denies unseen private data access', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.match(ai.defaultSystemPrompt, /JEE Main-only/i);
  assert.match(ai.defaultSystemPrompt, /Do not imply access/i);
  assert.doesNotMatch(ai.defaultSystemPrompt, /JEE Advanced mentor|combined JEE Advanced/i);
});

test('conversation normalisation bounds message data and removes unknown/provider secret fields', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const state = ai.normalizeState({
    provider: 'groq', profiles: { groq: { apiKey: 'DO-NOT-PERSIST', baseUrl: 'https://api.groq.com/openai/v1', model: 'test-model', mystery: 'x' } },
    conversations: [{ id: 'c1', title: 'A', messages: [{ id: 'm1', role: 'user', content: 'Hello', apiKey: 'DO-NOT-PERSIST' }, { id: 'm2', role: 'assistant', content: 'Hi', status: 'complete' }] }]
  });
  const serialized = JSON.stringify(ai.chatStorageSnapshot(state));
  assert.equal(state.schemaVersion, 4);
  assert.equal(state.provider, 'groq');
  assert.equal(state.conversations[0].messages.length, 2);
  assert.doesNotMatch(serialized, /DO-NOT-PERSIST|apiKey|mystery/);
});

test('conversation search is case-insensitive and ordered by last activity', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const rows = [
    { id: 'old', title: 'Physics', updatedAt: '2026-01-01', messages: [{ role: 'user', content: 'vectors' }] },
    { id: 'new', title: 'Chemistry', updatedAt: '2026-02-01', messages: [{ role: 'user', content: 'periodic trends' }] }
  ];
  assert.deepEqual(Array.from(ai.searchConversations(rows, 'PERIODIC'), row => row.id), ['new']);
  assert.deepEqual(Array.from(ai.searchConversations(rows, ''), row => row.id), ['new', 'old']);
});

test('history selection enforces count and estimated-token budgets while keeping newest context', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const history = Array.from({ length: 30 }, (_, index) => ({ role: index % 2 ? 'assistant' : 'user', content: `message-${index}-` + 'x'.repeat(100) }));
  const selected = ai.selectHistory(history, 4, 200);
  assert.ok(selected.length <= 4);
  assert.match(selected.at(-1).content, /message-29/);
});

test('study data is excluded by default and included only with explicit preferences', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const source = { chapters: [{ subject: 'Physics', status: 'completed', mastery: 77 }], attempts: [{ date: '2026-01-01', type: 'QFT', testId: 'MOCK-1', correct: 10, wrong: 2, unattempted: 3, score: 38, maxMarks: 60 }] };
  assert.equal(ai.buildStudyContext({}, source), '');
  const selected = ai.buildStudyContext({ includeStudySummary: true, includeRecentTests: true }, source);
  assert.match(selected, /STUDY SNAPSHOT/);
  assert.match(selected, /MOCK-1/);
  assert.match(selected, /10C\/2W\/3U/);
});

test('provider request builder uses HTTPS, correct provider schema, and never inserts credentials', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const request = ai.buildProviderRequest('groq', { baseUrl: 'https://api.groq.com/openai/v1', model: 'model-x' }, [{ role: 'user', content: 'Solve 2x=4' }], ai.defaultSystemPrompt, '', 1024);
  assert.equal(request.authMode, 'bearer');
  assert.equal(request.body.model, 'model-x');
  assert.equal(request.body.messages.at(-1).content, 'Solve 2x=4');
  assert.doesNotMatch(JSON.stringify(request), /apiKey|Bearer|secret/);
  assert.throws(() => ai.buildProviderRequest('groq', { baseUrl: 'http://127.0.0.1:11434/v1' }, [], '', '', 512), /HTTPS/);
  assert.throws(() => ai.buildProviderRequest('groq', { baseUrl: 'https://user:pass@example.com/v1' }, [], '', '', 512), /credentials/);
});

test('Gemini provider builder maps assistant history to model content', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const request = ai.buildProviderRequest('gemini', {}, [{ role: 'user', content: 'Question' }, { role: 'assistant', content: 'Working' }], '', '', 1024);
  assert.equal(request.authMode, 'google-api-key');
  assert.equal(request.body.contents[1].role, 'model');
  assert.equal(request.body.generationConfig.maxOutputTokens, 1024);
});

test('OpenAI-compatible SSE parser joins fragmented deltas and ignores [DONE]', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  let answer = '';
  const parser = ai.createSseParser('groq', text => { answer += text; });
  parser.push('data: {"choices":[{"delta":{"content":"Hel"}}]}\n');
  parser.push('data: {"choices":[{"delta":{"content":"lo"}}]}\n');
  parser.push('data: [DONE]\n');
  parser.finish();
  assert.equal(answer, 'Hello');
  assert.equal(parser.done, true);
});

test('Gemini SSE parser extracts candidate text deltas', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  let answer = '';
  const parser = ai.createSseParser('gemini', text => { answer += text; });
  parser.push('data: {"candidates":[{"content":{"parts":[{"text":"\u03c0"}]}}]}\n');
  parser.finish();
  assert.equal(answer, 'π');
});

test('Markdown renderer supports headings, nested lists, tables, code, quotes and safe links', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const html = ai.renderMarkdown('# Heading\n\n- Parent\n  - Child\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n```js\nconst x = 1;\n```\n\n> Quoted\n\n[Safe](https://example.com) [Bad](javascript:alert(1))');
  assert.match(html, /<h1>Heading<\/h1>/);
  assert.match(html, /<ul>[\s\S]*<li>Parent<ul><li>Child<\/li><\/ul><\/li>/);
  assert.match(html, /<table>/);
  assert.match(html, /<pre class="chat-code"><code class="language-js">/);
  assert.match(html, /<blockquote>/);
  assert.match(html, /href="https:\/\/example.com\/"/);
  assert.doesNotMatch(html, /javascript:/);
});

test('Markdown renderer escapes raw HTML and script injection payloads', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const html = ai.renderMarkdown('<img src=x onerror=alert(1)>\n\n<script>alert(2)</script>');
  assert.match(html, /&lt;img/);
  assert.match(html, /&lt;script&gt;/);
  assert.doesNotMatch(html, /<img|<script/);
});

test('KaTeX renderer is configured with trust disabled and local TeX delimiters', () => {
  const app = loadAiCoach();
  let options = null;
  app.renderMathInElement = (_element, received) => { options = received; };
  const result = app.LoadoutModules.aiCoach.renderMath({});
  assert.equal(result.rendered, true);
  assert.equal(options.trust, false);
  assert.ok(options.delimiters.some(item => item.left === '\\(' && item.right === '\\)'));
});

test('missing offline KaTeX assets are declared for postinstall and never loaded remotely', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
  assert.equal(pkg.dependencies.katex, '0.19.1');
  assert.match(pkg.scripts.postinstall, /vendor-katex\.mjs/);
  assert.match(html, /vendor\/katex\/katex\.min\.js/);
  assert.doesNotMatch(html, /https?:\/\/[^"']*katex/i);
});

test('connection test request contains only a fixed probe and no conversation or study context', () => {
  const request = loadAiCoach().LoadoutModules.aiCoach.buildConnectionTestRequest('custom', { baseUrl: 'https://api.example/v1', model: 'test-model' });
  const serialized = JSON.stringify(request.body);
  assert.equal(serialized.includes('LOADOUT_CONNECTION_OK'), true);
  assert.equal(serialized.includes('study snapshot'), false);
  assert.equal(serialized.includes('private conversation'), false);
  assert.equal(request.body.max_tokens, 128);
  assert.equal(request.url, 'https://api.example/v1/chat/completions');
});


test('stream append is bounded without throwing inside native event callbacks', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const first = ai.appendStreamText('abcd', 'XYZ', 5);
  assert.equal(first.content, 'abcdX'); assert.equal(first.truncated, true);
  const second = ai.appendStreamText('abc', 'd', 4);
  assert.equal(second.content, 'abcd'); assert.equal(second.truncated, false);
  const third = ai.appendStreamText('abcd', 'e', 4);
  assert.equal(third.content, 'abcd'); assert.equal(third.truncated, true);
});

test('provider base URLs reject query parameters while Gemini streaming adds its own alt=sse query later', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.throws(() => ai.buildProviderRequest('custom', { baseUrl: 'https://api.example/v1?key=secret', model: 'm' }, [{ role: 'user', content: 'x' }], '', '', 128), /query parameters/);
  const gemini = ai.buildProviderRequest('gemini', {}, [{ role: 'user', content: 'x' }], '', '', 128);
  assert.equal(gemini.url.includes('?'), false);
});

test('Hugging Face default uses the currently documented Inference Providers model identifier', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.equal(ai.providers.huggingface.model, 'deepseek-ai/DeepSeek-V4.1-Flash:fastest');
});

test('chat storage snapshot enforces a 24 MiB local durability ceiling instead of exhausting native storage', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const messages = Array.from({ length: 130 }, (_, index) => ({ id: `m-${index}`, role: 'user', content: 'x'.repeat(200000) }));
  const state = { conversations: [{ id: 'large', title: 'Large', messages }] };
  assert.throws(() => ai.chatStorageSnapshot(state), /safe local storage limit is 24 MiB/);
});


test('AI Coach converts persisted in-flight replies into retryable interrupted messages on startup', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const recovered = ai.recoverInterruptedStreams({
    conversations: [{ id: 'c1', title: 'Physics', messages: [
      { id: 'u1', role: 'user', content: 'Explain projectile motion', status: 'complete' },
      { id: 'a1', role: 'assistant', content: 'The horizontal component', status: 'streaming' }
    ] }]
  });
  assert.equal(recovered.interruptedCount, 1);
  assert.equal(recovered.state.conversations[0].messages[1].status, 'cancelled');
  assert.equal(recovered.state.conversations[0].messages[1].content, 'The horizontal component');
});

test('Gemini 3.8 request omits unsupported temperature parameter', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const request = ai.buildProviderRequest('gemini', {}, [{ role: 'user', content: 'Explain equilibrium' }], '', '', 1024);
  assert.equal(request.body.generationConfig.maxOutputTokens, 1024);
  assert.equal(Object.hasOwn(request.body.generationConfig, 'temperature'), false);
});


test('AI Coach provider defaults are source-backed current model identifiers and editable presets', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.equal(ai.providers.gemini.model, 'gemini-3.8-flash');
  assert.equal(ai.providers.groq.model, 'openai/gpt-oss-20b');
  assert.equal(ai.providers.openrouter.model, 'openrouter/free');
  assert.equal(ai.providers.huggingface.model, 'deepseek-ai/DeepSeek-V4.1-Flash:fastest');
  assert.equal(ai.providers.cerebras.model, 'zai-glm-4.7');
  assert.equal(ai.providers.custom.model, 'gpt-4o-mini');
  for (const provider of Object.values(ai.providers)) {
    assert.match(provider.baseUrl, /^https:\/\//);
    assert.ok(provider.model.length > 0);
  }
});


test('cancelled assistant replies expose a working retry action while unrelated states do not', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.equal(ai.canRetryMessage({ role: 'assistant', status: 'cancelled' }, 'retry'), true);
  assert.equal(ai.canRetryMessage({ role: 'assistant', status: 'error' }, 'retry'), true);
  assert.equal(ai.canRetryMessage({ role: 'assistant', status: 'complete' }, 'regenerate'), true);
  assert.equal(ai.canRetryMessage({ role: 'assistant', status: 'streaming' }, 'retry'), false);
  assert.equal(ai.canRetryMessage({ role: 'user', status: 'cancelled' }, 'retry'), false);
});

test('provider base URL validation rejects query strings before settings are saved', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  assert.equal(ai.validateProviderBaseUrl('https://api.example/v1/'), 'https://api.example/v1');
  assert.throws(() => ai.validateProviderBaseUrl('http://api.example/v1'), /HTTPS/);
  assert.throws(() => ai.validateProviderBaseUrl('https://api.example/v1?key=secret'), /query parameters/);
  assert.throws(() => ai.validateProviderBaseUrl('https://user:pass@api.example/v1'), /credentials/);
  assert.throws(() => ai.validateProviderBaseUrl('https://api.example/v1#frag'), /fragment/);
});

test('provider error strings redact common vendor token formats', () => {
  const ai = loadAiCoach().LoadoutModules.aiCoach;
  const raw = 'Bearer abcdefghijklmnop sk-or-v1-1234567890abcdef hf_1234567890abcdef gsk_1234567890abcdef';
  const safe = ai.redactProviderError(raw);
  assert.doesNotMatch(safe, /abcdefghijklmnop|sk-or-v1|hf_123|gsk_123/);
  assert.match(safe, /\[redacted\]/);
});
