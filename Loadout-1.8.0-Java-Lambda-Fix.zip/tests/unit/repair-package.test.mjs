import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { repairSigningPayload, validateUnsignedRepairPackage, verifySignedRepairPackage, REPAIR_SCOPES } from '../../src/core/repair-package.js';

function signedRepair(overrides = {}) {
  const pair = crypto.generateKeyPairSync('ed25519');
  const publicDer = pair.publicKey.export({ format: 'der', type: 'spki' });
  const rawPublic = publicDer.subarray(publicDer.length - 32).toString('base64');
  const keyId = 'owner-test-key';
  const pkg = { manifest: {
    formatVersion: '1.0', kind: 'ui-repair', repairId: 'repair-layout-001', title: 'Fix compact dashboard layout',
    description: 'Adjust the approved card spacing token.', createdAt: '2026-11-19T00:00:00.000Z', sourceBuild: '1.8.0',
    target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0', minimumAppVersion: '1.8.0' },
    fixes: [{ id: 'fix-gap', op: 'SET_UI_TOKEN', scope: 'loadout.command-center', token: 'grid-gap', value: '18px', reason: 'Prevent cards from appearing cramped.' }],
    ...overrides
  }};
  pkg.manifest.signature = { algorithm: 'Ed25519', keyId, value: crypto.sign(null, Buffer.from(repairSigningPayload(pkg)), pair.privateKey).toString('base64') };
  return { pkg, trust: { keys: [{ keyId, algorithm: 'Ed25519', publicKey: rawPublic }] } };
}

test('repair package scope catalog is explicit and covers the seven workspaces', () => {
  assert.equal(Object.keys(REPAIR_SCOPES).length, 8); // global shell + seven feature scopes
  assert.ok(REPAIR_SCOPES['loadout.ai-coach'].tokens.includes('chat-panel-max-height'));
});

test('valid owner-signed visual repair verifies against the trusted Ed25519 key', () => {
  const { pkg, trust } = signedRepair();
  assert.deepEqual(verifySignedRepairPackage(pkg, trust).scopes, ['loadout.command-center']);
  assert.equal(verifySignedRepairPackage(pkg, trust).signer, 'owner-test-key');
});

test('visual repair rejects untrusted and tampered signatures', () => {
  const { pkg, trust } = signedRepair();
  assert.throws(() => verifySignedRepairPackage(pkg, { keys: [] }), /not trusted/);
  pkg.manifest.title = 'Tampered';
  assert.throws(() => verifySignedRepairPackage(pkg, trust), /signature verification failed/);
});

test('visual repair rejects arbitrary CSS, script operations, unknown scopes and unbounded values', () => {
  const { pkg } = signedRepair();
  pkg.manifest.fixes[0].op = 'PATCH_SOURCE';
  assert.throws(() => validateUnsignedRepairPackage(pkg), /Unsupported repair operation/);
  const second = signedRepair().pkg;
  second.manifest.fixes[0].token = 'custom-css';
  assert.throws(() => validateUnsignedRepairPackage(second), /not permitted/);
  const third = signedRepair().pkg;
  third.manifest.fixes[0].value = '999px';
  assert.throws(() => validateUnsignedRepairPackage(third), /between 4px and 36px/);
});

test('visual repair rejects old app versions, oversized manifests and duplicate fix IDs', () => {
  const old = signedRepair().pkg;
  old.manifest.target.minimumAppVersion = '9.0.0';
  assert.throws(() => validateUnsignedRepairPackage(old), /requires Loadout 9.0.0/);
  const duplicate = signedRepair().pkg;
  duplicate.manifest.fixes.push({ ...duplicate.manifest.fixes[0] });
  assert.throws(() => validateUnsignedRepairPackage(duplicate), /unique safe identifiers/);
});
