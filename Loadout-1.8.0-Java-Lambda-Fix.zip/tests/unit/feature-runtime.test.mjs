import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
function loadFeatureSystem() {
  const sandbox = { console, Date, Math, Map, Set, Object, String, Number, Boolean, RegExp, Error };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  sandbox.LoadoutDatabase = { initialize() {}, bootstrap() {}, verify() {}, enqueueSync() {}, status() {} };
  const scripts = [
    'www/runtime/module-registry.js',
    'www/runtime/feature-runtime.js',
    'www/modules/features/chapter-intelligence.js',
    'www/modules/features/chapter-map.js',
    'www/modules/features/dashboard-analytics.js',
    'www/modules/test-ledger.js',
    'www/modules/features/command-center.js',
    'www/modules/features/pyq-intelligence.js',
    'www/modules/features/forecast-engine.js',
    'www/modules/features/test-ledger-route.js',
    'www/modules/features/data-settings.js',
    'www/modules/ai-coach/ai-coach.js'
  ];
  for (const relative of scripts) vm.runInContext(fs.readFileSync(path.join(ROOT, relative), 'utf8'), sandbox, { filename: relative });
  return sandbox;
}

test('registers all six study workspaces plus the dedicated AI Coach module against runtime API 1.5', () => {
  const app = loadFeatureSystem();
  const modules = app.LoadoutFeatureRuntime.initialize({});
  assert.equal(modules.length, 7);
  assert.deepEqual(Array.from(modules, item => item.route).sort(), ['chapters', 'chatbot', 'dashboard', 'data', 'forecasts', 'historical', 'tests']);
  assert.ok(modules.every(item => item.runtimeApi === '1.5.0' && item.offline));
  assert.equal(app.LoadoutFeatureRuntime.list().some(item => item.id === 'loadout.ai-coach'), true);
});

test('feature routes delegate to the preserved legacy views and update lifecycle state', () => {
  const app = loadFeatureSystem();
  const calls = [];
  const legacy = Object.fromEntries(['dashboard', 'chapters', 'historical', 'tests', 'forecasts', 'dataSettings'].map(key => [key, () => calls.push(key)]));
  for (const route of ['dashboard', 'chapters', 'historical', 'tests', 'forecasts', 'data']) {
    assert.equal(app.LoadoutFeatureRuntime.render(route, { legacy }), true);
  }
  assert.deepEqual(Array.from(calls), ['dashboard', 'chapters', 'historical', 'tests', 'forecasts', 'dataSettings']);
  assert.equal(app.LoadoutFeatureRuntime.activeModule, 'loadout.data-settings');
});

test('rejects duplicate feature IDs and routes', () => {
  const app = loadFeatureSystem();
  assert.throws(() => app.LoadoutFeatureRuntime.register({ id: 'loadout.test-ledger', version: '1.0.0', runtimeApi: '1.5.0', route: 'duplicate', render() {} }), /Duplicate/);
  assert.throws(() => app.LoadoutFeatureRuntime.register({ id: 'loadout.other-feature', version: '1.0.0', runtimeApi: '1.5.0', route: 'tests', render() {} }), /Duplicate/);
});

test('chapter map normalization, alias resolution and weighted chronological attempts are stable', () => {
  const app = loadFeatureSystem();
  const api = app.LoadoutModules.chapterMap;
  assert.equal(api.normalize('P–V & P–Block'), 'p v and p block');
  const chapter = { id: 'phy-modern', name: 'Modern Physics', subject: 'Physics' };
  assert.equal(api.resolveChapter('modern-physics', [chapter], { 'modern physics': 'phy-modern' }, { 'phy-modern': chapter }), chapter);
  const rows = api.chapterAttempts(chapter, [
    { id: 't2', testId: 'T2', date: '2026-02-02', type: 'QFT', chapterResults: [{ chapterId: 'phy-modern', n: 5, correct: 4 }] },
    { id: 't1', testId: 'T1', date: '2026-01-01', type: 'QCT', chapterResults: [{ chapterId: 'phy-modern', n: 3, correct: 2 }] }
  ], { QCT: 1, QFT: 0.5 });
  assert.deepEqual(Array.from(rows, row => row.testKey), ['t1', 't2']);
  assert.deepEqual(Array.from(rows, row => row.weight), [1, 0.5]);
});

test('chapter mastery service preserves weighted prior and evidence counts', () => {
  const app = loadFeatureSystem();
  const api = app.LoadoutModules.chapterIntelligence;
  const chapter = { id: 'phy-1' };
  const attempts = [{ n: 2, correct: 1, wrong: 1, unattempted: 0, weight: 1, type: 'QCT', date: '2026-01-01' }];
  const settings = { correctMarks: 4, wrongMarks: -1, alpha: 0.35, priorStrength: 0 };
  const stats = api.calculateStats({ chapter, attempts, baseline: 50, settings, tags: ['conceptual', 'calculation', 'unclassified'], recoverability: { conceptual: 1, calculation: 1, unclassified: 1 }, hours: { conceptual: 1, calculation: 1, unclassified: 1 } });
  assert.equal(stats.observations, 1);
  assert.equal(stats.count, 1);
  assert.equal(stats.mastery, 37.5);
  assert.equal(stats.wrong, 1);
  assert.equal(stats.unattempted, 0);
});

test('forecast calibration preserves the existing mean-bias fallback for small samples', () => {
  const app = loadFeatureSystem();
  const regression = app.LoadoutModules.forecastEngine.regressionFor('QFT', [
    { score: 110, prediction: { type: 'QFT', raw: 100 } },
    { score: 120, prediction: { type: 'QFT', raw: 100 } },
    { score: 130, prediction: { type: 'QFT', raw: 100 } }
  ]);
  assert.equal(regression.n, 3);
  assert.equal(regression.a, 20);
  assert.equal(regression.b, 1);
  assert.equal(regression.method, 'Mean-bias correction');
});

test('PYQ intelligence filters topic aliases without changing source rows', () => {
  const app = loadFeatureSystem();
  const rows = [{ topic: 'Capacitance', subtopic: 'Parallel plate' }, { topic: 'Current Electricity' }];
  const filtered = app.LoadoutModules.pyqIntelligence.filterRows(rows, 'parallel');
  assert.equal(filtered.length, 1);
  assert.equal(filtered[0], rows[0]);
  assert.equal(app.LoadoutModules.pyqIntelligence.datasetFor('Physics', { Physics: rows }), rows);
});
