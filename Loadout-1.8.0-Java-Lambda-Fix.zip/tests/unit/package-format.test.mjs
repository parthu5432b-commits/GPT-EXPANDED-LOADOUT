import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { signingPayload, validateUnsignedPackage, verifySignedPackage } from '../../src/core/package-format.js';
import { sha256 } from '../../src/core/ltl.js';
function baseOp(op, extra = {}) { return { id: 'test-op', op, description: 'Test declarative change', risk: 'low', dependencies: [], validation: ['postcondition'], failureAction: 'reject', recovery: 'discard staged copy', ...extra }; }
function packageFixture() {
  const content = '{"cycle":2027}';
  return { manifest: { formatVersion: '1.0', kind: 'data-update', updateId: 'test-pack-1', target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0' }, resources: [{ path: 'profiles/jee-main-2027.json', namespace: 'jee-main-2027', sha256: sha256(content) }], transformations: [] }, files: { 'profiles/jee-main-2027.json': content } };
}
test('accepts valid data-only package and returns impact metadata', () => { const result = validateUnsignedPackage(packageFixture()); assert.equal(result.resourceCount, 1); assert.equal(result.operationCount, 0); assert.equal(result.impact.manualApprovalRequired, true); });
test('rejects executable payloads and path traversal', () => {
  const p = packageFixture(); p.files = { 'app.js': 'window.bad=true' }; p.manifest.resources = [{ path: 'app.js', sha256: sha256('window.bad=true') }]; assert.throws(() => validateUnsignedPackage(p), /Executable/);
  const q = packageFixture(); q.manifest.resources[0].path = '../escape.json'; q.files = { '../escape.json': '{}' }; q.manifest.resources[0].sha256 = sha256('{}'); assert.throws(() => validateUnsignedPackage(q), /Unsafe resource path/);
});
test('validates LTL metadata, dependency order and duplicate operation IDs', () => {
  const p = packageFixture();
  p.manifest.transformations = [baseOp('ADD', { id: 'second', dependencies: ['first'], path: '/settings/b', value: 2 }), baseOp('ADD', { id: 'first', path: '/settings/a', value: 1 })];
  assert.deepEqual(validateUnsignedPackage(p).orderedOperationIds, ['first', 'second']);
  p.manifest.transformations[1].id = 'second';
  assert.throws(() => validateUnsignedPackage(p), /Duplicate/);
});
test('checks required dependency declarations against installed versions', () => {
  const p = packageFixture(); p.manifest.dependencies = [{ id: 'loadout.storage', version: '1.2.0' }]; p.manifest.dependenciesRequired = true;
  assert.throws(() => validateUnsignedPackage(p), /not installed/);
  assert.throws(() => validateUnsignedPackage(p, { installedDependencies: { 'loadout.storage': '1.1.0' } }), /version mismatch/);
  assert.equal(validateUnsignedPackage(p, { installedDependencies: { 'loadout.storage': '1.2.0' } }).resourceCount, 1);
});
test('verifies Ed25519 signature and raw public key', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519'); const p = packageFixture();
  const der = publicKey.export({ format: 'der', type: 'spki' }); const raw = der.subarray(12).toString('base64');
  p.manifest.signature = { algorithm: 'Ed25519', keyId: 'test-key-1', value: crypto.sign(null, Buffer.from(signingPayload(p)), privateKey).toString('base64') };
  assert.equal(verifySignedPackage(p, { keys: [{ keyId: 'test-key-1', algorithm: 'Ed25519', publicKey: raw }] }).signer, 'test-key-1');
});
test('rejects unsigned, untrusted, revoked and tampered packages', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519'); const p = packageFixture();
  const der = publicKey.export({ format: 'der', type: 'spki' }); const raw = der.subarray(12).toString('base64');
  p.manifest.signature = { algorithm: 'Ed25519', keyId: 'test-key-2', value: crypto.sign(null, Buffer.from(signingPayload(p)), privateKey).toString('base64') };
  assert.throws(() => verifySignedPackage(p, { keys: [] }), /not trusted/);
  assert.throws(() => verifySignedPackage(p, { keys: [{ keyId: 'test-key-2', algorithm: 'Ed25519', publicKey: raw, revokedAt: '2026-01-01' }] }), /revoked/);
  p.files['profiles/jee-main-2027.json'] = 'tampered';
  assert.throws(() => verifySignedPackage(p, { keys: [{ keyId: 'test-key-2', algorithm: 'Ed25519', publicKey: raw }] }), /SHA-256 mismatch/);
});
