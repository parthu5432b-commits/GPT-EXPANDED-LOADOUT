import test from 'node:test';
import assert from 'node:assert/strict';
import { APP_ID, REMOTE_INBOX, parseAdbDevices, selectAdbDevice, safePackageFilename, remotePackagePath, parsePackageIdentity } from '../../scripts/dev-port-core.mjs';

test('ADB parser recognises connected, unauthorized and offline devices', () => {
  const rows = parseAdbDevices('List of devices attached\nABC123 device product:pixel model:Pixel_8\nDEF456 unauthorized usb:1\nGHI789 offline transport_id:3\n');
  assert.deepEqual(rows.map(x => [x.serial, x.state]), [['ABC123','device'],['DEF456','unauthorized'],['GHI789','offline']]);
});

test('ADB device selection requires one explicitly authorized device', () => {
  const rows = parseAdbDevices('A device\nB device\nC unauthorized');
  assert.throws(() => selectAdbDevice(rows), /More than one/);
  assert.equal(selectAdbDevice(rows, 'B').serial, 'B');
  assert.throws(() => selectAdbDevice(rows, 'C'), /not connected and authorized/);
  assert.throws(() => selectAdbDevice([], ''), /No authorized/);
  assert.throws(() => selectAdbDevice(parseAdbDevices('C unauthorized'), ''), /authorization prompt/);
});

test('package inbox paths accept only safe package filenames', () => {
  assert.equal(APP_ID, 'app.loadout.jee');
  assert.match(REMOTE_INBOX, /Android\/data\/app\.loadout\.jee/);
  assert.equal(safePackageFilename('chapter-pack.lupdate'), 'chapter-pack.lupdate');
  assert.equal(safePackageFilename('registry.lreg'), 'registry.lreg');
  assert.equal(safePackageFilename('screen-fix.lfix'), 'screen-fix.lfix');
  assert.equal(remotePackagePath('chapter-pack.lupdate'), `${REMOTE_INBOX}/chapter-pack.lupdate`);
  for (const name of ['../escape.lupdate','/tmp/evil.lupdate','a b.lupdate','foo.js','executable.lmod','source-fix.lpatch','a..b.lupdate','x'.repeat(101)+'.lmod']) {
    assert.throws(() => safePackageFilename(name));
  }
});

test('installed package identity parser exposes version and debug gate', () => {
  assert.deepEqual(parsePackageIdentity('versionCode=11 minSdk=23\nversionName=1.8.0\nflags=[ HAS_CODE DEBUGGABLE ALLOW_CLEAR_USER_DATA ]'), { versionName: '1.8.0', versionCode: '11', debuggable: true });
  assert.equal(parsePackageIdentity('versionCode=11\nversionName=1.8.0\nflags=[ HAS_CODE ]').debuggable, false);
});
