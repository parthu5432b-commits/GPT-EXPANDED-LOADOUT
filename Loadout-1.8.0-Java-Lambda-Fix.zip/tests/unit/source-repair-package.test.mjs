import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { sourceRepairSha256, safeRepairSourcePath, sourceRepairSigningPayload, validateUnsignedSourceRepairPackage, verifySignedSourceRepairPackage, applySourceRepairOperations } from '../../src/core/source-repair-package.js';

function createPackage() {
  const pair = crypto.generateKeyPairSync('ed25519');
  const der = pair.publicKey.export({ format: 'der', type: 'spki' });
  const keyId = 'owner-source-key';
  const source = 'const label = "before";\n';
  const pkg = { manifest: {
    formatVersion: '1.0', kind: 'source-repair', repairId: 'source-repair-01', title: 'Correct label', description: 'Fix a stable text constant.', createdAt: '2026-11-19T00:00:00.000Z',
    target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0', minimumAppVersion: '1.8.0' },
    operations: [{ id: 'patch-label', op: 'PATCH_SOURCE', file: 'www/modules/features/sample.js', expectedSha256: sourceRepairSha256(source), anchor: 'const label = "before";', replacement: 'const label = "after";', expectedMatches: 1, reason: 'Correct the visible label.' }]
  }};
  pkg.manifest.signature = { algorithm: 'Ed25519', keyId, value: crypto.sign(null, Buffer.from(sourceRepairSigningPayload(pkg)), pair.privateKey).toString('base64') };
  return { pkg, pair, keyId, source, trust: { keys: [{ keyId, algorithm: 'Ed25519', publicKey: der.subarray(der.length - 32).toString('base64') }] } };
}

test('source repair path allowlist excludes traversal, dependencies, secrets and executable package types', () => {
  assert.equal(safeRepairSourcePath('www/app.js'), true);
  assert.equal(safeRepairSourcePath('native/android/LoadoutCorePlugin.java'), true);
  for (const value of ['../package.json', '/tmp/a.js', 'www/../package.json', 'node_modules/a.js', 'local-signing/key.pem', 'www/payload.lmod', 'www\\app.js']) assert.equal(safeRepairSourcePath(value), false, value);
});

test('signed source repair verifies, checks source hash and performs one exact anchor replacement', () => {
  const { pkg, trust, source } = createPackage();
  const verified = verifySignedSourceRepairPackage(pkg, trust);
  assert.equal(verified.signer, 'owner-source-key');
  const changed = applySourceRepairOperations(new Map([[pkg.manifest.operations[0].file, source]]), pkg.manifest.operations);
  assert.equal(changed.get(pkg.manifest.operations[0].file), 'const label = "after";\n');
});

test('source repair rejects tampering, stale hashes, non-unique anchors and executable-path escapes', () => {
  const { pkg, trust, source } = createPackage();
  pkg.manifest.description = 'tampered';
  assert.throws(() => verifySignedSourceRepairPackage(pkg, trust), /signature verification failed/);
  const { pkg: good } = createPackage();
  const stale = { ...good.manifest.operations[0], expectedSha256: '0'.repeat(64) };
  assert.throws(() => applySourceRepairOperations(new Map([[stale.file, source]]), [stale]), /Preimage SHA-256 mismatch/);
  const repeatedSource = 'const a=1; const b=2;';
  const repeated = { ...good.manifest.operations[0], expectedSha256: sourceRepairSha256(repeatedSource), anchor: 'const', replacement: 'let' };
  assert.throws(() => applySourceRepairOperations(new Map([[repeated.file, repeatedSource]]), [repeated]), /multiple/);
  const unsafe = createPackage().pkg;
  unsafe.manifest.operations[0].file = 'www/payload.exe';
  assert.throws(() => validateUnsignedSourceRepairPackage(unsafe), /outside the repair allowlist/);
});
