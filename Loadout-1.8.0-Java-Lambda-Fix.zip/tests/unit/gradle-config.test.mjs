import test from 'node:test';
import assert from 'node:assert/strict';
import { setGradleIntegerVariable } from '../../scripts/gradle-config.mjs';

const capacitor743Variables = `ext {\n    minSdkVersion = 23\n    compileSdkVersion = 35\n    targetSdkVersion = 35\n    androidxActivityVersion = '1.9.2'\n}\n`;

test('Gradle SDK version replacement handles the exact Capacitor 7.4.3 equals syntax', () => {
  let actual = capacitor743Variables;
  actual = setGradleIntegerVariable(actual, 'minSdkVersion', 23);
  actual = setGradleIntegerVariable(actual, 'compileSdkVersion', 35);
  actual = setGradleIntegerVariable(actual, 'targetSdkVersion', 35);
  assert.match(actual, /minSdkVersion = 23/);
  assert.match(actual, /compileSdkVersion = 35/);
  assert.match(actual, /targetSdkVersion = 35/);
  assert.match(actual, /androidxActivityVersion = '1\.9\.2'/);
});

test('Gradle SDK version replacement changes only requested integer and rejects absent/unsafe variables', () => {
  const changed = setGradleIntegerVariable(capacitor743Variables, 'compileSdkVersion', 36);
  assert.match(changed, /compileSdkVersion = 36/);
  assert.match(changed, /minSdkVersion = 23/);
  assert.throws(() => setGradleIntegerVariable(capacitor743Variables, 'targetSdkVersionX', 35), /assignment/);
  assert.throws(() => setGradleIntegerVariable(capacitor743Variables, 'x);bad', 35), /name/);
  assert.throws(() => setGradleIntegerVariable(capacitor743Variables, 'targetSdkVersion', 0), /integer value/);
});
