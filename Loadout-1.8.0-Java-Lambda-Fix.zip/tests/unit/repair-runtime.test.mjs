import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import vm from 'node:vm';
import fs from 'node:fs';
import { repairSigningPayload } from '../../src/core/repair-package.js';

function style() { const values = new Map(); return { values, setProperty(k,v){values.set(k,v);}, removeProperty(k){values.delete(k);} }; }
function runtimeHarness() {
  const elements = new Map([['view-dashboard', { style: style() }]]);
  const document = { documentElement: { style: style() }, getElementById(id){return elements.get(id)||null;} };
  const window = { document, crypto: crypto.webcrypto, TextEncoder, atob: value => Buffer.from(value,'base64').toString('binary') };
  vm.runInNewContext(fs.readFileSync(new URL('../../www/runtime/repair-engine.js', import.meta.url),'utf8'), { window, TextEncoder, Uint8Array });
  const store = new Map();
  const pair = crypto.generateKeyPairSync('ed25519');
  const der = pair.publicKey.export({ format:'der', type:'spki' });
  const keyId = 'runtime-key';
  const trust = { keys: [{ keyId, algorithm:'Ed25519', publicKey:der.subarray(der.length-32).toString('base64') }] };
  const read = async (key, fallback) => structuredClone(store.has(key) ? store.get(key) : fallback);
  const write = async (key, value) => { store.set(key, structuredClone(value)); };
  const engine = window.LoadoutRepairEngineFactory({ managedRead:read, managedWrite:write, loadTrustStore:async()=>trust, diagnostics:{ record:async()=>{} } });
  const pkg = { manifest: { formatVersion:'1.0',kind:'ui-repair',repairId:'runtime-fix-1',title:'Dashboard spacing',description:'Adjust card spacing.',createdAt:'2026-11-19T00:00:00.000Z',target:{appId:'app.loadout.jee',runtimeApi:'1.5.0',minimumAppVersion:'1.8.0'},fixes:[{id:'gap',op:'SET_UI_TOKEN',scope:'loadout.command-center',token:'grid-gap',value:'18px'}] } };
  pkg.manifest.signature={algorithm:'Ed25519',keyId,value:crypto.sign(null,Buffer.from(repairSigningPayload(pkg)),pair.privateKey).toString('base64')};
  return { engine, pkg, elements, store };
}

test('repair runtime stages without applying, commits scoped tokens, and rolls back', async () => {
  const { engine, pkg, elements, store } = runtimeHarness();
  const staged = await engine.stage(pkg, 'test');
  assert.equal(staged.state, 'awaiting-manual-decision');
  assert.equal((await engine.pending())[0].fixCount, 1);
  assert.equal(elements.get('view-dashboard').style.values.size, 0);
  await engine.commit(staged.repairId);
  assert.equal(elements.get('view-dashboard').style.values.get('--loadout-repair-grid-gap'), '18px');
  assert.equal((await engine.active())['loadout.command-center']['grid-gap'], '18px');
  await engine.rollback(staged.repairId);
  assert.equal(elements.get('view-dashboard').style.values.size, 0);
  assert.equal((await engine.active())['loadout.command-center'], undefined);
  assert.ok(store.size > 0);
});

test('repair runtime refuses a changed signature and does not stage it', async () => {
  const { engine, pkg } = runtimeHarness();
  pkg.manifest.title = 'altered after signing';
  await assert.rejects(() => engine.stage(pkg, 'test'), /signature verification failed/);
  assert.equal((await engine.pending()).length, 0);
});

test('repair runtime reconciles a process-death interruption after candidate activation', async () => {
  const { engine, pkg, store, elements } = runtimeHarness();
  const staged = await engine.stage(pkg, 'test');
  const txKey = 'repair-transaction-' + staged.repairId;
  const tx = store.get(txKey);
  tx.state = 'activating';
  store.set(txKey, tx);
  store.set('active-ui-repairs', structuredClone(tx.candidateActive));
  const recovered = await engine.recover();
  assert.equal(Array.from(recovered, row => row.recovered).join(','), 'commit');
  assert.equal((await engine.journal())[0].state, 'committed');
  assert.equal(elements.get('view-dashboard').style.values.get('--loadout-repair-grid-gap'), '18px');
});

test('repair runtime restores previous tokens after interruption before candidate activation', async () => {
  const { engine, pkg, store, elements } = runtimeHarness();
  const staged = await engine.stage(pkg, 'test');
  const txKey = 'repair-transaction-' + staged.repairId;
  const tx = store.get(txKey);
  tx.state = 'activating';
  store.set(txKey, tx);
  const recovered = await engine.recover();
  assert.equal(Array.from(recovered, row => row.recovered).join(','), 'restore-previous');
  assert.equal((await engine.journal())[0].state, 'activation-failed');
  assert.equal(elements.get('view-dashboard').style.values.size, 0);
});
