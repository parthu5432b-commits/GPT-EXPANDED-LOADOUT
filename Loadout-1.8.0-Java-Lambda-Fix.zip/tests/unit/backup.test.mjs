import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BACKUP_SCHEMA_VERSION,
  createBackup,
  validateBackup,
  verifyBackupReadback,
  applyBackupToState,
  mergeChatBackup
} from '../../src/core/backup.js';

const valid = {
  settings: { correctMarks: 4, wrongMarks: -1 },
  attempts: [{ id: 'a1', testId: 'QCT-1', n: 3, correct: 1, wrong: 1, unattempted: 1 }],
  forecasts: [{ id: 'f1', testId: 'QPT-1', type: 'QPT' }],
  chat: { provider: 'gemini', conversations: [{ id: 'c1', title: 'Physics', messages: [] }] },
  examProfileId: 'jee-main-2027-paper-1'
};

test('creates and verifies checksum-protected schema 3 backup', async () => {
  const backup = await createBackup(valid, { sourceAppVersion: '1.5.0' });
  assert.equal(backup.schemaVersion, BACKUP_SCHEMA_VERSION);
  assert.equal(backup.integrity.algorithm, 'SHA-256');
  const out = await validateBackup(backup);
  assert.equal(out.integrityVerified, true);
  assert.equal(out.attempts.length, 1);
  assert.deepEqual(out.chat, valid.chat);
});

test('safety snapshot read-back verifies the entire stored payload, not just its digest field', async () => {
  const snapshot = await createBackup(valid, { sourceAppVersion: '1.5.0', sourceSchedule: 'Pre-restore safety snapshot' });
  const verified = await verifyBackupReadback(snapshot, JSON.parse(JSON.stringify(snapshot)));
  assert.equal(verified.integrityVerified, true);
  const tampered = JSON.parse(JSON.stringify(snapshot));
  tampered.payload.attempts[0].title = 'modified after storage';
  await assert.rejects(verifyBackupReadback(snapshot, tampered), /integrity check failed/i);
  const mismatched = await createBackup({ ...valid, forecasts: [{ id: 'different' }] });
  await assert.rejects(verifyBackupReadback(snapshot, mismatched), /payload mismatch/i);
});

test('rejects schema 3 backup modified after export', async () => {
  const backup = await createBackup(valid);
  backup.payload.attempts[0].correct = 2;
  await assert.rejects(validateBackup(backup), /integrity check failed/i);
});

test('continues to read legacy schema 1 and 2 backups', async () => {
  for (const schemaVersion of [1, 2]) {
    const legacy = { app: 'loadout-backup', schemaVersion, ...valid };
    const out = await validateBackup(legacy);
    assert.equal(out.schemaVersion, schemaVersion);
    assert.equal(out.integrityVerified, false);
    assert.equal(out.attempts.length, 1);
  }
});

test('rejects inconsistent question accounting', async () => {
  await assert.rejects(
    validateBackup({ app: 'loadout-backup', schemaVersion: 2, ...valid, attempts: [{ testId: 'bad', n: 3, correct: 2, wrong: 1, unattempted: 1 }] }),
    /C\/W\/U/
  );
});

test('rejects unknown schema and unsafe object keys', async () => {
  await assert.rejects(validateBackup({ app: 'loadout-backup', schemaVersion: 99 }), /schema/i);
  const unsafe = JSON.parse('{"app":"loadout-backup","schemaVersion":2,"settings":{"__proto__":{"polluted":true}},"attempts":[],"forecasts":[]}');
  await assert.rejects(validateBackup(unsafe), /unsafe object key/i);
});

test('replace restore uses incoming data while preserving non-data UI state', () => {
  const current = { settings: { correctMarks: 3 }, attempts: [{ id: 'old' }], forecasts: [], ui: { view: 'tests' } };
  const next = applyBackupToState(current, { settings: { correctMarks: 4 }, attempts: [{ id: 'new' }], forecasts: [] }, 'replace');
  assert.deepEqual(next.attempts, [{ id: 'new' }]);
  assert.equal(next.settings.correctMarks, 4);
  assert.deepEqual(next.ui, { view: 'tests' });
});

test('merge restore preserves current settings and deduplicates stable record IDs', () => {
  const current = { settings: { correctMarks: 3 }, attempts: [{ id: 'a', score: 1 }, { id: 'b', score: 2 }], forecasts: [{ id: 'f1', raw: 100 }], ui: { view: 'dashboard' } };
  const incoming = { settings: { correctMarks: 4 }, attempts: [{ id: 'b', score: 9 }, { id: 'c', score: 3 }], forecasts: [{ id: 'f2', raw: 120 }] };
  const next = applyBackupToState(current, incoming, 'merge');
  assert.deepEqual(next.attempts, [{ id: 'a', score: 1 }, { id: 'b', score: 9 }, { id: 'c', score: 3 }]);
  assert.equal(next.settings.correctMarks, 3);
  assert.equal(next.forecasts.length, 2);
});

test('chat merge keeps newest conversation revision and never imports credentials', () => {
  const current = { provider: 'gemini', profiles: { gemini: { apiKey: 'local-secret', model: 'old' } }, conversations: [{ id: 'c1', updatedAt: '2026-01-01', messages: [] }] };
  const incoming = { provider: 'groq', profiles: { groq: { apiKey: 'foreign-secret', model: 'new' } }, conversations: [{ id: 'c1', updatedAt: '2026-02-01', messages: [{ id: 'm1', role: 'user', content: 'hi' }] }, { id: 'c2', messages: [] }] };
  const merged = mergeChatBackup(current, incoming);
  assert.equal(merged.conversations.length, 2);
  assert.equal(merged.conversations[0].messages[0].content, 'hi');
  assert.equal(merged.profiles.gemini.apiKey, undefined);
  assert.equal(merged.profiles.groq.apiKey, undefined);
});
