import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateModuleRegistry } from '../../src/core/module-registry.js';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
function fixtures() {
  const registry = JSON.parse(fs.readFileSync(path.join(ROOT, 'modules/registry.json'), 'utf8'));
  const manifests = registry.modules.map(row => JSON.parse(fs.readFileSync(path.join(ROOT, 'modules', row.id.replace(/^loadout\./, '') + '.module.json'), 'utf8')));
  return { registry, manifests };
}
test('validates every bundled first-party module, route and service contract', () => {
  const { registry, manifests } = fixtures();
  const result = validateModuleRegistry(registry, manifests, { runtimeApi: '1.5.0' });
  assert.equal(result.valid, true); assert.equal(result.moduleCount, 7); assert.equal(result.offlineModuleCount, 7); assert.ok(result.serviceCount > 10);
});
test('rejects unregistered module manifests and duplicate routes/services', () => {
  const { registry, manifests } = fixtures();
  const bad = structuredClone(registry); bad.modules[1].route = bad.modules[0].route;
  assert.throws(() => validateModuleRegistry(bad, manifests), /Duplicate module route/);
  const duplicate = structuredClone(registry); duplicate.modules[1].services.push(duplicate.modules[0].services[0]);
  assert.throws(() => validateModuleRegistry(duplicate, manifests), /provided by multiple modules/);
});
test('resolves module dependencies and rejects missing modules, version mismatch and cycles', () => {
  const { registry, manifests } = fixtures();
  const a = manifests.find(x => x.id === 'loadout.ai-coach'); const b = manifests.find(x => x.id === 'loadout.data-settings');
  a.dependencies = [{ id: b.id, version: b.version }];
  const valid = validateModuleRegistry(registry, manifests);
  assert.ok(valid.orderedModuleIds.indexOf(b.id) < valid.orderedModuleIds.indexOf(a.id));
  a.dependencies = ['loadout.unknown']; assert.throws(() => validateModuleRegistry(registry, manifests), /unregistered module/);
  a.dependencies = [{ id: b.id, version: '99.0.0' }]; assert.throws(() => validateModuleRegistry(registry, manifests), /version mismatch/);
  a.dependencies = [b.id]; b.dependencies = [a.id]; assert.throws(() => validateModuleRegistry(registry, manifests), /cycle/);
});
