import test from 'node:test';
import assert from 'node:assert/strict';
import { applyLtlOperation, applyLtlOperations, sha256, isSafeRelativePath, orderLtlOperations, stableStringify } from '../../src/core/ltl.js';
const base = (op, extra = {}) => ({ id: 'op-test-1', op, description: 'Unit test operation', risk: 'low', dependencies: [], validation: ['postcondition'], failureAction: 'reject transaction', recovery: 'discard staged transaction', ...extra });

test('safe paths reject traversal, absolute paths, drive paths and backslashes', () => {
  assert.equal(isSafeRelativePath('packs/jee/profile.json'), true);
  for (const path of ['../secret', '/tmp/a', 'C:/secret', 'a\\b', 'a//b', 'a/./b', 'a/../b', '']) assert.equal(isSafeRelativePath(path), false, path);
});
test('ADD/REPLACE/PATCH/REMOVE preserve declarative semantics', () => {
  const state = { settings: { theme: 'dark' }, policies: {}, dependencies: {}, tags: ['a'] };
  applyLtlOperation(state, base('ADD', { path: '/settings/density', value: 'compact' }));
  applyLtlOperation(state, base('REPLACE', { path: '/settings/theme', value: 'navy' }));
  applyLtlOperation(state, base('PATCH', { path: '/tags', action: 'append', value: 'b' }));
  applyLtlOperation(state, base('PATCH', { path: '/settings', action: 'merge', value: { compactMode: true } }));
  applyLtlOperation(state, base('REMOVE', { path: '/settings/density' }));
  assert.deepEqual(state, { settings: { theme: 'navy', compactMode: true }, policies: {}, dependencies: {}, tags: ['a', 'b'] });
});
test('array ADD, REPLACE, MOVE and REMOVE use JSON Pointer indices safely', () => {
  const state = { rows: ['a', 'b', 'c'] };
  applyLtlOperation(state, base('ADD', { path: '/rows/1', value: 'x' }));
  applyLtlOperation(state, base('REPLACE', { path: '/rows/0', value: 'A' }));
  applyLtlOperation(state, base('MOVE', { from: '/rows/1', to: '/rows/4' }));
  applyLtlOperation(state, base('REMOVE', { path: '/rows/0' }));
  assert.deepEqual(state.rows, ['b', 'c', 'x']);
});
test('RENAME/MOVE object paths preserve values and reject self-descendant moves', () => {
  const state = { settings: { oldName: { enabled: true } } };
  applyLtlOperation(state, base('RENAME', { from: '/settings/oldName', to: '/settings/newName' }));
  assert.deepEqual(state.settings, { newName: { enabled: true } });
  assert.throws(() => applyLtlOperation(state, base('MOVE', { from: '/settings/newName', to: '/settings/newName/child' })), /descendant/);
});
test('RECONFIGURE, CHANGE_POLICY and REWIRE are namespaced operations', () => {
  const state = { settings: {}, policies: {}, dependencies: {} };
  applyLtlOperation(state, base('RECONFIGURE', { path: '/density', value: 'compact' }));
  applyLtlOperation(state, base('CHANGE_POLICY', { path: '/cache', value: { ttlMs: 1000 } }));
  applyLtlOperation(state, base('REWIRE', { path: '/services', value: ['storage.v1'] }));
  assert.deepEqual(state, { settings: { density: 'compact' }, policies: { cache: { ttlMs: 1000 } }, dependencies: { services: ['storage.v1'] } });
});
test('dependency install/remove is validated and blocks declared dependants', () => {
  const state = { dependencies: {} };
  applyLtlOperation(state, base('INSTALL_DEPENDENCY', { dependencyId: 'storage.api', version: '1.2.0' }));
  state.moduleDependencies = { 'loadout.ai-coach': ['storage.api'] };
  assert.throws(() => applyLtlOperation(state, base('REMOVE_DEPENDENCY', { dependencyId: 'storage.api' })), /still required/);
  delete state.moduleDependencies;
  applyLtlOperation(state, base('REMOVE_DEPENDENCY', { dependencyId: 'storage.api' }));
  assert.deepEqual(state.dependencies, {});
});
test('MIGRATE runs bounded declarative nested steps only', () => {
  const state = { settings: { old: true } };
  const step = base('RENAME', { id: 'nested-rename', from: '/settings/old', to: '/settings/new' });
  applyLtlOperation(state, base('MIGRATE', { steps: [step] }));
  assert.deepEqual(state, { settings: { new: true } });
  assert.throws(() => applyLtlOperation(state, base('MIGRATE', { steps: [base('ACTIVATE', { id: 'nested-activate' })] })), /nested ACTIVATE/);
});
test('VALIDATE checks existence, type, equality and hash assertions', () => {
  const state = { settings: { mode: 'dark' }, rows: [1, 2] };
  applyLtlOperation(state, base('VALIDATE', { assert: { path: '/settings/mode', equals: 'dark' } }));
  applyLtlOperation(state, base('VALIDATE', { assert: { path: '/rows', type: 'array', minLength: 2 } }));
  assert.throws(() => applyLtlOperation(state, base('VALIDATE', { assert: { path: '/settings/mode', equals: 'light' } })), /equality assertion/);
  assert.throws(() => applyLtlOperation(state, base('VALIDATE', { assert: {} })), /JSON Pointer path/);
});
test('PATCH_SOURCE requires exact hash, safe text resource and unique guarded anchor', () => {
  const file = 'Title\nOld heading\nTail'; const files = { 'pack/readme.md': file };
  const op = base('PATCH_SOURCE', { file: 'pack/readme.md', expectedSha256: sha256(file), anchor: 'Old heading', replacement: 'New heading', expectedOccurrences: 1 });
  applyLtlOperation({}, op, files);
  assert.equal(files['pack/readme.md'], 'Title\nNew heading\nTail');
});
test('PATCH_SOURCE rejects stale preimage, executable source and ambiguous anchors', () => {
  const files = { 'app.js': 'alert(1)', 'readme.md': 'same same' };
  assert.throws(() => applyLtlOperation({}, base('PATCH_SOURCE', { file: 'readme.md', expectedSha256: '0'.repeat(64), anchor: 'same', replacement: 'changed' }), files), /preimage/);
  assert.throws(() => applyLtlOperation({}, base('PATCH_SOURCE', { file: 'app.js', expectedSha256: sha256('alert(1)'), anchor: 'alert', replacement: 'x' }), files), /non-executable/);
  assert.throws(() => applyLtlOperation({}, base('PATCH_SOURCE', { file: 'readme.md', expectedSha256: sha256('same same'), anchor: 'same', replacement: 'x', expectedOccurrences: 1 }), files), /found 2/);
});
test('operation metadata, duplicate IDs, missing dependencies and cycles are rejected', () => {
  assert.throws(() => applyLtlOperation({}, { op: 'REMOVE', path: '/settings/a' }), /unique safe id/);
  assert.throws(() => orderLtlOperations([base('VALIDATE', { dependencies: ['missing'] })]), /missing operation/);
  const a = base('VALIDATE', { id: 'a', dependencies: ['b'] }); const b = base('VALIDATE', { id: 'b', dependencies: ['a'] });
  assert.throws(() => orderLtlOperations([a, b]), /cycle/);
  assert.throws(() => orderLtlOperations([base('VALIDATE'), base('VALIDATE')]), /Duplicate/);
});
test('operations execute in dependency order and produce a reviewable impact report', () => {
  const second = base('ADD', { id: 'add-second', dependencies: ['add-first'], path: '/settings/b', value: 2, risk: 'medium' });
  const first = base('ADD', { id: 'add-first', path: '/settings/a', value: 1 });
  const result = applyLtlOperations({ settings: {} }, [second, first]);
  assert.deepEqual(result.applied, ['add-first', 'add-second']);
  assert.deepEqual(result.state, { settings: { a: 1, b: 2 } });
  assert.equal(result.impact.operationCount, 2);
  assert.equal(result.impact.manualApprovalRequired, true);
});
test('preconditions reject stale state before mutation', () => {
  const state = { settings: { theme: 'dark' } };
  const op = base('REPLACE', { path: '/settings/theme', value: 'light', precondition: { path: '/settings/theme', equals: 'blue' } });
  assert.throws(() => applyLtlOperation(state, op), /precondition failed/);
  assert.equal(stableStringify(state), '{"settings":{"theme":"dark"}}');
});
test('JSON pointer blocks prototype-pollution keys and invalid escapes', () => {
  const state = { settings: {} };
  assert.throws(() => applyLtlOperation(state, base('ADD', { path: '/settings/__proto__/polluted', value: true })), /Unsafe JSON pointer key/);
  assert.throws(() => applyLtlOperation(state, base('ADD', { path: '/settings/bad~2key', value: true })), /Invalid JSON pointer escape/);
  assert.equal({}.polluted, undefined);
});
