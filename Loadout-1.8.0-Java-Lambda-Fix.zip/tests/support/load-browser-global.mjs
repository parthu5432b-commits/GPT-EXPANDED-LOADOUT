// Minimal browser global only for testing classic-script feature modules.
if (!globalThis.window) globalThis.window = globalThis;
