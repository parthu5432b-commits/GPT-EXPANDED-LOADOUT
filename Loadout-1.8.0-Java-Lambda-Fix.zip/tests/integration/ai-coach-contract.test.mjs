import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

function loadRuntime(plugin) {
  const sandbox = { console, Date, Math, Map, Set, Object, String, Number, Boolean, RegExp, Error, Promise, JSON, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, URL, URLSearchParams, AbortController, setTimeout, clearTimeout, crypto: globalThis.crypto };
  sandbox.window = sandbox;
  sandbox.Capacitor = { Plugins: { LoadoutCore: plugin }, isPluginAvailable: name => name === 'LoadoutCore', getPlatform: () => 'android' };
  vm.createContext(sandbox);
  const source = fs.readFileSync(path.join(ROOT, 'www/runtime/loadout-runtime.js'), 'utf8');
  vm.runInContext(source, sandbox, { filename: 'www/runtime/loadout-runtime.js' });
  return sandbox.Loadout;
}

test('Android AI transport forwards only request-scoped native SSE chunks and unregisters listener', async () => {
  const listeners = new Set();
  let listenerRemoved = false;
  let requestArgs;
  const plugin = {
    setSecret: async () => ({}), hasSecret: async () => ({ available: true }), deleteSecret: async () => ({}),
    addListener: async (eventName, callback) => {
      assert.equal(eventName, 'aiProviderChunk');
      listeners.add(callback);
      return { remove: async () => { listenerRemoved = true; listeners.delete(callback); } };
    },
    requestAiProvider: async args => {
      requestArgs = args;
      for (const callback of listeners) {
        callback({ requestId: 'other-request', text: 'ignore' });
        callback({ requestId: args.requestId, text: 'token ' });
        callback({ requestId: args.requestId, text: 'delta' });
      }
      return { status: 200, streamed: true, body: '', requestId: args.requestId };
    },
    cancelAiProviderRequest: async () => ({ cancelled: true })
  };
  const runtime = loadRuntime(plugin);
  assert.equal(runtime.aiTransport.nativeAvailable, true);
  const chunks = [];
  const result = await runtime.aiTransport.request({
    credentialId: 'ai-gemini', requestId: 'request-123', url: 'https://provider.example/v1/stream',
    body: '{"stream":true}', authMode: 'google-api-key', providerKind: 'gemini', stream: true, onChunk: chunk => chunks.push(chunk)
  });
  assert.equal(result.streamed, true);
  assert.deepEqual(chunks, ['token ', 'delta']);
  assert.equal(requestArgs.credentialId, 'ai-gemini');
  assert.equal(requestArgs.stream, true);
  assert.equal(requestArgs.providerKind, 'gemini');
  assert.equal(Object.hasOwn(requestArgs, 'apiKey'), false);
  assert.equal(listenerRemoved, true);
  assert.equal(listeners.size, 0);
});

test('AI Coach persisted profile snapshots and conversation exports do not contain credentials', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/modules/ai-coach/ai-coach.js'), 'utf8');
  const sandbox = { console, Date, Math, Map, Set, Object, String, Number, Boolean, RegExp, Error, JSON, URL, URLSearchParams, TextEncoder };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 'www/modules/ai-coach/ai-coach.js' });
  const module = sandbox.LoadoutModules.aiCoach;
  const safe = module.chatStorageSnapshot({
    provider: 'custom', profiles: { custom: { baseUrl: 'https://api.example/v1', model: 'test-model', apiKey: 'DO-NOT-PERSIST' } },
    conversations: [{ id: 'c1', title: 'test', messages: [{ id: 'm1', role: 'user', content: 'hello', apiKey: 'DO-NOT-PERSIST' }] }]
  });
  const serialized = JSON.stringify(safe);
  assert.equal(serialized.includes('DO-NOT-PERSIST'), false);
  assert.equal(serialized.includes('apiKey'), false);
  assert.equal(safe.conversations[0].messages[0].content, 'hello');
});

test('native Android transport keeps API credentials inside Keystore and supports SSE event forwarding', () => {
  const native = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  assert.match(native, /readSecretValue\(credentialId, address\)/);
  assert.doesNotMatch(native, /public void getSecret\(PluginCall call\)/);
  assert.match(native, /readAiEventStream\(response, requestId, providerKind\)/);
  assert.match(native, /notifyListeners\("aiProviderChunk", chunk\)/);
  assert.match(native, /cancelledAiRequests\.contains\(requestId\)/);
  assert.match(native, /setInstanceFollowRedirects\(false\)/);
  assert.match(native, /validateAiEndpoint\(address\)/);
  const saveMethod = native.slice(native.indexOf('public void setSecret'), native.indexOf('private String normalizedAiOrigin'));
  assert.doesNotMatch(saveMethod, /validateAiEndpoint/);
  assert.match(saveMethod, /getRawQuery/);
  const endpointValidator = native.slice(native.indexOf('private void validateAiEndpoint'), native.indexOf('private String readBounded'));
  assert.match(endpointValidator, /alt=sse/);
});

test('provider connection test explicitly excludes private study and conversation context', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /AI_COACH\.buildConnectionTestRequest\(providerId, profile\)/);
  assert.match(source, /No conversation history or study data will be included/);
  assert.match(source, /chat-test-provider/);
});

test('AI Coach exposes distinct clear-current and clear-all flows with separate confirmations', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /id="chat-clear-current"/);
  assert.match(source, /id="chat-clear-all"/);
  assert.match(source, /Delete ALL/);
  assert.match(source, /Other conversations and provider settings will remain/);
  assert.match(source, /Provider endpoint\/model settings and secure API credentials will remain/);
});

test('destructive AI Coach conversation mutations are snapshot-first and persistence-verified', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /function cloneChatStateForRollback\(\)/);
  assert.match(source, /async function rollbackChatMutation\(previous, message\)/);
  assert.match(source, /return saveChatState\(\);\s*}\s*async function rollbackChatMutation/);
  assert.match(source, /if \(!\(await touchConversation\(\)\)\) \{ await rollbackChatMutation\(previous/);
  assert.match(source, /if \(!\(await saveChatState\(\)\)\) \{ await rollbackChatMutation\(previous/);
  assert.match(source, /Message deletion was not saved/);
  assert.match(source, /Conversation clearing was not saved/);
  assert.match(source, /Conversation deletion was not saved/);
  assert.match(source, /Message edit was not saved/);
  assert.match(source, /Retry preparation was not saved/);
});

test('AI Coach persists its user and assistant placeholder before provider transmission', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  const start = source.indexOf('async function sendChat(');
  const end = source.indexOf('async function stopChatGeneration', start);
  assert.ok(start >= 0 && end > start);
  const body = source.slice(start, end);
  const saveAt = body.indexOf('if (!(await touchConversation()))');
  const requestAt = body.indexOf('invokeChatProvider(');
  assert.ok(saveAt >= 0 && requestAt > saveAt, 'provider call must follow verified local persistence');
  assert.match(body, /Message not sent: local conversation storage verification failed/);
});

test('Android secure credentials are cryptographically bound to the exact HTTPS provider origin', async () => {
  let saved = null;
  const plugin = {
    setSecret: async args => { saved = args; return { ok: true }; },
    hasSecret: async () => ({ available: true, originBound: true, origin: 'https://api.example.com' }),
    deleteSecret: async () => ({ ok: true }),
    addListener: async () => ({ remove: async () => {} }),
    requestAiProvider: async () => ({ status: 200, body: '{}', streamed: false }),
    cancelAiProviderRequest: async () => ({ cancelled: true })
  };
  const runtime = loadRuntime(plugin);
  await runtime.secrets.set('ai-custom', 'secret-value', 'https://api.example.com/');
  assert.equal(saved.origin, 'https://api.example.com');
  assert.equal(saved.value, 'secret-value');
  assert.equal(await runtime.secrets.has('ai-custom', 'https://api.example.com'), true);
  assert.equal(await runtime.secrets.has('ai-custom', 'https://evil.example'), false);
  await assert.rejects(runtime.secrets.set('ai-custom', 'secret-value', 'http://api.example.com'), /HTTPS origin/);
});

test('native Keystore record binds AES-GCM AAD and provider request to the exact saved origin', () => {
  const native = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  assert.match(native, /normalizedAiOrigin\(originInput\)/);
  assert.match(native, /cipher\.updateAAD\(\(id \+ "\|" \+ origin\)/);
  assert.match(native, /record\.put\("version", 2\)/);
  assert.match(native, /origin\.equals\(expectedOrigin\)/);
  assert.match(native, /readSecretValue\(credentialId, address\)/);
  assert.match(native, /Legacy credential is not endpoint-bound/);
});


test('AI Coach periodically persists streamed output and flushes the final pending chunk before completion', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /function scheduleChatStreamPersistence\(request\)/);
  assert.match(source, /function scheduleChatStreamPaint\(request\)/);
  assert.match(source, /await flushChatStreamPersistence\(requestState\)/);
  assert.match(source, /1200\);/);
  assert.match(source, /const appended = AI_COACH\.appendStreamText/);
});

test('credential storage remains offline-capable but provider requests reject unapproved query strings', () => {
  const native = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  const saveMethod = native.slice(native.indexOf('public void setSecret'), native.indexOf('private String normalizedAiOrigin'));
  assert.doesNotMatch(saveMethod, /InetAddress|getAllByName|validateAiEndpoint/);
  const endpointValidator = native.slice(native.indexOf('private void validateAiEndpoint'), native.indexOf('private String readBounded'));
  assert.match(endpointValidator, /alt=sse/);
  assert.match(endpointValidator, /Provider endpoint query parameters are not supported/);
});


test('corrupt legacy chat bytes stay preserved and are explicitly exportable', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /const CHAT_CORRUPT_MARKER_KEY = 'loadout_chat_corrupt_quarantine_v1'/);
  assert.match(source, /function detectCorruptLegacyChatRecord\(\)/);
  assert.match(source, /function rememberCorruptChatRecord\(sourceKey, raw\)/);
  assert.match(source, /chatCorruptArchives\.push\(\{ sourceKey, raw \}\)/);
  assert.match(source, /if \(saved && allLegacyKeysSecured && chatCorruptArchives\.length === 0\)/);
  assert.match(source, /wouldOverwriteCorruptV4/);
  assert.match(source, /function acknowledgeCorruptChatExport\(\)/);
  assert.match(source, /function downloadUnreadableChatArchive\(\)/);
  assert.match(source, /id="chat-export-corrupt"/);
  assert.match(source, /id="chat-ack-corrupt-export"/);
  assert.match(source, /The archive may contain old provider credentials/);
});

test('AI Coach recovers stale streaming records before migration persistence', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  const start = source.indexOf('async function initializeChatStorage()');
  const end = source.indexOf('async function hydrateChatFromPrivateMirror()', start);
  const body = source.slice(start, end);
  assert.match(body, /AI_COACH\.recoverInterruptedStreams\(chatState\)/);
  assert.ok(body.indexOf('recoverInterruptedStreams') < body.indexOf('const saved = await saveChatState()'));
});


test('native AI transport stops an already-aborted request before dispatch and always removes SSE listeners', async () => {
  let dispatches = 0;
  let removed = false;
  const plugin = {
    setSecret: async () => ({}), hasSecret: async () => ({ available: true, originBound: true }), deleteSecret: async () => ({}),
    addListener: async () => ({ remove: async () => { removed = true; } }),
    requestAiProvider: async () => { dispatches++; return { status: 200, body: '{}', streamed: false }; },
    cancelAiProviderRequest: async () => ({ cancelled: true })
  };
  const runtime = loadRuntime(plugin);
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(runtime.aiTransport.request({
    credentialId: 'ai-gemini', requestId: 'aborted-before-dispatch', url: 'https://provider.example/v1',
    body: '{}', signal: controller.signal, onChunk: () => {}
  }), error => error?.name === 'AbortError');
  assert.equal(dispatches, 0);
  assert.equal(removed, true);
});

test('native cancellation registers pending request IDs before executor dispatch and ignores unknown IDs', () => {
  const native = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  const request = native.slice(native.indexOf('public void requestAiProvider'), native.indexOf('@PluginMethod', native.indexOf('public void requestAiProvider') + 1));
  const cancel = native.slice(native.indexOf('public void cancelAiProviderRequest'), native.indexOf('@PluginMethod', native.indexOf('public void cancelAiProviderRequest') + 1));
  assert.match(request, /if \(!pendingAiRequests\.add\(requestId\)\)/);
  assert.match(native, /Semaphore aiRequestSlots = new Semaphore\(4\)/);
  assert.match(request, /if \(!aiRequestSlots\.tryAcquire\(\)\)/);
  assert.match(request, /aiRequestSlots\.release\(\)/);
  assert.ok(request.indexOf('pendingAiRequests.add(requestId)') < request.indexOf('aiExecutor.execute'));
  assert.match(request, /pendingAiRequests\.remove\(requestId\)/);
  assert.match(request, /cancelledAiRequests\.remove\(requestId\)/);
  assert.match(cancel, /boolean knownRequest = pendingAiRequests\.contains\(requestId\)/);
  assert.match(cancel, /if \(knownRequest\) cancelledAiRequests\.add\(requestId\)/);
  assert.match(cancel, /result\.put\("cancelled", knownRequest\)/);
});

test('browser AI transport treats every non-2xx response as an error even when content type is SSE', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  const start = source.indexOf('async function invokeChatProvider(');
  const end = source.indexOf('async function testChatProviderConnection', start);
  const body = source.slice(start, end);
  assert.match(body, /if \(!response\.ok\)\s*\{/);
  assert.doesNotMatch(body, /if \(!response\.ok && !response\.headers/);
  assert.ok(body.indexOf('if (!response.ok)') < body.indexOf('await readResponseText(response, providerId, onDelta)'));
});

test('private corrupt-chat archives are rediscovered even when the local marker is missing', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  const start = source.indexOf('async function restorePrivateCorruptChatArchives()');
  const end = source.indexOf('function loadChatState()', start);
  const body = source.slice(start, end);
  assert.match(body, /for \(const sourceKey of \[CHAT_STORAGE_KEY, \.\.\.PREVIOUS_CHAT_KEYS\]\)/);
  assert.doesNotMatch(body, /const sourceKeys = Array\.isArray\(marker\?\.sourceKeys\)/);
});

test('AI Coach backup import cap matches the maximum persisted chat-store cap', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /if \(file\.size > 24 \* 1024 \* 1024\) throw new Error\('Chat backup exceeds the 24 MiB import limit\.'\)/);
});


test('native AI transport cancels the exact in-flight request when AbortSignal fires', async () => {
  let resolveRequest;
  const cancelled = [];
  const plugin = {
    setSecret: async () => ({}), hasSecret: async () => ({ available: true }), deleteSecret: async () => ({}),
    requestAiProvider: async args => new Promise(resolve => { resolveRequest = () => resolve({ status: 499, streamed: false, body: '', requestId: args.requestId }); }),
    cancelAiProviderRequest: async ({ requestId }) => { cancelled.push(requestId); if (resolveRequest) resolveRequest(); return { cancelled: true }; }
  };
  const runtime = loadRuntime(plugin);
  const controller = new AbortController();
  const pending = runtime.aiTransport.request({
    credentialId: 'ai-gemini', requestId: 'abort-in-flight-1', url: 'https://provider.example/v1/stream',
    body: '{}', authMode: 'google-api-key', stream: false, signal: controller.signal
  });
  await Promise.resolve();
  controller.abort();
  await pending;
  assert.deepEqual(cancelled, ['abort-in-flight-1']);
});

test('browser SSE reader flushes the same UTF-8 decoder before parsing its final event', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /parser\.push\(decoder\.decode\(\)\);\s*parser\.finish\(\);/);
  assert.doesNotMatch(source, /parser\.push\(new TextDecoder\(\)\.decode\(\)\)/);
});

test('retry handler uses the same retry eligibility rule that renders cancelled-message retry controls', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /if \(AI_COACH\.canRetryMessage\(message, action\)\)/);
  assert.match(source, /message\.status === 'error' \|\| message\.status === 'cancelled'/);
});

test('provider save path validates endpoint query parameters before persistence', () => {
  const source = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
  assert.match(source, /normalizedBaseUrl = AI_COACH\.validateProviderBaseUrl\(url\)/);
  assert.match(source, /baseUrl: normalizedBaseUrl/);
  assert.match(source, /signal: controller\.signal/);
});
