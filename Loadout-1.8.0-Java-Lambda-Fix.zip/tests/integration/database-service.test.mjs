import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { webcrypto, createHash } from 'node:crypto';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const STATE_KEY = 'main-study-state';

class FakeSQLiteBridge {
  constructor() {
    this.schemaVersion = 0;
    this.migrations = [];
    this.migrationRows = [];
    this.stateRow = null;
    this.dropAttemptWrites = false;
    this.attempts = [];
    this.forecasts = [];
    this.snapshots = [];
    this.conflicts = [];
    this.moduleRecords = new Map();
    this.legacyImports = new Map();
  }
  async databaseMigrate(name, migrations) {
    assert.equal(name, 'loadout-main');
    this.migrations = structuredClone(migrations);
    this.migrationRows = migrations.map(migration => ({
      version: migration.version,
      migration_id: migration.id,
      checksum: createHash('sha256').update(`${migration.version}|${migration.id}|${migration.statements.join('\n')}`).digest('hex')
    }));
    this.schemaVersion = migrations.at(-1).version;
    return { ok: true, schemaVersion: this.schemaVersion, migrationsApplied: migrations.length };
  }
  async databaseExecuteBatch(name, statements) {
    assert.equal(name, 'loadout-main');
    const snapshot = structuredClone({ stateRow: this.stateRow, attempts: this.attempts, forecasts: this.forecasts, snapshots: this.snapshots, conflicts: this.conflicts, moduleRecords: Array.from(this.moduleRecords.entries()), legacyImports: Array.from(this.legacyImports.entries()) });
    try {
      for (const { sql, args = [] } of statements) {
        if (sql.startsWith('INSERT OR REPLACE INTO app_state')) {
          this.stateRow = { state_key: args[0], schema_version: args[1], payload_json: args[2], payload_sha256: args[3], updated_at: args[4], revision: args[5], source_kind: args[6] };
        } else if (sql === 'DELETE FROM test_attempts') this.attempts = [];
        else if (sql === 'DELETE FROM forecasts') this.forecasts = [];
        else if (sql.startsWith('INSERT INTO test_attempts')) {
          if (this.dropAttemptWrites) continue;
          const keys = ['id','test_id','date','type','score','n','correct','wrong','unattempted','minutes','payload_json','created_at','source_kind'];
          this.attempts.push(Object.fromEntries(keys.map((key, index) => [key, args[index]])));
        } else if (sql.startsWith('INSERT INTO forecasts')) {
          const keys = ['id','test_id','type','date','raw_score','calibrated_score','payload_json','created_at','source_kind'];
          this.forecasts.push(Object.fromEntries(keys.map((key, index) => [key, args[index]])));
        } else if (sql.startsWith('INSERT OR REPLACE INTO legacy_imports')) {
          this.legacyImports.set(args[0], { source_key: args[0], source_sha256: args[1], record_count: args[2], imported_at: args[3] });
        } else if (sql.startsWith('INSERT INTO recovery_snapshots')) {
          this.snapshots.push({ id: args[0], source_key: args[1], payload_json: args[2], payload_sha256: args[3], created_at: args[4], reason: args[5] });
        } else if (sql.startsWith('INSERT INTO migration_conflicts')) {
          this.conflicts.push({ id: args[0], record_key: args[1], local_sha256: args[2], database_sha256: args[3], created_at: args[4], resolution: args[5] });
        } else if (sql.startsWith('INSERT OR REPLACE INTO module_records')) {
          this.moduleRecords.set(`${args[0]}::${args[1]}`, { module_id: args[0], record_key: args[1], schema_version: args[2], payload_json: args[3], payload_sha256: args[4], updated_at: args[5] });
        } else {
          throw new Error(`Fake SQLite bridge received unsupported SQL: ${sql}`);
        }
      }
      return { ok: true, statementsExecuted: statements.length };
    } catch (error) {
      this.stateRow = snapshot.stateRow;
      this.attempts = snapshot.attempts;
      this.forecasts = snapshot.forecasts;
      this.snapshots = snapshot.snapshots;
      this.conflicts = snapshot.conflicts;
      this.moduleRecords = new Map(snapshot.moduleRecords);
      this.legacyImports = new Map(snapshot.legacyImports);
      throw error;
    }
  }
  async databaseQuery(name, sql, args = []) {
    assert.equal(name, 'loadout-main');
    if (sql.includes('FROM app_state WHERE')) return { rows: this.stateRow ? [{ ...this.stateRow }] : [] };
    if (sql === 'SELECT id,payload_json FROM test_attempts') return { rows: this.attempts.map(({ id, payload_json }) => ({ id, payload_json })) };
    if (sql === 'SELECT id,payload_json FROM forecasts') return { rows: this.forecasts.map(({ id, payload_json }) => ({ id, payload_json })) };
    if (sql === 'SELECT version,migration_id,checksum FROM schema_migrations ORDER BY version') return { rows: this.migrationRows.map(row => ({ ...row })) };
    if (sql.includes('FROM module_records')) {
      const row = this.moduleRecords.get(`${args[0]}::${args[1]}`);
      return { rows: row ? [{ payload_json: row.payload_json, payload_sha256: row.payload_sha256, schema_version: row.schema_version, updated_at: row.updated_at }] : [] };
    }
    throw new Error(`Fake SQLite bridge received unsupported query: ${sql}`);
  }
  async databaseInfo() { return { available: true, schemaVersion: this.schemaVersion, bytes: 4096, private: true }; }
}

function loadDatabase(bridge = new FakeSQLiteBridge()) {
  const sandbox = { console, crypto: webcrypto, TextEncoder, Uint8Array, Date, Math, Promise, JSON, Map, Set, Object, String, Number, Boolean, RegExp, Error, structuredClone };
  sandbox.window = sandbox;
  sandbox.Loadout = { native: { databaseAvailable: true, databaseMigrate: (...args) => bridge.databaseMigrate(...args), databaseExecuteBatch: (...args) => bridge.databaseExecuteBatch(...args), databaseQuery: (...args) => bridge.databaseQuery(...args), databaseInfo: (...args) => bridge.databaseInfo(...args) } };
  vm.createContext(sandbox);
  for (const relative of ['www/runtime/database-schema.js', 'www/runtime/database-model.js', 'www/runtime/database.js']) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, relative), 'utf8'), sandbox, { filename: relative });
  }
  return { api: sandbox.LoadoutDatabase, bridge, sandbox };
}

const validState = () => ({
  settings: { correctMarks: 4, wrongMarks: -1 },
  attempts: [{ id: 'attempt-1', testId: 'QFT-1', type: 'QFT', date: '2026-11-18', score: 11, n: 4, correct: 3, wrong: 1, unattempted: 0, minutes: 30 }],
  forecasts: [{ id: 'forecast-1', testId: 'QFT-1', type: 'QFT', raw: 10, calibrated: 11, savedOn: '2026-11-18T10:00:00.000Z' }]
});

async function sha256(value) {
  const digest = await webcrypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
}

test('native SQLite contract applies ordered migrations and bootstraps a verifiable legacy snapshot', async () => {
  const runtime = loadDatabase();
  const result = await runtime.api.bootstrap(validState(), JSON.stringify(validState()));
  assert.equal(result.backend, 'sqlite');
  assert.equal(result.schemaVersion, 2);
  assert.deepEqual(Array.from(runtime.bridge.migrations, migration => migration.version), [1, 2]);
  assert.equal(runtime.bridge.stateRow.state_key, STATE_KEY);
  assert.equal(runtime.bridge.attempts.length, 1);
  assert.equal(runtime.bridge.forecasts.length, 1);
  const verified = await runtime.api.verify();
  assert.equal(verified.ok, true);
  assert.equal(verified.attempts, 1);
  assert.equal(verified.forecasts, 1);
  assert.equal(verified.migrations, 2);
});

test('verification checks each indexed row payload, not only aggregate counts', async () => {
  const runtime = loadDatabase();
  await runtime.api.bootstrap(validState(), JSON.stringify(validState()));
  runtime.bridge.attempts[0].payload_json = JSON.stringify({ id: 'attempt-1', tampered: true });
  await assert.rejects(runtime.api.verify(), /Test-attempt index payload mismatch/);
});

test('verification rejects altered or unexpected migration history rows', async () => {
  const runtime = loadDatabase();
  await runtime.api.bootstrap(validState(), JSON.stringify(validState()));
  runtime.bridge.migrationRows[1].checksum = '00'.repeat(32);
  await assert.rejects(runtime.api.verify(), /Migration history integrity mismatch/);
  runtime.bridge.migrationRows[1].checksum = createHash('sha256').update(`${runtime.bridge.migrations[1].version}|${runtime.bridge.migrations[1].id}|${runtime.bridge.migrations[1].statements.join('\n')}`).digest('hex');
  runtime.bridge.migrationRows.push({ version: 3, migration_id: 'unexpected', checksum: 'ff'.repeat(32) });
  await assert.rejects(runtime.api.verify(), /missing or unexpected entries/);
});

test('a committed batch is not reported as verified until every indexed row reads back', async () => {
  const bridge = new FakeSQLiteBridge();
  bridge.dropAttemptWrites = true;
  const runtime = loadDatabase(bridge);
  await assert.rejects(runtime.api.bootstrap(validState(), JSON.stringify(validState())), /Test-attempt index row count/);
  assert.equal(bridge.stateRow.payload_json, JSON.stringify(validState()));
  assert.equal(bridge.attempts.length, 0);
});

test('structured database revisions increase monotonically for each successful write', async () => {
  const runtime = loadDatabase();
  await runtime.api.bootstrap(validState(), JSON.stringify(validState()));
  assert.equal(runtime.bridge.stateRow.revision, 1);
  const next = validState(); next.settings.testRevision = 2;
  const result = await runtime.api.enqueueSync(next);
  await runtime.api.flush();
  assert.equal(result.revision, 2);
  assert.equal(runtime.bridge.stateRow.revision, 2);
  assert.equal((await runtime.api.verify()).ok, true);
});

test('legacy divergence is archived and checksummed before the structured state is reconciled', async () => {
  const bridge = new FakeSQLiteBridge();
  const legacy = validState();
  const earlier = { ...validState(), attempts: [{ id: 'attempt-old', n: 1, correct: 1, wrong: 0, unattempted: 0 }] };
  const earlierJson = JSON.stringify(earlier);
  bridge.stateRow = { state_key: STATE_KEY, schema_version: 1, payload_json: earlierJson, payload_sha256: await sha256(earlierJson), revision: 1, updated_at: '2026-01-01T00:00:00.000Z', source_kind: 'previous' };
  const runtime = loadDatabase(bridge);
  const result = await runtime.api.bootstrap(legacy, JSON.stringify(legacy));
  assert.equal(result.archivedConflict, true);
  assert.equal(bridge.snapshots.length, 1);
  assert.equal(bridge.conflicts.length, 1);
  assert.equal(bridge.snapshots[0].payload_json, earlierJson);
  assert.equal(bridge.snapshots[0].payload_sha256, await sha256(earlierJson));
  assert.equal((await runtime.api.verify()).attempts, 1);
});

test('invalid legacy state is rejected without altering the pre-existing structured row', async () => {
  const bridge = new FakeSQLiteBridge();
  const before = { state_key: STATE_KEY, schema_version: 1, payload_json: '{"retained":true}', payload_sha256: 'not-used', revision: 7, updated_at: '2026-01-01T00:00:00.000Z', source_kind: 'old' };
  bridge.stateRow = { ...before };
  const runtime = loadDatabase(bridge);
  const invalid = validState(); invalid.attempts[0].wrong = 2;
  await assert.rejects(runtime.api.bootstrap(invalid, JSON.stringify(invalid)), /C \+ W \+ U = N/);
  assert.deepEqual(bridge.stateRow, before);
  assert.equal(bridge.attempts.length, 0);
});

test('database module records round-trip with checksum protection', async () => {
  const runtime = loadDatabase();
  await runtime.api.initialize();
  const data = { status: 'planned', completed: 12, notes: ['offline', 'preserve legacy'] };
  const stored = await runtime.api.addModuleRecord('loadout.chapter-map', 'chapter-state-v1', data, 2);
  assert.equal(stored.moduleId, 'loadout.chapter-map');
  assert.deepEqual(JSON.parse(JSON.stringify(await runtime.api.getModuleRecord('loadout.chapter-map', 'chapter-state-v1'))), data);
  const row = runtime.bridge.moduleRecords.get('loadout.chapter-map::chapter-state-v1');
  row.payload_json = JSON.stringify({ tampered: true });
  await assert.rejects(runtime.api.getModuleRecord('loadout.chapter-map', 'chapter-state-v1'), /checksum mismatch/);
});
