import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

function schemaManifest() {
  const sandbox = {};
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'www/runtime/database-schema.js'), 'utf8'), sandbox);
  return JSON.parse(JSON.stringify(sandbox.LoadoutDatabaseSchema));
}

test('schema migrations execute against SQLite and preserve a committed schema on failed upgrade', () => {
  const schema = schemaManifest();
  const plugin = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  const expectedHashes = [
    'd50edc00ef2a57662980f9b400c135e63667a80d6129373d52a3dbe99dad35e3',
    'e772478fd9783c98bb61e51db99d62bcf60b5109eca671342f686de7eb204017'
  ];
  for (const [index, migration] of schema.migrations.entries()) {
    const canonical = `${migration.version}|${migration.id}|${migration.statements.join('\n')}`;
    const checksum = createHash('sha256').update(canonical).digest('hex');
    assert.equal(checksum, expectedHashes[index], `migration ${migration.version} checksum changed`);
    assert.ok(plugin.includes(checksum), `native APK allowlist must contain checksum for ${migration.id}`);
  }
  const python = String.raw`
import json, sqlite3, sys
schema = json.load(sys.stdin)
db = sqlite3.connect(':memory:')
db.execute('PRAGMA foreign_keys=ON')
db.execute('CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY NOT NULL, migration_id TEXT NOT NULL UNIQUE, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)')
for migration in schema['migrations'][:1]:
    db.execute('BEGIN')
    try:
        for sql in migration['statements']:
            db.execute(sql)
        db.execute('INSERT INTO schema_migrations VALUES(?,?,?,?)', (migration['version'], migration['id'], 'verified', '2026-11-18T00:00:00.000Z'))
        db.execute('PRAGMA user_version=1')
        db.commit()
    except Exception:
        db.rollback(); raise
assert db.execute('PRAGMA user_version').fetchone()[0] == 1
assert db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0] >= 6
# Force a failure after one valid additive statement; transaction rollback must preserve v1.
failed = False
db.execute('BEGIN')
try:
    db.execute("ALTER TABLE app_state ADD COLUMN rollback_probe TEXT")
    db.execute('CREATE TABLE forbidden_migration_probe (id INTEGER PRIMARY KEY)')
    raise RuntimeError('simulated migration failure after partial DDL')
except RuntimeError:
    db.rollback(); failed = True
assert failed
cols = {row[1] for row in db.execute('PRAGMA table_info(app_state)')}
assert 'rollback_probe' not in cols
assert db.execute('PRAGMA user_version').fetchone()[0] == 1
assert db.execute('SELECT COUNT(*) FROM schema_migrations').fetchone()[0] == 1
# Apply the actual v2 DDL atomically.
migration = schema['migrations'][1]
db.execute('BEGIN')
try:
    for sql in migration['statements']:
        db.execute(sql)
    db.execute('INSERT INTO schema_migrations VALUES(?,?,?,?)', (migration['version'], migration['id'], 'verified', '2026-11-18T00:00:00.000Z'))
    db.execute('PRAGMA user_version=2')
    db.commit()
except Exception:
    db.rollback(); raise
assert db.execute('PRAGMA user_version').fetchone()[0] == 2
# Verify every application table can be written/read using the expected columns.
db.execute("INSERT INTO app_state(state_key,schema_version,payload_json,payload_sha256,updated_at,revision,source_kind) VALUES(?,?,?,?,?,?,?)", ('main-study-state',1,'{}','digest','2026-11-18T00:00:00.000Z',1,'test'))
db.execute("INSERT INTO test_attempts(id,test_id,type,payload_json,created_at,source_kind) VALUES(?,?,?,?,?,?)", ('a1','QFT-1','QFT','{}','2026-11-18T00:00:00.000Z','test'))
db.execute("INSERT INTO forecasts(id,test_id,type,payload_json,created_at,source_kind) VALUES(?,?,?,?,?,?)", ('f1','QFT-1','QFT','{}','2026-11-18T00:00:00.000Z','test'))
db.execute("INSERT INTO module_records(module_id,record_key,schema_version,payload_json,payload_sha256,updated_at) VALUES(?,?,?,?,?,?)", ('loadout.chapter-map','chapter-v1',1,'{}','digest','2026-11-18T00:00:00.000Z'))
db.execute("INSERT INTO legacy_imports(source_key,source_sha256,record_count,imported_at) VALUES(?,?,?,?)", ('legacy','digest',2,'2026-11-18T00:00:00.000Z'))
db.execute("INSERT INTO recovery_snapshots(id,source_key,payload_json,payload_sha256,created_at,reason) VALUES(?,?,?,?,?,?)", ('r1','legacy','{}','digest','2026-11-18T00:00:00.000Z','test'))
db.execute("INSERT INTO migration_conflicts(id,record_key,local_sha256,database_sha256,created_at,resolution) VALUES(?,?,?,?,?,?)", ('c1','legacy','a','b','2026-11-18T00:00:00.000Z','test'))
assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
assert db.execute('SELECT COUNT(*) FROM schema_migrations').fetchone()[0] == 2
print(json.dumps({'sqlite_version': sqlite3.sqlite_version, 'schema_version': db.execute('PRAGMA user_version').fetchone()[0], 'tables': db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0], 'indexes': db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'").fetchone()[0], 'integrity': 'ok'}))
`;
  const run = spawnSync('python3', ['-c', python], { input: JSON.stringify(schema), encoding: 'utf8' });
  assert.equal(run.status, 0, `SQLite schema test failed: ${run.stderr || run.stdout}`);
  const result = JSON.parse(run.stdout.trim());
  assert.equal(result.schema_version, 2);
  assert.equal(result.integrity, 'ok');
  assert.ok(result.indexes >= 4);
});

test('native database access is pinned to compiled schema and allowlisted writes', () => {
  const plugin = fs.readFileSync(path.join(ROOT, 'native/android/LoadoutCorePlugin.java'), 'utf8');
  assert.match(plugin, /"loadout-main"\.equals\(name\)/);
  assert.match(plugin, /migrations\.length\(\) != 2/);
  assert.match(plugin, /Database migration ledger contains missing or unexpected rows/);
  assert.match(plugin, /Database read query is not in the native allowlist/);
  assert.match(plugin, /SELECT ID,PAYLOAD_JSON FROM TEST_ATTEMPTS/);
  assert.match(plugin, /Database read query is not in the native allowlist/);
  assert.match(plugin, /Migration is not an exact match for the compiled native schema contract/);
  assert.match(plugin, /private String validateBatchSql\(String sql\)/);
  assert.match(plugin, /Database write statement is not an exact approved operation/);
  assert.match(plugin, /INSERT OR REPLACE INTO APP_STATE/);
  assert.match(plugin, /DELETE FROM TEST_ATTEMPTS/);
  assert.doesNotMatch(plugin, /DELETE FROM APP_STATE/);
  assert.doesNotMatch(plugin, /validateSql\(operation\.getString\("sql"\), "INSERT\|UPDATE\|DELETE\|REPLACE"\)/);
});
