import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { webcrypto, generateKeyPairSync, createHash, sign } from 'node:crypto';
import { signingPayload } from '../../src/core/package-format.js';
import { registrySigningPayload } from '../../src/core/private-registry.js';
import { sha256, stableStringify } from '../../src/core/ltl.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const runtimeSource = fs.readFileSync(path.join(ROOT, 'www/runtime/loadout-runtime.js'), 'utf8');
const ltlSource = fs.readFileSync(path.join(ROOT, 'www/runtime/ltl-engine.js'), 'utf8');
const moduleRegistrySource = fs.readFileSync(path.join(ROOT, 'www/runtime/module-registry.js'), 'utf8');
const bundledCatalog = JSON.parse(fs.readFileSync(path.join(ROOT, 'registry/catalog.json'), 'utf8'));

class MemoryStorage {
  #values = new Map();
  getItem(key) { return this.#values.has(String(key)) ? this.#values.get(String(key)) : null; }
  setItem(key, value) { this.#values.set(String(key), String(value)); }
  removeItem(key) { this.#values.delete(String(key)); }
  clear() { this.#values.clear(); }
  key(index) { return Array.from(this.#values.keys())[index] ?? null; }
  get length() { return this.#values.size; }
}

function makeRuntime(options = {}) {
  const { publicKey, privateKey } = options.registryKey || generateKeyPairSync('ed25519');
  const der = publicKey.export({ format: 'der', type: 'spki' });
  const raw = der.subarray(12);
  const keyId = createHash('sha256').update(der).digest('hex').slice(0, 20);
  const trustStore = {
    schemaVersion: 1,
    algorithm: 'Ed25519',
    keys: [{ keyId, algorithm: 'Ed25519', publicKey: raw.toString('base64') }]
  };
  const sandbox = {
    console,
    crypto: webcrypto,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    ArrayBuffer,
    Date,
    Math,
    Promise,
    JSON,
    Map,
    Set,
    Object,
    String,
    Number,
    Boolean,
    RegExp,
    Error,
    TypeError,
    structuredClone,
    atob: value => Buffer.from(value, 'base64').toString('binary'),
    btoa: value => Buffer.from(value, 'binary').toString('base64'),
    localStorage: options.localStorage || new MemoryStorage(),
    sessionStorage: new MemoryStorage(),
    fetch: async url => ({ ok: true, json: async () => String(url).endsWith('registry-catalog.json') ? structuredClone(bundledCatalog) : structuredClone(trustStore) })
  };
  if (options.legacyNativeBridge) sandbox.Capacitor = { Plugins: { LoadoutCore: {} }, getPlatform: () => 'android' };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(ltlSource, sandbox, { filename: 'ltl-engine.js' });
  vm.runInContext(moduleRegistrySource, sandbox, { filename: 'module-registry.js' });
  vm.runInContext(runtimeSource, sandbox, { filename: 'loadout-runtime.js' });

  function makePackage(updateId, content, transformations = []) {
    const pkg = {
      manifest: {
        formatVersion: '1.0',
        kind: 'data-update',
        updateId,
        target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0' },
        resources: [{ path: 'profiles/current.json', namespace: 'test-profile', sha256: sha256(content) }],
        transformations
      },
      files: { 'profiles/current.json': content }
    };
    pkg.manifest.signature = {
      algorithm: 'Ed25519',
      keyId,
      value: sign(null, Buffer.from(signingPayload(pkg), 'utf8'), privateKey).toString('base64')
    };
    return pkg;
  }
  return { api: sandbox.Loadout, ready: sandbox.LoadoutReady, makePackage, sandbox, localStorage: sandbox.localStorage, registryKey: { keyId, publicKey, privateKey } };
}


test('LTL transformations are staged, dependency-ordered, reported and manually committed', async () => {
  const runtime = makeRuntime(); await runtime.ready;
  const operations = [
    { id: 'policy-change', op: 'CHANGE_POLICY', path: '/cache', value: { ttlMs: 60000 }, description: 'Set a bounded cache policy', risk: 'medium', dependencies: ['setting-change'], validation: ['cache policy exists'], failureAction: 'reject', recovery: 'discard staged transaction' },
    { id: 'setting-change', op: 'RECONFIGURE', path: '/density', value: 'compact', description: 'Set owner interface density preference', risk: 'low', dependencies: [], validation: ['setting exists'], failureAction: 'reject', recovery: 'restore prior config snapshot' }
  ];
  const staged = await runtime.api.updates.stage(runtime.makePackage('ltl-profile-1', '{"version":1}', operations));
  assert.equal(staged.impact.operationCount, 2);
  assert.equal(staged.impact.manualApprovalRequired, true);
  assert.deepEqual(Array.from(staged.impact.resources, x => x.action), ['add']);
  const tx = await runtime.api.updates.inspect(staged.transactionId);
  assert.deepEqual(JSON.parse(JSON.stringify(tx.candidateConfig)), { settings: { density: 'compact' }, policies: { cache: { ttlMs: 60000 } }, dependencies: {} });
  assert.deepEqual(Array.from(tx.journal, x => x.state), ['discovered', 'verified', 'planned', 'staged', 'awaiting-manual-decision']);
  assert.equal((await runtime.api.updates.pending())[0].impact.operationCount, 2);
  await runtime.api.updates.commit(staged.transactionId);
  const committed = await runtime.api.updates.inspect(staged.transactionId);
  assert.equal(committed.state, 'committed');
  assert.equal(committed.journal.at(-1).state, 'committed');
  assert.equal((await runtime.api.updates.journal()).at(-1).state, 'committed');
  await runtime.api.updates.rollback(staged.transactionId);
  assert.equal((await runtime.api.updates.inspect(staged.transactionId)).state, 'rolled-back');
});

test('invalid LTL dependencies and stale source patches are rejected before staging', async () => {
  const runtime = makeRuntime(); await runtime.ready;
  const missing = [{ id: 'broken-op', op: 'VALIDATE', assert: { path: '/settings/missing' }, description: 'Invalid dependency', risk: 'low', dependencies: ['does-not-exist'], validation: [], failureAction: 'reject', recovery: 'discard' }];
  await assert.rejects(runtime.api.updates.stage(runtime.makePackage('bad-dependency', '{}', missing)), /missing operation/);
  const patch = [{ id: 'patch-op', op: 'PATCH_SOURCE', file: 'profiles/current.json', expectedSha256: '0'.repeat(64), anchor: 'version', replacement: 'rev', description: 'Guarded text patch', risk: 'high', dependencies: [], validation: ['postimage hash'], failureAction: 'reject', recovery: 'discard' }];
  await assert.rejects(runtime.api.updates.stage(runtime.makePackage('bad-patch', '{"version":1}', patch)), /preimage/);
  assert.equal((await runtime.api.updates.pending()).length, 0);
});


test('startup recovery restores the previous pointers after an interrupted activation', async () => {
  const first = makeRuntime(); await first.ready;
  const staged = await first.api.updates.stage(first.makePackage('interrupted-activation', '{"version":9}', [
    { id: 'change-setting', op: 'RECONFIGURE', path: '/mode', value: 'new', description: 'Change test setting', risk: 'low', dependencies: [], validation: [], failureAction: 'reject', recovery: 'restore snapshot' }
  ]));
  const tx = await first.api.updates.inspect(staged.transactionId);
  const interrupted = { ...tx, state: 'activating', journal: [...tx.journal, { state: 'activating', at: new Date().toISOString() }] };
  first.localStorage.setItem('loadout.runtime.v2.managed.transaction-' + staged.transactionId, JSON.stringify(interrupted));
  first.localStorage.setItem('loadout.runtime.v2.managed.active-resource-packs', JSON.stringify(tx.candidateRegistry));
  first.localStorage.setItem('loadout.runtime.v2.managed.config', JSON.stringify(tx.candidateConfig));

  const restarted = makeRuntime({ localStorage: first.localStorage });
  const ready = await restarted.ready;
  assert.equal(ready.recovery.recovered, 1);
  assert.deepEqual(Array.from(await restarted.api.updates.listActive()), []);
  const recovered = await restarted.api.updates.inspect(staged.transactionId);
  assert.equal(recovered.state, 'activation-failed');
  assert.equal(recovered.decision, 'interrupted-activation-recovered');
  assert.deepEqual(JSON.parse(JSON.stringify(await restarted.api.updates.journal())).at(-1).state, 'activation-failed');
});

test('runtime stages without activation and requires explicit commit', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const staged = await runtime.api.updates.stage(runtime.makePackage('profile-v1', '{"version":1}'));
  assert.equal(staged.requiresManualDecision, true);
  assert.equal(staged.state, 'awaiting-manual-decision');
  assert.equal((await runtime.api.updates.listActive()).length, 0);
  assert.equal((await runtime.api.updates.pending()).length, 1);
  await runtime.api.updates.rollback(staged.transactionId);
  assert.equal((await runtime.api.updates.pending()).length, 0);
});

test('resource updates are immutable and rollback restores the previous content', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const first = await runtime.api.updates.stage(runtime.makePackage('profile-v1', '{"version":1}'));
  await runtime.api.updates.commit(first.transactionId);
  assert.equal(await runtime.api.updates.readResource('test-profile', 'profiles/current.json'), '{"version":1}');

  const second = await runtime.api.updates.stage(runtime.makePackage('profile-v2', '{"version":2}'));
  const stagedSecond = await runtime.api.updates.inspect(second.transactionId);
  const keyV1 = (await runtime.api.updates.inspect(first.transactionId)).candidateRegistry['test-profile:profiles/current.json'].fileKey;
  const keyV2 = stagedSecond.candidateRegistry['test-profile:profiles/current.json'].fileKey;
  assert.notEqual(keyV1, keyV2, 'different content must never share a mutable storage key');

  await runtime.api.updates.commit(second.transactionId);
  assert.equal(await runtime.api.updates.readResource('test-profile', 'profiles/current.json'), '{"version":2}');
  await runtime.api.updates.rollback(second.transactionId);
  assert.equal(await runtime.api.updates.readResource('test-profile', 'profiles/current.json'), '{"version":1}');
});

test('stale commits and stale historical rollbacks are rejected', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const stale = await runtime.api.updates.stage(runtime.makePackage('staged-old', '{"version":1}'));
  const current = await runtime.api.updates.stage(runtime.makePackage('committed-new', '{"version":2}'));
  await runtime.api.updates.commit(current.transactionId);
  await assert.rejects(runtime.api.updates.commit(stale.transactionId), /stale/i);
  await runtime.api.updates.rollback(stale.transactionId);

  const newer = await runtime.api.updates.stage(runtime.makePackage('committed-newer', '{"version":3}'));
  await runtime.api.updates.commit(newer.transactionId);
  await assert.rejects(runtime.api.updates.rollback(current.transactionId), /superseded/i);
  const older = await runtime.api.updates.inspect(current.transactionId);
  assert.equal(older.state, 'committed');
  assert.equal(await runtime.api.updates.readResource('test-profile', 'profiles/current.json'), '{"version":3}');
});

test('storage lifetimes use distinct persistence boundaries', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const persistent = await runtime.api.storage.create({ namespace: 'tests', name: 'persistent', lifetime: 'persistent' });
  await persistent.set({ ok: true });
  const persistentAgain = await runtime.api.storage.create({ namespace: 'tests', name: 'persistent', lifetime: 'persistent' });
  assert.deepEqual(JSON.parse(JSON.stringify(await persistentAgain.get())), { ok: true });

  const session = await runtime.api.storage.create({ namespace: 'tests', name: 'session', lifetime: 'session' });
  await session.set('alive-in-session');
  const sessionAgain = await runtime.api.storage.create({ namespace: 'tests', name: 'session', lifetime: 'session' });
  assert.equal(await sessionAgain.get(), 'alive-in-session');

  const ttl = await runtime.api.storage.create({ namespace: 'tests', name: 'cache', lifetime: 'ttl', ttlMs: 10000 });
  await ttl.set('cached');
  assert.equal(await ttl.get(), 'cached');
  await ttl.delete();
  assert.equal(await ttl.get(), null);

  const moduleStore = await runtime.api.storage.create({ namespace: 'question-viewer', name: 'preview', lifetime: 'module', moduleId: 'loadout.question-viewer' });
  await moduleStore.set({ questionId: 'sample-1' });
  assert.deepEqual(JSON.parse(JSON.stringify(await moduleStore.get())), { questionId: 'sample-1' });
  const cleared = await runtime.api.storage.deactivateModule('loadout.question-viewer');
  assert.equal(cleared.storesRemoved, 1);
  assert.equal(await moduleStore.get(), null);
  await assert.rejects(runtime.api.storage.create({ namespace: 'tests', name: 'bad-module', lifetime: 'module' }), /moduleId/);
});

test('persistent mirror serializes concurrent legacy writes and flush waits for completion', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const results = await Promise.all([
    runtime.api.storage.mirror('legacy', 'main-state', { revision: 1, attempts: [] }),
    runtime.api.storage.mirror('legacy', 'main-state', { revision: 2, attempts: [{ id: 'latest' }] })
  ]);
  assert.equal(results.every(result => result.verified), true);
  const flush = await runtime.api.storage.flush();
  assert.equal(flush.pendingWrites, 0);
  const latest = await runtime.api.storage.readMirror('legacy', 'main-state');
  assert.equal(latest.revision, 2);
  assert.equal(latest.attempts[0].id, 'latest');
});

test('namespace listing falls back to app local storage when an older native bridge lacks listPrivateFiles', async () => {
  const runtime = makeRuntime({ legacyNativeBridge: true });
  await runtime.ready;
  const store = await runtime.api.storage.create({ namespace: 'backups', name: 'pre-restore-123', lifetime: 'persistent' });
  await store.set({ marker: 'snapshot' });
  const names = await runtime.api.storage.list('backups');
  assert.deepEqual(Array.from(names), ['pre-restore-123']);
  assert.equal(runtime.api.native.available, true);
});

test('storage namespace listing exposes only keys within the requested namespace', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  await runtime.api.storage.create({ namespace: 'backups', name: 'pre-restore-100', lifetime: 'persistent' }).then(store => store.set({ schemaVersion: 3 }));
  await runtime.api.storage.create({ namespace: 'backups', name: 'pre-restore-200', lifetime: 'persistent' }).then(store => store.set({ schemaVersion: 3 }));
  await runtime.api.storage.create({ namespace: 'legacy', name: 'main-state', lifetime: 'persistent' }).then(store => store.set({ attempts: [] }));
  assert.deepEqual(Array.from(await runtime.api.storage.list('backups')), ['pre-restore-100', 'pre-restore-200']);
  assert.deepEqual(Array.from(await runtime.api.storage.list('legacy')), ['main-state']);
  await assert.rejects(runtime.api.storage.list('../backups'), /namespace/i);
});


test('private registry imports are signed, persisted, re-verified and resettable offline', async () => {
  const runtime = makeRuntime();
  await runtime.ready;
  const bundled = await runtime.api.registry.status();
  assert.equal(bundled.revision, 1);
  assert.equal(bundled.moduleCount, 7);
  assert.equal(bundled.offline, true);

  const catalog = structuredClone(bundledCatalog);
  catalog.revision = 2;
  delete catalog.catalogSha256;
  catalog.catalogSha256 = sha256(stableStringify(catalog));
  const pkg = {
    manifest: {
      formatVersion: '1.0', kind: 'module-registry', registryId: catalog.registryId, revision: 2,
      createdAt: '2026-11-19T00:00:00.000Z',
      target: { appId: 'app.loadout.jee', runtimeApi: '1.5.0' }
    },
    catalog
  };
  pkg.manifest.signature = {
    algorithm: 'Ed25519', keyId: runtime.registryKey.keyId,
    value: sign(null, Buffer.from(registrySigningPayload(pkg), 'utf8'), runtime.registryKey.privateKey).toString('base64')
  };

  const imported = await runtime.api.registry.importSignedPackage(pkg);
  assert.equal(imported.revision, 2);
  assert.equal(imported.moduleCount, 7);
  const active = await runtime.api.registry.status();
  assert.equal(active.revision, 2);
  assert.equal(active.offline, true);

  const restarted = makeRuntime({ localStorage: runtime.localStorage, registryKey: runtime.registryKey });
  await restarted.ready;
  assert.equal((await restarted.api.registry.status()).revision, 2);
  const reset = await restarted.api.registry.resetToBundled();
  assert.equal(reset.revision, 1);
  assert.equal((await restarted.api.registry.status()).revision, 1);

  const tampered = structuredClone(pkg);
  tampered.catalog.modules[0].name = 'Tampered';
  await assert.rejects(runtime.api.registry.importSignedPackage(tampered), /sha-256|signature/i);
});
