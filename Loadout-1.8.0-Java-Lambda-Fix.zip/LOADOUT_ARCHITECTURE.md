# Loadout Architecture — Integrated Source 1.8.0

- App ID: `app.loadout.jee`
- App version: `1.8.0`; Android versionCode `11`
- Runtime/API: `1.5.0` (backward-compatible additive release)
- Product: private, owner-controlled, JEE Main-only, offline-first Android app.
- Current source baseline: cumulative 1.7.0 integrated repository; 1.3.0, 1.4.0 and 1.7.0 release snapshots plus standalone owner-supplied 1.3.0/1.4.0 documents are retained under `reference/` for provenance.

## Product and source preservation

- Capacitor 7.4.3 WebView UI is preserved; seven current workspaces, navy/purple theme, existing study workflows and formulas remain in place.
- LocalStorage key `loadout-jee-2027-v1` remains the study source of truth. Structured SQLite/IndexedDB remains an additive verified mirror; no authoritative cutover is claimed.
- Historical datasets remain source-preserved: 550 source topic rows = 420 retained + 130 excluded under the existing dataset audit rule. This does not replace an official exam-cycle syllabus profile.
- AI Coach is JEE Main-only, opt-in online, and retains its local conversation / secure credential boundary.

## Module architecture and ports

Seven first-party feature modules have stable identities, semantic versions, runtime API compatibility, routes, entry points, service declarations, offline declarations, dependencies and storage-read/write declarations. `modules/registry.json` is the canonical repository declaration; `www/runtime/module-registry.js` is a checked app projection. Observatory displays these contracts.

Current extraction is progressive, not complete screen isolation: selected calculations/services are independently extracted and tested, while some visible workspace renderers remain behind the legacy `app.js` compatibility adapter. The registry must not be mistaken for independent module hot swapping. The private `.lreg` catalog can update metadata for bundled modules only; module code still ships in an APK.

## Repair lanes

- `.lfix` Visual Repair: signed declarative `SET_UI_TOKEN` only; bounded value catalogue and named module scopes; app verifies, stages, displays exact impact and waits for manual commit/rollback. Persisted overrides and interrupted activation/rollback recovery are handled by the runtime.
- `.lpatch` Source Repair: signed host-only exact source patches with SHA-256 preimages and one unique anchor. A host CLI stages a complete repository copy and runs `npm test`, `npm run check`, `npm run audit:data`; only an explicit CLI commit changes working files. Source/native changes require the normal APK build.
- The Repair Context export bundles runtime/module identity, active/pending repair metadata and bounded diagnostic event headers, not personal study records or AI chat messages. The screenshot is separately uploaded to the engineer and is never placed inside the repair package.
- Device USB/ADB Development Port is debug-build-only and accepts `.lupdate`, `.lreg`, `.lfix`. It rejects `.lmod` and `.lpatch`. There is no TCP/LAN listener, remote shell or eval endpoint.

## Native and update boundary

- Native plugin services remain compiled in the Android host. Kotlin/Java, manifest, package, permission, plugin and native-library changes require a new APK and Android's normal user-approved install/update path.
- DEX/JAR and `.so` hot loading remain disabled. Signed updates are fail-closed and owner-authorized.
- Empty trust store is the default. Owner key bootstrap requires registering a public key, reviewing the changed trust store and installing a rebuilt APK that contains it. Private key material is never included in this bundle.

## Build and validation status

The repository includes a GitHub Actions workflow targeting Node 22, JDK 21 and Android SDK 35. `npm test`, `npm run check` and `npm run audit:data` are the source-side checks. This preparation environment does not have the Android SDK/Gradle Android toolchain available; no APK is claimed as compiled here. Native Java compile, on-device Ed25519/WebCrypto support, ADB transfer, install-over-existing signing identity, process-death recovery, screenshot/keyboard/responsive comparison and a physical-device repair commit/rollback remain explicit validation gates. `package-lock.json` remains absent, so direct dependencies are exact-pinned but transitive npm resolution is not locked.

See `architecture/REPAIR-PORT.md`, `architecture/MODULE-PORTS.md`, `architecture/DEVELOPMENT-PORT.md`, `documentation/PORT_CATALOG.md`, `documentation/REQUIREMENTS_MATRIX.md`, `documentation/RELEASE_CHECKLIST.md` and `TEST_REPORT.txt` for detailed contracts and evidence.
