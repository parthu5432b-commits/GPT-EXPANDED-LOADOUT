# Requirements-to-code matrix — Loadout 1.8.0

| Master brief requirement | Current implementation | Evidence | Status / boundary |
|---|---|---|---|
| Preserve private, local-first identity and no telemetry | No public accounts, analytics, ads or automatic study-data upload | `www/`, runtime diagnostics, repo dependency inventory | Implemented for current source; re-audit dependencies on upgrades |
| JEE Main only | AI Coach fixed system prompt and app product scope are JEE Main-only | `www/modules/ai-coach/ai-coach.js`, app UI | Implemented; old historical records remain historical data |
| Preserve existing theme/workspaces | Seven original workspaces retained; AI Coach controls/styles extend original chat UI | `www/index.html`, `www/app.js` | Source preservation verified; no device screenshot comparison |
| Versioned feature modules | Six study modules plus AI Coach registered with stable IDs/routes/contracts | `modules/registry.json`, `www/runtime/module-registry.js`, `www/runtime/feature-runtime.js` | Implemented as bundled modules; legacy screen rendering remains adapter-based |
| Multiple AI Coach conversations | Stable IDs; create, rename, search, switch, delete and clear | `www/app.js`, AI Coach tests | Implemented in source; no physical-device UI test |
| Per-message actions | Copy, delete, edit/resend, retry and regenerate | `www/app.js` message action handlers | Implemented in source |
| Stop/cancel generation | Browser AbortController; Android native request disconnect by request ID | `www/app.js`, `LoadoutCorePlugin.java` | Implemented in source; native device validation pending |
| Local/offline conversation history | Chat v4 localStorage plus verified private mirror; local history UI | `www/app.js`, `loadout-runtime.js` | Implemented; browser mode uses localStorage + runtime fallback |
| Safe legacy chat migration | v1-v3 to v4 normalization; credential migration/historical record retention; gated deletion | `www/app.js`, `ai-coach.js` | Implemented in source/tests; requires test on real upgrade from an installed prior APK |
| Secure Android provider credentials | Native Keystore set/has/delete; native HTTP transport reads secret internally | `LoadoutCorePlugin.java`, `loadout-runtime.js` | Implemented in source; not compiled/device-tested in this environment |
| Browser credential fallback | In-memory session Map only; no localStorage/export | `www/app.js`, `ai-coach.js` tests | Implemented; disappears on page close; CORS can apply |
| OpenAI-compatible/Gemini requests | Correct payload mapping, HTTPS endpoints, native/browser transport | `ai-coach.js`, `app.js`, native plugin | Implemented in source; provider quotas/models are external and may change |
| Streaming and stop | Native and browser SSE parsing; request-scoped chunk listener; cancellation | `LoadoutCorePlugin.java`, `loadout-runtime.js`, `app.js`, integration tests | Implemented in source; end-to-end provider tests require real provider/device |
| Provider connection test | Explicit confirmation; fixed probe; no study/history context | `app.js`, `ai-coach.js`, integration tests | Implemented; may consume small provider quota |
| Context minimisation/transparency | Local study summary and latest five tests are separate opt-ins; bounded history; full request preview | `ai-coach.js`, `app.js` | Implemented in source |
| Rich Markdown | Headings, paragraphs, nested lists, tables, quotes, links, inline/fenced code, sanitised HTML | `ai-coach.js`, unit tests | Implemented in source |
| Math/chemistry rendering | Pinned local KaTeX, mhchem, auto-render, offline asset manifest/service-worker caching; trust disabled | `scripts/vendor-katex.mjs`, `index.html`, `sw.js` | Implemented via npm postinstall; vendor output absent in offline working copy until dependencies install |
| Chat export/import | Sanitized JSON backup, size cap, normalization and explicit replacement confirmation | `app.js`, `ai-coach.js` | Implemented in source |
| Structured database | SQLite/IndexedDB schema v2, indexed projections and checksum/revision/migration validation | `database/`, `www/runtime/database*.js`, native plugin | Additive verified mirror; no source-of-truth cutover |
| Private registry and guarded LTL update flow | Signed `.lupdate` resource packages, staged transformations, manual commit/rollback, signed `.lreg` catalog metadata, offline cache and bundled fallback | `src/core/`, `www/runtime/`, `registry/` | Implemented within declared boundaries; no ZIP package parser or executable module activation |
| Development Port/native extension contract | Debug-only USB/ADB inbox, host CLI, app Observatory and compiled native inventory | `native/android/`, `scripts/dev-port.mjs`, `window.Loadout.port` | Implemented in source; Android/device validation pending |
| Deterministic npm dependency build | Exact-pinned direct dependencies; no lockfile | `package.json`, workflow | Incomplete: transitive versions not locked; CI uses `npm install` |
| Genuine APK | GitHub Actions Android/Gradle build path | `.github/workflows/build-apk.yml`, `scripts/build.mjs` | APK not compiled here; Android SDK unavailable |

## 1.8.0 repair, port visibility and modularity addendum

| Requirement | Implementation | Status / boundary |
|---|---|---|
| Visible port directory | Data & Settings → Runtime & Observatory lists USB/ADB ingress, Visual Repair, Source Repair, feature service contracts, native bridge, AI provider and backup/data ports | Implemented in source. “Port” means an explicit local API/transport boundary; only the debug USB/ADB inbox is a device ingress transport. No TCP/LAN listener is opened. |
| Inspectable feature contracts | Seven module records expose stable ID, version, route, entry, runtime API, services, dependencies, offline capability and storage read/write declarations | Implemented and cross-checked between `modules/registry.json` and the runtime inventory. Several existing screen renderers still run through legacy compatibility adapters; the UI does not claim independently hot-swappable screen bundles. |
| Screenshot-to-visual-repair lane | Export Repair Context; bounded `.lfix` package; scoped UI token allowlist; device-side signature verification; stage, preview, manual commit, journal and rollback | Implemented for the declared layout tokens only. It cannot repair broken business logic, missing components, data defects or arbitrary CSS. |
| Source repair lane | Signed `.lpatch` package with exact file SHA-256, unique anchor, path allowlist and bounded replacement; host stages full workspace copy and runs tests/check/data audit | Implemented as a workstation tool. `.lpatch` is intentionally rejected by the Android inbox; a committed source repair still requires the normal APK build/install workflow. |
| Screenshot privacy | Repair-context export contains build/runtime identity, module contracts, repair history and diagnostic event headers; it excludes study records, chat bodies, prompts, provider credentials and diagnostic payload details | Implemented in the source export path. The screenshot itself is supplied by the owner to the repair author; no automatic upload or background capture is added. |
| Repair package trust | Ed25519 signature, trusted-key lookup/revocation checks, immutable repair IDs and fail-closed verification | Implemented. Shipped trust store remains empty by design; owner key registration and a rebuilt APK carrying the public key are required before import. |
| Repair transaction recovery | Persistent stage/activation journal, manual decision, active-token read-back, interrupted activation/rollback reconciliation | Implemented in runtime source/tests; Android process-death and WebCrypto Ed25519 behaviour still require device validation. |
| Source-patch rollback | Per-file backups, preimage/postimage checks, distinct commit/rollback commands, stale-file rejection | Implemented in host tooling. It is not a remote shell or an app-side source editor. |

## Test evidence

The current 1.8.0 test counts are recorded in `TEST_REPORT.txt`. The 1.7.0 historical evidence remains below for provenance. Android native compilation, APK creation in CI, physical-device UI comparison, ADB transfer and process-death tests are not claimed as completed in this preparation environment.


## 1.6.0 final-milestone first-half addendum

| Requirement | Implementation | Status / boundary |
|---|---|---|
| Full declarative LTL operation catalogue | `src/core/ltl.js`, `www/runtime/ltl-engine.js` | Implemented and tested for supported JSON/text-resource targets |
| Dependency ordering and impact analysis | LTL engine + updater transaction impact report | Implemented; no remote resolver |
| Guarded source patching | `PATCH_SOURCE` exact preimage/match/postimage guards | Non-executable text resources only |
| Signed package validation | `src/core/package-format.js`, runtime verifier | Ed25519 + resource hashes + signer revocation check |
| Manual update approval | Data & Settings pending transaction panel | Implemented; never auto-commits |
| Durable journal and recovery | managed transaction records + startup recovery | Implemented for interrupted pointer activation |
| ZIP `.lupdate`/`.lmod` | Not implemented | JSON `.lupdate` only |
| Authenticated Development Port | Implemented in 1.7.0 | Debug-only USB/ADB; device validation pending |
| Native extension loader | Compiled APK plugin only | Dynamic code loading deliberately disabled |


## 1.7.0 final integrated source addendum

| Requirement | Implementation | Status / boundary |
|---|---|---|
| Private signed registry catalog | `.lreg`, Ed25519 trust store, catalog hashes, module/dependency compatibility checks, persistent cache and bundled fallback | Implemented for catalog metadata; no hosted server or executable module installation |
| Registry key lifecycle | Generate/register/revoke scripts; trust store is fail-closed by default | Implemented; owner must register public key and install an APK carrying it; revocation also requires APK update |
| Authenticated Development Port | Debug-only app-specific ADB/USB inbox, Android host authorization, host CLI and in-app inspect/stage workflow | Implemented in source; no LAN listener/shell; physical Android validation pending |
| Native extension boundary | Versioned compiled `LoadoutCorePlugin` inventory and APK-bound lifecycle policy | Implemented as compiled-in native core; no dynamic DEX/JAR/`.so` hot load |
| Offline package cache | Persist signed `.lupdate` packages and re-verify before re-stage | Implemented in runtime; storage recovery should still be exercised on device |
| Repository build | GitHub workflow runs registry sync/tests/data audit/source checks/Gradle build | Workflow included; no APK compiled in this environment |
| APK/device verification | Gradle compile, signing identity, install/upgrade, screenshots and lifecycle tests | Pending real GitHub runner/device |
| App DB cutover | Structured DB remains verified additive mirror | Not implemented; LocalStorage remains authoritative |
| ZIP package import / executable module load | ZIP `.lupdate`/`.lmod` and code hot-loading | Not implemented; executable `.lmod` deliberately rejected |
