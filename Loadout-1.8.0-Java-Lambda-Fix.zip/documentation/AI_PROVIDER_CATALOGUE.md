# AI Coach provider catalogue

**Reviewed:** 18 November 2026  
**Scope:** starter defaults in Loadout 1.5.5; not a guarantee of live account access, free quota, uptime, latency, or provider availability.

The identifiers below are defaults shipped in `www/modules/ai-coach/ai-coach.js`. They are editable in the AI Coach Provider settings. Availability, quotas, pricing, rate limits, model aliases, and provider routing can change independently of a Loadout update. The app does not periodically phone providers to refresh this catalogue. The owner should use the provider's own live model list and the AI Coach's explicit Test connection action before relying on a configuration.

| Provider | API base URL | Starter model | Request format | Notes |
|---|---|---|---|---|
| Google Gemini | `https://generativelanguage.googleapis.com/v1beta` | `gemini-3.8-flash` | Gemini `generateContent` / SSE | Uses `x-goog-api-key`; stream URL uses `alt=sse`. |
| Groq | `https://api.groq.com/openai/v1` | `openai/gpt-oss-20b` | OpenAI-compatible Chat Completions | Model and account limits can change. |
| OpenRouter | `https://openrouter.ai/api/v1` | `openrouter/free` | OpenAI-compatible Chat Completions | `openrouter/free` is a router that selects among eligible free models; selection and capacity change. It is not a promise of a specific underlying model or unlimited free use. |
| Hugging Face Inference Providers | `https://router.huggingface.co/v1` | `deepseek-ai/DeepSeek-V4.1-Flash:fastest` | OpenAI-compatible Chat Completions | The `:fastest` suffix is a routing policy; provider routing/cost/capacity can change. |
| Cerebras | `https://api.cerebras.ai/v1` | `zai-glm-4.7` | OpenAI-compatible Chat Completions | Model ID is confirmed by Cerebras' model-specific API guide. Account access and limits may differ. |
| Custom OpenAI-compatible | `https://api.openai.com/v1` | `gpt-4o-mini` | OpenAI-compatible Chat Completions | The user can change both the base URL and model. The endpoint must be public HTTPS and implement the expected API format. |

## Official provider references

- Google Gemini model catalogue: https://ai.google.dev/gemini-api/docs/models
- Google Gemini 3.8 Flash model/pricing reference: https://ai.google.dev/gemini-api/docs/pricing
- Groq supported model catalogue: https://console.groq.com/docs/models
- Groq GPT OSS 20B model reference: https://console.groq.com/docs/model/openai/gpt-oss-20b
- OpenRouter free model router: https://openrouter.ai/openrouter/free
- OpenRouter free model collection and current usage notes: https://openrouter.ai/collections/free-models
- Hugging Face Inference Providers routing: https://huggingface.co/docs/inference-providers/routing
- Cerebras GLM 4.7 model guide: https://inference-docs.cerebras.ai/models/zai-glm-47
- Cerebras GLM 4.7 API migration guide: https://inference-docs.cerebras.ai/resources/glm-47-migration
- OpenAI API pricing/model references: https://platform.openai.com/pricing/

## Security and privacy boundaries

- Provider keys are not included in app backups, chat exports, prompt previews, request bodies, or routine diagnostics.
- On Android, the native plugin retrieves a saved key from Android Keystore and attaches it to the HTTPS request; the decrypted key is not returned to the WebView.
- Browser fallback credentials exist only in session memory and are lost when the page session ends.
- A provider request occurs only after the owner presses Send or confirms Test connection. The Test action sends only the fixed connection probe, not conversation history or study records.
- Send transmits the bounded selected conversation history, JEE Main system instructions, current message, and only those local study-context categories the owner explicitly enabled.
- Native requests reject HTTP, URL credentials, URL fragments, redirects, localhost/private/non-routable destinations, unsupported query parameters, and oversized bodies/responses. Local-network inference servers are deliberately not supported by the current native transport.

## Verification boundary

This catalogue was checked against the linked official provider documentation on the review date. No real provider API request was sent during release preparation because it would require the owner's credentials and could consume their quota. Model defaults are therefore **documentation-verified, not live-account-tested**.
