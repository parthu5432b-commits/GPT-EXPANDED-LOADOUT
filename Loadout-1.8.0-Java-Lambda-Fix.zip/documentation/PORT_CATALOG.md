# Loadout Port Catalog — 1.8.0

| Port | Direction / transport | Authentication | Payload / contract | Available when | Can it execute code? |
|---|---|---|---|---|---|
| USB/ADB Development Port | Host → app, ADB over USB or explicitly authorized ADB transport | Android ADB host authorization; debuggable APK gate | `.lupdate`, `.lreg`, `.lfix` in app-private inbox | Debug APK only | No |
| Visual Repair Port | Local file or ADB inbox → app runtime | Ed25519 signer in bundled trust store | `.lfix` bounded `SET_UI_TOKEN` changes | Installed 1.8 runtime + trusted key | No; fixed CSS custom properties only |
| Source Repair Port | File → development workstation/repository | Ed25519 trusted key + SHA-256 file preimage + unique anchor | `.lpatch` exact text `PATCH_SOURCE` operations | Developer workstation | No package-supplied scripts; fixed host checks only |
| Feature service ports | In-process runtime calls | Bundled first-party module registry / compatibility contracts | Named services, routes, dependencies | Offline, after runtime boot | Only already bundled code |
| Native bridge | WebView ↔ compiled Android plugin | Capacitor bridge / host app boundary | Native methods, app-private files, Keystore, diagnostics, ADB inbox, SQLite | Native APK build | Compiled host code only; requires APK to change |
| AI Coach provider | App → configured HTTPS provider | Owner-configured credential stored in Android Keystore where available | Explicit request and selected context | Online, only when owner sends | No inbound execution channel |
| Backup/data interchange | User-initiated local import/export | Local app and package validation | Backup JSON, CSV, snapshots | Offline | No |

## No listening network ports

“Port” in this catalog means a named API/transport boundary. The app does not open a TCP port, HTTP server, LAN listener, remote shell, WebSocket control endpoint or general-purpose remote file editor. The USB/ADB inbox exists only in debug builds and uses Android app-specific storage. Do not expose it with port forwarding or a public tunnel.

## Version and module visibility

- App: `1.8.0`; Android versionCode: `11`.
- Runtime API: `1.5.0`.
- Package identity: `app.loadout.jee`.
- Feature registry: seven first-party modules; module service/storage declarations are shown in Data & Settings → Runtime & Observatory.
- Native extensions: compiled-in first-party only; DEX/JAR loading and `.so` hot swap disabled.

## File extensions

- `.lupdate`: owner-signed declarative data/resource transformation package.
- `.lreg`: owner-signed private first-party registry catalog package.
- `.lfix`: owner-signed in-app visual token repair.
- `.lpatch`: owner-signed host-only source patch; deliberately not accepted by Android inbox.
- `.lmod`: executable module package; not accepted or dynamically loaded.
