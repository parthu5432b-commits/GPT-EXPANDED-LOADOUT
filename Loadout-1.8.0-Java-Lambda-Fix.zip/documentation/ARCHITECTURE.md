# Architecture and implementation status — Loadout 1.8.0

## Release identity

- App: `Loadout JEE`; application ID: `app.loadout.jee`.
- Version name: `1.8.0`; Android versionCode: `11`.
- Runtime API: `1.5.0` (unchanged; new feature remains backward compatible with this API).
- Platform: Capacitor 7.4.3 / Android host / WebView presentation.
- Target: private single-owner Android use; JEE Main only; offline-first local data.
- Source baseline: cumulative 1.7.0 integrated source; original 1.3.0/1.4.0/1.7.0 archives retained under `reference/` for provenance.

## Feature modules

Seven first-party feature modules are registered against runtime API `1.5.0`:

| Module | Route | Responsibility |
|---|---|---|
| Command Center | `dashboard` | Dashboard summaries |
| Chapter Map | `chapters` | Chapter identities, attempts and mastery services |
| PYQ Intelligence | `historical` | Offline history dataset selection/filtering |
| Test Ledger | `tests` | Test validation and canonical test record creation |
| Forecast Engine | `forecasts` | Forecast regression/calibration |
| AI Coach | `chatbot` | Conversation/provider/context/rendering services |
| Data & Settings | `data` | Backup/restore and database/migration controls |

The existing screen rendering functions remain the adapter while the pure domain and persistence services are extracted. Feature modules are bundled in the APK; the updater does not evaluate downloaded JavaScript.

## AI Coach Step 0.75.5

`loadout.ai-coach` is registered as a real offline feature module. `www/app.js` still owns the legacy-compatible conversation UI and event adapter, while `www/modules/ai-coach/ai-coach.js` owns pure conversation normalization, secret-free persistence snapshots, context selection, provider request construction, response parsing, SSE parsing, Markdown rendering and math-renderer integration.

### Local conversation state and migration

- Current chat key: `loadout_chat_v4`.
- Private mirror: `legacy/chat-state-v4` through the runtime storage facade.
- Prior stores considered: `loadout_chat_v1`, `loadout_chat_v2`, `loadout_chat_v3` and an explicit migration-hold record.
- The schema-4 snapshot contains normalized conversations, messages, active conversation, provider IDs, non-secret provider profiles and preferences. It never contains provider API keys.
- Writes are serialized, written to localStorage, read back exactly, mirrored to app-private storage, flushed and read back again. Old stores are only removed after successful sanitized-history verification and safe handling of all legacy secrets. If verification/migration fails, the original data is retained and editing is gated.

### Credential handling

On Android, provider credentials are stored via native Android Keystore AES-256-GCM. The native `requestAiProvider` method reads the secret and attaches `Authorization: Bearer` or `x-goog-api-key` within the native HTTPS request. JavaScript passes only credential ID, endpoint, request body and request metadata. It does not retrieve the secret for provider calls.

In browser/PWA fallback, credentials live only in a JavaScript `Map` for the current page session. They are not put in localStorage or backup exports and are lost on reload/close. Browser requests can be subject to provider CORS; Android uses native transport.

The native transport rejects non-HTTPS URLs, redirects, embedded URL credentials, fragments, localhost, `.local` and resolved private/non-routable addresses. It imposes 2 MiB request and 4 MiB response limits, connection/read timeouts, request IDs and cancellation. Provider keys and prompt bodies are not written to routine diagnostics.

### Streaming

- Browser: OpenAI-compatible and Gemini SSE parsed incrementally with `ReadableStream`/`TextDecoder`.
- Android: native `HttpsURLConnection` reads SSE and emits only `{requestId,text}` chunks through a plugin event; JavaScript filters by active request ID and removes its listener on completion.
- Stop: browser uses `AbortController`; Android invokes native cancellation to disconnect the active connection.
- Non-streaming JSON response fallback is retained for endpoints that don't return SSE, including explicit connection tests.

### Rendering

A pinned KaTeX 0.19.1 distribution is copied into `www/vendor/katex` by the npm postinstall hook. KaTeX core, auto-render, mhchem, CSS and fonts are local; the service worker caches the manifest and every listed vendor asset. Rendering sets KaTeX `trust:false`. Markdown escapes raw HTML and restricts link schemes to HTTP, HTTPS and mailto.

### Conversation features

- Create, rename, search, switch, delete and clear conversations.
- Per-message copy/delete/edit-and-resend/retry/regenerate.
- Stop generation and preserve partial responses.
- JSON export/import with a 10 MiB input cap, schema normalization and explicit replace confirmation. No keys in exported files.
- Explicit toggles for locally calculated study summary and recent test rows.
- Bounded conversation history/output token settings.
- A request preview displays provider/model, fixed JEE Main instructions, selected history, selected local study context and next message.
- Test connection requires explicit confirmation and sends only a fixed probe without conversation or study context.

## AI Coach patch hardening in 1.5.6

- Retry predicate is shared by the feature module and click handler; cancelled/interrupted assistant replies can be retried.
- Native AI transport observes AbortSignal for the full request lifetime and cancels the matching request ID.
- Browser SSE flushes its active TextDecoder before final parsing.
- Provider URLs are validated before they are saved and again before request construction.
- Provider error strings redact common provider API key formats.

## Structured data foundation

Android uses app-private SQLite through the native plugin; browser mode uses IndexedDB. Schema v2 includes full legacy state snapshot, indexed test and forecast projections, module records, provenance, recovery and migration history. The legacy localStorage state is still authoritative; the structured database is an additive, verified mirror. This release does not switch application reads/writes to the DB as the source of truth.

Native SQL is restricted to the single `loadout-main` database, exact compiled schema migrations and allowlisted parameterized statements. State writes are read-back verified, including individual indexed projection payloads and monotonic revision. Divergence is archived before reconciliation.

## Build and dependency status

- Build-control files and documentation remain outside `www/`.
- `www/` contains only intended app runtime/assets, feature modules and vendor resources.
- CI uses Node 22, JDK 21, Android SDK 35, Capacitor 7.4.3.
- Direct dependencies are exact pinned. No lockfile exists because registry DNS was unavailable; CI uses `npm install`, not `npm ci`.
- Android SDK was unavailable in the preparation environment; no genuine APK was produced. Native Java compile and physical device verification remain required.

## Remaining delivery and validation boundaries

The 1.7.0 source integrates the LTL transaction engine, private offline catalog, ADB/USB Development Port and the explicit APK-bound native extension policy. It does not silently claim completion of platform-only validation or data cutover. Remaining real-device/release gates are listed in `LOADOUT_RELEASE_NOTES.txt` and `RELEASE_CHECKLIST.md`: run GitHub Actions, compile the native Java plugin, verify signing identity, test migration/backup/restore/Keystore/stream cancellation/process-death recovery, and compare mobile screenshots. The legacy LocalStorage state remains authoritative while SQLite/IndexedDB is an additive verified mirror. `.lupdate` remains JSON; executable `.lmod`, arbitrary code loading and native hot swap are not supported.


## 1.6.0 — final milestone first half (87.5% cumulative project checkpoint)

The guarded declarative update engine and manual updater are materially expanded. `www/runtime/ltl-engine.js` is loaded before the host runtime and is mirrored by the Node reference implementation in `src/core/ltl.js`. Supported operations include ADD, REPLACE, PATCH, PATCH_SOURCE, REMOVE, MOVE, RENAME, RECONFIGURE, REWIRE, MIGRATE, CHANGE_POLICY, INSTALL_DEPENDENCY, REMOVE_DEPENDENCY, VALIDATE and ACTIVATE markers.

Operations require unique IDs, descriptions, risk, dependency declarations, validation labels, failure actions and recovery strategies. The engine resolves dependency order, rejects cycles/missing operations, guards JSON Pointer keys and source preimage hashes, evaluates state/value preconditions and applies changes only to staged copies.

The updater creates an impact report and durable transaction journal, requires manual commit/rollback, rejects stale commits, verifies immutable content-addressed resources and restores the previous active pointers on activation failure. Startup recovery detects a transaction left in `activating` by process death and restores its previous snapshot.

The first-party registry validator now checks manifests, route/service uniqueness, offline declarations and dependency graph consistency.

The 1.6.0 paragraph is historical. In 1.7.0, the source adds the owner-controlled ADB/USB Development Port, offline private catalog import/cache, signing/revocation tooling and a versioned compiled-native inventory. It intentionally does not add ZIP archive extraction, executable `.lmod` activation, a network registry server or dynamic DEX/JAR/`.so` loading.


## 1.7.0 — final integrated source

The final source integrates the complete LTL transaction path with a private signed registry and a debug-only USB/ADB Development Port. The catalog is first-party and APK-bundled; `.lreg` updates catalog metadata only and cannot change executable code. Catalog imports are Ed25519-verified, checked against the installed module set/dependencies, stored locally and re-verified. The bundled catalog is the offline fallback. The app opens no network listener for maintenance.

`native/extensions.json` and the native inventory API version the compiled-in Capacitor core. Native/feature source changes require a new APK; dynamic code loading is disabled. Verified `.lupdate` packages are cached and re-staged offline. Owner key bootstrap is required because the shipped trust store is empty by design.

Build/source status is in `TEST_REPORT.txt`. No APK or physical-device verification is claimed from the preparation environment; GitHub Actions must compile and validate the generated Android package.


## Release 1.8.0 — visible modular contracts and repair ports

### Module boundary visibility

`modules/registry.json` is the canonical first-party feature inventory. The generated `www/runtime/module-registry.js` mirrors its identity, version, entry, route, runtime API, offline flag, services, storage reads/writes, dependencies and description. `scripts/check-source.mjs` rejects drift between these inventories and the module manifests. The Observatory renders these declarations so the owner can inspect which services each feature provides and which stores it reads or writes.

This is genuine incremental modularisation, not a claim that all seven workspaces are already independently unloadable screen bundles. Pure/domain services and route adapters have been extracted and tested; legacy UI rendering and the existing state compatibility adapter remain in place where extraction would risk breaking working workflows. No module source is hot-loaded. Feature code changes remain APK-bound unless a future runtime contract is specifically designed and security-reviewed.

### Port catalog and repair lanes

The full operator-facing list is `documentation/PORT_CATALOG.md`. In short: USB/ADB ingress, in-app Visual Repair, workstation Source Repair, in-process feature service contracts, native bridge, outbound AI provider and local backup/data interchange are separate named boundaries. The word “port” is not a promise of an open network socket. The app has no general TCP/LAN maintenance listener.

`.lfix` is a signed JSON visual repair package limited to 12 named, bounded UI tokens and seven module/global scopes. It cannot contain CSS, selectors, scripts or executable code. The Android runtime validates the signer, stages the package, displays the impact, and requires manual commit. The active token map is read-back verified and journalled; rollback and startup reconciliation are implemented.

`.lpatch` is a signed JSON source patch package for the development machine. It accepts only a constrained `PATCH_SOURCE` operation with an allowlisted path, exact file preimage SHA-256 and a unique anchor. The host creates a complete staged repository copy, runs `npm test`, `npm run check` and `npm run audit:data`, and requires a separate commit command. Commit rechecks live/staged hashes and saves per-file backups; rollback refuses to overwrite subsequent edits. The phone inbox rejects `.lpatch`.

### Screenshot-to-repair workflow

1. Capture the defect screenshot manually.
2. In Runtime & Observatory, export the minimal Repair Context file. It includes app/runtime identity, module contracts, current visual repair state/history and diagnostic event headers. It excludes study state, chat content, prompts, credential material and diagnostic payload details.
3. Supply the screenshot and that context to the repair author. Ask for a `.lfix` when the issue is purely one of the supported layout tokens; ask for `.lpatch` only when code changes are required.
4. The owner signs the generated JSON locally with the private Ed25519 key. The private key never needs to be sent to the repair author or included in the source ZIP.
5. A `.lfix` is imported from a file or debug USB/ADB inbox, verified, previewed, and manually committed or rolled back in the app. A `.lpatch` is inspected/staged/committed on the development workstation, then built through GitHub Actions or the documented local Android build.

### Trust and platform boundary

The bundled trust store remains empty by default and rejects unsigned/untrusted packages. The owner must generate a key pair, register the public key, build and install an APK containing that public key, and keep the private key offline. Device WebCrypto Ed25519 support and Java native compilation have not been proven on the target phone in this preparation environment. No APK was compiled here; CI/device validation remains mandatory.
