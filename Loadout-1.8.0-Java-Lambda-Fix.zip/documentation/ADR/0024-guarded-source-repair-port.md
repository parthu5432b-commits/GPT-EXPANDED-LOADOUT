# ADR 0024 — Host-only guarded Source Repair Port

- Status: accepted; source package verifier, signer, staging CLI and unit tests added in Loadout 1.8.0. Full CLI integration/device-independent repository workflow validation pending.
- Context: visual tokens cannot fix logic, missing components or native defects. The owner needs a transferable source patch, but the installed Android app must not become a generic remote source editor or shell.
- Decision: define `.lpatch` as an Ed25519-signed declarative package with exact relative paths, SHA-256 preimages, single unique anchors and text replacements. A host-only CLI stages a full repository copy, applies changes to the staged copy and runs fixed tests/source checks/data audit. A separate explicit commit writes changes and creates backups; rollback is guarded against later edits. `.lpatch` is excluded from the Android Development Port.
- Alternatives rejected: remote shell, arbitrary migration scripts, unrestricted regex, direct live-file editing, remote package extraction or generic eval endpoint.
- Consequences: source/native changes are repairable via files but still require ordinary CI/APK build and Android package installation. Multi-file commit cannot be globally atomic across arbitrary filesystem failures; per-file backups and recovery journal reduce risk but do not replace repository version control.
