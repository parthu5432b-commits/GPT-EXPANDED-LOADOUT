# ADR 0021 — Compiled native extension boundary

- Status: accepted; source contract implemented in Loadout 1.7.0; compile/device validation pending.
- Date: 19 November 2026.

## Context

Downloaded DEX/JAR/native libraries would run with host application privileges. Android has platform restrictions on dynamic code loading, and a downloaded file is not a security sandbox.

## Decision

Keep native services compiled into the Capacitor Android host. Publish a versioned inventory/contract and native capability list. Native changes require a new APK and process restart. Dynamic DEX/JAR and `.so` hot swap remain disabled.

## Consequences

The implementation sacrifices in-place native hot updates for a smaller, clearer privilege boundary and normal APK signature/installation semantics. This is the selected supported path, not an unfinished dynamic loader.
