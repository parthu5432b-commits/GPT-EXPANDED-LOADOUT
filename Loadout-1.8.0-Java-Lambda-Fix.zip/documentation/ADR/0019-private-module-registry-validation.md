# ADR 0019 — Validate the private first-party module graph

- Status: accepted and implemented in Loadout 1.6.0
- Date: 19 November 2026

## Context

The root module registry, runtime registry and individual module manifests can drift independently. Missing dependencies, duplicate services or route collisions should fail before build/release rather than during a user session.

## Decision

Add a source-level validator that checks private/owner-controlled registry policy, module identity/version/runtime/entry/route parity, service declarations, offline declarations, route and service uniqueness, and module dependency ordering/cycles. Integrate it into `npm run check` and the automated tests.

## Consequences

- The seven currently registered modules and 29 service declarations are checked as a graph.
- This is a static bundled registry, not a hosted registry or remote sync service.
- First-party-only and no-public-marketplace decisions remain unchanged.
