# ADR 0013 — Bundle pinned KaTeX and mhchem locally

- Status: accepted and implemented in source release 1.5.5

Use the exact `katex@0.19.1` package as the source for KaTeX core, CSS, fonts, auto-render and mhchem. An npm postinstall script copies assets into `www/vendor/katex`, creates SHA-256 inventory metadata and the service worker caches the complete manifest. No runtime CDN is used. KaTeX trust is disabled and Markdown raw HTML is escaped before math rendering.

The trade-off is larger app resources and dependency-lock responsibility. Since npm registry access failed in preparation, generated vendor files are not present in this working tree until dependencies install and the npm lockfile remains outstanding.
