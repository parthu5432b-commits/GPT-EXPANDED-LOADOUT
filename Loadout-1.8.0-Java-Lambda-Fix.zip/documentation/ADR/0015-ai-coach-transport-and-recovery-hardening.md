# ADR 0015 — AI Coach transport and recovery hardening

- **Status:** Accepted
- **Date:** 18 November 2026
- **Release:** 1.5.5 / Step 0.75.5

## Context

The AI Coach must stream on Android without exposing decrypted provider credentials to JavaScript, support cancellation even when a native request is queued but has not opened its HTTPS connection, recover interrupted streams after process death, and preserve corrupt legacy chat bytes even when an auxiliary local marker is lost.

## Decisions

1. Native request IDs enter a pending set synchronously before executor dispatch. Duplicate IDs are rejected. Cancellation is retained while the request is pending and only affects known pending IDs.
2. Native AI provider concurrency is capped at four pending requests. A semaphore slot is released in the task `finally` path and when executor scheduling fails.
3. JavaScript checks an already-aborted signal after attaching the native SSE listener and before invoking the native request. The listener is removed in `finally`.
4. The browser transport treats every non-2xx response as an error before SSE parsing, even if the provider incorrectly labels an error body as `text/event-stream`.
5. Corrupt private chat archives are probed using a fixed allowlist of known generation keys. Discovery does not depend solely on a localStorage marker.
6. Chat-backup import is capped at the same 24 MiB limit as the persistent conversation store.
7. Provider model identifiers are recorded in a separate dated catalogue with official references; configuration remains user-editable.

## Consequences

- The Android WebView receives text deltas, not API keys.
- A pre-dispatch cancellation cannot be lost due to a request-start race.
- Unknown cancellation IDs do not accumulate in memory.
- A corrupt-chat archive remains discoverable if the local marker write failed, provided the private archive write succeeded.
- The app has a strict upper bound on queued native provider work.
- Provider defaults can become stale; the catalogue explicitly avoids claiming live availability.

## Alternatives rejected

- Returning decrypted secrets to JavaScript: rejected because it expands the exposure surface.
- Marking arbitrary request IDs cancelled: rejected because IDs not owned by a pending request could leak cancellation flags.
- Discovering private recovery data only from a local marker: rejected because the marker itself can be lost.
- Automatically switching user providers/models based on a background probe: rejected because it could send data without an explicit owner action.
