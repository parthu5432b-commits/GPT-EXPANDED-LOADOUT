# ADR 0017 — Guarded declarative LTL engine

- Status: accepted and implemented in Loadout 1.6.0
- Date: 19 November 2026

## Context

The earlier updater accepted signed data resources and a limited set of configuration/text transformations. The final-milestone first half requires a complete controlled declarative operation vocabulary without granting imported packages arbitrary execution or live filesystem access.

## Decision

Implement the same LTL semantics in a Node reference module (`src/core/ltl.js`) and browser runtime module (`www/runtime/ltl-engine.js`). Support ADD, REPLACE, PATCH, PATCH_SOURCE, REMOVE, MOVE, RENAME, RECONFIGURE, REWIRE, MIGRATE, CHANGE_POLICY, INSTALL_DEPENDENCY, REMOVE_DEPENDENCY, VALIDATE and ACTIVATE markers. Resolve operation dependencies topologically and reject missing IDs, duplicate IDs and cycles. Guard JSON Pointer paths, prototype-sensitive keys, state/value preconditions, source preimage hashes and expected match counts. MIGRATE contains bounded declarative steps only.

## Security boundary

PATCH_SOURCE may change staged non-executable text resources only. Executable JavaScript/TypeScript, DEX/JAR, class and native libraries are rejected. No eval, shell, general filesystem path access or arbitrary migration script is supported. The package remains signed JSON, not a ZIP archive, in this release.

## Consequences

- LTL is now a reusable and testable transformation language for staged JSON state/resources.
- The Node and browser engines have dedicated regression coverage.
- Runtime API remains 1.5.0; additions are backward-compatible to existing callers.
- Installable executable module replacement and full archive packaging remain future work.
