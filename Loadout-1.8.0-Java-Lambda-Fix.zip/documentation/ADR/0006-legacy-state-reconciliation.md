# ADR 0006 — preserve divergent state before startup mirror reconciliation

- Status: Accepted
- Release: 1.4.0

## Context

The legacy app writes localStorage synchronously and mirrors the same value to app-private storage asynchronously. A process may stop between these writes. Corrupt localStorage may also coexist with a previously valid private mirror.

## Decision

Keep the existing legacy key as the compatibility source for normal operation. If both valid local data and a different private mirror exist, first archive the mirror under a timestamped `legacy-recovery` key and verify the complete read-back value before reconciling the private mirror to local state. If local state is invalid, preserve its exact raw bytes in `legacy-recovery/corrupt-main-state` and compare the byte-for-byte read-back before attempting recovery from the private mirror. If preservation cannot be verified (or no valid recovery mirror exists), `www/runtime/recovery-gate.js` blocks future writes, offers raw-record export when possible, and requires an explicit owner acknowledgement to resume. The same write gate applies in browser mode when a corrupt record cannot be separately archived.

Chat migration is separately gated. v1/v2 are only removed after exact sanitized v3 persistence verification, secure credential migration and flushed mirror read-back. Chat writes are deferred before this gate. If Keystore is unavailable or a key migration fails, a minimal credential-only `loadout_chat_keystore_pending_v1` record is written and read-back verified before v3 history is normalised. This compatibility record contains plaintext legacy credential values until Keystore migration succeeds; it is a temporary preservation exception, not a secure steady-state store.

## Consequences

Potentially divergent records remain recoverable for owner inspection rather than being overwritten silently. Failure to establish a verified recovery copy fails closed instead of allowing the default state to overwrite the legacy record. LocalStorage remains the source of truth for the current legacy application; this does not replace a future transactional SQLite migration. Android process-death and hardware-keystore behaviour require device tests.
