# ADR 0004 — checksummed backups and recoverable pre-restore snapshots

- Status: Accepted
- Release: 1.4.0

## Context

The previous export/restore path did not have a unified versioned backup contract, a meaningful pre-restore verification step or an in-app recovery path for saved snapshots. A destructive restore must not proceed until the currently installed state has been retained and read back successfully.

## Decision

Use backup schema 3 with deterministic SHA-256 integrity metadata. Continue accepting schema 1 and 2 as legacy inputs and label them as not integrity-verified. Preview import contents and require an owner-selected replace or merge action. Before application, write a schema-3 snapshot into persistent local storage, flush pending writes and verify its digest by reading it back. Provide a snapshot list and a restore-preview workflow. Restoring a snapshot creates a fresh snapshot of the current state first.

## Security and correctness boundaries

- The digest is an unkeyed corruption/tamper-evidence check, not proof of author or authenticity.
- Backups are not encrypted; exported study/chat data is readable JSON.
- Provider API credentials are excluded from backups.
- The current localStorage schema is preserved; no SQLite conversion is implied.
- Merge identifies records by stable IDs where available and preserves current settings; replace restores incoming attempts/forecasts while retaining unrelated UI state.

## Consequences

The app gets a safer restore path and a recovery UX for snapshots. Snapshot retention is owner-controlled; no automatic pruning or deletion is performed. Native storage and physical-device process-death behaviour still require Android testing.
