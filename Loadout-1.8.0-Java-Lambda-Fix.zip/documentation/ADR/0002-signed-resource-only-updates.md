# ADR 0002 — Restrict installed updates to signed data/resource packs

- **Status:** Accepted
- **Decision:** The in-app updater accepts owner-signed JSON/Markdown/text resources only. Executable JavaScript, DEX/JAR and native libraries are rejected. Compiled/native host changes are delivered through a new APK.
- **Reason:** Dynamically loaded code inherits host app privileges and does not become sandboxed because it is stored separately. The current milestone does not have the full signing, loader, read-only staging, process restart and recovery infrastructure required for native code.
- **Consequences:** `.lupdate` is a JSON document, not a ZIP package. The default trust store is empty and rejects all signers. Registering a public key requires rebuilding the APK. Manual commit/rollback is enforced.
- **Alternatives rejected:** Unrestricted `eval`, accepting unsigned JS source, treating a hash as signer identity, or loading DEX/JAR before recovery tests exist.
