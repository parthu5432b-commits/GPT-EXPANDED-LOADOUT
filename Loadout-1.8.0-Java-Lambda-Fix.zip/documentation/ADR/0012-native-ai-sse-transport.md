# ADR 0012 — Native AI provider transport and request-scoped SSE

- Status: accepted and implemented in source release 1.5.5

## Context

Direct WebView provider `fetch` can be blocked by CORS and would require secrets to be exposed to page JavaScript. A whole-response native call solves CORS/secrets but loses streaming UX.

## Decision

The Capacitor native plugin performs HTTPS requests, reads credentials from Android Keystore and attaches them to the request. For SSE-capable providers, it parses each data event and emits only text deltas with a request ID. JavaScript subscribes before dispatch, accepts only the active request ID and unregisters the listener after completion. Cancellation disconnects the matching active native connection.

The transport rejects non-HTTPS, redirects, embedded URL credentials, fragments, local/private destinations and oversize bodies/responses. No request or credential content is written to diagnostics.

## Consequences

- Android requests avoid WebView CORS and key extraction into JavaScript.
- Browser fallback remains available but uses page-session memory keys and can be subject to CORS.
- Native compile and real provider/device tests remain a release gate; source-level integration tests do not replace them.
