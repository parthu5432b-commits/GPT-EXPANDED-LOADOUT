# ADR 0016 — AI Coach patch hardening

- **Status:** Accepted
- **Date:** 18 November 2026
- **Release:** 1.5.6

## Context

Post-integration review of Step 0.75.5 found several small defects not covered by the original test suite: cancelled assistant replies displayed Retry but the action handler accepted only error status; the native transport checked an AbortSignal only before dispatch; browser SSE did not flush its existing UTF-8 decoder at end-of-stream; provider URL query parameters could be saved despite being rejected later by request construction; and error text redaction covered only a subset of common provider token shapes.

## Decisions

1. Retry eligibility is a shared pure feature-module predicate used by the message action handler. Assistant messages in `error` or `cancelled` state can be retried; `complete` can be regenerated.
2. Native AI transport subscribes to the caller's AbortSignal for the duration of a request and cancels only the exact request ID. The abort listener is removed in `finally`.
3. Browser SSE flushes the same TextDecoder instance before parser finalization, preserving incomplete multi-byte UTF-8 sequences that complete in the final bytes.
4. Provider base URL validation is centralised in the AI Coach feature module and applied before saving settings and while constructing requests. Only HTTPS URLs without query parameters, embedded credentials, fragments or excessive length are accepted.
5. Provider error text redaction covers bearer values and common Google, OpenAI/OpenRouter, Hugging Face and Groq key prefixes before a message is shown in the UI.

## Consequences

- The Retry button now works for user-stopped and process-interrupted assistant responses.
- Native non-streaming connection tests and streamed generations share consistent abort behaviour.
- Browser streaming no longer loses a final character split across the last UTF-8 chunk boundary.
- Invalid provider endpoint settings are rejected before persistence rather than saved in a configuration that later fails at request time.
- Common provider secret formats are redacted from provider-returned error text. This is defense-in-depth, not a guarantee against every arbitrary secret format an endpoint might echo.

## Validation

Unit and integration regression tests cover each decision. They do not replace Android plugin compilation, emulator/device cancellation testing, visual UI comparison or a real user-authorised provider request.
