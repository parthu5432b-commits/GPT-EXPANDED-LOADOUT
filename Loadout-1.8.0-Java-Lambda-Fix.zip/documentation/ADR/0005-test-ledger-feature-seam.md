# ADR 0005 — extract Test Ledger record operations before extracting its UI

- Status: Accepted
- Release: 1.4.0

## Context

The legacy application contains a large screen/state module. Moving it wholesale would put existing study records and scoring behaviour at risk. A safe first extraction should isolate deterministic domain logic without introducing a competing attempt database or new user-facing route.

## Decision

Extract C/W/U validation, canonical test record creation, duplicate completed test-ID checking and immutable attempt removal into `www/modules/test-ledger.js` as `loadout.test-ledger` version `1.1.0`. Keep the existing Test History screen, modal, global state and localStorage key under the legacy UI adapter. The legacy app invokes the new module for manual test save and deletion.

## Consequences

A real domain service exists with unit tests and stable identity. Existing UI and record schema remain intact. This is deliberately not a separate runtime-loaded module, not a new database, and not full Iteration 2. Future extraction can move additional pure calculations behind the same contract after regression tests exist.
