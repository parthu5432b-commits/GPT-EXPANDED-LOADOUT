# ADR 0022 — Owner-signed private registry catalog and offline fallback

- Status: accepted and implemented in source for Loadout 1.7.0; signing bootstrap and device validation remain owner tasks.
- Date: 19 November 2026.

## Context

Installed features must remain usable offline, with owner-controlled metadata updates and no public marketplace or mandatory hosted server.

## Decision

Bundle the canonical first-party module catalog with the APK. Allow owner-signed Ed25519 `.lreg` catalog import and cache. Verify catalog digest, trust/revocation, app/runtime target, exact bundled module set, immutable module descriptors and dependencies. Fall back to the APK-bundled catalog when cache verification fails. The catalog cannot install executable code; module source changes require an APK update.

## Consequences

Catalog distribution is manual through file import or the debug-only ADB/USB Development Port. Trust store begins empty; owner must register a public signing key and install a corresponding APK before imports are accepted. No network registry outage can block app startup.
