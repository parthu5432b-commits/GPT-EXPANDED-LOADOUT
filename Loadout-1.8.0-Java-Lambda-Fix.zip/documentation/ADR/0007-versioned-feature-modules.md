# ADR 0007 — Versioned study feature modules with legacy presentation adapters (historical)

- Status: historical; its six-study-module decision remains active, but the AI Coach deferral was completed by ADR 0011
- Date: 18 November 2026

## Context

The current product is a functioning Capacitor/WebView application whose original screens, layout and state are concentrated in `www/app.js`. Rewriting the screens or moving all UI/state at once would create unnecessary regression and migration risk.

## Decision

Register the six non-AI study workspaces as versioned first-party features against runtime API 1.5.0. Extract pure domain services for chapter mapping/mastery, dashboard summaries, PYQ filtering, Test Ledger operations, forecast calculations and Data & Settings/database orchestration. Route modules delegate rendering to the existing legacy view functions until a feature can be completely extracted with persistence, lifecycle, error/empty states and regression coverage.

At the 1.5.0 decision point, AI Coach remained a legacy adapter reserved for Step 0.75.5. That reservation is now fulfilled by ADR 0011 and Loadout 1.5.5.

## Consequences

- The six non-AI modules have stable IDs, routes, versions, service declarations and offline claims.
- The existing screen implementation and state format remain active; this is a functioning modular seam, not a fully modular UI.
- Tests verify module registry agreement, duplicate route/ID rejection and calculation/service behaviour.
- Subsequent extraction can replace one complete route at a time without duplicating the whole application.
