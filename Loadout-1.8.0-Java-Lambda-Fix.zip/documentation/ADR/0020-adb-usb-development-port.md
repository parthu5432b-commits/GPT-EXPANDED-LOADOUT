# ADR 0020 — Debug-only ADB/USB Development Port

- Status: accepted and implemented in source for Loadout 1.7.0; Android/device validation pending.
- Date: 19 November 2026.

## Context

The owner needs a controlled way to inspect the app and transfer signed packages without creating a permanent network listener or remote shell.

## Decision

Use a debug-build-only native inbox under app-specific external storage. Android ADB host authorization is the pairing boundary. The CLI verifies signed `.lupdate` and `.lreg` packages before push; the app independently validates them before use. All paths, extensions and package sizes are constrained. The Observatory requires explicit staging and manual approval.

## Consequences

- No LAN listener, remote execution or root requirement.
- Non-debuggable builds disable the inbox.
- Device/ADB behaviour must be validated on real Android versions before relying on it.
