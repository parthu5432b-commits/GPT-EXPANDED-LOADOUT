# ADR 0014 — Explicit provider test and exact request preview

- Status: accepted and implemented in source release 1.5.5

A provider connection test is an explicit user action with a quota warning. It sends a fixed minimal probe and no selected conversation or study records. Normal provider requests expose a preview of the fixed JEE Main system instructions, bounded conversation history, currently selected study context and next message. Only individually selected study context fields may be attached. API keys and other conversations are never part of the request preview or request body.
