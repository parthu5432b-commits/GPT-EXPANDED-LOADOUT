# ADR 0011 — Complete AI Coach as Step 0.75.5

- Status: accepted and implemented in source release 1.5.5
- Owner directive: perform after the 75% feature/database foundation and before the final milestone

## Decision

Register AI Coach as a first-class offline feature module while retaining the existing chat UI as a compatible presentation adapter. Its pure conversation, context, provider-contract, Markdown and math functions live in `www/modules/ai-coach/ai-coach.js`. The `chatbot` route is declared in both JSON and runtime registries with a versioned service contract.

## Credential boundary

On Android, the provider key remains in Android Keystore and is read only by `LoadoutCorePlugin` when issuing a native HTTPS request. JavaScript passes the credential ID but not the secret value. This avoids WebView CORS and does not expose the key to page script. Browser fallback is explicitly session-only. Chat v4 persistence snapshots and backup exports strip credential-like and unknown profile fields.

## Streaming and request lifecycle

Both native Android and browser fallback support SSE text streaming for supported Gemini/OpenAI-compatible formats. Native events carry a request ID; JavaScript ignores non-matching chunks and removes the event listener in `finally`. Stop generation aborts browser fetch or disconnects native HTTPS. Payload and response limits, HTTPS enforcement, no redirects and timeout rules are enforced at the transport boundary.

## Context and provider transparency

Provider connection test uses a fixed probe with no chat history or study context and displays a quota warning/confirmation. Regular requests include bounded recent history and only local study summaries/recent tests selected by the owner. A preview shows the system prompt, selected history, enabled local context and current next message.

## Rendering and offline capability

Markdown raw HTML is escaped and URL schemes are validated. KaTeX 0.19.1 plus auto-render and mhchem are pinned dependencies, copied into local `www/vendor/katex` by `postinstall`, hashed in a vendor manifest and cached by the service worker. KaTeX `trust:false` is used.

## Migration and recovery

Legacy v1-v3 chat records are normalized into schema v4. The app does not delete old chat stores until the sanitized v4 local record and private mirror have exact read-back verification and every discovered legacy credential is either securely migrated or intentionally held in original data. A failed migration gates chat writes and preserves the old data.

## Validation boundary

Automated contract/unit tests pass in the repository. The native Java source has not yet been compiled against generated Android code; Android Keystore, SSE, cancellation, lifecycle and prior-installed-key compatibility still require device/emulator testing.
