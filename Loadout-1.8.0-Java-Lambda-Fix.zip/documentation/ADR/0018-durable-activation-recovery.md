# ADR 0018 — Durable update activation and startup recovery

- Status: accepted and implemented in Loadout 1.6.0
- Date: 19 November 2026

## Context

Android can terminate the process at any point. A rollback routine that runs only in a caught JavaScript exception does not protect against process death after one active pointer has been written.

## Decision

Before changing active registry/configuration pointers, persist the transaction as `activating` with the previous snapshot and journal entry. At runtime startup, scan the bounded transaction index. Any transaction still in `activating` is treated as an interrupted activation: restore the previous resource registry and managed config, mark the transaction `activation-failed`, and append a recovery journal record.

## Consequences

- Recovery is deterministic for the currently managed pointer/config transaction.
- User study records and database rows are not part of this update transaction.
- Recovery does not imply general DB rollback or reverse migration support.
- Device-level process-kill validation remains outstanding; automated tests simulate the durable state left by process death.
