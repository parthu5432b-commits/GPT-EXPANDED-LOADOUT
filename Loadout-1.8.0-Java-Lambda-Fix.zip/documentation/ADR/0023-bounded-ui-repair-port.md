# ADR 0023 — Bounded, signed in-app Visual Repair Port

- Status: accepted; source implementation and automated tests added in Loadout 1.8.0. Android/device validation pending.
- Context: screenshot-driven UI defects need a small, reversible delivery unit without turning the app's USB/ADB ingress into remote code execution.
- Decision: define `.lfix` as an Ed25519-signed JSON package supporting only `SET_UI_TOKEN` operations against a fixed token catalogue and stable global/module scopes. The app verifies, stages, presents exact token/value impact, then requires manual commit or rollback. Persisted active token overrides are reconciled at startup; the prior state is restored after an interrupted activation failure.
- Alternatives rejected: arbitrary CSS text, selector/DOM patches, JavaScript injection, WebView eval, dynamic module code, unauthenticated LAN endpoint.
- Consequences: common spacing/typography/overflow repairs can be installed without rebuilding APK. Any visual defect outside the safe token surface becomes a source repair and APK rebuild. Ed25519 WebCrypto availability on the target WebView must be device-tested; absence fails closed.
