# ADR 0009 — Compiled native SQLite migration and query allowlists

- Status: accepted for Loadout 1.5.0
- Date: 18 November 2026

## Context

A WebView-facing native database bridge must not become a general SQL endpoint. User-controlled update data or compromised web content must not be able to select arbitrary database files, execute arbitrary DDL or run arbitrary write statements.

## Decision

The native bridge opens only the app-private database named `loadout-main`. It accepts only the two exact schema migration IDs and SHA-256 values compiled into the installed plugin; applies migrations contiguously in a SQLite transaction; validates each existing migration row and rejects missing/extra ledger records. It accepts a small allowlist of fixed SELECT query shapes. Writes are parameterized INSERT/INSERT OR REPLACE and full-table DELETE operations against seven approved application tables. Schema DDL is only accepted in the exact compiled migration flow.

## Consequences

- Adding/altering DDL requires a sequential migration, a new reviewed checksum and a compatible APK update.
- No arbitrary SQL/DDL console or user-supplied migration executor exists.
- The native Java implementation still needs a real Android compile and physical-device tests before being called production-verified.
