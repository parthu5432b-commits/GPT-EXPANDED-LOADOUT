# ADR 0008 — Additive structured database before source-of-truth cutover

- Status: accepted for Loadout 1.5.0
- Date: 18 November 2026

## Context

The current UI synchronously reads/writes a legacy JSON state key. Changing its source of truth before validating all records, backups, recovery behaviour and Android process lifecycle would risk losing the user's study history.

## Decision

Introduce a versioned SQLite database on Android and IndexedDB for browser/PWA use. Preserve the full legacy JSON snapshot in `app_state`; build indexed attempt and forecast rows as projections. Bootstrap the structured store only after the existing local/private mirror recovery completes. Keep localStorage as the active application authority for this milestone.

Every write is validated, serialized, committed atomically, then read back. Read-back verification checks the whole state digest, every test/forecast row payload and the exact migration ledger. The state revision increases for each successful structured write.

## Consequences

- Existing UI code and legacy storage keys remain intact.
- Database mismatch is archived before reconciliation when its integrity digest is valid.
- A successful mirror is not permission to delete or rename the legacy source.
- Database failure does not silently become a legacy-state overwrite.
- A later source-of-truth cutover requires separate migration/backup/device tests, an owner-facing approval and a recovery plan.
