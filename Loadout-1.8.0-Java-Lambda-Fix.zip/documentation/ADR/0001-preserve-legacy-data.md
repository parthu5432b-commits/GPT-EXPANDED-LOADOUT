# ADR 0001 — Preserve the legacy app and state stores

- **Status:** Accepted
- **Decision:** Keep the working `www/app.js` UI and its current study/chat stores as a compatibility adapter; add a native private mirror and versioned runtime around it. Do not replace existing storage with a new database in this foundation milestone.
- **Reason:** The uploaded project already has functioning study workflows and potentially valuable private records. A wholesale rewrite or simultaneous storage migration would increase the risk of data loss and regressions.
- **Consequences:** The main state remains in localStorage with a native mirror; chat migration writes v3 and retains old stores until credential handling succeeds. Feature code is still monolithic; module extraction is deferred.
- **Alternatives rejected:** Rebuild all screens and move everything to SQLite in one release; remove old stores after writing v3 without a successful secure-key migration.
- **Recovery:** Keep exact raw corrupt state in `legacy-recovery/corrupt-main-state`; retain versioned source archives in `reference/`.
