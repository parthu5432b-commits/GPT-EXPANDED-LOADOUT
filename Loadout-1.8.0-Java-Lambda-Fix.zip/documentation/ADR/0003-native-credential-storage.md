# ADR 0003 — Store AI provider credentials with Android Keystore

- **Status:** Accepted
- **Decision:** Store provider credentials as AES-256-GCM ciphertext in app-private files, using a non-exportable Android Keystore AES key. Chat history serialization excludes provider API keys.
- **Reason:** WebView localStorage is not an adequate default for long-lived provider secrets. Credential identity is authenticated as AES-GCM additional authenticated data.
- **Consequences:** Persistent secure credentials are available only in the Android host where `LoadoutCore` is installed. Web-only use warns that there is no secure credential store. Existing v1/v2 keys are retained until migration to Keystore succeeds.
- **Recovery:** A missing Keystore alias does not silently generate a replacement key to decrypt old ciphertext; the plugin fails closed. Legacy chat stores are retained if a credential cannot be secured.
