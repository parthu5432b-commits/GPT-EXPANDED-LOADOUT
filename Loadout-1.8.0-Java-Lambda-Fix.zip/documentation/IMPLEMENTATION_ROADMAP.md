# Loadout implementation roadmap — fixed full-project checkpoints and post-integration hardening

Checkpoint percentages refer to the whole project, not the fraction remaining. They describe cumulative source delivery scope; they are not a proxy for device-validation coverage.

| Step | Cumulative checkpoint | Delivered scope | State |
|---|---:|---|---|
| Foundation | 25% | Repository reconstruction, native/runtime foundation, storage lifetimes, signed resource updates | Delivered in 1.3.0 |
| Data safety | 50% | Recovery gate, verified snapshots/restore, data safety, Test Ledger foundation | Delivered in 1.4.0 |
| Feature/database foundation | 75% | Feature modules, structured DB schema and additive migration/mirror | Delivered in 1.5.0 |
| AI Coach Step 0.75.5 | Reserved substep after 75% | Dedicated JEE Main AI Coach, history migration, provider security, streaming, context control, offline rendering | Delivered/hardened in 1.5.5/1.5.6 |
| Final milestone first half | 87.5% | Full guarded declarative LTL engine, signed package validation, impact report, transaction journal, manual approval and interrupted activation recovery | Delivered in 1.6.0 |
| Final milestone second half | 93.75% | Debug-only authenticated ADB/USB Development Port, native extension contract and decision to keep native code APK-bound | Delivered in 1.7.0 source |
| Final integrated source | 100% source target | Private signed registry catalog, dependency compatibility checks, offline cache/fallback, signer rotation/revocation tools, final CI/build integration | Delivered in 1.7.0 source; platform validation pending |

## Implemented architectural boundaries

1. The runtime is offline-first. Installed feature modules and local data do not require a registry server. AI provider requests require internet by their nature.
2. `.lupdate` remains a signed JSON resource package. Guarded LTL operations work against staged copies, never live files.
3. `.lreg` is a signed catalog metadata package. It can only describe feature modules already bundled in the APK; it cannot change module code or add/remove executable modules.
4. `.lmod` executable activation is not implemented and Development Port rejects it. Module code changes require a new APK.
5. Native services are compiled into the Android host. A versioned inventory/contract is exposed; dynamic DEX/JAR/`.so` loading is disabled. Native changes require APK replacement.
6. The Development Port is debug-only and uses ADB over USB with Android host-key authorization. No app network listener, arbitrary remote shell or eval endpoint exists.
7. Imported catalogs and verified `.lupdate` packages are persisted locally and re-verified; invalid registry cache falls back to the bundled catalog.
8. The app's original localStorage state remains authoritative. SQLite/IndexedDB schema v2 is a verified additive mirror; source-of-truth cutover is not claimed.

## Remaining real release validation

The source ZIP and GitHub workflow are delivered, but full product acceptance still requires a successful hosted build and device tests. Outstanding gates: native Java compilation against generated Capacitor Android project; APK package/signature inspection; comparison to any installed app certificate; USB/ADB inbox behavior on supported Android versions; migration/Keystore/AI stream/abort/backup/restore tests; forced process-death and rollback tests; screenshot/keyboard/responsive regression.

Build reproducibility is not fully locked because no `package-lock.json` is included; direct dependencies are exact-pinned but transitive resolution uses `npm install`. The owner must set a persistent `LOADOUT_DEBUG_KEYSTORE_BASE64` GitHub secret for stable debug signing identity.


## 1.8.0 — post-integration repairability and observability layer

The 100% line above describes the agreed core source-scope checkpoint, not the end of future maintenance or physical acceptance. Release 1.8.0 adds operational repairability and makes the modular/port boundaries visible without pretending the application has become a generic hot-swappable plugin host.

- Seven first-party feature contracts now expose service and storage read/write declarations in the owner-facing Runtime & Observatory.
- The screen layer remains incrementally extracted: feature services are independently registered/tested, while legacy-compatible screen rendering remains where a complete safe extraction has not yet been proven.
- The Visual Repair Port accepts only signed `.lfix` packages containing bounded `SET_UI_TOKEN` operations. The app stages, displays, commits and rolls back those changes.
- The Source Repair Port accepts signed `.lpatch` packages on the development workstation only. It stages a repository copy, applies hash/anchor-guarded text patches, runs the full local checks, and awaits a separate owner commit.
- The existing USB/ADB inbox carries `.lupdate`, `.lreg` and `.lfix`; it deliberately rejects `.lpatch`, executable `.lmod`, arbitrary scripts and shell commands.
- Screenshot repair is a human-in-the-loop workflow: export minimal repair context, provide the screenshot/context to the repair author, inspect the generated package, sign locally, transfer/import, preview and manually approve. Only layout defects covered by the current token catalogue can be fixed in-app. Logic/native changes still require a source patch and APK build.

No new cumulative percentage is assigned; 1.8.0 is a repairability/observability release after the 100% core source checkpoint. Remaining acceptance gates still include a successful hosted Gradle build, APK signature inspection, native compilation, Android/ADB/Keystore validation, install-over-existing, real process-death recovery and mobile screenshot regression.
