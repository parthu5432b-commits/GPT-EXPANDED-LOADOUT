# Source audit — Loadout Foundation 1.3.0

**Audit date:** 18 November 2026  
**Canonical source:** `Loadout--main.zip` (user identified the 400+ KB archive as the important version)  
**Reference source:** `silver-spoon-main.zip`

## 1. Archive integrity and selection

| Archive | Bytes | SHA-256 | Decision |
|---|---:|---|---|
| `Loadout--main.zip` | 435,520 | `570ddfd391b0e3aacfea33226393ecbf9c637c41f1e7035e336eb5d346215ae4` | Canonical source baseline |
| `silver-spoon-main.zip` | 193,160 | `5e6435db808a218f87bf7ebc058df2eb1958bf342312061ab10572cf586d3986` | Older predecessor/reference |

Both archives passed ZIP integrity checks. The primary archive contains the repository source at its root and an embedded legacy application payload ZIP. The older archive is a wrapper ZIP containing an earlier project ZIP. The primary root project was selected because it contains the more developed build/runtime/native layer; the smaller project is retained only for recovery/reference. No nested payload archive is used as the new build input.

The primary archive contained an embedded application payload ZIP, while the smaller archive wrapped an earlier project ZIP. Both nested ZIPs were listed and inspected; the primary repository root is the selected build source. Its embedded payload is not extracted by the new build. The source generations contain some duplicate legacy application files; the primary repository version is kept active, and the full original archives are retained for forensic recovery.

The primary archive's initial project metadata was `package.json` version `1.1.0`, app ID `app.loadout.jee`, app name `Loadout JEE`, Capacitor `7.4.3`, runtime `0.1.0` / API `1.0.0`, and build instructions versionCode `2`. The delivered source advances this to package version `1.3.0`, Android versionCode `4`, runtime/API `1.2.0`.

The legacy `app.js` and three historical trend JSON datasets were compared between the two source generations and were byte-for-byte identical at baseline. The work in this release then modifies the primary `www/app.js` to add runtime governance, data recovery and secure AI Coach credential migration while preserving the original study features/formulas. The original complete source archives are included under `reference/`.

## 2. Project tree (current delivery)

```text
.github/workflows/build-apk.yml
architecture/
  DEVELOPMENT-PORT.md
  L-SEAA-SPECIFICATION.md
  NATIVE-EXTENSION-SECURITY.md
  TRANSACTION-AND-ROLLBACK.md
  UPDATE-PACKAGE-FORMAT.md
capacitor.config.json
BUILD_INSTRUCTIONS.json
BUILD_INSTRUCTIONS.md
BUILD_PLAN.json
CHANGELOG.md
README.md
LOADOUT_ARCHITECTURE.md
modules/registry.json
native/android/LoadoutCorePlugin.java
exam-profiles/jee-main-2027/profile.json
documentation/
  MASTER_CODING_AGENT_BRIEF.txt (verbatim owner specification; repository-only)
  SOURCE_AUDIT.md
  REQUIREMENTS_MATRIX.md
  ARCHITECTURE.md
  DATA_DICTIONARY.md
  RELEASE_CHECKLIST.md
  MASTER_CODING_AGENT_BRIEF.txt
  ADR/0001-preserve-legacy-data.md
  ADR/0002-signed-resource-only-updates.md
  ADR/0003-native-credential-storage.md
reference/
  Loadout--main-original.zip
  silver-spoon-main-original.zip
scripts/
  build.mjs
  check-source.mjs
  validate-data.mjs
  generate-update-keypair.mjs
  register-update-key.mjs
  sign-update-package.mjs
  validate-update-package.mjs
src/core/
  backup.js
  ltl.js
  package-format.js
tests/unit/...
tests/integration/runtime-transactions.test.mjs
www/
  index.html, app.js, sw.js, manifest.webmanifest
  subject history scripts
  assets/
  data/ (2019–2025 historical datasets and JEE Main 2027 profile)
  runtime/ (Loadout runtime, module registry, trust store)
```

## 2.1 Complete file inventory and sizes

`FILE_INVENTORY.tsv` is the generated complete repository file inventory. It records each included relative path, byte size and SHA-256 digest (the inventory file itself is excluded from its own manifest). This includes the two preserved source ZIPs under `reference/`. Build output, generated `android/`, node_modules, local signing material and Git internals are not repository inputs.

## 3. Languages, framework and build toolchain

| Layer | Technology/version |
|---|---|
| UI | Static HTML/CSS/JavaScript, no frontend framework or bundler |
| Android bridge | Java Capacitor plugin template |
| Android wrapper | Capacitor Android/Core/CLI `7.4.3` |
| Package scripts | Node.js ES modules, Node `22.x` |
| Build runtime | Java/JDK `21` |
| Android SDK | compile SDK `35`, target SDK `35`, min SDK `23` |
| Android build | Capacitor-generated Gradle project + Gradle wrapper; task `assembleDebug` |

No `package-lock.json` is included. Direct Capacitor dependencies are exact-pinned, but transitive dependencies are not locked. Network access to the npm registry was unavailable during this preparation, so a lockfile could not be generated and validated. The workflow uses `npm install` and documents this limitation.

## 4. Android identity and signing

- Application ID: `app.loadout.jee`.
- App name: `Loadout JEE`.
- Source package version: `1.3.0`.
- Android versionCode: `4`.
- Capacitor webDir: `www`.
- Native plugin: `LoadoutCorePlugin` registered in the generated `MainActivity` by the root build script.
- Signing: debug build. GitHub Actions accepts `LOADOUT_DEBUG_KEYSTORE_BASE64` to restore an owner-provided stable debug keystore. When absent, it generates a temporary runner-local debug keystore. The signing certificate of any already-installed user APK has not been verified.

## 5. Entry points and startup

`www/index.html` is the WebView entry. Deferred scripts load the Physics/Chemistry/Mathematics history datasets, the JEE Main 2027 profile, the module registry, `www/runtime/loadout-runtime.js`, and then `www/app.js`. The runtime is loaded before the legacy app so the global service facade is ready before native storage/credential operations are requested.

The Android native host is generated by Capacitor. `scripts/build.mjs` inserts the native plugin source into the generated package, ensures `registerPlugin(LoadoutCorePlugin.class)` is present in `MainActivity.onCreate`, synchronises the `www/` directory and runs Gradle.

## 6. Existing screens and navigation

The existing UI has desktop sidebar and mobile navigation. Routes/screens are:

1. Command Center / dashboard (`view-dashboard`).
2. Chapter Map (`view-chapters`).
3. PYQ Intelligence (`view-historical`).
4. Test History (`view-tests`).
5. Forecast Lab (`view-forecasts`).
6. AI Coach (`view-chatbot`).
7. Data & Settings (`view-data`).

The CSS uses a deep navy base (`#090d18`), dark navy panels, blue-grey borders, light text and purple/mint/amber accents. This release keeps the existing design language and does not attempt an unsolicited redesign. No device-sized screenshot regression was possible in the preparation environment.

## 7. Persistence stores discovered

| Store/key | Purpose |
|---|---|
| `loadout-jee-2027-v1` | Main study state: settings, attempts, forecasts and UI state |
| `loadout_chat_v2` | Prior conversation/provider state, including possible legacy key values |
| `loadout_chat_v1` | Earlier chat format; may hold provider key in a single-profile shape |
| `loadout_chat_v3` | New multi-conversation chat history/profile metadata without API keys |
| `loadout-pre-restore-<timestamp>` | Pre-restore snapshot |
| `loadout-pre-restore-index` | Index of UI pre-restore snapshots |
| `loadout.runtime.v2.*` | Browser fallback for runtime configuration, transaction registry and diagnostics |
| Native `legacy/main-state` | Private mirror of main study state |
| Native `legacy-recovery/corrupt-main-state` | Exact raw invalid state retained before mirror recovery |
| Native `credentials/s_<sha256>` | AES-GCM credential ciphertext; AES key held in Android Keystore |
| Native `runtime/*`, `diagnostics/*`, `data-packs/*` | Runtime-managed config/journal/resource pack storage |

The main legacy state schema uses `version: 1` and settings/attempts/forecasts/ui fields. There is no formal SQLite schema in this release. Chat v3 migration keeps old stores until chat history is persisted and known legacy credentials have been transferred to secure storage; it does not silently erase the only remaining key copy.

## 8. Data sets and provenance

| Dataset | Source shape / audit |
|---|---|
| Physics | 32 source chapters; 170 topic rows before filter; 145 retained; 25 excluded |
| Chemistry | 28 source chapters; 170 before; 132 retained; 38 excluded |
| Mathematics | 31 source chapters; 210 before; 143 retained; 67 excluded |
| Total | 550 original topic rows = 420 retained + 130 excluded |
| Historical coverage | 2019–2025 source year keys |

The validator checks subject/chapter counts, yearly E/M/T/O rows, `O = E + M + T`, excluded count and total reconciliation. It does not prove that every row is a unique official shift question or that any historical topic is active in the 2027 syllabus. Excluded-topic records preserve labels and audit metadata but not all original numerical rows. The source audit metadata says source document pages total 91, but original PDFs were not bundled with either uploaded ZIP.

The separate JEE Main 2027 Paper 1 profile records 54 top-level NTA unit headings: Mathematics 14, Physics 20, Chemistry 20. The source is the official NTA syllabus listing/PDF; retrieval date recorded as 2026-11-18. The source PDF does not state an exact publication date in captured metadata. A reviewed mapping from these unit headings to legacy chapter IDs has **not** been done and remains explicitly `not-yet-mapped`.

## 9. Build workflow and artifact

- Workflow: `.github/workflows/build-apk.yml`.
- Triggers: branch push, pull request and manual `workflow_dispatch`.
- Steps: checkout, Node 22, JDK 21, Android SDK platform/build-tools 35, dependency install, tests, data audit, syntax/source checks, root build script, Gradle `assembleDebug`, APK identity/signature/assets verification, artifact upload.
- Artifact: `Loadout-Android-1.3.0-debug` containing `dist/Loadout-Android-debug.apk`, checksum and `build/BUILD_INFO.json`.
- Workflow/build instructions are outside `www/`; only `www/` is Capacitor's web payload.

The workflow is a real Gradle build path. No Android SDK/Gradle build was run in this session because `ANDROID_HOME` and `ANDROID_SDK_ROOT` were not configured and no Android SDK is installed in the environment. Therefore no genuine APK is included or claimed.

## 10. Tests and known gaps

Current automated coverage:
- Unit: backup schema validation; path safety; declarative LTL operations; guarded source patching; operation metadata; prototype-pollution rejection; package validation; executable-resource rejection; Ed25519 signature verification and untrusted/tampered rejection.
- Integration: runtime staging/manual decision; immutable content-addressed resource versions; commit/rollback; stale commit/rollback rejection; storage persistence lifetimes and module deactivation.
- Static: Node syntax check across 23 JS/MJS files.
- Data: historical row reconciliation and official profile unit count/mapping state.

Not covered in this runtime: Android Java compilation, device Keystore, MediaStore export, actual Capacitor plugin registration, localStorage/native mirror upgrade on real process death, UI screenshot regression, install-over-existing APK/signature and Gradle APK packaging.

## 11. Security/privacy risks found and addressed

- Legacy chat stores could be removed before a Keystore write succeeded. The migration now retains v1/v2 until the secure store is confirmed and history v3 is saved.
- Previously a provider key could be serialized in legacy chat records. New v3 serialization excludes API keys; legacy data is migrated cautiously.
- An update resource path key was path-derived, allowing different resource contents to share a mutable file slot and break rollback. Storage is now content-addressed by the content SHA-256.
- A staged transaction could become stale if another update changed active state. Commits and historical rollbacks now check snapshots and reject stale/superseded changes.
- JSON Pointer prototype-pollution keys are rejected.
- Native credential key replacement now fails closed if encrypted records remain but the Keystore alias is missing.
- Update packages reject executable code and require a trusted Ed25519 signer. The shipped trust store is empty by default.
- API credentials, private update signing keys and personal study data must not enter repository or diagnostics.

## 12. Existing features preserved and files modified

Preserved in the legacy application: the seven UI workspaces; chapter/test records; QCT/QPT/QFT/HFT/OTHER support; C/W/U accounting; configured `4 × correct − wrong` scoring; chapter/subject breakdowns where supplied; forecast records/formulas/calibration; historical datasets/trends; local export/import; AI provider request flow and offline chat history.

Modified in this release: app startup/runtime script integration, JEE Main-only chat persona/credential handling, secure storage access, native backup/export bridge, local corrupt-state recovery, runtime governance/observatory and service-worker cache version. Existing scoring/forecast formulas were not changed.

## 13. Generated, stale or unused content

- Original project ZIPs are under `reference/` for provenance and are not build inputs.
- No `android/` generated Capacitor project is committed; it is generated by the build script and ignored.
- No `node_modules/`, local signing keystore, private update key or built APK is included.
- No nested payload ZIP is retained in the active repository tree; build uses repository-root source directly.


---

# Release 1.4.0 source-audit addendum — 18 November 2026

This addendum records the second fixed 25-percentage-point milestone. The preceding 1.3.0 audit above is retained as a historical record; it is not the current release state.

## Current release identity

- Primary source remains `Loadout--main.zip` (435,520 bytes at intake). `silver-spoon-main.zip` (193,160 bytes) remains predecessor/reference only.
- Package/source version: `1.4.0`; Android `versionCode`: `5`; package ID: `app.loadout.jee`; app label: `Loadout JEE`.
- Capacitor dependencies: exact-pinned direct dependencies `7.4.3`; runtime/API `1.4.0`; Node engine `>=22 <23`.
- Existing UI remains in `www/app.js`; seven existing workspaces and legacy state key `loadout-jee-2027-v1` are retained.

## 1.4.0 source changes

- Added `www/runtime/recovery-gate.js`, loaded before the legacy UI. It provides a fail-closed write gate when an invalid local state record cannot be preserved or verified. Writes resume only after an explicit owner confirmation. The exact raw string is downloadable when it can be read.
- Divergent private study-state mirrors are archived and read back before reconciliation. Invalid local state quarantine is read back byte-for-byte before private-mirror recovery. If the quarantine cannot be verified, writes remain blocked rather than overwriting the original local value.
- Private mirror writes remain serialized, awaited on flush and compared against the full current state.
- Schema-3 pre-restore safety snapshots are fully validated after storage read-back; snapshot listing/review/restore remains owner controlled.
- AI Coach migration writes remain gated until legacy provider credentials are either migrated through Android Keystore or retained in the explicit minimal migration-hold record. Existing legacy records are not normalised/overwritten before this decision. Old stores are removed only after exact sanitized-history persistence verification and no unresolved provider credentials remain.
- `loadout.test-ledger` v1.1.0 remains the first extracted feature service for C/W/U validation, canonical record construction, configured scoring, duplicate ID checks and deletion. The surrounding screen/state adapter remains legacy code.
- Test suite gains recovery-gate unit tests; current suite total: 34.
- `scripts/check-source.mjs` validates the recovery-gate file and script ordering; the service worker pre-cache includes it.

## Updated current-source validation

- `npm test`: 34 tests passed, 0 failed. The final 79-entry ZIP was extracted to a clean directory and the same tests were rerun there.
- `npm run check`: 29 JavaScript/MJS files syntax-checked; 14 JSON files parsed; repository identity, startup order, feature-module/runtime contracts, service-worker references and web asset declarations passed.
- `npm run audit:data`: 550 historical source rows reconcile as 420 retained plus 130 excluded (Physics 145/25, Chemistry 132/38, Mathematics 143/67). The official-source JEE Main 2027 Paper 1 profile contains 14 Maths, 20 Physics and 20 Chemistry top-level units; mapping to legacy chapters remains unverified.
- No Android SDK/Gradle compile or physical-device validation was performed. The native Java plugin and Keystore migration are source-implemented but not device-verified.
- No `package-lock.json` is present because npm registry metadata could not be retrieved in the preparation environment; transitive dependency reproducibility remains incomplete.

## Repository boundaries

The source-native plugin is under `native/android/`. Generated Capacitor/Gradle project output is the separate root `android/` directory and is excluded from the committed source bundle. The repository root, not either nested historical archive, is the build input. Capacitor `webDir` remains `www/`; workflow, scripts, tests, prompt and engineering documents remain outside it.

---

# Release 1.5.0 source-audit addendum — 18 November 2026

This addendum supersedes earlier release identity/status lines for the current source tree. Earlier historical audit sections are retained for provenance.

## 1.5.0 baseline and identity

- Primary source baseline remains the larger `Loadout--main.zip` upload. `silver-spoon-main.zip` is retained as predecessor/reference only.
- Version: `1.5.0`; Android `versionCode`: `6`; package ID: `app.loadout.jee`; label: `Loadout JEE`.
- Capacitor direct dependencies remain exactly pinned to `7.4.3`; Node engine is `>=22 <23`; Android toolchain declarations are Java 21, compile/target SDK 35 and min SDK 23.
- Legacy `www/app.js`, visual system, navigation and `loadout-jee-2027-v1` state key remain present. The AI Coach remains a legacy adapter reserved for Step 0.75.5.

## New/expanded 1.5.0 source

- `www/runtime/feature-runtime.js` adds first-party feature lifecycle/route/service contracts. `www/runtime/module-registry.js` and `modules/registry.json` declare six feature modules plus the AI Coach deferred adapter entry.
- Pure service extractions include chapter mapping/attempt shaping, chapter mastery/baseline, dashboard summary, PYQ filtering, forecast regression/prediction, and existing Test Ledger operations.
- `www/runtime/database-schema.js`, `database-model.js`, and `database.js` implement logical schema v2 with Android SQLite and browser IndexedDB backends. `app_state` preserves complete JSON; indexed attempts/forecasts are projections; module_records supports future feature-owned records.
- The current localStorage key remains the active UI source of truth. Database bootstrap occurs after legacy recovery and performs digest and row-level verification. No localStorage cutover or destructive deletion occurs.
- `native/android/LoadoutCorePlugin.java` adds an app-private `loadout-main` SQLite bridge with compiled migration hash allowlist and fixed query/write statement shapes. The native code has not been compiled against an Android SDK in this environment.
- The build workflow artifact name is updated to `Loadout-Android-1.5.0-debug`.

## 1.5.0 verification record

- `npm test`: 56 tests passed, 0 failed at this audit point. The suite includes actual SQLite-engine execution of schema DDL and simulated transactional rollback; it does not execute the Android Java plugin.
- `npm run check`: JavaScript/MJS syntax, JSON configs, runtime/module registry/service agreement, startup order, offline asset declarations, native migration/source contract and release metadata pass. It emits a warning because no npm lockfile could be generated in the offline/DNS-restricted environment.
- `npm run audit:data`: 550 historical rows reconcile as 420 retained plus 130 excluded. This is source dataset integrity, not a verification that all retained topics are in the official active JEE Main 2027 syllabus.
- `npm ping` to `registry.npmjs.org` failed with DNS `EAI_AGAIN`; no package-lock integrity data was invented. GitHub Actions currently installs exact-pinned direct dependencies with `npm install`; transitive dependency reproducibility remains incomplete.
- Android SDK/build-tools are not installed in this environment. No Gradle APK, native plugin compilation, real-device Keystore/SQLite operation, install/upgrade, screenshot comparison or process-death test is claimed.

## Files and boundaries

- New/updated scripts and feature/runtime source are under `www/`, `modules/`, `native/android/`, `scripts/`, `src/`, and `tests/`.
- `www/` remains the only Capacitor web asset directory. Build instructions, workflow, documentation, source ZIPs, test files and signing material remain outside it.
- The full master coding brief is preserved at `documentation/MASTER_CODING_AGENT_BRIEF.txt`.

# Release 1.5.5 addendum — Step 0.75.5 AI Coach

## Baseline and identity

- Source baseline: extracted `Loadout-Source-1.5.0-Feature-Modules-Migration-Foundation-75pct.zip`, itself based on the larger `Loadout--main.zip` source upload.
- Release: 1.5.5; Android versionCode 7; package ID remains `app.loadout.jee`.
- Runtime API remains 1.5.0; the AI Coach registers as the seventh bundled first-party feature module.

## AI Coach source changes

- New `www/modules/ai-coach/ai-coach.js` owns normalization, bounded context selection, provider payload construction, SSE response parsing, safe Markdown and KaTeX integration.
- `www/app.js` retains the chat screen but dispatches the chatbot route through `LoadoutFeatureRuntime`. Chat state schema v4 supports multiple conversations, local/offline persistence, message actions, backup import/export and request-context preview.
- Provider profiles persist endpoint/model only. Android secrets are stored through the Keystore-backed plugin and are used natively without returning the value to JavaScript. Browser fallback credentials are session-only memory values.
- Native `requestAiProvider` adds bounded HTTPS transport, private/local endpoint rejection, native key attachment, request-ID-scoped SSE events and cancellation. The browser path uses SSE `fetch` and `AbortController`.
- Pinned KaTeX 0.19.1 is copied by the npm postinstall script into `www/vendor/katex`; the service worker caches the vendor manifest and all vendor assets.
- AI Coach UI includes separate provider/model settings, connection test, context selection, complete request preview, conversation search and CRUD, per-message actions, stop, export/import and Markdown/LaTeX display.

## Data handling

- v1/v2/v3 localStorage stores are migration inputs. Current store is `loadout_chat_v4`, plus private mirror `legacy/chat-state-v4`.
- The v4 snapshot strips API keys and unknown provider fields. Old stores are removed only after sanitized v4 local + private mirror verification and successful secret migration/retention checks.
- Chat backup JSON is not encrypted, but contains no provider keys. Browser-session keys disappear at page close.

## Validation

- 77 automated tests passed (including AI Coach feature registration, schema normalization/secret removal, SSE parser behaviour, safe Markdown, provider request construction, request-ID-filtered native event forwarding, listener cleanup and source-level native bridge/security checks).
- 49 JavaScript/MJS files syntax-checked; 20 JSON/config files parsed; seven feature modules/service contracts pass repository validation.
- Historical dataset check remains 550 source rows = 420 retained + 130 excluded.
- Native Java plugin was not compiled and no real Android device/provider run occurred. APK was not built because Android SDK is unavailable in the preparation environment.
- npm lockfile remains absent; KaTeX assets are produced when postinstall runs in an online dependency install.


# Release 1.5.6 addendum — AI Coach defect fixes

- Release: 1.5.6; Android versionCode: 8; app ID: `app.loadout.jee`; runtime API remains `1.5.0`.
- Fixed the Retry action mismatch for assistant messages in `cancelled` status by centralising retry eligibility in `www/modules/ai-coach/ai-coach.js`.
- `www/runtime/loadout-runtime.js` now observes the request `AbortSignal` during native AI transport and cancels the exact request ID; the listener is removed on completion.
- `www/app.js` flushes the original TextDecoder before SSE parser finalization.
- Provider endpoint URL validation is shared between settings persistence and request construction.
- Provider error strings redact common vendor key formats.
- Added ADR 0016 and automated unit/integration regressions.
- These source checks do not establish Android runtime success: native plugin compilation, physical device tests, UI screenshot comparisons and real provider calls remain unperformed.

# Release 1.6.0 addendum — final-milestone first half

- Baseline: `Loadout-Source-1.5.6-AI-Coach-Step-0.75.5.zip`; app ID remains `app.loadout.jee`; runtime API remains `1.5.0`; app version advances to `1.6.0`, Android versionCode to `9`.
- Added a browser-safe LTL engine loaded before the L-SEAA runtime and a Node reference implementation for test parity.
- Supported declarative operations: ADD, REPLACE, PATCH, PATCH_SOURCE, REMOVE, MOVE, RENAME, RECONFIGURE, REWIRE, MIGRATE, CHANGE_POLICY, INSTALL_DEPENDENCY, REMOVE_DEPENDENCY, VALIDATE and ACTIVATE markers.
- Added operation dependency ordering, cycle/missing/duplicate rejection, JSON Pointer safety, state/value preconditions, assertions, bounded declarative migration steps and exact source-patch preimage/match/postimage checks.
- Package validation now checks declared dependencies, resource actions, signer revocation and transformation metadata. The signed payload remains canonical JSON and contains no executable code.
- Update staging now reports operation/risk/resource/config/dependency impact, persists transaction state/journal, requires manual commit/rollback, rejects stale commits and verifies content-addressed resource read-back.
- The runtime writes an `activating` journal state before pointer changes. Startup recovery restores the previous active registry/configuration if Android terminates the process mid-activation.
- Added a static first-party module-registry validator covering manifest parity, route/service uniqueness, offline declarations and dependency graph consistency.
- New test suites cover all supported declarative operation families, package dependency validation, browser-runtime staging/approval, interrupted activation recovery and module-registry validation.
- Boundaries: `.lupdate` remains signed JSON, not ZIP; executable module package activation, full DB migration packages, remote authenticated Development Port, native extension lifecycle framework and dynamic DEX/JAR loading remain unimplemented. Native changes require an APK.
- Android SDK/device tests and screenshot comparison remain separate validation requirements; no APK is claimed unless the real Gradle build completes.

# Release 1.7.0 addendum — final integrated source bundle

## Baseline and identity

- Current repository is the cumulative continuation of the larger `Loadout--main.zip` source baseline, through releases 1.3.0, 1.4.0, 1.5.0, AI Coach Step 0.75.5, the 1.6.0 LTL engine and this 1.7.0 final integration.
- Release identity: `app.loadout.jee`, Loadout JEE `1.7.0`, Android `versionCode` 10, runtime API `1.5.0`.
- The original UI and legacy study-state key are preserved. The Android Gradle project is generated by the repository-root build script and is not committed.

## Final integration changes

- Added the debug-only Development Port, using Android's app-specific external files inbox and ADB host authorization. The host CLI supports `pair`, `status`, `push`, `list` and `remove` through fixed ADB operations. The app has no LAN listener or remote command execution API.
- The Development Port accepts signed `.lupdate` resource packages and `.lreg` private registry catalogs only. It explicitly rejects executable `.lmod`; no executable module hot-installation is claimed.
- Added owner-signed Ed25519 registry catalog packaging and validation, catalog SHA-256 integrity, installed-module/runtime compatibility checks, dependency declaration/graph validation, trusted-key revocation checks and persistent offline catalog caching with bundled fallback/reset.
- Registry catalogs are metadata-only. They cannot add/remove/replace the APK-bundled executable module set. Feature source changes require a new APK.
- Added registry source-hash synchronization, Ed25519 key generation/registration/revocation tools and signed catalog package creation/validation commands.
- Added persistent verified `.lupdate` package cache, re-read digest verification and signature re-verification for offline re-staging.
- Published a versioned native extension inventory/contract for the compiled-in LoadoutCore plugin. Dynamic DEX/JAR and native `.so` loading remain disabled; native changes require a new APK and process restart.
- Updated the service-worker shell and build asset manifest for the bundled registry catalog, release metadata, source inventory and GitHub Actions workflow. Added source inventory regeneration to CI.
- Matched SDK version editing to the exact Capacitor 7.4.3 `variables.gradle` format (`name = integer`); a regression test guards all three SDK assignments.
- Added runtime integration coverage for signed registry import, persistence across simulated restart with the same trust key, reset to bundled state and tamper rejection.

## Repository workflow

- `.github/workflows/build-apk.yml` triggers on pushes to branches, pull requests and manual dispatch. It provisions Node 22, Java 21 and Android SDK 35, installs dependencies, regenerates registry source hashes, runs tests/data audit/source checks, builds the debug APK and uploads the APK, SHA file and build identity.
- Repository content must be placed at the private GitHub repository root and the hidden `.github/` workflow directory must be retained. The workflow artifact is `Loadout-Android-1.7.0-debug`.
- `LOADOUT_DEBUG_KEYSTORE_BASE64` is optional but recommended to keep debug signing stable between GitHub runner invocations. No private signing key is committed.

## Verification and limitations

- `npm test`: 130 passed, 0 failed, including browser-runtime registry persistence/re-verification/reset/tamper test.
- `npm run check`: 63 JS/MJS files and 23 JSON/config files validated; seven modules, 29 services, catalog source hashes, Dev Port and APK-bound native-extension policy pass.
- `npm run audit:data`: 550 historical rows reconcile (420 retained, 130 excluded); this is dataset reconciliation, not a full NTA topic/shift provenance verification.
- A temporary Ed25519 keypair was used outside the repository to exercise registry package creation and signature validation. The bundled trust store intentionally starts empty and rejects untrusted packages.
- The preparation environment has no Android SDK; `npm run build:apk` stops at the explicit SDK preflight. No APK was built.
- Native Java code has not been compiled against the generated Android project or validated on device/emulator. ADB transfer, native lifecycle, Keystore/process-death, screenshot regression and live provider tests remain device gates.
- `package-lock.json` remains absent because npm registry DNS was unavailable in the preparation environment. Direct dependencies are exact-pinned; GitHub Actions uses `npm install`, but transitive dependency resolution is not yet lockfile-reproducible.
- Five KaTeX browser assets are produced by the exact-pinned npm postinstall step; they are not present in this offline preparation tree. The CI install step runs postinstall before building.
- SQLite/IndexedDB schema v2 remains a verified additive mirror; legacy localStorage remains authoritative. No destructive migration/cutover is claimed.


## 1.8.0 source baseline addendum — 19 November 2026

The current release candidate was independently unpacked from the owner-uploaded `Loadout-Source-1.7.0-Final-Integrated.zip` and used as the continuation baseline. The 1.3.0 and 1.4.0 archives and standalone 1.3/1.4 owner documents were retained as historical reference material. The 1.7.0 archive passed `zipfile` CRC integrity verification before changes. The release candidate continues the 1.7.0 repository-root source tree; it does not extract a nested project ZIP for builds.

### 1.8.0 additions verified in the working tree

- Release metadata: application `1.8.0`, Android `versionCode 11`, application ID `app.loadout.jee`, runtime/API `1.5.0`.
- Seven first-party module manifests remain the canonical list. `www/runtime/module-registry.js` is generated from `modules/registry.json` and mirrors route, service, dependency, description and storage access declarations.
- `documentation/PORT_CATALOG.md`, `architecture/MODULE-PORTS.md` and `architecture/REPAIR-PORT.md` define the visible boundaries and repair workflows.
- `.lfix` is a signed JSON in-app UI token package; `www/runtime/repair-engine.js` handles verification, staging, manual decision, activation, rollback and interrupted-transaction recovery.
- `.lpatch` is a signed JSON workstation source repair package; `scripts/repair-port.mjs` stages a repository copy and invokes the fixed test, source-check and data-audit commands before a separate commit.
- The Android inbox type allowlist includes `.lfix` but excludes `.lpatch`, `.lmod` and arbitrary code packages. No TCP maintenance listener is added.
- Runtime & Observatory includes the port directory, module service/storage declarations, repair status and a manually initiated minimal Repair Context export.

### Explicitly unverified

No Android SDK/Gradle compilation or APK generation was performed in this preparation environment. Native Java compilation, target WebView Ed25519 support, physical ADB transfer, installed-app signature compatibility, true process-death recovery and mobile screenshot regression remain release gates. The empty trust store is retained by design; an owner-controlled key bootstrap and trusted APK are required before signed packages can be used. The 1.8.0 source does not claim all seven screen renderers are independently hot-swappable; legacy compatibility adapters remain until a safe extraction is proven.
