# Data dictionary — Loadout 1.5.6

## Legacy stores and current authoritative records

| Key/store | Purpose | Current policy |
|---|---|---|
| `loadout-jee-2027-v1` | Canonical local study state: settings, chapter records, attempts, forecasts and other current app state | Remains the UI source of truth; preserve byte-for-byte before migration |
| `loadout_chat_v4` | Normalized AI Coach conversation state schema 4 | Current local chat store; contains no API keys |
| `loadout_chat_v1` | Earlier single-provider AI Coach state | Read only as legacy migration source; remove only after credential/history migration verifies |
| `loadout_chat_v2` | Earlier multi-conversation chat state | Read only as legacy migration source; credential/key cleanup is gated |
| `loadout_chat_v3` | Prior chat conversations/provider profiles | Read only as legacy migration source; no key allowed in v4 snapshot |
| `legacy/chat-state-v4` | Private runtime mirror of sanitized v4 chat history | Serialized and read-back verified; used for recovery |
| `legacy-recovery/corrupt-chat-state` | Preserved corrupt legacy chat bytes | Persistent owner recovery record; never silently deleted |
| `AndroidKeyStore:ai-*` | Provider credential encryption keys and encrypted files | Credentials remain native; never export or log |
| `loadout-main` SQLite | App-private structured mirror | Schema version 2; not yet the source of truth |
| `loadout-main` IndexedDB | Browser structured mirror | Schema version 2; not yet the source of truth |

## AI Coach schema 4

- `schemaVersion`: integer `4`.
- `provider`: selected provider ID.
- `profiles`: map of provider ID to `baseUrl` and `model` only. API keys and unknown fields are stripped.
- `autoFallback`: whether the owner allows fallback across configured providers.
- `preferences`: history message count, output token limit, include-study-summary toggle, include-recent-tests toggle.
- `conversations`: stable conversation ID, title, created/updated timestamps and message array.
- `messages`: stable ID, role, text content, timestamp, status (`complete`, `streaming`, `cancelled`, `error`) and optional provider ID.
- `activeConversationId`: selected conversation reference.

Bounds: maximum 500 conversations; 5,000 messages per conversation; 200,000 characters per message; up to 80 history messages; output token setting 128–8,192. Import input is capped at 10 MiB. Imported state is normalized and any credential-like or unknown properties are discarded.

## Native provider transport

Request fields: safe `credentialId`, safe `requestId`, HTTPS URL, JSON body, auth mode, provider kind, stream flag and allowlisted extra header metadata. The native transport reads the matching secret inside Android, adds the auth header, disables redirects, restricts resolved addresses, and returns status/content type/body (non-streaming) or request-ID-scoped text events (SSE). It does not return the credential.

Native bounds: 2 MiB request body, 4 MiB response/stream, 20 s connection timeout and 120 s read timeout. Browser fallback secrets exist in memory only.

## AI Coach backup format

- `format`: `loadout-ai-coach-backup`.
- `formatVersion`: `1`.
- `exportedAt`: ISO timestamp.
- `data`: sanitized schema-4 state.

Backups contain no provider keys. Import requires valid JSON, supported shape, normalization, a 10 MiB cap and explicit confirmation before replacing local conversations. Previous local conversations are restored if verified persistence fails.

## Structured database

Database `loadout-main`, schema version 2. The exact table definitions and migration IDs/checksums are in `www/runtime/database-schema.js` and `database/`. Structured state is additive only; legacy localStorage remains authoritative until a separate cutover milestone with owner approval.
