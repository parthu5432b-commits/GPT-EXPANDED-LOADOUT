# Private registry, package signing and key lifecycle — Loadout 1.8.0

## Registry model

The registry is private, first-party and owner-controlled. The APK bundles the active module code, versioned manifests, runtime API contract and default catalog (`registry/catalog.json`, copied to `www/runtime/registry-catalog.json`). The catalog records each bundled module's entry/manifest SHA-256, service declarations and dependency declarations.

`.lreg` is a signed JSON catalog package, not an executable-code archive. Its Ed25519 signature covers the registry manifest and complete catalog. Import checks:
- package format, app ID and runtime API;
- owner-controlled/no-marketplace policy and registry identity;
- increasing catalog revision;
- catalog content SHA-256;
- trusted, non-revoked Ed25519 signer;
- exact installed module set, version, route, entry, offline flag and services;
- dependency declarations and compatibility against the installed bundle;
- valid manifest/entry integrity digest metadata.

A registry package cannot add, remove, replace or hot-load feature source. Module code changes require a new APK. Imported catalogs are persisted locally and re-verified before use; invalid cached state falls back to the bundled catalog. Registry connectivity is not required for startup or use.

## Key bootstrap (owner action)

No private key is committed or distributed. The shipped trust store has an empty `keys` list and `deny-untrusted` policy. This is intentionally fail-closed; `.lupdate`, `.lreg`, `.lfix` and `.lpatch` packages cannot be accepted until the owner performs key bootstrap.

```bash
npm install
node scripts/generate-update-keypair.mjs
node scripts/register-update-key.mjs local-signing/loadout-update-public.pem
```

`KEY_INFO.txt` prints the key ID and public-key details. Commit only the modified `www/runtime/trust-store.json`, not `local-signing/`. Build and install an APK containing the trust store public key before attempting imports.

Keep `loadout-update-private.pem` in encrypted offline backup. Never upload it to GitHub, a ZIP, the APK, app data, diagnostics or chat. Public key identifiers and public key bytes are not secret.

## Package creation and validation

For data/resource updates, use `scripts/sign-update-package.mjs` and `scripts/validate-update-package.mjs` with the JSON format defined in `architecture/UPDATE-PACKAGE-FORMAT.md`.

For a private module catalog:

```bash
npm run registry:sync
node scripts/create-registry-package.mjs local-signing/loadout-update-private.pem <key-id> ./registry-r2.lreg
node scripts/validate-registry-package.mjs ./registry-r2.lreg
```

The package command defaults to a revision newer than the currently bundled catalog. Import by file picker in the Observatory or transfer through the debug-only Development Port.

## Rotation and revocation

1. Generate a replacement Ed25519 key pair and back up its private key offline.
2. Register the new public key with `scripts/register-update-key.mjs`.
3. Build/install an APK that trusts both old and new keys.
4. Sign future packages with the new key and verify import.
5. Revoke the old key with `npm run update:key:revoke -- <old-key-id>`.
6. Build/install an APK carrying the revocation. Devices enforce revocation only after the updated trust store is installed.

Retain the prior known-good APK and public trust state until the replacement is verified. Do not destroy the old key until the owner has decided no remaining recovery package depends on it.

## Registry availability / scope

The registry is an owner-signed local catalog distributed by file/ADB. There is no hosted service, automatic fetch, remote marketplace, multi-user publishing or server-side account. Offline cache and a bundled fallback preserve local operation.


## Visual repair and source repair signing (1.8.0)

The same owner-controlled Ed25519 trust key signs `.lfix` and `.lpatch` packages. The helper scripts can use the default key at `local-signing/loadout-update-private.pem` and key ID in `local-signing/KEY_INFO.txt`; the directory is local-only and excluded from the release ZIP. Example: `npm run repair:sign -- ./repairs/my-fix.lfix.json` creates `repairs/my-fix.lfix`; `npm run repair:validate -- ./repairs/my-fix.lfix` validates it against the public trust store. For source changes, `npm run repair:sign-source -- ./repairs/my-source-fix.lpatch.json` produces `.lpatch`, and `npm run repair:validate-source -- ./repairs/my-source-fix.lpatch` checks it.

A generated package is not automatically trusted merely because it was created by the helper. The matching public key must be registered and present in the installed APK's trust store. Never share the private key. A screenshot and exported Repair Context can be used to author a repair draft, but signing is a local owner action.
