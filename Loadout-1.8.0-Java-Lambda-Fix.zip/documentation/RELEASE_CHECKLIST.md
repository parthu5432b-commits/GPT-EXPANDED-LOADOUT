# Release checklist — Loadout 1.8.0 modular repair-port source

## Preserved product/data
- [x] Larger `Loadout--main.zip` preserved as canonical primary baseline.
- [x] Master coding brief retained verbatim in repository documentation.
- [x] Existing UI/theme/navigation and historical datasets retained.
- [x] Seven first-party feature modules, including AI Coach, declared and versioned.
- [x] Legacy storage keys and schema v2 additive mirror retained; no destructive source cutover.
- [x] JEE Main-only profile; no JEE Advanced features introduced.

## AI Coach and security
- [x] Local conversation CRUD/actions/history and export/import.
- [x] Android Keystore-native provider credential transport; browser session-only fallback.
- [x] Streaming, cancellation, error handling, key redaction, Markdown/LaTeX and explicit context selection.
- [ ] Native Keystore/SSE/provider behavior physically exercised on device.

## LTL and update recovery
- [x] Guarded declarative operation families, dependency order and cycle rejection.
- [x] Safe JSON Pointer, preimage hashes, state/value assertions and staged postconditions.
- [x] Signed JSON `.lupdate` package validation, trust/revocation and resource hashes.
- [x] Durable transaction journal, impact report, manual commit/rollback and interrupted activation recovery.
- [x] Verified resource package cache and offline re-stage.
- [ ] ZIP archive `.lupdate` import/export.
- [x] Executable `.lmod` activation explicitly rejected; code changes are APK-bound.

## Private registry
- [x] First-party catalog with per-module manifest/entry hashes.
- [x] Signed Ed25519 `.lreg` catalog package, trust/revocation, target/version checks.
- [x] Module set, services, routes and dependency descriptors constrained to APK-bundled modules.
- [x] Persistent imported catalog, re-verification, bundled fallback and reset control.
- [x] Key-generation, registration, package creation/validation and revocation commands.
- [x] No signing private key included; empty trust-store is fail-closed.
- [ ] Owner bootstraps their public key and installs APK before importing signed packages.
- [ ] Device-level persistence/revocation failure injection.

## Development Port/native extension boundary
- [x] Debug-only ADB/USB inbox in app-specific external storage.
- [x] Android host authorization as pairing boundary.
- [x] Host CLI for status, package verification/push/list/remove and explicit serial selection.
- [x] In-app Observatory for package inspection, verification and staging.
- [x] 10 MiB package cap, path/filename allowlist and `.lupdate`/`.lreg`/`.lfix` type allowlist; `.lpatch` and `.lmod` rejected by device inbox.
- [x] No network listener, remote shell, arbitrary eval or root assumption.
- [x] Versioned compiled-in native extension inventory and API contract.
- [x] Dynamic DEX/JAR and `.so` hot swap explicitly disabled; native changes require APK.
- [ ] Compile native plugin and test Dev Port on physical Android versions.

## Visible modules and screenshot repair
- [x] Seven module service/storage contracts shown in Runtime & Observatory.
- [x] Honest legacy-adapter status shown; no claim of seven hot-swappable screens.
- [x] Port Directory lists each local/in-process/network boundary and explains which are actual transports.
- [x] Minimal Repair Context export omits private study/chat/provider content.
- [x] `.lfix` signature, token/scope allowlist, stage/preview, manual commit/rollback and startup recovery implemented.
- [x] `.lpatch` signature, path/preimage/anchor guards, staged full-copy validation, separate commit and rollback implemented on host.
- [x] Device ingress rejects `.lpatch`; no remote shell, arbitrary script, generic TCP listener or runtime source editor.
- [ ] Owner creates and backs up an Ed25519 key pair, registers public key and rebuilds/installs trusted APK.
- [ ] Test actual `.lfix` generation/sign/transfer/import/preview/commit/rollback on target phone.
- [ ] Test screenshot context export and verify it contains no study/chat/provider secrets.
- [ ] Test host `.lpatch` against a disposable clone and validate commit/rollback under file-change failure.

## Build/release evidence
- [x] Repository-root build manifest and Capacitor identity align at app version 1.8.0 / versionCode 11.
- [x] GitHub Actions build workflow included under hidden `.github/`; runs on push to any branch.
- [x] Workflow syncs registry, runs tests/data audit/checks, then Gradle build and uploads APK/SHA/BUILD_INFO.
- [x] ZIP CRC, root structure and clean-extract checks are run for final bundle.
- [ ] Hosted GitHub Actions build actually completed.
- [ ] APK signature and package identity inspected from built APK.
- [ ] Compare APK certificate with any previously installed app before update.
- [ ] Persistent `LOADOUT_DEBUG_KEYSTORE_BASE64` secret configured.
- [ ] `package-lock.json` generated/reviewed; workflow switches to `npm ci`.
- [ ] Screenshot, device lifecycle, process-death, backup/restore and install/update tests.

**Release statement:** 1.8.0 is the integrated repository source delivery with executable automated validation and a configured real Android build workflow. It is not represented as a verified APK or physically validated Android release until the unchecked hosted/device gates are completed.
