# Repair package drafts and examples

`examples/dashboard-spacing.lfix.json` is an **unsigned draft** showing the exact visual-repair envelope. It is intentionally not importable until the owner signs it with a registered key. The example is illustrative and should not be applied without checking the actual screenshot/device issue.

For a real screenshot-driven correction, upload the screenshot and a fresh `Export Repair Context` JSON from Loadout to the engineering chat. The returned repair draft is signed locally:

```bash
npm run repair:sign -- ./my-fix.lfix.json
npm run dev:port -- push ./my-fix.lfix
```

Source-level repairs use `npm run repair:sign-source -- ./my-fix.lpatch.json` and the host-only `npm run repair:port` staging/commit workflow. See `architecture/REPAIR-PORT.md` for all formats, limits, trust setup, review and rollback rules.
