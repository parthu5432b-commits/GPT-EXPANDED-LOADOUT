# Loadout JEE — Private Android Source Release 1.8.0

**JEE Main only · Offline-first · Private single-owner application · Repository-root source bundle**

This is the cumulative repository source based on the larger `Loadout--main.zip` baseline. The smaller `silver-spoon-main.zip` remains predecessor/reference material. Existing study workflows, the navy/purple visual identity, historical datasets and legacy data keys are preserved.

## Release 1.8.0 — Visible module ports and screenshot-driven repair lanes

This is the cumulative continuation of the verified 1.7.0 source baseline. It keeps the existing JEE Main workspaces, calculations, data sets, legacy storage keys and navy/purple UI, while adding inspectable module service/storage ports and two guarded repair routes:

- **Visible Port Directory:** names USB/ADB ingress, the in-app Visual Repair Port, host-only Source Repair Port, module service interfaces, native bridge, opt-in AI provider boundary and local backup/data interchange. These are logical interfaces; Loadout does not open a TCP/LAN listener.
- **Visual Repair (`.lfix`):** signed Ed25519 package with a fixed allowlist of module-scoped UI tokens (spacing, card sizing, type scale, table overflow and chat sizing). The app verifies and stages it, presents every scope/token/value, then waits for manual Commit or Roll Back. Active overrides persist and interrupted activation/rollback is reconciled at startup.
- **Source Repair (`.lpatch`):** signed host-only patch format with exact source-file SHA-256 preimages and a unique anchor match. A workstation CLI stages a complete repository copy, applies the patch only to staging and runs tests, source checks and the data audit. A separate explicit commit writes the patch and creates backups; source/native changes still require the normal APK build/install path.
- **Screenshot workflow:** the Observatory exports a privacy-limited Repair Context JSON. Upload that and the screenshot to the engineering chat, receive an unsigned `.lfix.json` or `.lpatch.json` draft, sign it locally with your private key, then route it through the relevant port. Signing keys are never uploaded or included in source bundles.
- **Inspectable feature contracts:** module directory rows now show each module's service names, storage reads/writes, dependencies, route and entry. The display explicitly marks where route rendering still passes through the legacy compatibility adapter; module metadata is not misrepresented as independent hot-swappability.
- **Release identity:** app version `1.8.0`, Android versionCode `11`, stable runtime API `1.5.0`.

The exact format and limitations are in `architecture/REPAIR-PORT.md`, `architecture/MODULE-PORTS.md` and `documentation/PORT_CATALOG.md`.

## Previous milestone 1.7.0 — Integrated self-evolving runtime source

This release integrates the 1.6.0 guarded LTL engine and adds the owner-controlled device/registry path:

- **Guarded LTL updater:** signed `.lupdate` JSON packages; bounded declarative operations; dependency ordering; precondition and postcondition checks; staged impact report; durable transaction journal; manual Commit/Roll Back; startup recovery after interrupted activation.
- **Private first-party registry:** static APK-bundled module inventory plus signed `.lreg` catalog import, Ed25519 verification, strict app/runtime/module compatibility validation, dependency resolution, local persistent catalog cache, reset-to-bundled recovery and key revocation/rotation tooling. No registry server is required for normal app use.
- **Development Port:** debug-build-only authenticated ADB/USB file transfer into an app-specific inbox. The host CLI checks the installed app identity and verifies package signatures before transfer. The in-app Observatory can inspect, verify and stage inbox packages. No LAN listener, remote shell or arbitrary command execution is exposed.
- **Native extension boundary:** a versioned inventory/contract for the compiled-in first-party Capacitor native core. Native changes require a new APK and process restart. Dynamic DEX/JAR or `.so` hot loading is deliberately disabled.
- **Offline package recovery:** verified `.lupdate` packages are saved to a persistent integrity-checked cache and can be re-staged offline. Imported registry catalogs are separately persisted and re-verified before use.
- **Build integration:** the GitHub Actions workflow runs registry catalog synchronization, tests, data audit, source checks, then a real Capacitor/Gradle debug APK build and uploads the APK, SHA-256 and build metadata.

## Preserved product architecture

- JEE Main only; no JEE Advanced or unrelated exam mode.
- Seven first-party feature modules: Command Center, Chapter Map, PYQ Intelligence, Test Ledger, Forecast Engine, AI Coach and Data & Settings.
- Runtime API `1.5.0`; app version `1.8.0`; Android versionCode `11`.
- Existing `loadout-jee-2027-v1` localStorage state remains the application source of truth. SQLite/IndexedDB schema v2 remains an additive, read-back-verified mirror; source-of-truth cutover is not claimed.
- AI Coach remains a separate first-party feature: secure Android Keystore provider transport, browser session-only credentials, offline conversation history, context controls, Markdown/LaTeX and provider streaming.
- Installed app data and bundled modules remain usable offline. AI provider requests naturally require network access. Registry availability is not required for ordinary app startup/use.

## Build this repository into an APK

The repository is designed to be uploaded as **repository-root contents**, not nested under another folder.

1. Extract this ZIP.
2. Upload the extracted folder's **contents** to the root of your private GitHub repository. Keep hidden files and folders, especially `.github/workflows/build-apk.yml`.
3. Commit the files. When the commit is pushed to GitHub, the `Loadout Android build` workflow starts automatically.
4. Open the repository's **Actions** tab. Download the artifact named `Loadout-Android-1.8.0-debug` after the run succeeds. It contains `dist/Loadout-Android-debug.apk`, its SHA-256 file and `build/BUILD_INFO.json`.

The workflow uses Node 22, JDK 21 and Android SDK 35. It runs `npm install`, regenerates registry source hashes, executes automated tests and data/source validation, then runs the actual Capacitor/Gradle `assembleDebug` build. A failed verification step stops the APK build.

### Signing identity warning

For repeatable in-place updates, set the GitHub Actions secret `LOADOUT_DEBUG_KEYSTORE_BASE64` to a persistent debug keystore encoded as Base64. To create one compatible with Android's default debug signing configuration, run `keytool -genkeypair -v -noprompt -keystore loadout-debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Loadout Debug,O=Private,C=IN"`, then Base64-encode that file (`base64 -w0 loadout-debug.keystore` on Linux) and save the output as the GitHub Actions secret. Keep the keystore outside the repository. Without the secret, the workflow creates a runner-local debug keystore; later runner builds may have a different certificate. Android rejects an update signed with a different certificate. The signing certificate of any previously installed Loadout APK has not been verified. Export and verify your study data/chat backup before replacing an installed app if the certificate differs.

## Owner signing and private registry operations

No signing private key is included in this repository or ZIP. The trust store is intentionally empty (`deny-untrusted`) until you create and register your own public key. This means signed update/catalog imports fail closed until you perform the setup below and build/install an APK containing the public key.

```bash
npm install
node scripts/generate-update-keypair.mjs
node scripts/register-update-key.mjs local-signing/loadout-update-public.pem
npm run registry:sync
# Commit the changed www/runtime/trust-store.json and build/install a new APK.
```

Keep `local-signing/loadout-update-private.pem` offline and out of Git. The `local-signing/` directory and private key files are ignored by `.gitignore`. Use the private key to sign data resources with the existing `scripts/sign-update-package.mjs` or to create a private registry catalog package:

```bash
node scripts/create-registry-package.mjs local-signing/loadout-update-private.pem <key-id> ./my-registry.lreg
node scripts/validate-registry-package.mjs ./my-registry.lreg
```

The registry signer defaults to a revision newer than the bundled catalog. Import the `.lreg` file from Data & Settings → Observatory → Import private registry catalog, or transfer it over the authenticated Development Port. A catalog may describe only modules already bundled in the APK; it cannot add, remove or replace executable code.

To transfer a signed package over USB/ADB, install a **debug** APK, enable Android USB debugging, connect and authorize the computer on the phone, then use:

```bash
npm run dev:port -- status
npm run dev:port -- push ./my-update.lupdate
npm run dev:port -- list
```

The app then shows the inbox package under Data & Settings → Observatory → Development Port. Select **Verify & stage**, inspect the impact report, and explicitly choose Commit or Roll Back. The Development Port accepts `.lreg` and `.lfix`; it rejects executable `.lmod` and host-only `.lpatch` packages. Native or bundled module code changes require a rebuilt APK.

To rotate a signer, generate/register the replacement public key and install an APK containing it before using it. Sign new packages with the new key. Then revoke the old key using `npm run update:key:revoke -- <key-id>`, rebuild and install the APK carrying the revocation. Revocation is enforced by the trust store on devices only after that APK is installed. Back up key material safely; losing the private key prevents future packages signed by that key.

## Screenshot-to-repair quick path

One-time owner setup (the trust store starts empty and rejects everything until a public key is installed in an APK):

```bash
node scripts/generate-update-keypair.mjs
node scripts/register-update-key.mjs local-signing/loadout-update-public.pem
# Review/commit www/runtime/trust-store.json, then build/install the new APK.
```

Never share `local-signing/loadout-update-private.pem`. After bootstrap, attach a screenshot and a Repair Context export in the engineering chat. Sign the resulting draft locally and transfer it:

```bash
npm run repair:sign -- ./fix.lfix.json
npm run dev:port -- push ./fix.lfix
```

Then open **Data & Settings → Runtime & Observatory → Visual Repair Port**, inspect all proposed changes and choose **Commit** or **Roll Back**. For code or logic defects use `.lpatch` and the host-only `npm run repair:port` workflow described in `architecture/REPAIR-PORT.md`; it requires an APK rebuild to reach the phone.

## Verification and declared boundaries

The included `TEST_REPORT.txt`, `LOADOUT_RELEASE_NOTES.txt`, source audit and ADRs record the release checks and known limits. Key boundaries:

- `.lupdate` remains a signed JSON resource package, not a ZIP archive. General ZIP `.lupdate`/`.lmod` package extraction/import is not implemented.
- `.lmod` executable module activation is rejected. Web feature modules and native code are APK-bundled; they cannot be hot-loaded from external packages.
- Registry distribution is first-party and manual/offline-file-based. There is no hosted registry server, public marketplace or automatic network sync.
- Native extension changes require a new APK; dynamic DEX/JAR/native library loading is disabled.
- SQLite/IndexedDB is an additive mirror, not yet the app's single source of truth.
- No Android SDK was available in the preparation environment, so no APK is included or claimed as compiled here. The included workflow is the real APK build route.
- The native Java plugin has not been compiled against a generated Android project in this environment, nor tested on a physical Android device/emulator. GitHub Actions must complete successfully, followed by device installation and validation.
- `package-lock.json` is absent because npm registry resolution was unavailable during preparation. Direct dependency versions are exact-pinned, but transitive npm resolution is not fully locked; CI uses `npm install`, not `npm ci`.
- KaTeX 0.19.1 assets are generated by the `npm postinstall` script. They are build outputs, not copied into this offline source bundle.
- No physical-device screenshot regression, process-death/restore test, APK signing-certificate comparison or live AI provider request was performed during preparation.

## Repository structure

```text
.github/workflows/       GitHub Actions APK build
architecture/            L-SEAA, module ports, repair ports, Development Port and extension security contracts
database/                Logical DB schema and migration references
documentation/            Master brief, ADRs, port catalog, release audit and requirements
repairs/                  Screenshot-to-repair package instructions and unsigned examples
exam-profiles/            Versioned JEE Main 2027 Paper 1 profile
modules/                  First-party module manifests and root registry
native/android/           Compiled Capacitor native plugin
native/extensions.json    Native extension contract and loading policy
registry/                 Private registry catalog
scripts/                  Build, tests, registry, signing and ADB tools
src/core/                 LTL, package and module/registry validators
tests/                    Unit and integration tests
www/                      App UI, runtime, modules, historical data and offline shell
```
