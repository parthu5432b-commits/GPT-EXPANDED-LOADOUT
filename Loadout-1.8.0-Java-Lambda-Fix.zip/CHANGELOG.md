# Changelog

## 1.8.0 — Visible module ports and screenshot-driven repair workflow
- Added an owner-facing Port Directory and expanded Runtime & Observatory with module routes, services, dependencies and explicit storage read/write contracts.
- Added signed `.lfix` visual repair packages with a bounded UI-token catalogue, per-module/global scopes, signature verification, staging, manual commit/rollback, durable journal and interrupted-activation recovery.
- Added a local Repair Context export for screenshot-based diagnosis; the export omits study records, conversation bodies, prompts, provider secrets and diagnostic payload details.
- Added signed `.lpatch` source-repair packages with path allowlists, exact preimage SHA-256, unique anchors, staged workspace validation, explicit host commit, backup and guarded rollback.
- Extended debug USB/ADB inbox to accept `.lfix`; `.lpatch` remains workstation-only and is rejected by Android ingress.
- Preserved the existing JEE Main-only workspaces, study data keys, historical datasets, scoring/mastery/forecast formulae and established visual identity.
- Clarified that feature services are progressively extracted while screen renderers can remain behind the legacy adapter; no arbitrary executable hot-loading or generic TCP listener was added.
- Bumped app version to 1.8.0 / Android versionCode 11; runtime API remains 1.5.0.
- Actual APK compilation and target-device/ADB validation remain pending; see `TEST_REPORT.txt` and `LOADOUT_RELEASE_NOTES.txt`.


## 1.7.0 — Final integrated runtime and private device/registry path
- Added a debug-only authenticated ADB/USB Development Port with app-specific inbox, fixed host CLI, package verification, in-app staging and manual approval.
- Added an owner-signed private registry catalog format (`.lreg`) with Ed25519 verification, module/runtime compatibility checks, dependency validation, persistent offline catalog cache and bundled fallback.
- Added registry source-hash synchronization, package creation/validation and signer revocation tooling.
- Added verified persistent resource-package caching and offline re-staging.
- Added a versioned compiled-native extension inventory; selected policy keeps native and executable feature updates APK-bound and disables DEX/JAR/native-library hot loading.
- Updated repository-root build contract to 1.7.0 / Android versionCode 10 and GitHub Actions artifact `Loadout-Android-1.7.0-debug`.
- Added Capacitor 7.4.3 Gradle `name = value` SDK assignment handling with regression tests, plus automatic source-inventory refresh in CI.
- Preserved known device/build limitations; see `LOADOUT_RELEASE_NOTES.txt`.

## 1.6.0 — Declarative LTL engine and update recovery
- Implemented the full guarded declarative LTL operation set with dependency ordering and strict operation metadata.
- Added precondition hashes, value assertions, safe array/object JSON Pointer operations, bounded MIGRATE steps and guarded non-executable text PATCH_SOURCE.
- Added package dependency checks, signer revocation rejection, richer transaction impact reports and durable transition journal.
- Added startup recovery for interrupted activations and expanded module-registry graph validation.
- Preserved manual owner approval; executable code and native extensions are not dynamically loaded.


## 1.5.6 — AI Coach patch hardening

- Fixed Retry for cancelled/interrupted assistant responses.
- Propagated AbortSignal cancellation to the active native provider request and exact request ID.
- Flushed the same UTF-8 TextDecoder before finalizing browser SSE parsing.
- Centralised provider base URL validation and rejected query parameters before saving settings.
- Added redaction for common Google, OpenAI/OpenRouter, Hugging Face and Groq provider-token formats in error strings.
- Added regression tests for each defect and bumped Android versionCode to 8.

## 1.5.5 — AI Coach Step 0.75.5
- Extracted AI Coach as the seventh versioned first-party feature module while preserving the legacy chat screen adapter.
- Added multi-conversation local history, selected context controls, provider profiles, native Keystore-backed credentials, request streaming/cancellation and safe Markdown/LaTeX rendering.
- Added migration and regression tests for legacy chat records and credential exclusion from backups.

## 1.5.0 — Feature modules and additive migration foundation (18 November 2026)

- Introduced a versioned feature runtime and registry for six non-AI workspaces. Existing legacy renderers remain the compatibility adapter; no screen/theme redesign occurred.
- Extracted chapter mapping, alias resolution, attempt shaping, chapter mastery/baseline, dashboard summary, PYQ filtering, forecast calculations and Test Ledger operations into testable services.
- Added logical SQLite/IndexedDB schema v2: canonical app state, indexed attempts/forecasts, module records, import provenance, migration history, recovery snapshots and conflict records.
- Added sequential schema migrations v1/v2 and a compiled native checksum allowlist.
- Restricted Android native database access to one app-private database, exact read-query shapes and parameterized writes against approved tables.
- Added legacy-first database bootstrap and reconciliation with structured snapshots before conflicting DB payloads are replaced.
- Added exact post-write read-back verification for canonical JSON, each test/forecast payload and the complete migration ledger; structured-state revision is monotonic.
- Added tests for tampered row payloads, altered/extra migration ledger rows, dropped writes and revision increments.
- Added source audit addendum, migration data dictionary, requirements matrix, roadmap, and ADRs for modules, additive DB, native SQL/migration restrictions and AI Coach sequencing.
- AI Coach is intentionally preserved as the legacy adapter and deferred to owner-selected Step 0.75.5 immediately before the final step.

## 1.4.0 — Data safety and Test Ledger milestone (18 November 2026)

- Preserved the original study state key and added startup mirror reconciliation with byte-for-byte verified divergence archival, exact corrupt-state quarantine and a fail-closed write gate.
- Added tracked main-state mirror flush/read-back verification.
- Added schema-3 pre-restore safety snapshots, full stored payload/digest verification, an in-app snapshot inventory and owner-reviewed restore workflow.
- Deferred chat-history writes until credential migration is settled; added a minimal credential migration-hold record when Android Keystore is unavailable or a key migration fails.
- Kept provider keys out of chat backups and sanitized v3 history; old stores are removed only after exact history verification and no unresolved credentials remain.
- Expanded first-party Test Ledger service operations and retained existing scoring/C/W/U rules.

## 1.3.0 — Native/runtime foundation milestone

- Established repository-root Capacitor build orchestration, native bridge source and initial L-SEAA runtime foundation.
- Added signed owner-supplied data resource updates, manual commit/rollback and initial storage lifetimes.

## 1.1.0 — Primary uploaded baseline

- Original private Capacitor Loadout app and historical datasets as supplied in the upload baseline.
