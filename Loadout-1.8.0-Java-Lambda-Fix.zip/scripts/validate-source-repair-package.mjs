import fs from 'node:fs';
import { verifySignedSourceRepairPackage } from '../src/core/source-repair-package.js';
const [packagePath, trustPath = 'www/runtime/trust-store.json'] = process.argv.slice(2);
if (!packagePath) throw new Error('Usage: node scripts/validate-source-repair-package.mjs <package.lpatch> [trust-store.json]');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
const trust = JSON.parse(fs.readFileSync(trustPath, 'utf8'));
console.log(JSON.stringify({ valid: true, ...verifySignedSourceRepairPackage(pkg, trust) }, null, 2));
