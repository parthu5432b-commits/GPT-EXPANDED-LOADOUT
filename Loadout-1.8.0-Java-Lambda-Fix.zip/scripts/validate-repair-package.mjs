import fs from 'node:fs';
import { verifySignedRepairPackage } from '../src/core/repair-package.js';
const [packagePath, trustPath = 'www/runtime/trust-store.json'] = process.argv.slice(2);
if (!packagePath) throw new Error('Usage: node scripts/validate-repair-package.mjs <package.lfix> [trust-store.json]');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
const trust = JSON.parse(fs.readFileSync(trustPath, 'utf8'));
const result = verifySignedRepairPackage(pkg, trust);
console.log(JSON.stringify({ valid: true, ...result }, null, 2));
