import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { validateModuleRegistry } from '../src/core/module-registry.js';
import { sha256, stableStringify } from '../src/core/ltl.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ignoredAtRoot = new Set(['node_modules', 'android', '.build', 'dist', '.git', '.loadout-repair']);
const sourceFiles = [];
const jsonFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error(`Symlink is not permitted in the source repository: ${path.relative(root, path.join(dir, entry.name))}`);
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const relative = path.relative(root, file).replaceAll('\\', '/');
      if (!(relative.split('/').length === 1 && ignoredAtRoot.has(entry.name))) walk(file);
    } else {
      if (/\.(js|mjs)$/.test(entry.name)) sourceFiles.push(file);
      if (/\.json$/i.test(entry.name)) jsonFiles.push(file);
    }
  }
}
walk(root);
for (const file of sourceFiles) execFileSync(process.execPath, ['--check', file], { cwd: root, stdio: 'inherit' });
for (const file of jsonFiles) {
  try { JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (error) { throw new Error(`Invalid JSON in ${path.relative(root, file)}: ${error.message}`); }
}

const required = [
  '.github/workflows/build-apk.yml',
  'documentation/MASTER_CODING_AGENT_BRIEF.txt',
  'www/runtime/loadout-runtime.js', 'www/runtime/ltl-engine.js', 'www/runtime/repair-engine.js', 'www/runtime/recovery-gate.js',
  'www/runtime/database-schema.js', 'www/runtime/database-model.js', 'www/runtime/database.js',
  'www/runtime/feature-runtime.js', 'www/runtime/module-registry.js',
  'www/runtime/backup-manager.mjs', 'www/runtime/registry-catalog.json', 'www/modules/test-ledger.js', 'www/modules/ai-coach/ai-coach.js',
  'www/modules/features/chapter-intelligence.js', 'www/modules/features/dashboard-analytics.js',
  'www/modules/features/command-center.js', 'www/modules/features/chapter-map.js',
  'www/modules/features/pyq-intelligence.js', 'www/modules/features/forecast-engine.js',
  'www/modules/features/test-ledger-route.js', 'www/modules/features/data-settings.js',
  'modules/registry.json', 'modules/test-ledger.module.json', 'modules/ai-coach.module.json', 'registry/catalog.json', 'native/extensions.json', 'scripts/dev-port.mjs', 'scripts/dev-port-core.mjs', 'scripts/repair-port.mjs', 'scripts/sign-repair-package.mjs', 'scripts/validate-repair-package.mjs', 'scripts/sign-source-repair-package.mjs', 'scripts/validate-source-repair-package.mjs', 'scripts/revoke-update-key.mjs', 'scripts/create-registry-package.mjs', 'scripts/sync-registry-catalog.mjs', 'scripts/validate-registry-package.mjs', 'native/extensions.json',
  'documentation/ARCHITECTURE.md', 'documentation/DATA_DICTIONARY.md',
  'documentation/REQUIREMENTS_MATRIX.md', 'documentation/IMPLEMENTATION_ROADMAP.md',
  'documentation/MASTER_CODING_AGENT_BRIEF.txt', 'documentation/PRIVATE_REGISTRY_AND_SIGNING.md',
  'documentation/ADR/0020-adb-usb-development-port.md', 'documentation/ADR/0021-compiled-native-extension-boundary.md', 'documentation/ADR/0022-private-registry-offline-catalog.md', 'documentation/ADR/0023-bounded-ui-repair-port.md', 'documentation/ADR/0024-guarded-source-repair-port.md',
  'documentation/PORT_CATALOG.md', 'architecture/REPAIR-PORT.md', 'architecture/MODULE-PORTS.md', 'architecture/DEVELOPMENT-PORT.md', 'architecture/NATIVE-EXTENSION-SECURITY.md', 'native/android/LoadoutCorePlugin.java'
];
for (const relative of required) if (!fs.existsSync(path.join(root, relative))) throw new Error(`Missing required repository file: ${relative}`);
const forbiddenSecrets = sourceFiles.concat(jsonFiles).filter(file => /(^|[._-])(private[-_]?key|secret|credentials?)([._-]|$)/i.test(path.basename(file)) && !file.endsWith('trust-store.json'));
if (forbiddenSecrets.length) throw new Error(`Potential secret-bearing source file found: ${forbiddenSecrets.map(f => path.relative(root, f)).join(', ')}`);

const plan = JSON.parse(fs.readFileSync(path.join(root, 'BUILD_PLAN.json'), 'utf8'));
const instructions = JSON.parse(fs.readFileSync(path.join(root, 'BUILD_INSTRUCTIONS.json'), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const workflow = fs.readFileSync(path.join(root, '.github/workflows/build-apk.yml'), 'utf8');
if (!workflow.includes(`name: Loadout-Android-${pkg.version}-debug`)) throw new Error('GitHub Actions artifact name does not match the package version.');
if (!workflow.includes('npm run registry:sync') || !workflow.includes('npm run inventory') || !workflow.includes('node scripts/build.mjs')) throw new Error('GitHub workflow is missing registry sync, source inventory or Android build phase.')
if (!workflow.includes("node-version: '22'") || !workflow.includes("java-version: '21'")) throw new Error('GitHub Actions Node/Java toolchain does not match the build plan.');
const cap = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
if (plan.sourceMode !== 'repository-root' || cap.webDir !== 'www' || cap.appId !== plan.expectedAppId) throw new Error('Repository-root / Capacitor webDir / app ID contract mismatch.');
if (pkg.version !== instructions.release.versionName || Number(plan.expectedVersionCode) !== Number(instructions.release.versionCode)) throw new Error('Release version contract mismatch.');
if (instructions.runtime.version !== instructions.runtime.api) throw new Error('Runtime implementation/API contract must be aligned for this release.');
if (instructions.runtime.api !== '1.5.0') throw new Error('This source tree must use runtime API 1.5.0.');
if (pkg.version !== '1.8.0' || instructions.release.versionCode !== 11) throw new Error('Release identity must be Loadout 1.8.0 / Android versionCode 11.');
if (!instructions.webAssets.includes('www/runtime/registry-catalog.json')) throw new Error('APK web asset manifest is missing the private registry catalog.');
if (!instructions.webAssets.includes('www/runtime/repair-engine.js')) throw new Error('APK web asset manifest is missing the Visual Repair engine.');
for (const script of ['repair:sign','repair:validate','repair:sign-source','repair:validate-source','repair:port']) if (!pkg.scripts?.[script]) throw new Error(`package.json is missing operational script ${script}.`);
for (const script of ['dev:port','registry:sync','registry:package','registry:validate','update:key:revoke']) if (!pkg.scripts?.[script]) throw new Error(`package.json is missing operational script ${script}.`);
if (instructions.native?.databaseName !== 'loadout-main' || instructions.native?.databaseMigrationPolicy !== 'compiled-checksum-allowlist') throw new Error('Native database security contract is missing or inconsistent.');
if (pkg.engines?.node !== '>=22 <23') throw new Error('Node build toolchain must remain pinned to Node 22.');

const generatedVendorAssets = new Set(['www/vendor/katex/katex.min.css','www/vendor/katex/katex.min.js','www/vendor/katex/contrib/mhchem.min.js','www/vendor/katex/contrib/auto-render.min.js','www/vendor/katex/vendor-manifest.json']);
const missingGeneratedVendor = [];
for (const asset of instructions.webAssets || []) {
  const normalized = String(asset).replaceAll('\\', '/');
  if (!normalized.startsWith('www/') || normalized.includes('../')) throw new Error(`Invalid declared web asset path: ${asset}`);
  if (!fs.existsSync(path.join(root, normalized))) {
    if (generatedVendorAssets.has(normalized) && pkg.dependencies?.katex === '0.19.1' && fs.existsSync(path.join(root,'scripts/vendor-katex.mjs'))) missingGeneratedVendor.push(normalized);
    else throw new Error(`Missing declared web asset: ${asset}`);
  }
}
if (missingGeneratedVendor.length) console.warn(`WARN KaTeX assets are generated by npm postinstall and are not present in this offline working copy: ${missingGeneratedVendor.length} files.`);
const html = fs.readFileSync(path.join(root, 'www/index.html'), 'utf8');
const scriptSrcs = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["']/gi)].map(match => match[1].replace(/^\.\//, ''));
for (const src of scriptSrcs) if (!fs.existsSync(path.join(root, 'www', src)) && !src.startsWith('vendor/katex/')) throw new Error(`HTML refers to missing local script: ${src}`);
const requiredOrder = [
  'runtime/module-registry.js', 'runtime/ltl-engine.js', 'runtime/repair-engine.js', 'runtime/loadout-runtime.js', 'runtime/recovery-gate.js',
  'runtime/database-schema.js', 'runtime/database-model.js', 'runtime/database.js',
  'runtime/feature-runtime.js', 'modules/test-ledger.js', 'modules/features/chapter-intelligence.js',
  'modules/features/dashboard-analytics.js', 'modules/features/command-center.js',
  'modules/features/chapter-map.js', 'modules/features/pyq-intelligence.js',
  'modules/features/forecast-engine.js', 'modules/features/test-ledger-route.js',
  'modules/features/data-settings.js', 'modules/ai-coach/ai-coach.js', 'app.js'
];
let previous = -1;
for (const src of requiredOrder) {
  const index = scriptSrcs.indexOf(src);
  if (index < 0 || index <= previous) throw new Error(`HTML module startup order is invalid at ${src}.`);
  previous = index;
}
for (const src of scriptSrcs) if (src.endsWith('.js') && !instructions.webAssets.includes(`www/${src}`)) throw new Error(`Build asset manifest omits HTML script: ${src}`);

const moduleManifest = JSON.parse(fs.readFileSync(path.join(root, 'modules/registry.json'), 'utf8'));
const registrySandbox = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'www/runtime/module-registry.js'), 'utf8'), registrySandbox);
const runtimeRows = registrySandbox.window.LOADOUT_MODULE_REGISTRY;
if (!Array.isArray(runtimeRows)) throw new Error('Runtime module registry failed to declare a module list.');
if (moduleManifest.runtimeApi !== instructions.runtime.api) throw new Error('Root module registry runtime API does not match BUILD_INSTRUCTIONS.');
const runtimeMap = new Map(runtimeRows.map(item => [item.id, item]));
const validatedManifests = [];
for (const item of moduleManifest.modules) {
  const runtime = runtimeMap.get(item.id);
  if (!runtime || runtime.version !== item.version || runtime.runtimeApi !== item.runtimeApi || runtime.status !== item.status || runtime.route !== item.route || runtime.entry !== item.entry || runtime.description !== item.description) {
    throw new Error(`JSON and runtime registry metadata disagree for ${item.id}.`);
  }
  if (item.status === 'feature-module') {
    const slug = item.id.replace(/^loadout\./, '');
    const manifestPath = path.join(root, 'modules', `${slug}.module.json`);
    if (!fs.existsSync(manifestPath)) throw new Error(`Missing module manifest for ${item.id}.`);
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    validatedManifests.push(manifest);
    if (manifest.id !== item.id || manifest.version !== item.version || manifest.runtimeApi !== item.runtimeApi || manifest.route !== item.route || manifest.entry !== item.entry) {
      throw new Error(`Feature module manifest mismatch for ${item.id}.`);
    }
    const servicesA = [...(manifest.servicesProvided || [])].sort().join('|');
    const servicesB = [...(item.services || [])].sort().join('|');
    if (servicesA !== servicesB || servicesA !== [...(runtime.services || [])].sort().join('|')) throw new Error(`Feature service declarations disagree for ${item.id}.`);
    if (stableStringify([...(manifest.dependencies || [])]) !== stableStringify([...(item.dependencies || [])]) || stableStringify([...(manifest.dependencies || [])]) !== stableStringify([...(runtime.dependencies || [])])) throw new Error(`Feature dependency declarations disagree for ${item.id}.`);
    for (const field of ['storageRead','storageWrite']) if (stableStringify([...(item[field] || [])]) !== stableStringify([...(runtime[field] || [])])) throw new Error(`Feature ${field} declarations disagree for ${item.id}.`);
    if (!fs.existsSync(path.join(root, manifest.entry))) throw new Error(`Feature module entry is missing for ${item.id}.`);
  } else if (item.id === 'loadout.ai-coach') {
    throw new Error('AI Coach registry declaration must be a real feature module in every production release.');
  }
}
if (runtimeRows.length !== moduleManifest.modules.length) throw new Error('Runtime and JSON module registries do not contain the same number of modules.');
const moduleGraph = validateModuleRegistry(moduleManifest, validatedManifests, { runtimeApi: instructions.runtime.api });
const catalog = JSON.parse(fs.readFileSync(path.join(root, 'registry/catalog.json'), 'utf8'));
const runtimeCatalog = JSON.parse(fs.readFileSync(path.join(root, 'www/runtime/registry-catalog.json'), 'utf8'));
const catalogCopy = structuredClone(catalog); const catalogDigest = catalogCopy.catalogSha256; delete catalogCopy.catalogSha256;
if (sha256(stableStringify(catalogCopy)) !== catalogDigest || stableStringify(catalog) !== stableStringify(runtimeCatalog)) throw new Error('Private registry catalog integrity or app/repository copies disagree.');
if (catalog.modules.length !== moduleManifest.modules.length || catalog.modules.some(item => { const row = moduleManifest.modules.find(x => x.id === item.id); return !row || row.version !== item.version || row.entry !== item.entry || row.route !== item.route || sha256(fs.readFileSync(path.join(root, item.entry))) !== item.entrySha256 || sha256(fs.readFileSync(path.join(root, item.manifestPath))) !== item.manifestSha256; })) throw new Error('Private registry catalog source hashes do not match the bundled feature modules.');
const nativeExtensions = JSON.parse(fs.readFileSync(path.join(root, 'native/extensions.json'), 'utf8'));
if (nativeExtensions.policy !== 'compiled-in-first-party-only' || nativeExtensions.dynamicDexJarLoading !== false || nativeExtensions.nativeLibraryHotSwap !== false || nativeExtensions.extensions.length !== 1 || nativeExtensions.extensions[0].className !== instructions.native.pluginClass) throw new Error('Native extension contract must remain compiled-in and APK-bound.');
console.log(`PASS private module registry: ${moduleGraph.moduleCount} modules, ${moduleGraph.serviceCount} services, ${moduleGraph.offlineModuleCount} offline; dependency graph resolved`);
console.log(`PASS signed-catalog baseline: revision ${catalog.revision}, ${catalog.modules.length} modules; native extension contract ${nativeExtensions.extensions.length} compiled-in service.`);

const aiManifest = JSON.parse(fs.readFileSync(path.join(root, 'modules/ai-coach.module.json'), 'utf8'));
const aiSource = fs.readFileSync(path.join(root, 'www/modules/ai-coach/ai-coach.js'), 'utf8');
const aiRow = moduleManifest.modules.find(item => item.id === 'loadout.ai-coach');
if (!aiRow || aiRow.status !== 'feature-module' || aiRow.version !== aiManifest.version || aiManifest.entry !== aiRow.entry || aiManifest.route !== 'chatbot') throw new Error('AI Coach feature manifest and root registry do not agree.');
for (const contract of ['createSseParser','renderMarkdown','renderMath','buildProviderRequest','chatStorageSnapshot','canRetryMessage','validateProviderBaseUrl','redactProviderError']) if (!aiSource.includes(contract)) throw new Error(`AI Coach implementation is missing ${contract}.`);
if (!fs.readFileSync(path.join(root,'native/android/LoadoutCorePlugin.java'),'utf8').includes('requestAiProvider')) throw new Error('Native secure AI transport is missing.');
const appSource = fs.readFileSync(path.join(root, 'www/app.js'), 'utf8');
if (!appSource.includes('AI_COACH.canRetryMessage(message, action)') || !appSource.includes('parser.push(decoder.decode()); parser.finish();') || !appSource.includes('AI_COACH.validateProviderBaseUrl(url)') || !appSource.includes('signal: controller.signal')) throw new Error('AI Coach retry, SSE flush, provider URL or abort integration contract is missing.');
const transportSource = fs.readFileSync(path.join(root, 'www/runtime/loadout-runtime.js'), 'utf8');
if (!transportSource.includes("request.signal.addEventListener('abort', abortHandler") || !transportSource.includes('AITransport.cancel(request.requestId)')) throw new Error('Native AI transport AbortSignal cancellation contract is missing.');

const ledgerManifest = JSON.parse(fs.readFileSync(path.join(root, 'modules/test-ledger.module.json'), 'utf8'));
const ledgerSource = fs.readFileSync(path.join(root, 'www/modules/test-ledger.js'), 'utf8');
const ledgerRoute = fs.readFileSync(path.join(root, 'www/modules/features/test-ledger-route.js'), 'utf8');
const serviceVersion = ledgerSource.match(/version:\s*'([^']+)'/)?.[1];
const routeVersion = ledgerRoute.match(/version:\s*'([^']+)'/)?.[1];
const ledger = moduleManifest.modules.find(item => item.id === 'loadout.test-ledger');
if (!ledger || ledger.status !== 'feature-module' || ledger.version !== ledgerManifest.version || ledger.version !== serviceVersion || ledger.version !== routeVersion) throw new Error('Test Ledger service/route/manifest/registry versions do not agree.');

const dbModel = fs.readFileSync(path.join(root, 'www/runtime/database-model.js'), 'utf8');
const native = fs.readFileSync(path.join(root, 'native/android/LoadoutCorePlugin.java'), 'utf8');
for (const requiredText of ['maxRecordRows', 'validateState', 'attemptRow', 'forecastRow']) if (!dbModel.includes(requiredText)) throw new Error(`Database model is missing ${requiredText}.`);
for (const requiredText of ['Migration is not an exact match for the compiled native schema contract', 'validateBatchSql', 'Database name is not in the native allowlist', 'Database write statement is not an exact approved operation', 'getDevelopmentPortStatus', 'listDevelopmentPortPackages', 'readDevelopmentPortPackage', 'deleteDevelopmentPortPackage', 'getNativeExtensionInventory']) if (!native.includes(requiredText)) throw new Error(`Native database service is missing ${requiredText}.`);

const sw = fs.readFileSync(path.join(root, 'www/sw.js'), 'utf8');
for (const asset of instructions.webAssets.filter(item => /\.(js|mjs)$/.test(item) && item !== 'www/sw.js')) {
  const shellRef = `./${asset.replace(/^www\//, '')}`;
  if (!sw.includes(shellRef)) throw new Error(`Service worker shell cache is missing ${shellRef}.`);
}
if (!sw.includes('./runtime/registry-catalog.json')) throw new Error('Service worker offline cache is missing the private registry catalog.');
for (const dep of Object.values(pkg.dependencies || {}).concat(Object.values(pkg.devDependencies || {}))) if (/^(\^|~|latest$)/.test(String(dep))) throw new Error('Production-critical package versions must be exact-pinned.');
const lockPath = path.join(root, 'package-lock.json');
if (fs.existsSync(lockPath)) {
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  if (lock.packages?.['']?.version !== pkg.version) throw new Error('package-lock root version does not match package.json.');
}

console.log(`PASS JavaScript/MJS syntax: ${sourceFiles.length} files checked.`);
console.log(`PASS JSON/config validation: ${jsonFiles.length} files checked.`);
console.log(`PASS feature modules: ${runtimeRows.filter(item => item.status === 'feature-module').length} registered, including AI Coach.`);
console.log('PASS repository boundary, feature manifests/service contracts, database/schema security, CI artifact/toolchain identity, startup order and offline shell declarations.');
const devPortSource = fs.readFileSync(path.join(root,'scripts/dev-port-core.mjs'),'utf8');
if (!devPortSource.includes('\\.(?:lupdate|lreg|lfix)') || devPortSource.includes('lupdate|lmod|lreg|lfix')) throw new Error('Development Port must accept .lfix and reject executable .lmod packages.');
if (!native.includes('\\.(?:lupdate|lreg|lfix)') || native.includes('\\.(?:lupdate|lmod|lreg|lfix)')) throw new Error('Native Development Port allowlist must accept only .lupdate, .lreg and .lfix.');
const registrySource = fs.readFileSync(path.join(root,'www/runtime/loadout-runtime.js'),'utf8');
for (const contract of ['developmentPortStatus','developmentInbox','stageDevelopmentInboxPackage','importRegistryPackage','stageCachedPackage','nativeExtensionInventory']) if (!registrySource.includes(contract)) throw new Error(`Runtime Developer Port / registry contract missing ${contract}.`);
const repairCore = fs.readFileSync(path.join(root,'src/core/repair-package.js'),'utf8');
const sourceRepairCore = fs.readFileSync(path.join(root,'src/core/source-repair-package.js'),'utf8');
const repairRuntime = fs.readFileSync(path.join(root,'www/runtime/repair-engine.js'),'utf8');
for (const token of ['REPAIR_SCOPES','SET_UI_TOKEN','REPAIR_MAX_BYTES','verifySignedRepairPackage']) if (!repairCore.includes(token)) throw new Error(`Visual Repair package contract missing ${token}.`);
for (const token of ['safeRepairSourcePath','expectedSha256','expectedMatches','verifySignedSourceRepairPackage']) if (!sourceRepairCore.includes(token)) throw new Error(`Source Repair package contract missing ${token}.`);
for (const token of ['applyActive','awaiting-manual-decision','Ed25519','--loadout-repair-']) if (!repairRuntime.includes(token)) throw new Error(`In-app Repair Port contract missing ${token}.`);
const devPortCliSource = fs.readFileSync(path.join(root,'scripts/dev-port.mjs'),'utf8');
if (devPortCliSource.includes("name.endsWith('.lpatch')") || devPortCliSource.includes('verifySignedSourceRepairPackage')) throw new Error('Host-only .lpatch source repair must never be accepted by the Android USB/ADB Development Port.');
console.log('PASS private registry cache, USB/ADB Development Port, APK-bound native extension policy and operational CLI contracts.');
console.log('PASS signed UI Repair Port, bounded token catalog, manual activation/rollback and host-only hash-guarded Source Repair Port.');
console.log('PASS pinned direct dependencies and release metadata.')
if (fs.existsSync(lockPath)) console.log('PASS npm lockfile root/version metadata.');
else console.warn('WARN package-lock.json is absent; direct dependencies are pinned, but transitive dependency resolution is not reproducible yet.');
