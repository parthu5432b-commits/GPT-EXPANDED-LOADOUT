import fs from 'node:fs';
import { verifySignedPackage } from '../src/core/package-format.js';
const [packagePath, trustPath = 'www/runtime/trust-store.json'] = process.argv.slice(2);
if (!packagePath) throw new Error('Usage: node scripts/validate-update-package.mjs <package.lupdate> [trust-store.json]');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
const trust = JSON.parse(fs.readFileSync(trustPath, 'utf8'));
const result = verifySignedPackage(pkg, trust);
console.log(JSON.stringify({ valid: true, signer: result.signer, bytes: result.totalBytes, resources: result.resourceCount }, null, 2));
