import fs from 'node:fs';
import { verifySignedRegistryPackage } from '../src/core/private-registry.js';
const [packagePath, trustPath = 'www/runtime/trust-store.json'] = process.argv.slice(2);
if (!packagePath) throw new Error('Usage: node scripts/validate-registry-package.mjs <package.lreg> [trust-store.json]');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
const trust = JSON.parse(fs.readFileSync(trustPath, 'utf8'));
const installedRegistry = JSON.parse(fs.readFileSync('modules/registry.json', 'utf8'));
console.log(JSON.stringify(verifySignedRegistryPackage(pkg, trust, { installedRegistry }), null, 2));
