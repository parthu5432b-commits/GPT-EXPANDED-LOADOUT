const SAFE_VARIABLE = /^[A-Za-z][A-Za-z0-9]*$/;

/** Update an integer assignment in the variables.gradle format used by Capacitor 7. */
export function setGradleIntegerVariable(source, name, value) {
  if (typeof source !== 'string') throw new TypeError('Gradle source must be text.');
  if (!SAFE_VARIABLE.test(String(name))) throw new Error('Invalid Gradle variable name.');
  const numeric = Number(value);
  if (!Number.isSafeInteger(numeric) || numeric < 1) throw new Error(`Invalid integer value for ${name}.`);
  const pattern = new RegExp(`(^[ \\t]*${name}[ \\t]*=[ \\t]*)(\\d+)([ \\t]*(?://.*)?$)`, 'm');
  if (!pattern.test(source)) throw new Error(`Could not find ${name} assignment in variables.gradle.`);
  return source.replace(pattern, `$1${numeric}$3`);
}
