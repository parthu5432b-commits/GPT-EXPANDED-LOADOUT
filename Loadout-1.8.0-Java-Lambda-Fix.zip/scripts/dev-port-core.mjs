import path from 'node:path';

export const APP_ID = 'app.loadout.jee';
export const REMOTE_INBOX = `/sdcard/Android/data/${APP_ID}/files/Loadout/devport/inbox`;

export function parseAdbDevices(output) {
  const rows = [];
  for (const line of String(output || '').split(/\r?\n/)) {
    const match = line.trim().match(/^(\S+)\s+(device|unauthorized|offline)\b(.*)$/);
    if (match) rows.push({ serial: match[1], state: match[2], details: match[3].trim() });
  }
  return rows;
}

export function selectAdbDevice(rows, serial = '') {
  const usable = rows.filter(row => row.state === 'device');
  if (serial) {
    const selected = usable.find(row => row.serial === serial);
    if (!selected) throw new Error(`ADB device ${serial} is not connected and authorized.`);
    return selected;
  }
  if (usable.length !== 1) {
    if (usable.length > 1) throw new Error('More than one authorized ADB device is connected. Select one with --serial <serial>.');
    if (rows.some(row => row.state === 'unauthorized')) throw new Error('ADB device is unauthorized. Unlock the phone and accept the Android USB debugging authorization prompt.');
    throw new Error('No authorized ADB device is connected. Enable USB debugging and connect the phone.');
  }
  return usable[0];
}

export function safePackageFilename(input) {
  const name = path.basename(String(input || ''));
  if (name !== String(input || '') || name.length > 120 || name.includes('..') || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}\.(?:lupdate|lreg|lfix)$/.test(name)) {
    throw new Error('Package filename must be a simple .lupdate, .lreg or .lfix filename without path components.');
  }
  return name;
}

export function remotePackagePath(filename) {
  return `${REMOTE_INBOX}/${safePackageFilename(filename)}`;
}

export function parsePackageIdentity(dumpsys) {
  const text = String(dumpsys || '');
  const versionName = text.match(/versionName=([^\s]+)/)?.[1] || 'unknown';
  const versionCode = text.match(/versionCode=(\d+)/)?.[1] || 'unknown';
  const debuggable = /\bDEBUGGABLE\b/.test(text) || /flags=\[[^\]]*DEBUGGABLE/.test(text);
  return { versionName, versionCode, debuggable };
}
