import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { signingPayload, validateUnsignedPackage } from '../src/core/package-format.js';
const [inputPath, privateKeyPath, keyId, outputPath] = process.argv.slice(2);
if (!inputPath || !privateKeyPath || !keyId || !outputPath) throw new Error('Usage: node scripts/sign-update-package.mjs <unsigned-package.json> <private-key.pem> <key-id> <output.lupdate>');
const pkg = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
validateUnsignedPackage(pkg);
const privateKey = crypto.createPrivateKey(fs.readFileSync(privateKeyPath));
if (privateKey.asymmetricKeyType !== 'ed25519') throw new Error('Signing key must be Ed25519.');
pkg.manifest.signature = {
  algorithm: 'Ed25519',
  keyId,
  value: crypto.sign(null, Buffer.from(signingPayload(pkg), 'utf8'), privateKey).toString('base64')
};
fs.writeFileSync(outputPath, `${JSON.stringify(pkg, null, 2)}\n`);
console.log(`Signed ${outputPath} (${keyId}).`);
