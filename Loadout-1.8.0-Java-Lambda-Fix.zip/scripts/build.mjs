import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { setGradleIntegerVariable } from './gradle-config.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJson = relative => JSON.parse(fs.readFileSync(path.join(ROOT, relative), 'utf8'));
const fail = message => { console.error(`\nBUILD STOPPED: ${message}`); process.exit(1); };
function run(command, args, cwd = ROOT) {
  console.log(`\n> ${command} ${args.join(' ')}`);
  execFileSync(command, args, { cwd, stdio: 'inherit', env: { ...process.env, CI: 'true' } });
}
function walk(dir) {
  const out = [];
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) out.push(...walk(file)); else out.push(file);
  }
  return out;
}
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }

const plan = readJson('BUILD_PLAN.json');
const instructions = readJson('BUILD_INSTRUCTIONS.json');
const pkg = readJson('package.json');
const cap = readJson('capacitor.config.json');
if (plan.formatVersion !== 2 || plan.sourceMode !== 'repository-root') fail('Unsupported build plan; this release builds from the repository root, not an embedded ZIP.');
if (instructions.schemaVersion !== 2) fail('Unsupported BUILD_INSTRUCTIONS schema.');
if (cap.appId !== plan.expectedAppId || cap.appName !== plan.expectedAppName || cap.webDir !== plan.expectedWebDir) fail('Capacitor config does not match BUILD_PLAN app identity or webDir.');
if (instructions.app.appId !== cap.appId || instructions.app.webDir !== cap.webDir) fail('Deep build instructions disagree with capacitor.config.json.');
if (instructions.release.versionName !== pkg.version) fail('package.json version and BUILD_INSTRUCTIONS versionName disagree.');
if (Number(plan.expectedVersionCode) !== Number(instructions.release.versionCode) || String(plan.expectedVersionName) !== String(instructions.release.versionName)) fail('BUILD_PLAN version contract disagrees with BUILD_INSTRUCTIONS.');
if (!fs.existsSync(path.join(ROOT, 'package-lock.json'))) console.warn('WARNING: package-lock.json is not present. Direct dependencies are exact-pinned, but transitive npm resolution is not yet lockfile-reproducible.');
for (const file of ['www/index.html','www/app.js','www/runtime/loadout-runtime.js','www/runtime/trust-store.json','native/android/LoadoutCorePlugin.java']) {
  if (!fs.existsSync(path.join(ROOT, file))) fail(`Required source/build file missing: ${file}`);
}
if (!process.env.ANDROID_HOME && !process.env.ANDROID_SDK_ROOT) fail('Android SDK environment is not configured. Run this build in GitHub Actions or configure ANDROID_HOME locally.');

console.log('\nLoadout build contract:');
console.log(JSON.stringify({ app: instructions.app, release: instructions.release, runtime: instructions.runtime, native: instructions.native, toolchain: instructions.toolchain }, null, 2));

// Dependencies and verification are installed/run by the repository workflow.
if (!fs.existsSync(path.join(ROOT, 'node_modules', '@capacitor', 'cli', 'bin', 'capacitor'))) fail('Capacitor CLI is not installed. Run npm install before building.');

const androidRoot = path.join(ROOT, 'android');
if (!fs.existsSync(androidRoot)) run('npx', ['cap', 'add', 'android']);

const variablesGradle = path.join(androidRoot, 'variables.gradle');
if (!fs.existsSync(variablesGradle)) fail('Generated Android variables.gradle not found; refusing to build with an unknown SDK configuration.');
let variables = fs.readFileSync(variablesGradle, 'utf8');
for (const [name, value] of [['minSdkVersion', instructions.toolchain.androidMinSdk], ['compileSdkVersion', instructions.toolchain.androidCompileSdk], ['targetSdkVersion', instructions.toolchain.androidTargetSdk]]) {
  try { variables = setGradleIntegerVariable(variables, name, value); }
  catch (error) { fail(error.message); }
}
fs.writeFileSync(variablesGradle, variables);

const javaRoot = path.join(androidRoot, 'app', 'src', 'main', 'java');
if (!fs.existsSync(javaRoot)) fail('Generated Android Java source directory not found.');
const mainActivities = walk(javaRoot).filter(file => path.basename(file) === 'MainActivity.java');
if (mainActivities.length !== 1) fail(`Expected exactly one generated MainActivity.java; found ${mainActivities.length}.`);
const mainPath = mainActivities[0];
let main = fs.readFileSync(mainPath, 'utf8');
const packageMatch = main.match(/^\s*package\s+([A-Za-z0-9_.]+)\s*;/m);
if (!packageMatch) fail('Could not read package declaration from MainActivity.java.');
const javaPackage = packageMatch[1];
const nativeDir = path.join(ROOT, instructions.native.sourceDir);
const pluginFiles = walk(nativeDir).filter(file => file.endsWith('.java'));
if (!pluginFiles.some(file => path.basename(file) === `${instructions.native.pluginClass}.java`)) fail('Declared native plugin source is missing.');
for (const file of pluginFiles) {
  const template = fs.readFileSync(file, 'utf8');
  if (!template.includes('package __PACKAGE__;')) fail(`Native template must contain package placeholder: ${path.relative(ROOT, file)}`);
  const source = template.replace('package __PACKAGE__;', `package ${javaPackage};`);
  const destination = path.join(path.dirname(mainPath), path.basename(file));
  fs.writeFileSync(destination, source);
}
const importLine = `import ${javaPackage}.${instructions.native.pluginClass};`;
if (!main.includes(importLine)) main = main.replace(packageMatch[0], `${packageMatch[0]}\n\n${importLine}`);
if (!main.includes('import android.os.Bundle;')) main = main.replace(packageMatch[0], `${packageMatch[0]}\n\nimport android.os.Bundle;`);
if (!main.includes(`registerPlugin(${instructions.native.pluginClass}.class);`)) {
  const onCreate = /((?:public|protected)\s+void\s+onCreate\s*\(\s*Bundle\s+savedInstanceState\s*\)\s*\{)/;
  if (onCreate.test(main)) main = main.replace(onCreate, `$1\n        registerPlugin(${instructions.native.pluginClass}.class);`);
  else {
    const classOpen = /public\s+class\s+MainActivity\s+extends\s+BridgeActivity\s*\{/;
    if (!classOpen.test(main)) fail('Could not find Capacitor BridgeActivity host to register LoadoutCore.');
    main = main.replace(classOpen, `$&\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        registerPlugin(${instructions.native.pluginClass}.class);\n        super.onCreate(savedInstanceState);\n    }`);
  }
}
fs.writeFileSync(mainPath, main);

const gradleCandidates = [path.join(androidRoot, 'app', 'build.gradle'), path.join(androidRoot, 'app', 'build.gradle.kts')];
const gradlePath = gradleCandidates.find(file => fs.existsSync(file));
if (!gradlePath) fail('Generated app Gradle build file not found.');
let gradle = fs.readFileSync(gradlePath, 'utf8');
const versionCode = Number(instructions.release.versionCode);
const versionName = String(instructions.release.versionName);
if (!Number.isInteger(versionCode) || versionCode < 1 || !/^\d+\.\d+\.\d+$/.test(versionName)) fail('Invalid release version metadata.');
if (!/versionCode\s*(?:=\s*)?\d+/.test(gradle) || !/versionName\s*(?:=\s*)?["'][^"']+["']/.test(gradle)) fail('Could not find Android versionCode/versionName in generated Gradle file.');
gradle = gradle.replace(/versionCode\s*(?:=\s*)?\d+/, `versionCode ${versionCode}`);
gradle = gradle.replace(/versionName\s*(?:=\s*)?["'][^"']+["']/, `versionName "${versionName}"`);
fs.writeFileSync(gradlePath, gradle);

// Sync only the webDir to Android assets. Build-control, private keys and source archives stay outside www/.
run('npx', ['cap', 'sync', 'android']);
const publicAssets = path.join(androidRoot, 'app', 'src', 'main', 'assets', 'public');
if (!fs.existsSync(publicAssets)) fail('Capacitor public web asset directory was not generated.');
const assetFiles = walk(publicAssets);
const forbiddenAsset = assetFiles.find(file => /(^|[\\/])(\.github|scripts|tests|documentation|reference|signing|node_modules)([\\/]|$)|BUILD_INSTRUCTIONS|BUILD_PLAN|package-lock\.json/i.test(path.relative(publicAssets, file)));
if (forbiddenAsset) fail(`Build-control file leaked into APK web assets: ${path.relative(publicAssets, forbiddenAsset)}`);
for (const file of instructions.webAssets) {
  const normalized = path.posix.normalize(String(file).replaceAll('\\', '/'));
  if (!normalized.startsWith('www/') || normalized.includes('../')) fail(`Invalid declared web asset path: ${file}`);
  const relative = normalized.slice(4);
  if (!fs.existsSync(path.join(ROOT, normalized))) fail(`Declared source web asset missing: ${file}`);
  if (!fs.existsSync(path.join(publicAssets, relative))) fail(`Expected web asset missing from Android bundle: ${file}`);
}

const gradlew = path.join(androidRoot, 'gradlew');
if (!fs.existsSync(gradlew)) fail('Gradle wrapper missing after Capacitor Android generation.');
fs.chmodSync(gradlew, 0o755);
run('./gradlew', [instructions.build.gradleTask, '--no-daemon', '--stacktrace'], androidRoot);

const apkDir = path.join(androidRoot, 'app', 'build', 'outputs', 'apk', 'debug');
const apkFiles = fs.existsSync(apkDir) ? fs.readdirSync(apkDir).filter(name => name.endsWith('.apk')) : [];
if (!apkFiles.length) fail('Gradle completed but no debug APK was produced.');
const apk = path.join(apkDir, apkFiles.sort()[0]);
const dist = path.join(ROOT, 'dist');
fs.mkdirSync(dist, { recursive: true });
const output = path.join(dist, 'Loadout-Android-debug.apk');
fs.copyFileSync(apk, output);

let apkSignature = 'not-checked';
const sdkRoot = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
const buildToolsDir = path.join(sdkRoot, 'build-tools');
if (!fs.existsSync(buildToolsDir)) fail('Android build-tools directory is missing; APK identity cannot be verified.');
const versions = fs.readdirSync(buildToolsDir).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
const apksigner = versions.map(v => path.join(buildToolsDir, v, 'apksigner')).find(file => fs.existsSync(file));
const aapt = versions.map(v => path.join(buildToolsDir, v, 'aapt')).find(file => fs.existsSync(file));
if (!apksigner || !aapt) fail('Android build-tools must contain both apksigner and aapt for release verification.');
run(apksigner, ['verify', '--verbose', output]);
apkSignature = 'apksigner-verified';
const badging = execFileSync(aapt, ['dump', 'badging', output], { cwd: ROOT, encoding: 'utf8' });
const identity = badging.match(/^package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'/m);
if (!identity) fail('aapt could not read APK package identity and version.');
if (identity[1] !== instructions.app.appId || Number(identity[2]) !== versionCode || identity[3] !== versionName) {
  fail(`APK identity mismatch: ${identity[1]} v${identity[3]} (${identity[2]})`);
}
const apkEntries = execFileSync('unzip', ['-Z1', output], { cwd: ROOT, encoding: 'utf8' }).split(/\r?\n/).filter(Boolean);
for (const required of ['assets/public/index.html','assets/public/app.js','assets/public/runtime/loadout-runtime.js','classes.dex']) {
  if (!apkEntries.includes(required)) fail(`APK is missing required entry: ${required}`);
}
const forbiddenPublic = apkEntries.find(name => name.startsWith('assets/public/') && /(^|\/)(\.github|scripts|tests|documentation|reference|signing|node_modules)(\/|$)|BUILD_INSTRUCTIONS|BUILD_PLAN|package-lock\.json|\.ya?ml$/i.test(name.slice('assets/public/'.length)));
if (forbiddenPublic) fail(`Build-control file leaked into APK public assets: ${forbiddenPublic}`);
const sourceFiles = walk(ROOT).filter(file => {
  const relative = path.relative(ROOT, file).split(path.sep);
  const generatedRoot = ['node_modules', 'android', '.build', 'dist', '.git'];
  return !(relative.length > 1 && generatedRoot.includes(relative[0])) && !file.endsWith('.zip') && !file.includes(`${path.sep}local-signing${path.sep}`);
});
const sourceManifest = sourceFiles.map(file => ({ path: path.relative(ROOT, file).split(path.sep).join('/'), sha256: sha256(file) })).sort((a,b) => a.path.localeCompare(b.path));
const buildInfo = {
  appId: instructions.app.appId, appName: instructions.app.appName,
  versionName, versionCode, runtime: instructions.runtime,
  nativePlugin: instructions.native.pluginName,
  apk: 'dist/Loadout-Android-debug.apk', apkBytes: fs.statSync(output).size,
  apkSha256: sha256(output), apkSignature, apkIdentity: { packageName: identity[1], versionCode: Number(identity[2]), versionName: identity[3] },
  sourceFileCount: sourceManifest.length,
  sourceManifestSha256: crypto.createHash('sha256').update(JSON.stringify(sourceManifest)).digest('hex'),
  gitCommit: process.env.GITHUB_SHA || 'local', builtAt: new Date().toISOString(),
  caveat: 'This is a genuine Gradle APK artifact. Debug signing is stable across builds only when the same debug keystore is supplied to the build environment.'
};
fs.mkdirSync(path.join(ROOT, 'build'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'build', 'BUILD_INFO.json'), `${JSON.stringify(buildInfo, null, 2)}\n`);
fs.writeFileSync(path.join(dist, 'Loadout-Android-debug.apk.sha256'), `${buildInfo.apkSha256}  Loadout-Android-debug.apk\n`);
console.log('\nBUILD COMPLETE');
console.log(JSON.stringify(buildInfo, null, 2));
