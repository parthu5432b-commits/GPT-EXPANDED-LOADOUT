import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = p => JSON.parse(fs.readFileSync(path.join(ROOT, p), 'utf8'));
const expected = {
  physics: { chapters: 32, topics: 145, original: 170, excluded: 25 },
  chemistry: { chapters: 28, topics: 132, original: 170, excluded: 38 },
  mathematics: { chapters: 31, topics: 143, original: 210, excluded: 67 }
};
let totalTopics = 0, totalOriginal = 0, totalExcluded = 0;
const errors = [];
for (const [subject, counts] of Object.entries(expected)) {
  const data = read(`www/data/${subject}_historical_trends.json`);
  const summary = data.summary || {};
  const chapters = Array.isArray(data.chapters) ? data.chapters : [];
  const topicCount = chapters.reduce((sum, chapter) => sum + (Array.isArray(chapter.topics) ? chapter.topics.length : 0), 0);
  if (chapters.length !== counts.chapters) errors.push(`${subject}: chapter count ${chapters.length}, expected ${counts.chapters}`);
  if (topicCount !== counts.topics || summary.subtopic_count !== counts.topics) errors.push(`${subject}: active topic count ${topicCount}/${summary.subtopic_count}, expected ${counts.topics}`);
  if (summary.original_subtopic_count !== counts.original) errors.push(`${subject}: original topic count mismatch`);
  if (summary.excluded_topic_count !== counts.excluded) errors.push(`${subject}: excluded topic summary mismatch`);
  if (!Array.isArray(data.source_years) || data.source_years.join(',') !== '2025,2024,2023,2022,2021,2020,2019') errors.push(`${subject}: unexpected source year keys`);
  for (const chapter of chapters) {
    if (!chapter.title || !Array.isArray(chapter.topics)) errors.push(`${subject}: chapter missing title/topics`);
    for (const topic of chapter.topics || []) {
      if (!topic.name || !topic.years || typeof topic.years !== 'object') errors.push(`${subject}/${chapter.title}: malformed topic`);
      for (const year of data.source_years || []) {
        const row = topic.years?.[String(year)];
        if (!row) { errors.push(`${subject}/${chapter.title}/${topic.name}: missing ${year}`); continue; }
        const vals = [row.easy,row.moderate,row.tough,row.total];
        if (vals.some(v => !Number.isInteger(v) || v < 0) || row.total !== row.easy + row.moderate + row.tough) errors.push(`${subject}/${chapter.title}/${topic.name}/${year}: invalid E/M/T/O counts`);
      }
    }
  }
  totalTopics += topicCount; totalOriginal += counts.original; totalExcluded += counts.excluded;
  console.log(`PASS ${subject}: ${chapters.length} chapters · ${topicCount} retained topics · ${counts.excluded} exclusions`);
}
const audit = read('www/data/source_audit.json');
const exclusions = read('www/data/excluded_topics.json');
if (totalTopics !== 420 || audit.active_topic_rows !== 420) errors.push('Overall active rows must reconcile to 420.');
if (totalOriginal !== 550 || audit.original_topic_rows !== 550) errors.push('Overall source rows must reconcile to 550.');
if (totalExcluded !== 130 || audit.total_excluded_topics !== 130 || exclusions.count !== 130 || exclusions.topics?.length !== 130) errors.push('Overall excluded topic records must reconcile to 130.');
if (totalOriginal !== totalTopics + totalExcluded) errors.push('Original topic total does not reconcile to retained + excluded.');
const profile = read('exam-profiles/jee-main-2027/profile.json');
const unitCounts = Object.fromEntries(Object.entries(profile.subjects).map(([key,value]) => [key,value.units.length]));
if (unitCounts.Mathematics !== 14 || unitCounts.Physics !== 20 || unitCounts.Chemistry !== 20) errors.push('Official JEE Main 2027 Paper 1 top-level unit counts do not match the source profile.');
if (profile.mapping?.status !== 'not-yet-mapped') errors.push('The 2027 profile mapping must remain explicitly unverified until reviewed.');
const webProfile = read('www/data/exam-profiles/jee-main-2027.json');
if (JSON.stringify(webProfile) !== JSON.stringify(profile)) errors.push('Bundled web JEE Main 2027 profile differs from the repository source profile.');
const profileScript = fs.readFileSync(path.join(ROOT, 'www/data/jee-main-2027-profile.js'), 'utf8');
if (!profileScript.includes('window.LOADOUT_EXAM_PROFILE = ' + JSON.stringify(profile) + ';')) errors.push('WebView JavaScript syllabus profile differs from repository source profile.');
if (errors.length) { console.error('\nDATA AUDIT FAILED:\n- ' + errors.join('\n- ')); process.exit(1); }
console.log(`PASS overall: ${totalOriginal} historical source rows = ${totalTopics} retained + ${totalExcluded} excluded.`);
console.log(`PASS official syllabus profile: Maths ${unitCounts.Mathematics}, Physics ${unitCounts.Physics}, Chemistry ${unitCounts.Chemistry} top-level Paper 1 units.`);
console.log('Note: source row reconciliation validates bundled dataset integrity, not NTA syllabus inclusion or a shift-by-shift PYQ inventory.');
