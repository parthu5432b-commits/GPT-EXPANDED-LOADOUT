import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const excludedAtRoot = new Set(['node_modules', 'android', '.build', 'dist', '.git', '.loadout-repair']);
const rows = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error(`Refusing to inventory symlink: ${path.relative(root, path.join(dir, entry.name))}`);
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const relative = path.relative(root, full).replaceAll('\\', '/');
      if (!(relative.split('/').length === 1 && excludedAtRoot.has(entry.name))) walk(full);
      continue;
    }
    if (path.relative(root, full).replaceAll('\\', '/') === 'FILE_INVENTORY.tsv') continue;
    const bytes = fs.readFileSync(full);
    rows.push({ path: path.relative(root, full).replaceAll('\\', '/'), size: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex') });
  }
}
walk(root);
rows.sort((a, b) => a.path.localeCompare(b.path));
const output = ['path\tsize_bytes\tsha256', ...rows.map(r => `${r.path}\t${r.size}\t${r.sha256}`)].join('\n') + '\n';
fs.writeFileSync(path.join(root, 'FILE_INVENTORY.tsv'), output);
console.log(`Wrote FILE_INVENTORY.tsv for ${rows.length} repository files (inventory file itself is excluded from its own hash list).`);
