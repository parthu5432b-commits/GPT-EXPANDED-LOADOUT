#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { verifySignedPackage } from '../src/core/package-format.js';
import { verifySignedRegistryPackage } from '../src/core/private-registry.js';
import { verifySignedRepairPackage } from '../src/core/repair-package.js';
import { APP_ID, REMOTE_INBOX, parseAdbDevices, selectAdbDevice, safePackageFilename, remotePackagePath, parsePackageIdentity } from './dev-port-core.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [command = 'help', ...rawArgs] = process.argv.slice(2);
const serialIndex = rawArgs.indexOf('--serial');
const serial = serialIndex >= 0 ? rawArgs[serialIndex + 1] : (process.env.ANDROID_SERIAL || '');
const args = rawArgs.filter((_, i) => i !== serialIndex && i !== serialIndex + 1);

function runAdb(adbArgs, { encoding = 'utf8' } = {}) {
  try { return execFileSync('adb', adbArgs, { encoding, stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 16 * 1024 * 1024 }); }
  catch (error) {
    const detail = error.stderr?.toString?.() || error.message || String(error);
    throw new Error(`adb ${adbArgs.join(' ')} failed: ${detail.trim()}`);
  }
}
function chooseDevice() {
  const rows = parseAdbDevices(runAdb(['devices', '-l']));
  return selectAdbDevice(rows, serial);
}
function runOn(device, remoteArgs) { return runAdb(['-s', device.serial, ...remoteArgs]); }
function installedIdentity(device) {
  const apkPath = runOn(device, ['shell', 'pm', 'path', APP_ID]).trim();
  if (!apkPath.startsWith('package:')) throw new Error(`Loadout (${APP_ID}) is not installed on ${device.serial}.`);
  const dump = runOn(device, ['shell', 'dumpsys', 'package', APP_ID]);
  const info = parsePackageIdentity(dump);
  if (info.versionName === 'unknown') throw new Error('Could not read installed Loadout version metadata.');
  return info;
}
function hostKeyFingerprint() {
  const pub = path.join(os.homedir(), '.android', 'adbkey.pub');
  if (!fs.existsSync(pub)) return 'ADB host key fingerprint unavailable; first connection may show the Android authorization dialog.';
  const key = fs.readFileSync(pub, 'utf8').trim();
  return 'SHA256:' + crypto.createHash('sha256').update(key).digest('base64').replace(/=+$/, '');
}
function verifyPackageFile(file) {
  const resolved = path.resolve(file);
  if (!fs.statSync(resolved).isFile() || fs.statSync(resolved).size > 10 * 1024 * 1024) throw new Error('Package must be a regular file no larger than 10 MiB.');
  const pkg = JSON.parse(fs.readFileSync(resolved, 'utf8'));
  const trust = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/runtime/trust-store.json'), 'utf8'));
  const name = safePackageFilename(path.basename(resolved));
  if (!name.endsWith('.lreg') && !name.endsWith('.lupdate') && !name.endsWith('.lfix')) throw new Error('Unsupported Development Port package type. Use .lupdate, .lreg or .lfix; executable .lmod is not supported.');
  const verified = name.endsWith('.lreg')
    ? verifySignedRegistryPackage(pkg, trust, { installedRegistry: JSON.parse(fs.readFileSync(path.join(ROOT, 'modules/registry.json'), 'utf8')) })
    : name.endsWith('.lfix')
      ? verifySignedRepairPackage(pkg, trust)
      : verifySignedPackage(pkg, trust);
  return { resolved, name, pkg, verified, digest: crypto.createHash('sha256').update(fs.readFileSync(resolved)).digest('hex') };
}
function printHelp() {
  console.log(`Loadout Development Port — authenticated USB/ADB bridge (debug APK only)

Usage:
  node scripts/dev-port.mjs pair [--serial SERIAL]
  node scripts/dev-port.mjs status [--serial SERIAL]
  node scripts/dev-port.mjs push <signed-package.lupdate|.lreg|.lfix> [--serial SERIAL]
  node scripts/dev-port.mjs list [--serial SERIAL]
  node scripts/dev-port.mjs remove <filename> [--serial SERIAL]

Pairing uses Android's ADB host authorization prompt. The app opens no LAN listener
and provides no remote shell or arbitrary code execution endpoint. Signed .lupdate resources, .lreg catalogs and bounded .lfix UI repairs are accepted. Executable .lmod and host-only .lpatch packages are rejected. The app requires manual Commit or Roll Back.
`);
}

try {
  if (command === 'help' || command === '--help' || command === '-h') { printHelp(); process.exit(0); }
  const device = chooseDevice();
  if (command === 'pair' || command === 'status') {
    const info = installedIdentity(device);
    if (!info.debuggable) throw new Error('Installed Loadout build is not debuggable; the Development Port is intentionally disabled in production builds. Install the private debug APK first.');
    console.log(JSON.stringify({ paired: true, transport: 'adb-usb', serial: device.serial, hostKeyFingerprint: hostKeyFingerprint(), package: APP_ID, ...info, inbox: REMOTE_INBOX, networkListener: false, remoteExecution: false, manualCommit: true }, null, 2));
    if (command === 'pair') console.log('\nADB authorization is the pairing boundary. Keep this workstation authorized only while you trust it.');
    process.exit(0);
  }
  const info = installedIdentity(device);
  if (!info.debuggable) throw new Error('Installed Loadout build is not debuggable; the Development Port is intentionally disabled.');
  if (command === 'push') {
    if (!args[0]) throw new Error('Provide a signed package path.');
    const item = verifyPackageFile(args[0]);
    runOn(device, ['shell', 'mkdir', '-p', REMOTE_INBOX]);
    runOn(device, ['push', item.resolved, remotePackagePath(item.name)]);
    console.log(JSON.stringify({ transferred: true, device: device.serial, file: item.name, bytes: fs.statSync(item.resolved).size, sha256: item.digest, signer: item.verified.signer, packageIdentity: item.name.endsWith('.lreg') ? { registryId: item.pkg.manifest.registryId, revision: item.pkg.manifest.revision } : item.name.endsWith('.lfix') ? { repairId: item.pkg.manifest.repairId, title: item.pkg.manifest.title } : { updateId: item.pkg.manifest.updateId }, inbox: REMOTE_INBOX, next: item.name.endsWith('.lfix') ? 'Open Loadout → Data & Settings → Observatory → Repair Port → Verify & stage, then inspect token impact and choose Commit or Roll Back.' : 'Open Loadout → Data & Settings → Observatory → Development Port → Verify & stage. Then inspect the impact report and choose Commit or Roll Back.' }, null, 2));
  } else if (command === 'list') {
    runOn(device, ['shell', 'mkdir', '-p', REMOTE_INBOX]);
    const listing = runOn(device, ['shell', 'ls', '-la', REMOTE_INBOX]);
    console.log(listing || '(empty inbox)');
  } else if (command === 'remove') {
    const name = safePackageFilename(args[0]);
    runOn(device, ['shell', 'rm', '-f', remotePackagePath(name)]);
    console.log(`Removed ${name} from the Development Port inbox.`);
  } else {
    printHelp();
    throw new Error(`Unknown command: ${command}`);
  }
} catch (error) {
  console.error(`Development Port stopped: ${error.message}`);
  process.exitCode = 1;
}
