#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { verifySignedSourceRepairPackage, applySourceRepairOperations, sourceRepairSha256 } from '../src/core/source-repair-package.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const META = path.join(ROOT, '.loadout-repair');
const [command = 'help', ...args] = process.argv.slice(2);
const EXCLUDES = new Set(['.git', 'node_modules', 'android', 'dist', '.build', 'local-signing', '.loadout-repair']);

function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`); }
function readTrust() { return readJson(path.join(ROOT, 'www/runtime/trust-store.json'), { keys: [] }); }
function readPackage(file) {
  const stat = fs.statSync(file);
  if (!stat.isFile() || stat.size > 2 * 1024 * 1024) throw new Error('Source repair must be a regular file no larger than 2 MiB.');
  const pkg = JSON.parse(fs.readFileSync(file, 'utf8'));
  const verified = verifySignedSourceRepairPackage(pkg, readTrust());
  return { pkg, verified };
}
function safeRootPath(relative) {
  const full = path.resolve(ROOT, relative);
  if (!full.startsWith(ROOT + path.sep)) throw new Error(`Path escapes workspace: ${relative}`);
  const parts = path.relative(ROOT, full).split(path.sep);
  let cursor = ROOT;
  for (let i = 0; i < parts.length; i++) {
    cursor = path.join(cursor, parts[i]);
    if (!fs.existsSync(cursor)) continue;
    const stat = fs.lstatSync(cursor);
    if (stat.isSymbolicLink()) throw new Error(`Source repair target traverses a symlink: ${relative}`);
    if (i < parts.length - 1 && !stat.isDirectory()) throw new Error(`Source repair path has a non-directory parent: ${relative}`);
    if (i === parts.length - 1 && !stat.isFile()) throw new Error(`Source repair target is not a regular file: ${relative}`);
  }
  return full;
}
function atomicRestore(target, bytes) {
  const temp = `${target}.loadout-restore-${process.pid}.tmp`;
  fs.writeFileSync(temp, bytes, { flag: 'wx' });
  fs.renameSync(temp, target);
}
function copyWorkspace(destination) {
  fs.mkdirSync(destination, { recursive: true });
  for (const name of fs.readdirSync(ROOT)) {
    if (EXCLUDES.has(name)) continue;
    const from = path.join(ROOT, name), to = path.join(destination, name);
    fs.cpSync(from, to, { recursive: true, dereference: false, errorOnExist: false, filter: source => !fs.lstatSync(source).isSymbolicLink() });
  }
}
function readWorkspaceFiles(operations, base = ROOT) {
  const map = new Map();
  for (const op of operations) {
    const full = path.resolve(base, op.file);
    if (!full.startsWith(base + path.sep) || !fs.existsSync(full) || !fs.lstatSync(full).isFile() || fs.lstatSync(full).isSymbolicLink()) throw new Error(`Source target missing or not a regular file: ${op.file}`);
    const stat = fs.statSync(full);
    if (stat.size > 2 * 1024 * 1024) throw new Error(`Source file exceeds 2 MiB patch limit: ${op.file}`);
    map.set(op.file, fs.readFileSync(full, 'utf8'));
  }
  return map;
}
function writeJournal(journal) { writeJson(path.join(META, 'journal.json'), journal); }
function runChecks(stageRoot) {
  const checks = [
    ['npm test', ['test']],
    ['npm run check', ['run', 'check']],
    ['npm run audit:data', ['run', 'audit:data']]
  ];
  const results = [];
  for (const [label, commandArgs] of checks) {
    const result = spawnSync('npm', commandArgs, { cwd: stageRoot, encoding: 'utf8', timeout: 240000, maxBuffer: 12 * 1024 * 1024, env: { ...process.env, CI: '1' } });
    const ok = result.status === 0 && !result.error;
    results.push({ command: label, ok, status: result.status, output: (result.stdout || '') + (result.stderr || ''), error: result.error?.message || null });
    if (!ok) break;
  }
  return results;
}

function usage() {
  console.log(`Loadout Source Repair Port — guarded repository patcher

Commands:
  npm run repair:port -- inspect <signed-file.lpatch>
  npm run repair:port -- stage <signed-file.lpatch>
  npm run repair:port -- commit <repair-id>
  npm run repair:port -- rollback <repair-id>
  npm run repair:port -- status

The port applies only Ed25519-trusted, SHA-256-bound, single-anchor source patches.
It stages a complete workspace copy and runs tests, source checks and the data audit.
A separate explicit commit command writes the patch to the working tree. It does not
build or install an APK. Native/manifest/source changes still require the normal APK workflow.`);
}

try {
  if (command === 'help' || command === '--help' || command === '-h') { usage(); process.exit(0); }
  if (command === 'status') { console.log(JSON.stringify(readJson(path.join(META, 'journal.json'), []), null, 2)); process.exit(0); }
  if (command === 'inspect' || command === 'stage') {
    if (!args[0]) throw new Error('Provide a signed .lpatch package.');
    const file = path.resolve(args[0]);
    const { pkg, verified } = readPackage(file);
    const operations = pkg.manifest.operations;
    const current = readWorkspaceFiles(operations);
    const changed = applySourceRepairOperations(current, operations);
    const plan = operations.map(op => ({ file: op.file, before: op.expectedSha256, after: sourceRepairSha256(changed.get(op.file)), reason: op.reason || '' }));
    if (command === 'inspect') { console.log(JSON.stringify({ valid: true, signer: verified.signer, repairId: verified.repairId, title: verified.title, operations: plan }, null, 2)); process.exit(0); }
    const repairId = pkg.manifest.repairId;
    const stageRoot = path.join(META, 'staging', repairId);
    if (fs.existsSync(stageRoot)) throw new Error(`A staging directory already exists for ${repairId}. Inspect status or clear it after review.`);
    copyWorkspace(stageRoot);
    const currentStage = readWorkspaceFiles(operations, stageRoot);
    const changedStage = applySourceRepairOperations(currentStage, operations);
    for (const [relative, content] of changedStage) fs.writeFileSync(path.resolve(stageRoot, relative), content, 'utf8');
    const checks = runChecks(stageRoot);
    const passed = checks.length === 3 && checks.every(row => row.ok);
    const report = { repairId, title: pkg.manifest.title, description: pkg.manifest.description, signer: verified.signer, stagedAt: new Date().toISOString(), state: passed ? 'validated-awaiting-owner-commit' : 'validation-failed', operations: plan, checks: checks.map(({ command, ok, status, error, output }) => ({ command, ok, status, error, output: output.slice(-16000) })) };
    writeJson(path.join(stageRoot, '.loadout-repair-stage.json'), report);
    const journal = readJson(path.join(META, 'journal.json'), []);
    journal.push({ repairId, title: report.title, state: report.state, stagedAt: report.stagedAt, signer: verified.signer, stageRoot: path.relative(ROOT, stageRoot), files: operations.map(op => op.file), operations: plan, checkSummary: checks.map(({ command, ok }) => ({ command, ok })) });
    writeJournal(journal.slice(-100));
    console.log(JSON.stringify(report, null, 2));
    if (!passed) process.exitCode = 2;
    else console.log(`\nValidated. No live file has changed. Explicit next step: npm run repair:port -- commit ${repairId}`);
    process.exit();
  }
  if (command === 'commit') {
    const repairId = args[0];
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/.test(String(repairId || ''))) throw new Error('Provide a valid repair ID.');
    const stageRoot = path.join(META, 'staging', repairId);
    const stageReport = readJson(path.join(stageRoot, '.loadout-repair-stage.json'), null);
    if (!stageReport || stageReport.state !== 'validated-awaiting-owner-commit') throw new Error('A validated staging report is required; rejected or untested patches cannot be committed.');
    const backupRoot = path.join(META, 'backups', repairId);
    if (fs.existsSync(backupRoot)) throw new Error(`A backup already exists for ${repairId}; refusing to overwrite it.`);
    fs.mkdirSync(backupRoot, { recursive: true });
    for (const row of stageReport.operations) {
      const live = safeRootPath(row.file), staged = path.resolve(stageRoot, row.file);
      const liveText = fs.readFileSync(live, 'utf8');
      if (sourceRepairSha256(liveText) !== row.before) throw new Error(`Live file changed after staging; re-stage required: ${row.file}`);
      if (sourceRepairSha256(fs.readFileSync(staged, 'utf8')) !== row.after) throw new Error(`Staged file changed after validation: ${row.file}`);
      const backup = path.resolve(backupRoot, row.file);
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.writeFileSync(backup, liveText, 'utf8');
    }
    const written = [];
    try {
      for (const row of stageReport.operations) {
        const live = safeRootPath(row.file), staged = path.resolve(stageRoot, row.file);
        const temp = live + `.loadout-${repairId}.tmp`;
        fs.writeFileSync(temp, fs.readFileSync(staged));
        fs.renameSync(temp, live);
        written.push(row.file);
      }
    } catch (error) {
      for (const relative of written.reverse()) atomicRestore(safeRootPath(relative), fs.readFileSync(path.resolve(backupRoot, relative)));
      throw new Error(`Commit failed; prior files were restored. ${error.message}`);
    }
    stageReport.state = 'committed'; stageReport.committedAt = new Date().toISOString();
    writeJson(path.join(stageRoot, '.loadout-repair-stage.json'), stageReport);
    const journal = readJson(path.join(META, 'journal.json'), []);
    const row = journal.find(item => item.repairId === repairId); if (row) { row.state = 'committed'; row.committedAt = stageReport.committedAt; row.backupRoot = path.relative(ROOT, backupRoot); }
    writeJournal(journal);
    console.log(`Committed ${repairId}. Backup: ${path.relative(ROOT, backupRoot)}. Next run npm test, npm run check and npm run audit:data; APK changes still require the normal build workflow.`);
    process.exit(0);
  }
  if (command === 'rollback') {
    const repairId = args[0];
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/.test(String(repairId || ''))) throw new Error('Provide a valid repair ID.');
    const stageRoot = path.join(META, 'staging', repairId);
    const report = readJson(path.join(stageRoot, '.loadout-repair-stage.json'), null);
    if (!report || report.state !== 'committed') throw new Error('Only a committed repair can be rolled back.');
    const backupRoot = path.join(META, 'backups', repairId);
    for (const row of report.operations) {
      const live = fs.readFileSync(safeRootPath(row.file), 'utf8');
      if (sourceRepairSha256(live) !== row.after) throw new Error(`Rollback refused because ${row.file} changed after this repair. Resolve later edits first.`);
    }
    for (const row of report.operations) atomicRestore(safeRootPath(row.file), fs.readFileSync(path.resolve(backupRoot, row.file)));
    report.state = 'rolled-back'; report.rolledBackAt = new Date().toISOString();
    writeJson(path.join(stageRoot, '.loadout-repair-stage.json'), report);
    const journal = readJson(path.join(META, 'journal.json'), []); const item = journal.find(x => x.repairId === repairId); if (item) { item.state = 'rolled-back'; item.rolledBackAt = report.rolledBackAt; } writeJournal(journal);
    console.log(`Rolled back ${repairId}; original source files restored from ${path.relative(ROOT, backupRoot)}.`);
    process.exit(0);
  }
  usage(); throw new Error(`Unknown command: ${command}`);
} catch (error) {
  console.error(`Source Repair Port stopped: ${error.message}`);
  process.exitCode = 1;
}
