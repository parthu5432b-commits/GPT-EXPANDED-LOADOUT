import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const stable = value => {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
};
const source = JSON.parse(fs.readFileSync(path.join(root, 'modules/registry.json'), 'utf8'));
const modules = source.modules.map(row => {
  const slug = row.id.replace(/^loadout\./, '');
  const manifestPath = `modules/${slug}.module.json`;
  const manifestBytes = fs.readFileSync(path.join(root, manifestPath));
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  const entry = fs.readFileSync(path.join(root, row.entry));
  return {
    id: row.id, name: row.name, version: row.version, runtimeApi: row.runtimeApi,
    route: row.route, entry: row.entry, offline: row.offline,
    services: [...row.services].sort(), dependencies: [...(manifest.dependencies || [])].sort((a,b) => String(typeof a === 'string' ? a : a.id).localeCompare(String(typeof b === 'string' ? b : b.id))), manifestPath,
    manifestSha256: hash(manifestBytes), entrySha256: hash(entry)
  };
});
const catalog = {
  schemaVersion: 1,
  registryId: source.registryId,
  ownerControlled: source.ownerControlled,
  publicMarketplace: source.publicMarketplace,
  runtimeApi: source.runtimeApi,
  revision: 1,
  distribution: 'bundled-apk-plus-owner-signed-offline-import',
  modules
};
catalog.catalogSha256 = hash(stable(catalog));
const json = JSON.stringify(catalog, null, 2) + '\n';
for (const relative of ['registry/catalog.json', 'www/runtime/registry-catalog.json']) fs.writeFileSync(path.join(root, relative), json);
console.log(`Wrote first-party registry catalog ${catalog.registryId} revision ${catalog.revision} (${modules.length} modules, ${catalog.catalogSha256}).`);
