import { createPublicKey, verify as cryptoVerify } from 'node:crypto';
import { sha256, stableStringify } from './ltl.js';

const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
const SEMVER = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;

export function registrySigningPayload(pkg) {
  const manifest = structuredClone(pkg.manifest);
  delete manifest.signature;
  return `LOADOUT-REGISTRY-1.0\n${stableStringify({ manifest, catalog: pkg.catalog })}`;
}

export function validateRegistryPackage(pkg, installedRegistry, { appId = 'app.loadout.jee', runtimeApi = '1.5.0' } = {}) {
  if (!pkg || typeof pkg !== 'object' || !pkg.manifest || !pkg.catalog || typeof pkg.catalog !== 'object') throw new Error('Registry package requires manifest and catalog objects.');
  const m = pkg.manifest, c = pkg.catalog;
  if (m.formatVersion !== '1.0' || m.kind !== 'module-registry' || m.target?.appId !== appId || m.target?.runtimeApi !== runtimeApi) throw new Error('Registry package format or target mismatch.');
  if (!SAFE_ID.test(String(m.registryId || '')) || !Number.isSafeInteger(m.revision) || m.revision < 1) throw new Error('Registry identity/revision is invalid.');
  if (c.schemaVersion !== 1 || c.registryId !== m.registryId || c.revision !== m.revision || c.runtimeApi !== runtimeApi || c.ownerControlled !== true || c.publicMarketplace !== false || !Array.isArray(c.modules)) throw new Error('Registry catalog policy or metadata is invalid.');
  const suppliedHash = String(c.catalogSha256 || '').toLowerCase();
  const content = structuredClone(c); delete content.catalogSha256;
  if (!/^[a-f0-9]{64}$/.test(suppliedHash) || sha256(stableStringify(content)) !== suppliedHash) throw new Error('Registry catalog SHA-256 mismatch.');
  if (!Array.isArray(installedRegistry?.modules)) throw new Error('Installed module registry is unavailable.');
  const installed = new Map(installedRegistry.modules.map(row => [row.id, row]));
  if (c.modules.length !== installed.size) throw new Error('Registry package cannot add or remove executable module declarations; rebuild the APK for module-code changes.');
  const seen = new Set(), routes = new Set();
  for (const module of c.modules) {
    if (!module || !SAFE_ID.test(String(module.id || '')) || !SEMVER.test(String(module.version || '')) || !SEMVER.test(String(module.runtimeApi || '')) || typeof module.entry !== 'string' || !module.entry.startsWith('www/') || module.entry.includes('..') || typeof module.offline !== 'boolean' || !Array.isArray(module.services) || !Array.isArray(module.dependencies)) throw new Error('Invalid registry module descriptor.');
    if (seen.has(module.id) || routes.has(module.route)) throw new Error('Duplicate registry module or route.');
    seen.add(module.id); routes.add(module.route);
    const row = installed.get(module.id);
    if (!row) throw new Error(`Unbundled module is not eligible for registry activation: ${module.id}`);
    if (module.version !== row.version || module.runtimeApi !== row.runtimeApi || module.route !== row.route || module.entry !== row.entry || module.offline !== row.offline) throw new Error(`Registry descriptor disagrees with APK-bundled module ${module.id}; executable module changes require a new APK.`);
    if ([...module.services].sort().join('|') !== [...(row.services || [])].sort().join('|')) throw new Error(`Registry service contract mismatch for ${module.id}.`);
    const sortDeps = (items) => [...items].sort((a, b) => String(typeof a === 'string' ? a : a.id).localeCompare(String(typeof b === 'string' ? b : b.id)));
    const expectedDeps = sortDeps(row.dependencies || []);
    const suppliedDeps = sortDeps(module.dependencies);
    if (stableStringify(suppliedDeps) !== stableStringify(expectedDeps)) throw new Error(`Registry dependency declaration mismatch for ${module.id}.`);
    for (const dependency of suppliedDeps) {
      const dep = typeof dependency === 'string' ? { id: dependency } : dependency;
      if (!dep || !SAFE_ID.test(String(dep.id || '')) || !installed.has(dep.id)) throw new Error(`Unresolved registry dependency for ${module.id}.`);
      const target = installed.get(dep.id);
      if (dep.version && target.version !== dep.version) throw new Error(`Registry dependency version mismatch for ${module.id}: ${dep.id}@${dep.version} required.`);
    }
    for (const digest of [module.manifestSha256, module.entrySha256]) if (!/^[a-f0-9]{64}$/i.test(String(digest || ''))) throw new Error(`Missing source integrity digest for ${module.id}.`);
  }
  return { valid: true, registryId: c.registryId, revision: c.revision, moduleCount: c.modules.length, catalogSha256: suppliedHash };
}

export function verifySignedRegistryPackage(pkg, trustedKeys, options) {
  const validated = validateRegistryPackage(pkg, options?.installedRegistry, options);
  const sig = pkg.manifest.signature;
  if (!sig || sig.algorithm !== 'Ed25519' || !SAFE_ID.test(String(sig.keyId || '')) || !/^[A-Za-z0-9+/]{86}==$/.test(String(sig.value || ''))) throw new Error('Registry package has no supported Ed25519 signature.');
  const entry = trustedKeys?.keys?.find(key => key.keyId === sig.keyId && key.algorithm === 'Ed25519' && !key.revokedAt && key.status !== 'revoked');
  if (!entry) throw new Error(`Registry signer is not trusted or has been revoked: ${sig.keyId}`);
  let publicKey;
  if (typeof entry.publicKeyPem === 'string' && entry.publicKeyPem.includes('BEGIN PUBLIC KEY')) publicKey = createPublicKey(entry.publicKeyPem);
  else if (typeof entry.publicKey === 'string') {
    const raw = Buffer.from(entry.publicKey, 'base64');
    if (raw.length !== 32) throw new Error('Trusted Ed25519 public key must decode to 32 bytes.');
    publicKey = createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), raw]), format: 'der', type: 'spki' });
  } else throw new Error('Registry trust entry has no public key.');
  if (!cryptoVerify(null, Buffer.from(registrySigningPayload(pkg)), publicKey, Buffer.from(sig.value, 'base64'))) throw new Error('Registry Ed25519 signature verification failed.');
  return { ...validated, signer: sig.keyId };
}
