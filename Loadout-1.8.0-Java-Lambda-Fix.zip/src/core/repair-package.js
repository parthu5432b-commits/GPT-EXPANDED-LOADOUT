import { createPublicKey, verify as cryptoVerify } from 'node:crypto';
import { stableStringify } from './ltl.js';

export const REPAIR_FORMAT_VERSION = '1.0';
export const REPAIR_APP_ID = 'app.loadout.jee';
export const REPAIR_RUNTIME_API = '1.5.0';
export const REPAIR_MAX_BYTES = 1024 * 1024;
export const REPAIR_MAX_FIXES = 48;

const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
const SEMVER = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;

export const REPAIR_SCOPES = Object.freeze({
  global: Object.freeze({ label: 'Application shell', route: null, tokens: ['main-horizontal-padding', 'main-max-width', 'font-scale', 'line-height'] }),
  'loadout.command-center': Object.freeze({ label: 'Command Center', route: 'dashboard', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] }),
  'loadout.chapter-map': Object.freeze({ label: 'Chapter Map', route: 'chapters', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] }),
  'loadout.pyq-intelligence': Object.freeze({ label: 'PYQ Intelligence', route: 'historical', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] }),
  'loadout.test-ledger': Object.freeze({ label: 'Test Ledger', route: 'tests', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow', 'modal-max-height'] }),
  'loadout.forecast-engine': Object.freeze({ label: 'Forecast Lab', route: 'forecasts', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] }),
  'loadout.ai-coach': Object.freeze({ label: 'AI Coach', route: 'chatbot', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'chat-panel-max-height', 'chat-input-min-height'] }),
  'loadout.data-settings': Object.freeze({ label: 'Data & Settings', route: 'data', tokens: ['grid-gap', 'card-padding', 'card-radius', 'font-scale', 'line-height', 'table-min-width', 'table-overflow'] })
});

const tokenRules = Object.freeze({
  'main-horizontal-padding': { type: 'px', min: 8, max: 56 },
  'main-max-width': { type: 'px', min: 900, max: 1900 },
  'grid-gap': { type: 'px', min: 4, max: 36 },
  'card-padding': { type: 'px', min: 8, max: 36 },
  'card-radius': { type: 'px', min: 6, max: 32 },
  'font-scale': { type: 'number', min: 0.88, max: 1.15 },
  'line-height': { type: 'number', min: 1.25, max: 1.85 },
  'table-min-width': { type: 'px', min: 280, max: 1200 },
  'table-overflow': { type: 'enum', values: ['auto', 'scroll', 'hidden'] },
  'modal-max-height': { type: 'vh', min: 45, max: 95 },
  'chat-panel-max-height': { type: 'vh', min: 35, max: 82 },
  'chat-input-min-height': { type: 'px', min: 44, max: 160 }
});

function validateTokenValue(token, value) {
  const rule = tokenRules[token];
  if (!rule) throw new Error(`Unsupported repair token: ${token}`);
  if (rule.type === 'enum') {
    if (typeof value !== 'string' || !rule.values.includes(value)) throw new Error(`Invalid value for ${token}. Allowed: ${rule.values.join(', ')}.`);
    return;
  }
  if (rule.type === 'number') {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < rule.min || value > rule.max) throw new Error(`${token} must be a number from ${rule.min} to ${rule.max}.`);
    return;
  }
  const suffix = rule.type === 'px' ? 'px' : 'vh';
  if (typeof value !== 'string' || !new RegExp(`^(?:\\d+(?:\\.\\d+)?)${suffix}$`).test(value)) throw new Error(`${token} must be a bounded ${suffix} value.`);
  const numeric = Number.parseFloat(value);
  if (numeric < rule.min || numeric > rule.max) throw new Error(`${token} must be between ${rule.min}${suffix} and ${rule.max}${suffix}.`);
}

export function repairSigningPayload(pkg) {
  const manifest = structuredClone(pkg.manifest);
  delete manifest.signature;
  return `LOADOUT-LFIX-${REPAIR_FORMAT_VERSION}\n${stableStringify(manifest)}`;
}

export function validateUnsignedRepairPackage(pkg, { appId = REPAIR_APP_ID, runtimeApi = REPAIR_RUNTIME_API, appVersion = '1.8.0' } = {}) {
  if (!pkg || typeof pkg !== 'object' || Array.isArray(pkg) || Object.keys(pkg).some(key => key !== 'manifest') || !pkg.manifest || typeof pkg.manifest !== 'object' || Array.isArray(pkg.manifest)) {
    throw new Error('A repair package must contain only a manifest object.');
  }
  const m = pkg.manifest;
  if (m.formatVersion !== REPAIR_FORMAT_VERSION || m.kind !== 'ui-repair') throw new Error('Unsupported repair format or package kind.');
  if (m.target?.appId !== appId || m.target?.runtimeApi !== runtimeApi) throw new Error('Repair targets a different app or runtime API.');
  if (m.target.minimumAppVersion !== undefined) {
    if (typeof m.target.minimumAppVersion !== 'string' || !SEMVER.test(m.target.minimumAppVersion)) throw new Error('Invalid minimumAppVersion.');
    const [requiredMajor, requiredMinor, requiredPatch] = m.target.minimumAppVersion.split(/[.+-]/).slice(0, 3).map(Number);
    const [currentMajor, currentMinor, currentPatch] = appVersion.split(/[.+-]/).slice(0, 3).map(Number);
    if ([requiredMajor, requiredMinor, requiredPatch, currentMajor, currentMinor, currentPatch].some(x => !Number.isFinite(x))) throw new Error('Could not compare repair target app version.');
    if (currentMajor < requiredMajor || (currentMajor === requiredMajor && currentMinor < requiredMinor) || (currentMajor === requiredMajor && currentMinor === requiredMinor && currentPatch < requiredPatch)) throw new Error(`Repair requires Loadout ${m.target.minimumAppVersion} or later.`);
  }
  if (typeof m.repairId !== 'string' || !SAFE_ID.test(m.repairId)) throw new Error('Invalid repairId.');
  if (typeof m.title !== 'string' || !m.title.trim() || m.title.length > 120) throw new Error('Repair title must contain 1–120 characters.');
  if (typeof m.description !== 'string' || m.description.length > 1200) throw new Error('Repair description must be text no longer than 1200 characters.');
  if (typeof m.createdAt !== 'string' || !Number.isFinite(Date.parse(m.createdAt))) throw new Error('Repair createdAt must be an ISO-compatible timestamp.');
  if (m.sourceBuild !== undefined && (typeof m.sourceBuild !== 'string' || m.sourceBuild.length > 80)) throw new Error('Invalid sourceBuild metadata.');
  if (m.target.screenshotId !== undefined && (typeof m.target.screenshotId !== 'string' || m.target.screenshotId.length > 96)) throw new Error('Invalid screenshot reference. Do not embed the screenshot itself in a repair package.');
  if (!Array.isArray(m.fixes) || m.fixes.length < 1 || m.fixes.length > REPAIR_MAX_FIXES) throw new Error(`A repair must contain between 1 and ${REPAIR_MAX_FIXES} fixes.`);
  if (Object.keys(m).some(key => !['formatVersion', 'kind', 'repairId', 'title', 'description', 'createdAt', 'sourceBuild', 'target', 'fixes', 'signature'].includes(key))) throw new Error('Repair manifest contains an unknown field.');
  if (Object.keys(m.target).some(key => !['appId', 'runtimeApi', 'minimumAppVersion', 'screenshotId'].includes(key))) throw new Error('Repair target contains an unsupported field.');
  const ids = new Set();
  for (const fix of m.fixes) {
    if (!fix || typeof fix !== 'object' || Array.isArray(fix)) throw new Error('Every repair fix must be an object.');
    if (Object.keys(fix).some(key => !['id', 'op', 'scope', 'token', 'value', 'reason'].includes(key))) throw new Error('Repair fix contains an unknown field.');
    if (typeof fix.id !== 'string' || !SAFE_ID.test(fix.id) || ids.has(fix.id)) throw new Error('Repair fix IDs must be unique safe identifiers.');
    ids.add(fix.id);
    if (fix.op !== 'SET_UI_TOKEN') throw new Error(`Unsupported repair operation: ${fix.op}`);
    const scope = REPAIR_SCOPES[fix.scope];
    if (!scope) throw new Error(`Unknown repair scope: ${fix.scope}`);
    if (!scope.tokens.includes(fix.token)) throw new Error(`Token ${fix.token} is not permitted for scope ${fix.scope}.`);
    validateTokenValue(fix.token, fix.value);
    if (fix.reason !== undefined && (typeof fix.reason !== 'string' || fix.reason.length > 300)) throw new Error('Fix reason must be text no longer than 300 characters.');
  }
  const bytes = Buffer.byteLength(JSON.stringify(pkg), 'utf8');
  if (bytes > REPAIR_MAX_BYTES) throw new Error('Repair package exceeds the 1 MiB limit.');
  return { repairId: m.repairId, title: m.title, description: m.description, fixCount: m.fixes.length, scopes: [...new Set(m.fixes.map(f => f.scope))], tokens: [...new Set(m.fixes.map(f => f.token))], bytes };
}

export function verifySignedRepairPackage(pkg, trustedKeys, options) {
  const validated = validateUnsignedRepairPackage(pkg, options);
  const sig = pkg.manifest.signature;
  if (!sig || sig.algorithm !== 'Ed25519' || typeof sig.keyId !== 'string' || !SAFE_ID.test(sig.keyId) || typeof sig.value !== 'string' || !/^[A-Za-z0-9+/]{86}==$/.test(sig.value)) throw new Error('Repair package has no supported Ed25519 signature.');
  const entry = trustedKeys?.keys?.find(key => key.keyId === sig.keyId && key.algorithm === 'Ed25519');
  if (!entry || entry.revokedAt || entry.status === 'revoked') throw new Error(`Repair signer is not trusted or has been revoked: ${sig.keyId}`);
  let publicKey;
  if (typeof entry.publicKeyPem === 'string' && entry.publicKeyPem.includes('BEGIN PUBLIC KEY')) publicKey = createPublicKey(entry.publicKeyPem);
  else if (typeof entry.publicKey === 'string') {
    const raw = Buffer.from(entry.publicKey, 'base64');
    if (raw.length !== 32) throw new Error('Trusted Ed25519 raw public keys must decode to exactly 32 bytes.');
    publicKey = createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), raw]), format: 'der', type: 'spki' });
  } else throw new Error('Trusted key entry must contain publicKey (raw base64) or publicKeyPem.');
  if (!cryptoVerify(null, Buffer.from(repairSigningPayload(pkg), 'utf8'), publicKey, Buffer.from(sig.value, 'base64'))) throw new Error('Ed25519 repair signature verification failed.');
  return { ...validated, signer: sig.keyId };
}
