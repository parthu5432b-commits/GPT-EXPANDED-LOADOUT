const SAFE_ID = /^[a-z][a-z0-9.-]{2,95}$/;
const SEMVER = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;
function safeEntry(value) { return typeof value === 'string' && value.startsWith('www/') && !value.includes('..') && !value.includes('\\') && /\.(?:js|mjs)$/.test(value); }

export function validateModuleRegistry(registry, manifests, { runtimeApi = registry?.runtimeApi } = {}) {
  if (!registry || registry.schemaVersion !== 2 || registry.ownerControlled !== true || registry.publicMarketplace !== false || !Array.isArray(registry.modules)) throw new Error('Invalid private first-party module registry header.');
  if (!Array.isArray(manifests)) throw new Error('Module manifests must be supplied as an array.');
  const rows = new Map(), declared = new Map(), services = new Map(), routes = new Map();
  for (const row of registry.modules) {
    if (!row || !SAFE_ID.test(String(row.id || '')) || !SEMVER.test(String(row.version || '')) || row.runtimeApi !== runtimeApi || !safeEntry(row.entry) || typeof row.offline !== 'boolean') throw new Error('Invalid module registry row: ' + (row?.id || '(missing)'));
    if (rows.has(row.id)) throw new Error('Duplicate module ID: ' + row.id);
    if (row.status !== 'feature-module') throw new Error('Only first-party feature modules are currently installable: ' + row.id);
    if (typeof row.route !== 'string' || !/^[a-z][a-z0-9-]{1,63}$/.test(row.route)) throw new Error('Invalid module route: ' + row.id);
    if (routes.has(row.route)) throw new Error('Duplicate module route: ' + row.route);
    routes.set(row.route, row.id);
    if (!Array.isArray(row.services) || !Array.isArray(row.storageRead || []) || !Array.isArray(row.storageWrite || [])) throw new Error('Invalid module capability declaration: ' + row.id);
    for (const service of row.services) {
      if (typeof service !== 'string' || !/^[a-z][A-Za-z0-9.-]{1,95}$/.test(service)) throw new Error('Invalid service declaration: ' + row.id);
      if (services.has(service)) throw new Error('Service is provided by multiple modules: ' + service);
      services.set(service, row.id);
    }
    rows.set(row.id, row);
  }
  for (const manifest of manifests) {
    if (!manifest || !SAFE_ID.test(String(manifest.id || '')) || declared.has(manifest.id)) throw new Error('Invalid or duplicate module manifest.');
    const row = rows.get(manifest.id);
    if (!row) throw new Error('Module manifest is not in the root registry: ' + manifest.id);
    if (manifest.version !== row.version || manifest.runtimeApi !== row.runtimeApi || manifest.route !== row.route || manifest.entry !== row.entry || manifest.offline !== row.offline) throw new Error('Module manifest and registry metadata disagree: ' + manifest.id);
    if (!Array.isArray(manifest.dependencies || []) || !Array.isArray(manifest.servicesProvided || [])) throw new Error('Invalid module dependency/service declarations: ' + manifest.id);
    const a = [...manifest.servicesProvided].sort().join('|'), b = [...row.services].sort().join('|');
    if (a !== b) throw new Error('Module service contract mismatch: ' + manifest.id);
    declared.set(manifest.id, manifest);
  }
  if (declared.size !== rows.size) throw new Error('Every registered feature module must have exactly one module manifest.');
  const order = [], visiting = new Set(), visited = new Set();
  function visit(id) {
    if (visited.has(id)) return;
    if (visiting.has(id)) throw new Error('Module dependency cycle detected: ' + id);
    const manifest = declared.get(id);
    if (!manifest) throw new Error('Missing module manifest/dependency: ' + id);
    visiting.add(id);
    for (const raw of manifest.dependencies || []) {
      const dep = typeof raw === 'string' ? { id: raw } : raw;
      if (!dep || !SAFE_ID.test(String(dep.id || ''))) throw new Error('Invalid dependency declaration in ' + id);
      const depManifest = declared.get(dep.id);
      if (!depManifest) throw new Error(`Module ${id} depends on unregistered module ${dep.id}`);
      if (dep.version && depManifest.version !== dep.version) throw new Error(`Module dependency version mismatch: ${id} requires ${dep.id}@${dep.version}, found ${depManifest.version}`);
      visit(dep.id);
    }
    visiting.delete(id); visited.add(id); order.push(id);
  }
  for (const id of declared.keys()) visit(id);
  return { valid: true, registryId: registry.registryId, moduleCount: rows.size, serviceCount: services.size, orderedModuleIds: order, routes: Object.fromEntries(routes), services: Object.fromEntries(services), offlineModuleCount: [...rows.values()].filter(row => row.offline).length };
}
