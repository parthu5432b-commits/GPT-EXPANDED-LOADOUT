import { createHash } from 'node:crypto';

export const LTL_OPERATIONS = Object.freeze([
  'ADD', 'REPLACE', 'PATCH', 'PATCH_SOURCE', 'REMOVE', 'MOVE', 'RENAME',
  'RECONFIGURE', 'REWIRE', 'MIGRATE', 'CHANGE_POLICY', 'INSTALL_DEPENDENCY',
  'REMOVE_DEPENDENCY', 'VALIDATE', 'ACTIVATE'
]);
const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
const DANGEROUS_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

export function isSafeRelativePath(value) {
  if (typeof value !== 'string' || !value || value.length > 240) return false;
  if (value.startsWith('/') || value.includes('\\') || value.includes('\0')) return false;
  if (/^[A-Za-z]:/.test(value)) return false;
  return value.split('/').every(part => part && part !== '.' && part !== '..');
}
export function sha256(value) { return createHash('sha256').update(value).digest('hex'); }
export function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}
const clone = value => structuredClone(value);

export function parsePointer(pointer) {
  if (typeof pointer !== 'string' || !pointer.startsWith('/') || pointer === '/') throw new Error('JSON pointer must identify a non-root path and start with /.');
  const parts = pointer.slice(1).split('/').map(part => {
    if (/~(?![01])/.test(part)) throw new Error('Invalid JSON pointer escape.');
    return part.replace(/~1/g, '/').replace(/~0/g, '~');
  });
  if (parts.some(part => DANGEROUS_KEYS.has(part))) throw new Error('Unsafe JSON pointer key rejected.');
  return parts;
}
function arrayIndex(key, length, allowEnd = false) {
  if (!/^(0|[1-9]\d*)$/.test(String(key))) throw new Error(`Invalid array index: ${key}`);
  const n = Number(key);
  if (!Number.isSafeInteger(n) || n < 0 || n > length || (!allowEnd && n === length)) throw new Error(`Array index out of range: ${key}`);
  return n;
}
function locate(root, pointer) {
  const parts = parsePointer(pointer); let node = root;
  for (const part of parts.slice(0, -1)) {
    if (Array.isArray(node)) node = node[arrayIndex(part, node.length)];
    else if (node && typeof node === 'object' && Object.hasOwn(node, part)) node = node[part];
    else throw new Error(`Path does not exist: ${pointer}`);
  }
  if (!node || typeof node !== 'object') throw new Error(`Parent is not an object/array: ${pointer}`);
  return { node, key: parts.at(-1) };
}
function has(node, key) { return Array.isArray(node) ? /^(0|[1-9]\d*)$/.test(String(key)) && Number(key) < node.length : Object.hasOwn(node, key); }
function readPointer(root, pointer) {
  const { node, key } = locate(root, pointer);
  if (Array.isArray(node)) return node[arrayIndex(key, node.length)];
  if (!Object.hasOwn(node, key)) throw new Error(`Path does not exist: ${pointer}`);
  return node[key];
}
function writePointer(root, pointer, value, mode) {
  const { node, key } = locate(root, pointer);
  if (Array.isArray(node)) {
    if (mode === 'add') node.splice(arrayIndex(key, node.length, true), 0, clone(value));
    else if (mode === 'replace') node[arrayIndex(key, node.length)] = clone(value);
    else throw new Error(`Operation ${mode} is not supported on array paths.`);
    return;
  }
  const exists = Object.hasOwn(node, key);
  if (mode === 'add' && exists) throw new Error(`ADD target already exists: ${pointer}`);
  if (mode === 'replace' && !exists) throw new Error(`REPLACE target does not exist: ${pointer}`);
  node[key] = clone(value);
}
function removePointer(root, pointer) {
  const { node, key } = locate(root, pointer);
  if (Array.isArray(node)) node.splice(arrayIndex(key, node.length), 1);
  else {
    if (!Object.hasOwn(node, key)) throw new Error(`REMOVE target does not exist: ${pointer}`);
    delete node[key];
  }
}
function assertMetadata(op, nested = false) {
  if (!op || typeof op !== 'object' || Array.isArray(op)) throw new Error('LTL operation must be an object.');
  const kind = String(op.op || '').toUpperCase();
  if (!LTL_OPERATIONS.includes(kind)) throw new Error(`Unsupported LTL operation: ${kind || '(missing)'}`);
  if (!SAFE_ID.test(String(op.id || ''))) throw new Error('Every LTL operation needs a unique safe id.');
  if (typeof op.description !== 'string' || !op.description.trim() || op.description.length > 500) throw new Error(`${op.id}: audit description is required (max 500 characters).`);
  if (!['low', 'medium', 'high', 'critical'].includes(String(op.risk || '').toLowerCase())) throw new Error(`${op.id}: risk must be low, medium, high or critical.`);
  if (!Array.isArray(op.dependencies || []) || (op.dependencies || []).some(x => !SAFE_ID.test(String(x)))) throw new Error(`${op.id}: dependencies must be safe operation IDs.`);
  if (!Array.isArray(op.validation || []) || (op.validation || []).some(x => typeof x !== 'string' || !x.trim())) throw new Error(`${op.id}: validation must be an array of named checks.`);
  if (typeof op.failureAction !== 'string' || !op.failureAction.trim()) throw new Error(`${op.id}: failureAction is required.`);
  if (typeof op.recovery !== 'string' || !op.recovery.trim()) throw new Error(`${op.id}: recovery strategy is required.`);
  if (nested && op.dependencies?.length) throw new Error(`${op.id}: nested MIGRATE steps cannot depend on outer operations.`);
  return kind;
}

export function orderLtlOperations(operations) {
  if (!Array.isArray(operations)) throw new Error('LTL transformations must be an array.');
  const byId = new Map();
  for (const op of operations) {
    assertMetadata(op);
    if (byId.has(op.id)) throw new Error(`Duplicate LTL operation ID: ${op.id}`);
    byId.set(op.id, op);
  }
  const ordered = [], visiting = new Set(), visited = new Set();
  function visit(id) {
    if (visited.has(id)) return;
    if (visiting.has(id)) throw new Error(`LTL dependency cycle detected at ${id}.`);
    const op = byId.get(id);
    if (!op) throw new Error(`LTL dependency references missing operation: ${id}`);
    visiting.add(id);
    for (const dependency of op.dependencies || []) visit(dependency);
    visiting.delete(id); visited.add(id); ordered.push(op);
  }
  for (const id of byId.keys()) visit(id);
  return ordered;
}

function checkPrecondition(state, op) {
  if (op.expectedStateSha256) {
    const actual = sha256(stableStringify(state));
    if (actual !== String(op.expectedStateSha256).toLowerCase()) throw new Error(`${op.id}: state precondition hash mismatch.`);
  }
  if (op.precondition?.path) {
    const value = readPointer(state, op.precondition.path);
    if (Object.hasOwn(op.precondition, 'equals') && stableStringify(value) !== stableStringify(op.precondition.equals)) throw new Error(`${op.id}: value precondition failed.`);
    if (op.precondition.sha256 && sha256(stableStringify(value)) !== String(op.precondition.sha256).toLowerCase()) throw new Error(`${op.id}: value hash precondition failed.`);
  }
}
function validateAssertion(state, op) {
  if (!op.assert || typeof op.assert !== 'object' || typeof op.assert.path !== 'string' || !op.assert.path) throw new Error(`${op.id}: VALIDATE requires an assertion object with a JSON Pointer path.`);
  const a = op.assert;
  if (a.path) {
    const value = readPointer(state, a.path);
    if (Object.hasOwn(a, 'equals') && stableStringify(value) !== stableStringify(a.equals)) throw new Error(`${op.id}: VALIDATE equality assertion failed.`);
    if (a.sha256 && sha256(stableStringify(value)) !== String(a.sha256).toLowerCase()) throw new Error(`${op.id}: VALIDATE hash assertion failed.`);
    if (a.type === 'array' && !Array.isArray(value)) throw new Error(`${op.id}: VALIDATE expected an array.`);
    if (a.type === 'object' && (!value || typeof value !== 'object' || Array.isArray(value))) throw new Error(`${op.id}: VALIDATE expected an object.`);
    if (Number.isInteger(a.minLength) && (!Array.isArray(value) || value.length < a.minLength)) throw new Error(`${op.id}: VALIDATE minimum length assertion failed.`);
  } else if (a.path !== undefined) throw new Error(`${op.id}: invalid assertion path.`);
}

export function applyLtlOperation(state, op, stagedFiles = {}) {
  const kind = assertMetadata(op);
  checkPrecondition(state, op);
  if (kind === 'VALIDATE' || kind === 'ACTIVATE') {
    if (kind === 'VALIDATE') validateAssertion(state, op);
    return state;
  }
  if (kind === 'PATCH_SOURCE') {
    if (!isSafeRelativePath(op.file) || /\.(?:m?js|cjs|jsx|ts|tsx|jar|dex|so|class)$/i.test(op.file)) throw new Error('PATCH_SOURCE is limited to non-executable staged text resources.');
    const source = stagedFiles[op.file];
    if (typeof source !== 'string') throw new Error(`PATCH_SOURCE target not found in staged files: ${op.file}`);
    if (sha256(source) !== String(op.expectedSha256 || '').toLowerCase()) throw new Error(`PATCH_SOURCE preimage SHA-256 mismatch: ${op.file}`);
    if (typeof op.anchor !== 'string' || !op.anchor.length || typeof op.replacement !== 'string') throw new Error('PATCH_SOURCE requires anchor and replacement strings.');
    const matches = source.split(op.anchor).length - 1;
    const expected = Number(op.expectedOccurrences ?? 1);
    if (!Number.isInteger(expected) || expected < 1 || matches !== expected) throw new Error(`PATCH_SOURCE expected ${expected} matches; found ${matches}.`);
    const next = source.split(op.anchor).join(op.replacement);
    if (op.resultSha256 && sha256(next) !== String(op.resultSha256).toLowerCase()) throw new Error(`PATCH_SOURCE postimage SHA-256 mismatch: ${op.file}`);
    stagedFiles[op.file] = next;
    return state;
  }
  if (kind === 'MIGRATE') {
    if (!Array.isArray(op.steps) || !op.steps.length || op.steps.length > 100) throw new Error(`${op.id}: MIGRATE requires 1–100 declarative steps.`);
    const ids = new Set();
    for (const step of op.steps) {
      const nestedKind = assertMetadata(step, true);
      if (['MIGRATE', 'ACTIVATE', 'VALIDATE'].includes(nestedKind)) throw new Error(`${op.id}: nested ${nestedKind} is not supported.`);
      if (ids.has(step.id)) throw new Error(`${op.id}: duplicate nested step ID ${step.id}.`);
      ids.add(step.id); applyLtlOperation(state, step, stagedFiles);
    }
    return state;
  }
  if (kind === 'INSTALL_DEPENDENCY' || kind === 'REMOVE_DEPENDENCY') {
    const dependencyId = String(op.dependencyId || '');
    if (!SAFE_ID.test(dependencyId)) throw new Error(`${op.id}: dependencyId is required.`);
    state.dependencies ??= {};
    if (kind === 'INSTALL_DEPENDENCY') {
      if (typeof op.version !== 'string' || !/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(op.version)) throw new Error(`${op.id}: dependency version must be semantic version text.`);
      state.dependencies[dependencyId] = op.version;
    } else {
      if (!Object.hasOwn(state.dependencies, dependencyId)) throw new Error(`${op.id}: dependency is not installed: ${dependencyId}`);
      const declaredDependants = Object.entries(state.moduleDependencies || {}).filter(([, deps]) => Array.isArray(deps) && deps.includes(dependencyId)).map(([moduleId]) => moduleId);
      const claimedDependants = Array.isArray(op.requiredBy) ? op.requiredBy : [];
      const dependants = [...new Set([...declaredDependants, ...claimedDependants])];
      if (dependants.length) throw new Error(`${op.id}: dependency is still required by ${dependants.join(', ')}.`);
      delete state.dependencies[dependencyId];
    }
    return state;
  }
  if (['RECONFIGURE', 'CHANGE_POLICY', 'REWIRE'].includes(kind)) {
    const prefix = kind === 'RECONFIGURE' ? '/settings' : kind === 'CHANGE_POLICY' ? '/policies' : '/dependencies';
    op = { ...op, path: `${prefix}${op.path || ''}` };
  }
  if (['ADD', 'REPLACE', 'PATCH', 'REMOVE', 'RECONFIGURE', 'CHANGE_POLICY', 'REWIRE'].includes(kind)) {
    if (kind === 'REMOVE' || (kind === 'PATCH' && op.action === 'remove')) { removePointer(state, op.path); return state; }
    if (kind === 'PATCH' && op.action === 'append') {
      const target = readPointer(state, op.path);
      if (!Array.isArray(target)) throw new Error(`PATCH append target is not an array: ${op.path}`);
      target.push(clone(op.value)); return state;
    }
    if (kind === 'PATCH' && op.action === 'merge') {
      const target = readPointer(state, op.path);
      if (!target || typeof target !== 'object' || Array.isArray(target) || !op.value || typeof op.value !== 'object' || Array.isArray(op.value)) throw new Error('PATCH merge requires object target and object value.');
      for (const [key, value] of Object.entries(op.value)) { if (DANGEROUS_KEYS.has(key)) throw new Error('Unsafe merge key rejected.'); target[key] = clone(value); }
      return state;
    }
    if (kind === 'PATCH' && op.action !== 'set') throw new Error('PATCH action must be set, append, merge or remove.');
    writePointer(state, op.path, op.value, kind === 'ADD' ? 'add' : kind === 'REPLACE' ? 'replace' : 'set');
    return state;
  }
  if (kind === 'MOVE' || kind === 'RENAME') {
    const value = clone(readPointer(state, op.from));
    if (op.from === op.to || op.to.startsWith(`${op.from}/`)) throw new Error(`${kind} cannot move a value into itself or its descendant.`);
    writePointer(state, op.to, value, 'add');
    removePointer(state, op.from);
    return state;
  }
  throw new Error(`LTL operation is not implemented: ${kind}`);
}

export function applyLtlOperations(initialState, operations, stagedFiles = {}) {
  const ordered = orderLtlOperations(operations);
  const state = clone(initialState), files = clone(stagedFiles);
  const applied = [];
  for (const op of ordered) { applyLtlOperation(state, op, files); applied.push(op.id); }
  return { state, files, applied, impact: summarizeLtlImpact(ordered) };
}
export function summarizeLtlImpact(operations) {
  const counts = {}, risks = new Set(), targets = new Set();
  for (const op of operations) { const kind = String(op.op || '').toUpperCase(); counts[kind] = (counts[kind] || 0) + 1; risks.add(String(op.risk || 'unknown').toLowerCase()); if (op.path) targets.add(op.path); if (op.file) targets.add(op.file); }
  return { operationCount: operations.length, counts, riskLevels: [...risks], targets: [...targets].sort(), manualApprovalRequired: true, executableCodeLoading: false };
}
