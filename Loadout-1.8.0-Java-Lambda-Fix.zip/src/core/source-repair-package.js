import { createPublicKey, verify as cryptoVerify } from 'node:crypto';
import { createHash } from 'node:crypto';
import { stableStringify } from './ltl.js';

export const SOURCE_REPAIR_FORMAT_VERSION = '1.0';
const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
const ALLOWED_ROOTS = ['www/', 'src/', 'native/', 'modules/', 'scripts/', 'tests/', 'documentation/', 'architecture/', 'registry/'];
const ALLOWED_EXTENSIONS = new Set(['.js', '.mjs', '.html', '.css', '.json', '.md', '.txt', '.java', '.xml', '.yml', '.yaml']);
const MAX_OPERATIONS = 32;
const MAX_FILE_BYTES = 2 * 1024 * 1024;
const MAX_PACKAGE_BYTES = 2 * 1024 * 1024;

export function sourceRepairSha256(value) { return createHash('sha256').update(value).digest('hex'); }
export function safeRepairSourcePath(value) {
  if (typeof value !== 'string' || !value || value.length > 240 || value.startsWith('/') || value.includes('\\') || value.includes('\0') || /^[A-Za-z]:/.test(value)) return false;
  if (!ALLOWED_ROOTS.some(root => value.startsWith(root))) return false;
  const parts = value.split('/');
  if (parts.some(part => !part || part === '.' || part === '..')) return false;
  if (parts.some(part => ['node_modules', 'vendor', '.git', 'local-signing', '.loadout-repair'].includes(part))) return false;
  const ext = value.slice(value.lastIndexOf('.')).toLowerCase();
  return ALLOWED_EXTENSIONS.has(ext);
}

export function sourceRepairSigningPayload(pkg) {
  const manifest = structuredClone(pkg.manifest);
  delete manifest.signature;
  return `LOADOUT-LPATCH-${SOURCE_REPAIR_FORMAT_VERSION}\n${stableStringify(manifest)}`;
}

export function validateUnsignedSourceRepairPackage(pkg, { appId = 'app.loadout.jee', runtimeApi = '1.5.0', appVersion = '1.8.0' } = {}) {
  if (!pkg || typeof pkg !== 'object' || Array.isArray(pkg) || Object.keys(pkg).some(key => key !== 'manifest') || !pkg.manifest || typeof pkg.manifest !== 'object') throw new Error('A source repair package must contain only a manifest.');
  const m = pkg.manifest;
  if (m.formatVersion !== SOURCE_REPAIR_FORMAT_VERSION || m.kind !== 'source-repair') throw new Error('Unsupported source repair package format or kind.');
  if (m.target?.appId !== appId || m.target?.runtimeApi !== runtimeApi) throw new Error('Source repair targets another app or runtime API.');
  if (m.target.minimumAppVersion !== undefined && m.target.minimumAppVersion !== appVersion) throw new Error(`Source repair was authored for Loadout ${m.target.minimumAppVersion}; current source is ${appVersion}.`);
  if (Object.keys(m).some(key => !['formatVersion', 'kind', 'repairId', 'title', 'description', 'createdAt', 'target', 'operations', 'signature'].includes(key))) throw new Error('Source repair manifest contains an unknown field.');
  if (Object.keys(m.target || {}).some(key => !['appId', 'runtimeApi', 'minimumAppVersion'].includes(key))) throw new Error('Unsupported source repair target field.');
  if (typeof m.repairId !== 'string' || !SAFE_ID.test(m.repairId)) throw new Error('Invalid source repair ID.');
  if (typeof m.title !== 'string' || !m.title.trim() || m.title.length > 120) throw new Error('Source repair title must contain 1–120 characters.');
  if (typeof m.description !== 'string' || m.description.length > 1200) throw new Error('Source repair description must be text no longer than 1200 characters.');
  if (typeof m.createdAt !== 'string' || !Number.isFinite(Date.parse(m.createdAt))) throw new Error('Source repair createdAt must be a valid timestamp.');
  if (!Array.isArray(m.operations) || m.operations.length < 1 || m.operations.length > MAX_OPERATIONS) throw new Error(`Source repair must contain between 1 and ${MAX_OPERATIONS} operations.`);
  const ids = new Set(), paths = new Set();
  for (const op of m.operations) {
    if (!op || typeof op !== 'object' || Array.isArray(op)) throw new Error('Source repair operation must be an object.');
    if (Object.keys(op).some(key => !['id', 'op', 'file', 'expectedSha256', 'anchor', 'replacement', 'expectedMatches', 'resultSha256', 'reason'].includes(key))) throw new Error('Source repair operation contains an unknown field.');
    if (typeof op.id !== 'string' || !SAFE_ID.test(op.id) || ids.has(op.id)) throw new Error('Source repair operation IDs must be unique safe identifiers.');
    ids.add(op.id);
    if (op.op !== 'PATCH_SOURCE') throw new Error('Only guarded PATCH_SOURCE operations are supported by the source repair port.');
    if (!safeRepairSourcePath(op.file)) throw new Error(`Source path is outside the repair allowlist: ${op.file}`);
    if (paths.has(op.file)) throw new Error(`A source repair may patch a file only once: ${op.file}`);
    paths.add(op.file);
    if (!/^[a-f0-9]{64}$/i.test(String(op.expectedSha256 || ''))) throw new Error(`Missing expected SHA-256 preimage for ${op.file}.`);
    if (typeof op.anchor !== 'string' || !op.anchor.length || op.anchor.length > 40_000 || typeof op.replacement !== 'string' || op.replacement.length > 100_000) throw new Error(`Invalid guarded anchor/replacement for ${op.file}.`);
    if (op.expectedMatches !== 1) throw new Error(`Source repair requires exactly one expected anchor match for ${op.file}.`);
    if (op.resultSha256 !== undefined && !/^[a-f0-9]{64}$/i.test(String(op.resultSha256))) throw new Error(`Invalid result SHA-256 for ${op.file}.`);
    if (op.reason !== undefined && (typeof op.reason !== 'string' || op.reason.length > 300)) throw new Error('Operation reason must be text no longer than 300 characters.');
  }
  const bytes = Buffer.byteLength(JSON.stringify(pkg), 'utf8');
  if (bytes > MAX_PACKAGE_BYTES) throw new Error('Source repair package exceeds the 2 MiB limit.');
  return { repairId: m.repairId, title: m.title, operationCount: m.operations.length, paths: [...paths], bytes };
}

export function verifySignedSourceRepairPackage(pkg, trustedKeys, options) {
  const validated = validateUnsignedSourceRepairPackage(pkg, options);
  const sig = pkg.manifest.signature;
  if (!sig || sig.algorithm !== 'Ed25519' || typeof sig.keyId !== 'string' || !SAFE_ID.test(sig.keyId) || typeof sig.value !== 'string' || !/^[A-Za-z0-9+/]{86}==$/.test(sig.value)) throw new Error('Source repair package has no supported Ed25519 signature.');
  const entry = trustedKeys?.keys?.find(key => key.keyId === sig.keyId && key.algorithm === 'Ed25519');
  if (!entry || entry.revokedAt || entry.status === 'revoked') throw new Error(`Source repair signer is not trusted or has been revoked: ${sig.keyId}`);
  let publicKey;
  if (typeof entry.publicKeyPem === 'string' && entry.publicKeyPem.includes('BEGIN PUBLIC KEY')) publicKey = createPublicKey(entry.publicKeyPem);
  else if (typeof entry.publicKey === 'string') {
    const raw = Buffer.from(entry.publicKey, 'base64');
    if (raw.length !== 32) throw new Error('Trusted Ed25519 raw public keys must decode to exactly 32 bytes.');
    publicKey = createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), raw]), format: 'der', type: 'spki' });
  } else throw new Error('Trusted key entry must contain publicKey or publicKeyPem.');
  if (!cryptoVerify(null, Buffer.from(sourceRepairSigningPayload(pkg), 'utf8'), publicKey, Buffer.from(sig.value, 'base64'))) throw new Error('Source repair Ed25519 signature verification failed.');
  return { ...validated, signer: sig.keyId };
}

export function applySourceRepairOperations(files, operations) {
  const next = new Map(files);
  for (const op of operations) {
    const source = next.get(op.file);
    if (typeof source !== 'string') throw new Error(`Source repair file is missing: ${op.file}`);
    if (sourceRepairSha256(source) !== op.expectedSha256.toLowerCase()) throw new Error(`Preimage SHA-256 mismatch: ${op.file}`);
    const first = source.indexOf(op.anchor);
    const matches = first < 0 ? 0 : source.indexOf(op.anchor, first + op.anchor.length) < 0 ? 1 : 2;
    if (matches !== 1 || op.expectedMatches !== 1) throw new Error(`Expected exactly one anchor match in ${op.file}; found ${matches === 2 ? 'multiple' : matches}.`);
    const updated = source.slice(0, first) + op.replacement + source.slice(first + op.anchor.length);
    if (op.resultSha256 && sourceRepairSha256(updated) !== op.resultSha256.toLowerCase()) throw new Error(`Postimage SHA-256 mismatch: ${op.file}`);
    next.set(op.file, updated);
  }
  return next;
}
