import { createPublicKey, verify as cryptoVerify } from 'node:crypto';
import { isSafeRelativePath, sha256, stableStringify, LTL_OPERATIONS, orderLtlOperations, summarizeLtlImpact } from './ltl.js';

export const PACKAGE_FORMAT_VERSION = '1.0';
export const APP_ID = 'app.loadout.jee';
export const RUNTIME_API = '1.5.0';
const MAX_FILE_BYTES = 4 * 1024 * 1024;
const MAX_TOTAL_BYTES = 8 * 1024 * 1024;
const ALLOWED_RESOURCE_EXTENSIONS = new Set(['.json', '.md', '.txt']);
const SAFE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$/;
const SEMVER = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;

export function signingPayload(pkg) {
  const manifest = structuredClone(pkg.manifest);
  delete manifest.signature;
  const files = Object.fromEntries(Object.keys(pkg.files || {}).sort().map((key) => [key, pkg.files[key]]));
  return `LOADOUT-LUPDATE-${PACKAGE_FORMAT_VERSION}\n${stableStringify({ manifest, files })}`;
}

export function validateUnsignedPackage(pkg, { appId = APP_ID, runtimeApi = RUNTIME_API, installedDependencies = {} } = {}) {
  if (!pkg || typeof pkg !== 'object' || Array.isArray(pkg) || !pkg.manifest || typeof pkg.manifest !== 'object' || !pkg.files || typeof pkg.files !== 'object' || Array.isArray(pkg.files)) throw new Error('Package must contain manifest and files objects.');
  const m = pkg.manifest;
  if (m.formatVersion !== PACKAGE_FORMAT_VERSION || m.kind !== 'data-update') throw new Error('Unsupported update package format or kind.');
  if (m.target?.appId !== appId) throw new Error('Update package targets a different application.');
  if (m.target?.runtimeApi !== runtimeApi) throw new Error('Update package runtime API mismatch.');
  if (typeof m.updateId !== 'string' || !SAFE_ID.test(m.updateId)) throw new Error('Invalid updateId.');
  if (m.target.minimumAppVersion !== undefined && (typeof m.target.minimumAppVersion !== 'string' || !SEMVER.test(m.target.minimumAppVersion))) throw new Error('Invalid minimumAppVersion.');
  if (!Array.isArray(m.transformations) || !Array.isArray(m.resources)) throw new Error('Manifest resources and transformations must be arrays.');
  if (m.resources.length > 500 || m.transformations.length > 500) throw new Error('Package declares too many resources or transformations.');
  const totalFiles = Object.keys(pkg.files);
  if (totalFiles.length !== m.resources.length) throw new Error('Every package file must be declared exactly once in manifest.resources.');
  let total = 0;
  for (const [name, content] of Object.entries(pkg.files)) {
    if (!isSafeRelativePath(name)) throw new Error(`Unsafe resource path: ${name}`);
    const ext = name.slice(name.lastIndexOf('.')).toLowerCase();
    if (!ALLOWED_RESOURCE_EXTENSIONS.has(ext)) throw new Error(`Executable or unsupported resource type rejected: ${name}`);
    if (typeof content !== 'string') throw new Error(`Resource must be UTF-8 text: ${name}`);
    const bytes = Buffer.byteLength(content, 'utf8');
    if (bytes > MAX_FILE_BYTES) throw new Error(`Resource exceeds 4 MiB: ${name}`);
    total += bytes;
  }
  if (total > MAX_TOTAL_BYTES) throw new Error('Package exceeds the 8 MiB expanded text resource limit.');
  const seen = new Set();
  for (const resource of m.resources) {
    if (!resource || !isSafeRelativePath(resource.path) || !Object.hasOwn(pkg.files, resource.path)) throw new Error('Invalid resource descriptor or missing resource file.');
    if (seen.has(resource.path)) throw new Error(`Duplicate resource path: ${resource.path}`);
    seen.add(resource.path);
    if (!/^[a-f0-9]{64}$/i.test(String(resource.sha256 || '')) || sha256(pkg.files[resource.path]) !== resource.sha256.toLowerCase()) throw new Error(`Resource SHA-256 mismatch: ${resource.path}`);
    if (resource.namespace !== undefined && !SAFE_ID.test(resource.namespace)) throw new Error(`Unsafe resource namespace: ${resource.namespace}`);
    if (resource.action !== undefined && !['add', 'replace', 'upsert'].includes(resource.action)) throw new Error(`Unsupported resource action: ${resource.action}`);
  }
  const ordered = orderLtlOperations(m.transformations);
  const dependencies = m.dependencies ?? [];
  if (!Array.isArray(dependencies) || dependencies.length > 100) throw new Error('Manifest dependencies must be an array of at most 100 entries.');
  const depIds = new Set();
  for (const dep of dependencies) {
    if (!dep || !SAFE_ID.test(String(dep.id || '')) || !SEMVER.test(String(dep.version || ''))) throw new Error('Invalid dependency declaration.');
    if (depIds.has(dep.id)) throw new Error(`Duplicate dependency declaration: ${dep.id}`);
    depIds.add(dep.id);
    const installed = installedDependencies[dep.id];
    if (installed && installed !== dep.version) throw new Error(`Dependency version mismatch for ${dep.id}: requires ${dep.version}, installed ${installed}.`);
    if (dep.required !== false && !installed && m.dependenciesRequired === true) throw new Error(`Required dependency is not installed: ${dep.id}@${dep.version}.`);
  }
  if (totalFiles.some(name => !seen.has(name))) throw new Error('Every package file must be declared exactly once in manifest.resources.');
  return { totalBytes: total, resourceCount: seen.size, operationCount: ordered.length, orderedOperationIds: ordered.map(op => op.id), impact: summarizeLtlImpact(ordered) };
}

export function verifySignedPackage(pkg, trustedKeys, options) {
  const validated = validateUnsignedPackage(pkg, options);
  const sig = pkg.manifest.signature;
  if (!sig || sig.algorithm !== 'Ed25519' || typeof sig.keyId !== 'string' || !SAFE_ID.test(sig.keyId) || typeof sig.value !== 'string' || !/^[A-Za-z0-9+/]{86}==$/.test(sig.value)) throw new Error('Package has no supported Ed25519 signature.');
  const entry = trustedKeys?.keys?.find((key) => key.keyId === sig.keyId && key.algorithm === 'Ed25519');
  if (!entry || entry.revokedAt || entry.status === 'revoked') throw new Error(`Signer key is not trusted or has been revoked: ${sig.keyId}`);
  let publicKey;
  if (typeof entry.publicKeyPem === 'string' && entry.publicKeyPem.includes('BEGIN PUBLIC KEY')) {
    publicKey = createPublicKey(entry.publicKeyPem);
  } else if (typeof entry.publicKey === 'string') {
    const raw = Buffer.from(entry.publicKey, 'base64');
    if (raw.length !== 32) throw new Error('Trusted Ed25519 raw public keys must decode to exactly 32 bytes.');
    const spkiPrefix = Buffer.from('302a300506032b6570032100', 'hex');
    publicKey = createPublicKey({ key: Buffer.concat([spkiPrefix, raw]), format: 'der', type: 'spki' });
  } else {
    throw new Error('Trusted key entry must contain publicKey (raw base64) or publicKeyPem.');
  }
  const ok = cryptoVerify(null, Buffer.from(signingPayload(pkg), 'utf8'), publicKey, Buffer.from(sig.value, 'base64'));
  if (!ok) throw new Error('Ed25519 package signature verification failed.');
  return { ...validated, signer: sig.keyId };
}
