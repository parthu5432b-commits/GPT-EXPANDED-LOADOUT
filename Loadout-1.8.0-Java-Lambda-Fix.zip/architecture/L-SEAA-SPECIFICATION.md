> **Current implementation note (Loadout 1.5.5):** This architecture specification was written during the 1.5.0 migration-foundation milestone. Its statement that AI Coach was reserved for Step 0.75.5 is historical; that step is now implemented in 1.5.5 as the seventh registered feature module. The final private registry, complete LTL ZIP transaction UI, Development Port and native extension framework remain future scope. See `documentation/ARCHITECTURE.md` for current status.

# Loadout Self-Evolving Application Architecture (L-SEAA)

**Implementation release:** 1.5.0 · **Runtime/API:** 1.5.0 · **Status:** Third fixed 25-percentage-point milestone (cumulative roadmap target 75%)

This document separates source-implemented capabilities from the long-term architecture. It does not represent future capabilities as finished features.

## Locked product decisions

- Private single-owner Android app; JEE Main only.
- Offline-first local study data; no public SaaS, public marketplace, advertisements or telemetry.
- Preserve existing navigation, formulas, data and navy/purple design language.
- Capacitor remains the presentation/WebView layer; Android-native services handle device-specific services.
- First-party owner-controlled resource updates only; staged changes require manual Commit or Roll Back.
- Executable hot-loading is disabled. Native/host changes use a reviewed new APK and Android package installer.

## Implemented system layers

### 1. Android host and native core

`native/android/LoadoutCorePlugin.java` is injected into the generated Capacitor `MainActivity` by `scripts/build.mjs`. It exposes runtime identity, namespace/key-scoped private file operations, bounded storage, AES-256-GCM credential encryption through Android Keystore, Downloads export and the restricted database bridge.

The structured database bridge is pinned to a single app-private database (`loadout-main`). It accepts only the exact two schema migrations and canonical SHA-256 values compiled into this plugin. Migration DDL runs contiguously inside a SQLite transaction. Query and write shapes are restricted; no general SQL console, arbitrary database path or arbitrary user-supplied DDL is exposed to the WebView.

The native source has not yet been compiled against a real Android SDK/Gradle host in this environment. The bridge remains source-implemented pending CI/device validation.

### 2. Web runtime and service contracts

`www/runtime/loadout-runtime.js` exposes `window.Loadout` version `1.5.0` / runtime API `1.5.0`:

- Native runtime/storage/Keystore/database bridge.
- Storage lifetimes `volatile`, `session`, `module`, `ttl` and `persistent`.
- Event bus and balanced local diagnostics.
- Ed25519 signature verification using an owner-pinned trust store.
- Staged data-only resource transactions with content-addressed immutable storage, stale-state checks, explicit manual commit/rollback and health checks.

No JavaScript, DEX/JAR or native `.so` module is dynamically loaded from an update package. APK build/install is required for native or WebView bootstrap changes.

### 3. Feature runtime and legacy UI compatibility

Six non-AI workspaces have versioned first-party module manifests/runtime entries:

- Command Center: dashboard summary calculations.
- Chapter Map: chapter identity/alias resolution, attempt shaping, mastery/baseline calculations.
- PYQ Intelligence: offline dataset selection and source-preserving filters.
- Test Ledger: C/W/U validation, canonical record creation, duplicate IDs and deletion.
- Forecast Lab: existing regression/calibration/prediction calculations.
- Data & Settings: backup/database lifecycle, verify and sync contracts.

`www/app.js` remains the legacy presentation/state adapter. The modules own real domain service seams and route/lifecycle contracts, but UI and core state ownership are not fully extracted. This avoids a blind rewrite and preserves all current screens. No visual regression test could be performed in this environment.

AI Coach remains the legacy-compatible route and is explicitly reserved for **Step 0.75.5**, immediately before the final step. No AI Coach extraction or redesign is part of 1.5.0.

### 4. Structured database and migration foundation

`www/runtime/database-schema.js` defines the same logical schema v2 for Android SQLite and browser IndexedDB. It contains a canonical JSON `app_state` snapshot, indexed attempts and forecasts, module records, legacy import provenance, recovery snapshots, conflict records and an ordered migration ledger.

Migration 1 (`core-records-v1`) creates core tables. Migration 2 (`recovery-and-indexes-v2`) adds revision/source-kind fields, recovery/conflict tables and query indexes. Android requires an exact two-item manifest with the IDs and SHA-256 digests compiled into the plugin. The schema model validates stable IDs, C+W+U=N, non-negative counts, 19,990 projected-row maximum and 24 MiB canonical-state limit.

The original `loadout-jee-2027-v1` localStorage record remains the active UI source of truth. Startup runs legacy recovery first, then bootstraps the structured mirror. Divergent structured data is archived before reconciliation when its digest is valid. Every database write is read back and checked against the canonical JSON digest and every indexed attempt/forecast record payload. The full migration ledger is verified by version, ID and checksum; the structured record revision is monotonic.

This is an additive mirror, **not** a localStorage-to-database cutover. No old state key is deleted, renamed or demoted in this release. The next source-of-truth migration requires separate owner approval, device tests, a backup/rollback plan and a proven compatibility layer.

### 5. Versioned JEE Main 2027 syllabus profile

The official-source Paper 1 profile records 54 top-level units (14 Mathematics, 20 Physics and 20 Chemistry). It has not yet been fully mapped to legacy chapter IDs/subtopics; profile presence does not imply that every historical label is currently in syllabus.

### 6. Resource-update format and transaction boundary

The UI imports an owner-signed `.lupdate` JSON resource document, not a ZIP archive. It allows bounded UTF-8 `.json`, `.md` and `.txt` resources, checks SHA-256 and Ed25519 signer identity, and rejects executable files. The default trust store is empty. Supported LTL operations are a bounded subset of structured data/resource operations and guarded text patches.

The resource updater is separate from the compiled SQLite schema migrations. An `.lupdate` cannot execute SQL, run source code or change the SQLite schema. Full ZIP packages, general data migrations, dependency impact planning and registry distribution remain future work.

## Data preservation and privacy

- Legacy study state stays at `loadout-jee-2027-v1`; app-private mirror and recovery gate remain active.
- Database bootstrap preserves legacy state and archives valid conflicts; database failures do not become a legacy-state overwrite.
- Backups use schema 3 and SHA-256 corruption detection; snapshots are read-back verified. Hashes are not authenticity signatures, and JSON backups are not encrypted.
- AI Coach chat history remains in the previous release's secured legacy path; this milestone does not change its data semantics.
- No cloud sync, accounts, analytics, telemetry or silent upload is added.

## Planned, not implemented in this release

- Full UI/state extraction for every screen and source-of-truth cutover from localStorage to SQLite/IndexedDB.
- Physical-device validation of native bridge, Android SQLite, Keystore, process death, backup/restore and app update signing.
- Genuine `package-lock.json` generation and `npm ci` conversion (registry DNS was unavailable during this build).
- Full LTL operation catalogue/ZIP `.lupdate` decoder, dependency/impact graph, package migrations, private registry and release revocation.
- Authenticated USB/ADB/Development Port and complete native extension lifecycle.
- AI Coach extraction/completion in Step 0.75.5.
- Question bank/PDF ingestion and viewer.
- Dynamic DEX/JAR/`.so` loading; standard APK updates remain the safer native update path.

## Android boundaries

Native plugin, manifest, permission, package identity, compiled resource, Capacitor and bootstrap changes require a new APK. A same-package in-place update requires the same signing certificate and increasing versionCode. Ordinary Android apps cannot silently install another APK. Dynamic code would run with host app privileges and is not sandboxed by being a separate file; this release does not load it.

See `documentation/ARCHITECTURE.md`, `documentation/DATA_DICTIONARY.md`, `documentation/IMPLEMENTATION_ROADMAP.md`, ADRs and the other architecture documents for current contracts and limitations.
