# Signed update package and LTL contract — Loadout 1.7.0

## Current transport boundary

The current installed runtime imports a UTF-8 JSON document with the `.lupdate` extension. It is **not yet a ZIP archive**. The manifest and exact resource contents are signed together using Ed25519. The app rejects unsigned, untrusted, revoked, mismatched, malformed or tampered packages. The default trust store remains empty and denies all signers.

## Declarative LTL operations

Supported operations: `ADD`, `REPLACE`, `PATCH`, `PATCH_SOURCE`, `REMOVE`, `MOVE`, `RENAME`, `RECONFIGURE`, `REWIRE`, `MIGRATE`, `CHANGE_POLICY`, `INSTALL_DEPENDENCY`, `REMOVE_DEPENDENCY`, `VALIDATE`, and `ACTIVATE` (an intent marker only).

Every operation has a unique ID, description, risk, dependencies, validation labels, failure action and recovery strategy. Operations are topologically ordered. Missing dependencies, cycles, duplicate IDs, malformed metadata and unsafe paths are rejected. Optional preconditions can bind the operation to a state hash or expected JSON Pointer value/hash. `VALIDATE` supports existence/type/equality/hash/minimum-length assertions.

`PATCH_SOURCE` is restricted to staged, non-executable text resources. It requires the exact preimage SHA-256, an anchor and exact match count, and can require a postimage SHA-256. It cannot patch JS/TS, JAR, DEX, class or native library files. `MIGRATE` contains bounded declarative sub-operations only; no JavaScript migration function is evaluated.

JSON Pointer blocks prototype-pollution keys and invalid escapes. Array indices are range-checked. Dependency install/remove is explicit and removal can be blocked by declared dependants.

## Transaction lifecycle

1. Discover and parse the signed package.
2. Validate target app/runtime, resources, hashes, signer, dependencies and operation metadata.
3. Snapshot current resource registry and managed config.
4. Apply LTL only to cloned staged state/resources.
5. Produce an impact report with operation types/counts, risk levels, resources added/replaced, config changes and dependency changes.
6. Persist `awaiting-manual-decision`; active state remains unchanged.
7. Owner chooses Commit or Roll Back. No validation result auto-commits.
8. Commit re-checks snapshot freshness, writes content-addressed immutable resources, verifies read-back, then switches active pointers.
9. Activation failure restores previous pointers. If the process dies during activation, startup recovery detects the durable `activating` state and restores the prior snapshot.
10. Commit/rollback/stage/recovery transitions are journalled locally.

## Explicit limits

- No ZIP archive reader/writer yet.
- No arbitrary executable web-module payload is activated by this engine.
- No DEX/JAR/native `.so` loading.
- No general package-supplied SQL/JavaScript migration code. Existing SQLite migrations remain compiled and checksum-allowlisted in the native APK.
- No remote listener or Development Port network transport.
- Native host, bridge, manifest and APK changes require a new APK.
