# Module ports and service contracts — Loadout 1.8.0

## Contract model

A feature module has a stable ID, semantic version, runtime API compatibility, route/entry, offline declaration, service names it provides, storage namespaces it reads/writes, dependencies and a source manifest. `modules/registry.json` is the canonical repository declaration. `www/runtime/module-registry.js` is the app-bundled projection. `scripts/check-source.mjs` compares both representations and the feature manifests; `registry/catalog.json` and `www/runtime/registry-catalog.json` carry content hashes.

These are in-process logical ports, not network endpoints. Calls are made through the Loadout runtime/feature registry. The private catalog can describe only modules already bundled in the APK; it cannot inject executable modules. New module code therefore ships through a rebuilt APK in this release. Installed UI/resource token repairs use `.lfix`; a future code-module delivery mechanism is not implied.

## Current first-party module map

| Module ID | Workspace | Provided services | Storage reads | Storage writes |
|---|---|---|---|---|
| `loadout.command-center` | Command Center | `dashboard.summary` | `loadout-jee-2027-v1` | `loadout-jee-2027-v1` |
| `loadout.chapter-map` | Chapter Map | `chapter-map.normalize`, `chapter-map.resolve`, `chapter-map.attempts`, `chapter-intelligence.calculateStats`, `chapter-intelligence.calculateBaseline` | `loadout-jee-2027-v1` | `loadout-jee-2027-v1` |
| `loadout.pyq-intelligence` | PYQ Intelligence | `pyq.datasetFor`, `pyq.filterRows` | historical trend JSON, excluded-topic JSON | none declared |
| `loadout.test-ledger` | Test History | `test-ledger.validateCounts`, `test-ledger.createAttempt`, `test-ledger.removeAttempt` | `loadout-jee-2027-v1` | `loadout-jee-2027-v1` |
| `loadout.forecast-engine` | Forecast Lab | `forecast.regressionFor`, `forecast.predict` | `loadout-jee-2027-v1` | `loadout-jee-2027-v1` |
| `loadout.ai-coach` | AI Coach | conversation normalization/search, context construction/selection, provider request construction, Markdown/math rendering | legacy chat keys and Android Keystore AI credential namespace | current chat store, Android Keystore AI credentials, runtime chat mirror |
| `loadout.data-settings` | Data & Settings | backup create/validate/merge, database initialize/bootstrap/verify/sync/status | legacy study state and runtime store | legacy study state, runtime, diagnostics, data packs |

The UI lists the exact full service names and read/write namespace arrays from the canonical registry at runtime. The table above is a readable summary; inspect `modules/registry.json` for exact identifiers and entry paths.

## Current modularity boundary

All seven workspaces have stable module identity and version metadata. Their service seams are not equally deep. Test Ledger, forecast calculations, chapter-intelligence and dashboard analytics have meaningful extracted pure/service logic. Several screen renderers still sit behind the legacy `app.js` compatibility adapter. AI Coach is a larger independently structured feature with local data and provider boundaries. Data & Settings provides route-level adapters over existing backup/database services. The registry and Observatory must not be read as proof that every screen is fully isolated or independently hot-swappable.

Extraction policy:

1. Keep the legacy application as a functioning compatibility module until each screen is fully moved and tested.
2. Give a module a stable ID and explicit route, runtime API, service dependencies and storage namespaces before wiring it.
3. Move one coherent domain/service at a time; do not create empty folders or wrapper-only modules as a substitute for extraction.
4. Preserve legacy storage keys and formulas until a separately tested migration has a data snapshot, read-back verification, recovery plan and explicit owner approval.
5. Add contract, integration, offline and migration tests before changing module ownership.
6. Native service changes stay APK-bound. Dynamic DEX/JAR/`.so` loading remains disabled; a module manifest is not a sandbox.

## Adding a module/service

- Assign a permanent `loadout.<slug>` ID and semantic module version.
- Create `modules/<slug>.module.json` with the same route, entry, runtime API, provided services, dependencies and capability declarations as the root registry.
- Add a real implementation entry below `www/` and register it with the feature runtime.
- Add exact `storageRead` / `storageWrite` namespace declarations to `modules/registry.json` and mirror them in `www/runtime/module-registry.js`.
- Declare service dependencies and test missing service, version mismatch, cycles, route collision and duplicate service names.
- Update the bundled private registry catalog and integrity hashes via `npm run registry:sync`.
- Add service contract, offline and migration tests, then run `npm test`, `npm run check` and `npm run audit:data`.
- If the entry or native service is new code, build and install a new APK; do not assume `.lreg` catalog import can deliver it.
