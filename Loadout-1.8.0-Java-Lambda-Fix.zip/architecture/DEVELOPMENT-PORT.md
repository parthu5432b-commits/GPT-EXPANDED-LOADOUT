# Development Port — Loadout 1.7.0

## Purpose and trust model

The Development Port is the controlled owner path for inspecting the installed app and transferring signed packages from the owner's trusted workstation. This implementation deliberately uses Android Debug Bridge over a USB connection. Pairing is the Android ADB host-key authorization prompt, not a new application-level network service.

The native inbox is enabled only when `ApplicationInfo.FLAG_DEBUGGABLE` is present. It lives under the app-specific external files directory at `Loadout/devport/inbox`. The plugin checks canonical paths, simple package filenames, package size and regular-file status. Supported inbox types are `.lupdate` and `.lreg`; `.lmod` executable packages are rejected.

There is no LAN listener, remote shell, generic command API, remote JavaScript/eval endpoint, or root assumption. Android USB debugging must be enabled by the owner; the workstation must be authorized on-device.

## Implemented host commands

```bash
npm run dev:port -- status [--serial SERIAL]
npm run dev:port -- push ./owner-signed-update.lupdate [--serial SERIAL]
npm run dev:port -- push ./owner-signed-registry.lreg [--serial SERIAL]
npm run dev:port -- list [--serial SERIAL]
npm run dev:port -- remove <filename> [--serial SERIAL]
```

The host CLI:
- Finds connected/unauthorized/offline ADB devices and requires an explicit serial if more than one authorized target exists.
- Reads installed package identity (`app.loadout.jee`, versionName/versionCode, debug flag).
- Refuses to operate against a non-debuggable installation.
- Verifies Ed25519 signature/trust and resource/catalog structure locally before pushing.
- Limits packages to 10 MiB, uses a safe app-specific inbox path and only fixed ADB commands.
- Prints a digest and next in-app staging instruction after successful transfer.

## In-app workflow

Open Data & Settings → Loadout Runtime & Observatory → Development Port.

1. Refresh the inbox.
2. Select **Verify & stage** for a `.lupdate`, or import a `.lreg` from the private registry catalog picker.
3. Inspect the staged impact report, version/compatibility details, resources, storage/database changes, test results and warnings.
4. Explicitly choose Commit or Roll Back. A passing test never auto-commits.

Staged `.lupdate` files are copied into an integrity-checked persistent local package cache. A cached package can be re-read, signature-verified and re-staged without the device being connected to the workstation. Removing an inbox file does not delete its staged/cache copy.

## Local inspection surface

`window.Loadout.port.inspectRuntime()` exposes app/runtime identity, module inventory, loaded feature modules, transaction journal, cached packages, private registry state and native extension inventory to the local Observatory. Diagnostics remain local and omit user prompts, provider secrets and study notes by default.

## Not provided

- Wi-Fi pairing, a network listener, remote shell or remote execution.
- Remote filesystem browsing beyond the Development Port package inbox.
- A remote source editor or generic remote test runner.
- Downloaded executable JavaScript/native module activation.
- A public registry or background network synchronization.

These are deliberate security/platform boundaries, not hidden implementation claims. A non-debuggable production APK has no active Development Port inbox.
