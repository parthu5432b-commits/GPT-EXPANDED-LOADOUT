# Transaction and rollback contract — Loadout 1.7.0

The owner-signed update path uses durable, local transaction records. Package verification and transformation happen against inactive staged copies. The active registry/configuration and personal study records remain untouched until explicit owner approval.

## States

`discovered → verified → planned → staged → awaiting-manual-decision → activating → committed`

Owner rejection transitions to `rolled-back`. An activation error transitions to `activation-failed` after the previous registry/configuration is restored.

## Guardrails

- Ed25519 signer trust and resource SHA-256 are verified before staging.
- Resource paths and resource types are allowlisted; executable payloads are rejected.
- LTL dependencies are ordered; cycles and missing operation IDs are rejected.
- State snapshots and optional preconditions prevent stale transformations.
- The transaction includes an owner-facing impact report.
- Commit is a separate explicit action and re-checks that the base state has not changed.
- Resource content is immutable and content-addressed.
- Rollback is rejected if a later update superseded the transaction.
- A durable `activating` state is written before pointer changes. Startup recovery restores previous pointers if Android kills the process during activation.
- Transaction journal stores state transitions and recovery outcomes without chat content, credentials or personal study notes.

The update path does not change user study records or the database schema. Schema migrations remain separate compiled allowlisted migrations. No package-supplied JavaScript is evaluated.
