# Native extension contract and Android security — Loadout 1.7.0

## Selected architecture

The native extension contract is versioned in `native/extensions.json` and exposed by the compiled-in `LoadoutCorePlugin` inventory API. The current first-party native core is a Capacitor plugin compiled into the Android host APK. Its privilege model is the host application's privilege model; it is not a sandbox.

Lifecycle is the Capacitor plugin/application process lifecycle. A native extension change requires a new APK and a process restart. The app reports the active compiled-in core extension, API version, capabilities and restart policy through the Observatory.

## Explicitly disabled

- Dynamic DEX/JAR loading.
- Dynamic `.so`/native library loading.
- In-place native hot swapping.
- Third-party executable extensions or public plugin marketplace.

Android code loading is not a safe sandbox. Downloaded code would execute with host app privileges. The repository therefore rejects executable module update packages, keeps feature modules bundled in the APK and uses APK replacement for native and executable web-module changes.

## Native service lifecycle / privilege boundary

The compiled core plugin exposes only versioned, purpose-built capabilities: native runtime identity, app-private data/file operations, Keystore-backed credentials, constrained SQLite access, AI HTTPS transport and the debug-only ADB/USB inbox. Calls are allowlisted and do not expose a generic filesystem, shell, reflection, eval or command execution surface.

The `getNativeExtensionInventory` contract reports:
- extension ID/version/API version;
- compiled Capacitor implementation and active state;
- host-application privilege model;
- APK-update/process-restart policy;
- dynamic loading and hot-swap flags as false.

## Platform validation boundary

The native Java template is in the repository and the build script injects its package declaration into the generated Capacitor host. It has not been compiled against a generated Android project or tested on a device in the preparation environment. GitHub Actions must build it; physical-device testing is still required before relying on the extension and Dev Port lifecycle in daily use.
