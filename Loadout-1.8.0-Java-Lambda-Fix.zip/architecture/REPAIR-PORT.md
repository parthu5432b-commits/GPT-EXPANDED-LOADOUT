# Loadout Repair Ports — 1.8.0

## Purpose

The Repair Ports turn a screenshot or diagnostic finding into a reviewable, owner-approved change package. They are deliberately split into two channels because a visual adjustment and a program-code change have different trust, execution and Android-delivery boundaries.

| Package | Where it runs | What it can change | Delivery |
|---|---|---|---|
| `.lfix` | Installed Loadout app | A fixed allowlist of scoped CSS custom-property tokens | In-app stage → owner reviews exact changes → Commit or Roll Back |
| `.lpatch` | Development computer / repository checkout only | Exact text source patches in allowlisted repository files | Host stage → tests/source checks/data audit → explicit commit → APK build when app code changes |

Neither package contains a screenshot. A screenshot is diagnostic evidence supplied separately to the engineer/ChatGPT; the package contains only the intended repair. No screenshot, chat history, study record or API credential is uploaded by the repair system.

## Screenshot-to-repair workflow

1. In Loadout, reproduce the issue and capture a screenshot. In Data & Settings → Runtime & Observatory, use **Export Repair Context**. That JSON contains app/runtime identity, declared module ports, repair state and bounded diagnostics; it excludes study records and AI conversation content.
2. Upload the screenshot and Repair Context JSON to the engineering chat. State what should happen and what actually happens. The repair author inspects the evidence and returns either an unsigned `.lfix.json` draft for a supported visual token change or an unsigned `.lpatch.json` draft for a source-level fix.
3. Sign the draft locally with the owner-held Ed25519 key. The private key must never be uploaded to ChatGPT, GitHub, the app, or this repository ZIP. After key bootstrap, the short form is:

   ```bash
   npm run repair:sign -- ./repair.lfix.json
   # or, for a source repair:
   npm run repair:sign-source -- ./repair.lpatch.json
   ```

   These commands use `local-signing/loadout-update-private.pem` and the key ID recorded in `local-signing/KEY_INFO.txt`, then emit `repair.lfix` or `repair.lpatch` next to the draft. Explicit key path, key ID and output path arguments remain available.
4. For an installed-app visual repair, transfer `.lfix` over the authenticated debug-only USB/ADB ingress:

   ```bash
   npm run dev:port -- push ./repair.lfix
   ```

   In Loadout open Data & Settings → Runtime & Observatory → Visual Repair Port / Development Port. Select **Verify & stage**. Review each scope, token, value, signer and reason. Commit only when the impact is correct; otherwise Roll Back. Local file selection is also supported, so ADB is optional.
5. For a source repair, do not send `.lpatch` to the phone. On the development computer:

   ```bash
   npm run repair:port -- inspect ./repair.lpatch
   npm run repair:port -- stage ./repair.lpatch
   npm run repair:port -- commit REPAIR-ID
   ```

   Stage creates a complete working copy, applies the guarded patch there, and runs `npm test`, `npm run check` and `npm run audit:data`. No live source file is changed at this stage. Commit rechecks live preimages and staged postimages and creates a per-file backup first. A later rollback is available with `npm run repair:port -- rollback REPAIR-ID`, provided no subsequent edit changed those files. Push the committed source to the private repository and allow GitHub Actions to build the APK. Native Kotlin/Java, manifest, permissions, plugin and compiled runtime changes require APK installation through Android's normal user-confirmed installer flow.

## Visual Repair package (`.lfix`)

Format: UTF-8 JSON with one `manifest` object, signed with Ed25519. The format version is `1.0`; package kind is `ui-repair`; runtime API is `1.5.0`; current app release is `1.8.0` / Android versionCode `11`.

A fix must be `SET_UI_TOKEN` and identify exactly one declared module/global scope and one known token. Raw CSS, selectors, HTML, JavaScript, WebAssembly, arbitrary expressions, paths, shell commands and native code are not accepted.

| Token | Permitted values |
|---|---|
| `main-horizontal-padding` | 8–56 px |
| `main-max-width` | 900–1900 px |
| `grid-gap` | 4–36 px |
| `card-padding` | 8–36 px |
| `card-radius` | 6–32 px |
| `font-scale` | 0.88–1.15 (number) |
| `line-height` | 1.25–1.85 (number) |
| `table-min-width` | 280–1200 px |
| `table-overflow` | `auto`, `scroll`, `hidden` |
| `modal-max-height` | 45–95 vh |
| `chat-panel-max-height` | 35–82 vh |
| `chat-input-min-height` | 44–160 px |

The shell scope can set horizontal padding, max width, font scale and line height. Feature scopes are named by stable module IDs: `loadout.command-center`, `loadout.chapter-map`, `loadout.pyq-intelligence`, `loadout.test-ledger`, `loadout.forecast-engine`, `loadout.ai-coach`, and `loadout.data-settings`. The engine applies variables only to the application root or the corresponding route container. A module can use only the tokens assigned to its scope.

A `.lfix` is capped at 1 MiB and 48 fixes. Repair IDs and fix IDs are stable and unique. The app verifies the trusted signer and package signature before staging. Staging is read-only relative to active UI configuration. Commit snapshots the previous token map, verifies write/read-back, applies the styles and journals the result. Interrupted activation/rollback is reconciled at startup. The user must choose Commit; a successful signature or validation does not activate the repair. Rollback restores the previous active token map, subject to the stale-state check.

A `.lfix` is not a generic layout editor. If the screenshot reveals a missing component, incorrect route, broken interaction, faulty data logic, a chart-rendering defect, or a layout property outside the token catalogue, use the Source Repair Port and rebuild the APK rather than trying to smuggle arbitrary CSS or code through the visual package.

## Source Repair package (`.lpatch`)

Format: UTF-8 JSON with one `manifest` object, signed with Ed25519. Package kind is `source-repair`; format version `1.0`; target app ID `app.loadout.jee`; runtime API `1.5.0`; minimum source app version `1.8.0`.

Only `PATCH_SOURCE` is currently accepted. Each operation must supply an allowlisted relative file path, the exact current file SHA-256, one unique anchor that must occur exactly once, a replacement string, `expectedMatches: 1`, a unique operation ID and an explanatory reason. Supported roots are `www/`, `src/`, `native/`, `modules/`, `scripts/`, `tests/`, `documentation/`, `architecture/`, and `registry/`; a narrow text extension allowlist applies. Path traversal, symlinks, dependency/vendor folders, signing material, root files and unknown fields are rejected. One package may contain at most 32 operations and 2 MiB.

The Source Repair Port runs on the developer computer, not in Android. It verifies the signer against the repository trust store. It creates `.loadout-repair/staging/<repairId>/`, patches only that copy, and runs the complete verification suite. A validation failure cannot be committed. Commit is a distinct explicit command and rechecks hashes so changes made after staging cause a refusal. Backups and a journal are kept in `.loadout-repair/`, which is ignored by Git and excluded from source archives. Rollback refuses to overwrite later changes.

The source patcher is not a remote shell or arbitrary script runner. The patch format has no executable migration body, shell command, arbitrary function or postinstall hook. Tests are invoked by the fixed host toolchain only. The normal CI build remains a separate step.

## Trust bootstrap and signing

The source trust store starts empty and fails closed. A fresh owner setup is:

```bash
node scripts/generate-update-keypair.mjs
node scripts/register-update-key.mjs local-signing/loadout-update-public.pem
```

The registration step modifies `www/runtime/trust-store.json`. Review and commit that **public** trust-store change, then build and install a new APK containing it before importing signed repairs. Keep the generated private key offline and backed up securely. Do not put `local-signing/` or any private key in the ZIP, repository, APK, diagnostics, repair context or ChatGPT upload. For an already-installed copy, confirm package signing identity before installing a rebuilt APK; Android may reject a signature mismatch. Never uninstall before exporting and verifying user data.

The signing helpers verify that the key ID is present and not revoked in the repository trust store. The app independently verifies the `.lfix` signature using WebCrypto and the public key it ships. If the device WebView lacks Ed25519 WebCrypto support, the package is rejected safely; no unsigned fallback exists.

## Android device ingress boundary

The Android Development Port is an app-specific USB/ADB inbox enabled only in a debuggable APK. ADB host authorization is the pairing boundary. It accepts `.lupdate`, `.lreg` and `.lfix`; it rejects `.lmod` and `.lpatch`. There is no TCP listener, LAN port, HTTP development server, remote shell, arbitrary filesystem endpoint or remote JavaScript execution. Production/release APK builds disable the ADB package inbox. These controls are intentional even though the project is privately installed.

## Operational guarantees and remaining gates

The repository tests cover package structure, Ed25519 verification, tampering, token/path allowlists, stale and ambiguous source anchors, staging, commit, rollback and interrupted visual-repair recovery. Native Java compilation, Ed25519/WebCrypto support on the target phone, Android ADB transfer, real process-death recovery, physical-device visual regression and APK install-over-existing remain device/CI gates. The source package is not a claim that an APK has already been compiled or installed.
