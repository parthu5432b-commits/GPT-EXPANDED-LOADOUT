# Build instructions — Loadout 1.8.0 repository-root source

The canonical build orchestrator is `scripts/build.mjs`. This release builds directly from this repository root. Upload the contents of the extracted source folder to the private GitHub repository root; keep `.github/` visible/preserved.

## Toolchain

- Node.js 22.x
- Temurin JDK 21
- Capacitor 7.4.3 (exact-pinned direct dependency)
- Android platform 35 / build-tools 35.0.0
- minSdk 23 / targetSdk 35

## Local build

```bash
npm install
npm run registry:sync
npm test
npm run audit:data
npm run check
npm run build:apk
```

`npm run build:apk` requires `ANDROID_HOME` or `ANDROID_SDK_ROOT` with a configured SDK. The build script validates package identity, build instructions, declared web assets, native plugin template, Capacitor output and APK identity. It fails before Gradle if SDK/toolchain requirements are missing.

## GitHub Actions

Workflow: `.github/workflows/build-apk.yml`.

It runs on **push to any branch**, pull request and manual dispatch. Node 22 / JDK 21 / Android SDK 35 are configured. CI installs npm dependencies, regenerates the bundled registry catalog source hashes, executes tests/data/source checks, and performs the real Gradle `assembleDebug` build.

Expected artifact: `Loadout-Android-1.8.0-debug`, containing `dist/Loadout-Android-debug.apk`, its SHA-256 file and `build/BUILD_INFO.json`.

## Signing

Set repository Actions secret `LOADOUT_DEBUG_KEYSTORE_BASE64` to a persistent debug keystore's Base64 content for stable signing between runners. Without it, CI creates a runner-local debug key and signatures may differ between runs. A previously installed APK's signing certificate has not been checked; Android does not permit in-place update when the signing certificate differs.

## npm reproducibility

Direct dependencies in `package.json` are exact-pinned. This bundle does not contain `package-lock.json` because npm registry resolution was unavailable during preparation. CI uses `npm install`, not `npm ci`, so transitive resolution is not fully lockfile-reproducible. Do not describe the build as fully deterministic until a reviewed lockfile is generated on a network-enabled machine and the workflow is updated to use `npm ci`.

KaTeX 0.19.1 assets are copied into `www/vendor/katex/` by `scripts/vendor-katex.mjs` during npm postinstall. They are generated build outputs and are not included as pre-generated binaries in the source ZIP.

## APK status

No APK was compiled during preparation because Android SDK was unavailable here. GitHub Actions is the configured real build route; its successful completion is required before an APK can be claimed as produced.


## Repair-port quick path

- To build an unsigned visual repair draft, use the schema and example in `repairs/`; the app accepts only trusted signed `.lfix` packages.
- After the owner has registered the public trust key and installed an APK that includes it, sign/validate a visual package with `npm run repair:sign -- <draft.lfix.json>` and `npm run repair:validate -- <signed.lfix>`. Import it in Data & Settings → Runtime & Observatory → Visual Repair, or transfer it to the debug ADB inbox with `npm run dev:port -- push <file.lfix>`. Then inspect the pending token changes and manually commit or roll back.
- For code repairs, create a signed `.lpatch` and use `npm run repair:port -- inspect <file.lpatch>`, then `stage`, review the test/check/data-audit report, and separately `commit <repair-id>`. The `.lpatch` port is workstation-only, not an Android inbox format. Run the normal CI/APK build afterward.
- Export Repair Context from the Observatory and pair it with a manually captured screenshot when asking for a repair. It is designed to omit study records, chat text and provider secrets; still inspect exported content before sharing it.

The `repair:sign` helper never needs the private key sent to another party. Keep `local-signing/` outside Git and ZIP bundles. The initial trust store is empty and rejects all packages until you explicitly register your public key and install a trusted build.
