# Loadout JEE — Data Safety & Test Ledger Release 1.4.0

**Private, local-first Android application · JEE Main only · Second fixed 25-point milestone (cumulative roadmap target: 50%)**

This repository is based on the larger `Loadout--main.zip` upload. The smaller `silver-spoon-main.zip` is retained as a historical reference. The original Loadout UI, calculations, datasets and localStorage compatibility keys remain part of the application.

This is a repository-root source bundle. Capacitor packages only `www/` as WebView assets. Workflows, scripts, tests, source archives, architecture documents and the master brief remain outside that web payload.

## This milestone adds

- A startup recovery gate for legacy study data. If local state is valid but differs from the app-private mirror, the differing mirror is archived before the mirror is reconciled. If local state is corrupt, the exact raw localStorage value is quarantined and read back byte-for-byte before mirror recovery. If that cannot be verified, a fail-closed recovery gate prevents writes until the owner exports the raw value and explicitly resumes.
- A tracked app-private mirror write path with queued-write flushing and exact full-record read-back verification. The legacy `loadout-jee-2027-v1` key remains the current UI compatibility source; this is not yet a SQLite migration.
- Verified schema-3 pre-restore snapshots. The complete stored backup is revalidated after write, including its SHA-256 digest and payload equality, before any restore is applied.
- A Data & Settings list of locally stored safety snapshots. Each is revalidated and must be reviewed and explicitly confirmed before it can replace current records. Restoring a snapshot itself creates another pre-restore snapshot.
- Safer AI Coach migration. Chat writes are deferred until credential migration is complete. Legacy API keys are transferred to Android Keystore when available. When Keystore is unavailable, only a minimal, explicit migration-hold record is retained until secure migration can complete; chat history backups remain key-free. Old stores are deleted only after exact history persistence/read-back succeeds and no unresolved credentials remain.
- A versioned Test Ledger feature service (`loadout.test-ledger` v1.1.0) now handles C/W/U validation, canonical test record construction with the existing configured scoring convention, duplicate-ID rejection and attempt removal. UI and record ownership remain in the legacy adapter.
- Compatibility fallback for `Storage.list()` when a native bridge is present but predates `listPrivateFiles`.
- Updated architecture, ADRs, data dictionary, requirement matrix, build docs and automated verification.

## Preserved

The seven existing workspaces and established navy/purple UI remain: Command Center, Chapter Map, PYQ Intelligence, Test History, Forecast Lab, AI Coach, and Data & Settings. The original study state key, chat history, configured scoring formula, forecast and mastery calculations, and historical datasets remain the legacy-compatible source of truth. No UI redesign or JEE Advanced product scope has been introduced.

## Verified in this environment

- `npm test`: **34 tests passed, 0 failed**.
- `npm run check`: **29 JavaScript/MJS files syntax-checked; 14 JSON files parsed; repository/build/module contracts passed**.
- `npm run audit:data`: **550 historical topic rows reconcile to 420 retained + 130 excluded**; the official-source 2027 profile contains 14 Mathematics, 20 Physics and 20 Chemistry top-level Paper 1 headings.
- Repository inventory records per-file sizes and SHA-256 hashes. The generated inventory includes the `native/android/` source plugin; only the root generated `android/` output is excluded.

## Known limitations — not represented as finished

- **No APK was compiled in this environment.** Android SDK/Gradle build-tools are unavailable here. GitHub Actions is configured to generate an APK with a real Gradle build.
- Android Java plugin compilation, Keystore hardware/software operations, real process-death recovery, Downloads export, physical-device restore, install-over-existing and actual-phone visual screenshot regression still require Android/CI/device validation.
- A `package-lock.json` could not be generated because npm registry metadata was not available in this environment. Direct Capacitor versions are exact-pinned, but the transitive npm dependency graph is not fully locked; CI uses `npm install`, not `npm ci`.
- Study state is still legacy JSON in localStorage plus an app-private mirror; no SQLite/Room migration is included.
- Test Ledger is the first extracted service, not a full modularisation of all seven screens.
- The update mechanism remains signed JSON data/resource packs. There is no ZIP `.lupdate` decoder, private registry client/server, full dependency impact graph, schema migration transaction engine, authenticated USB/LAN Development Port, dynamic DEX/JAR loader or native `.so` hot loader.
- Backup SHA-256 detects changes against the embedded digest but is not a signature or authentication mechanism. Exported backups are not encrypted.

## Repository layout

```text
.github/workflows/                 GitHub Actions APK build
architecture/                      L-SEAA, update, security and Development Port specs
documentation/                     Source audit, ADRs, matrix, architecture, data dictionary
exam-profiles/jee-main-2027/       Official-source JEE Main 2027 profile
modules/                            First-party module registry and manifests
native/android/                     Capacitor Java plugin source template
reference/                          Original uploaded ZIPs, provenance only
scripts/                            Build, checks, inventory and signing tools
src/core/                           Testable backup, package and LTL contracts
tests/                              Unit and runtime integration tests
www/                                Installed application web assets only
```

## Build the APK with GitHub Actions

1. Extract this ZIP.
2. Back up the existing private repository before replacing its contents.
3. Upload the **contents** of the extracted folder to the repository root; preserve the hidden `.github/workflows/build-apk.yml` directory.
4. Commit and push. The workflow runs on branch pushes, pull requests and manual dispatch.
5. Open **GitHub → Actions → Loadout Android build** and download `Loadout-Android-1.4.0-debug` from a successful run. The artifact contains the APK, checksum and `build/BUILD_INFO.json`.

The workflow uses Node 22, Temurin JDK 21, Android platform/build-tools 35, executes tests/audits, generates the Capacitor Android host, injects `LoadoutCore`, syncs only `www/`, and runs Gradle `assembleDebug`. The APK is produced by CI, not by this preparation environment.

### Signing identity warning

Set the GitHub Actions secret `LOADOUT_DEBUG_KEYSTORE_BASE64` to a persistent debug keystore to keep the signing certificate stable between builds. Without it, the workflow generates a runner-local key; signatures may differ between runs. The certificate on the APK currently installed on the device has not been verified. Android rejects an in-place update signed with a different certificate. Do not uninstall an existing app to solve a mismatch before exporting and verifying its study-data/chat backup.

## Dependency reproducibility

`package.json` pins direct Capacitor packages exactly to `7.4.3`. The transitive lockfile is not present because the npm registry could not be reached while preparing this bundle. On a network-enabled environment, generate and review `package-lock.json`, commit it, and switch CI from `npm install` to `npm ci` before treating npm resolution as fully reproducible.

## Local checks

```bash
npm install
npm test
npm run check
npm run audit:data
```

For local APK compilation, install Android SDK platform 35 and build-tools 35.0.0, set `ANDROID_HOME` or `ANDROID_SDK_ROOT`, and run `npm run build:apk`.

## Key documentation

- `documentation/MASTER_CODING_AGENT_BRIEF.txt` — exact owner specification.
- `documentation/SOURCE_AUDIT.md` — source selection and source audit, including the 1.4.0 addendum.
- `documentation/REQUIREMENTS_MATRIX.md` — master-brief implementation status.
- `documentation/ARCHITECTURE.md` — current implementation and explicit boundaries.
- `documentation/DATA_DICTIONARY.md` — storage keys, formats and migration policy.
- `documentation/ADR/` — consequential decisions.
- `documentation/RELEASE_CHECKLIST.md` — automated results and Android/device gates.
- `FILE_INVENTORY.tsv` — source-file sizes and SHA-256 hashes.
- `TEST_REPORT.txt` and `LOADOUT_RELEASE_NOTES.txt` — exact results and release scope.

## Privacy

No public accounts, ads, telemetry, analytics SDKs or automatic cloud sync were added. AI Coach prompts are sent only when the owner explicitly sends a provider request. Diagnostics export is local and manually initiated. API keys are excluded from chat history backups and new chat-history writes; Android Keystore is the secure persistence mechanism when the native plugin is available.
