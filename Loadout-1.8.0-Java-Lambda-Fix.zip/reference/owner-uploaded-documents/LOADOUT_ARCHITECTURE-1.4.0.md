# Loadout architecture — 1.4.0

**Project milestone:** second fixed 25 percentage points; cumulative roadmap target 50%  
**App version:** `1.4.0` · **Android versionCode:** `5`  
**Runtime/API:** `1.4.0` · **App ID:** `app.loadout.jee`

## Implemented in this source release

- Preserved the existing Capacitor/WebView app and legacy state key.
- Added private-state reconciliation, byte-for-byte verified divergence archival, verified corrupt raw-state quarantine and a fail-closed recovery write gate with explicit raw export/resume.
- Added exact mirror write/flush/read-back verification entry point and a separately tested recovery-gate component.
- Added schema-3 pre-restore snapshot creation, full payload verification, snapshot listing and owner-reviewed restore.
- Added deferred chat persistence around Keystore migration and a minimal `loadout_chat_keystore_pending_v1` record for legacy credentials that cannot yet be secured.
- Extracted the first functional feature-service seam: `loadout.test-ledger` v1.1.0.
- Added storage namespace listing with fallback for older native plugin versions.

## Architecture principles retained

The existing UI remains in `www/app.js`; feature extraction is incremental. Android-native services are introduced through the Capacitor `LoadoutCore` plugin. The runtime supports data/resource updates only, signed with an owner-trusted Ed25519 key and requiring explicit manual commit/rollback. It does not hot-load executable JS, DEX/JAR or native libraries.

## Not implemented yet

- SQLite/Room migration and a full migration registry.
- Full modularisation of all visible workspaces.
- ZIP update packages, private registry client/server and full dependency-impact planner.
- Authenticated USB/ADB/LAN Development Port.
- Native extension lifecycle beyond the bundled plugin.
- Dynamic DEX/JAR or `.so` loading.

Android native compile/device validation and actual APK compilation were not performed in this environment. See `documentation/ARCHITECTURE.md`, `documentation/RELEASE_CHECKLIST.md` and `TEST_REPORT.txt` for the exact boundaries.
